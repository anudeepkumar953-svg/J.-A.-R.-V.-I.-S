import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { withPayload } from '@payloadcms/next/withPayload';
import { withCmsFacetRewrites } from './route-ownership.mjs';

const dirname = path.dirname(fileURLToPath(import.meta.url));

// Legacy HTML pipeline marker. The old Python ``website_create`` pipeline
// writes the chosen design to ``public/prototype.html``; the Next.js
// pipeline (``website_create_opencode``) overlays real routes onto
// ``src/app/`` and never writes a prototype file. The rewrite below only
// kicks in for legacy apps so the new pipeline's real routes take effect
// without hitting an infinite-loop on Vercel
// (``/`` → ``/prototype.html`` → 404 → ``_not-found`` → rewrite → loop).
const hasPrototypeHtml = fs.existsSync(
  path.join(dirname, 'public', 'prototype.html'),
);

// Content-derived redirects. A generated site often needs per-slug legacy
// redirects (old URLs → new slugs) that can't go in the baked config and aren't
// bulk enough for Vercel's `redirects.csv` channel. The generation/migration
// pipeline may emit a `redirects.json` manifest at the project root — an array of
// `{ source, destination, permanent? }` (Next.js redirect rules). This baked
// loader reads it so the redirects apply in both `next dev` and on Vercel.
// Missing/malformed → no redirects (never a build break).
function loadGeneratedRedirects() {
  const manifestPath = path.join(dirname, 'redirects.json');
  if (!fs.existsSync(manifestPath)) return [];
  try {
    const raw = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    if (!Array.isArray(raw)) return [];
    return raw
      .filter(
        // Next.js throws (not skips) during config normalization for a redirect
        // whose source isn't `/`-prefixed or whose destination is neither
        // `/`-prefixed nor an absolute URL — that would fail `next build`/`dev`
        // startup outright, contradicting the never-a-build-break intent. Drop
        // such entries here so a malformed manifest degrades to no redirects.
        // The source charset check keeps path-to-regexp specials (`(`, `)`,
        // `?`, `+`, `*`, `:param`) out — an unbalanced pattern also throws at
        // normalization, and migration manifests only carry literal paths.
        // Self-redirects (source === destination) would loop; drop them too.
        (r) =>
          r &&
          typeof r.source === 'string' &&
          /^\/[A-Za-z0-9\-._~/%]*$/.test(r.source) &&
          typeof r.destination === 'string' &&
          (r.destination.startsWith('/') ||
            /^https?:\/\//.test(r.destination)) &&
          r.source !== r.destination,
      )
      .map((r) => ({
        source: r.source,
        destination: r.destination,
        // Legacy-URL redirects default to permanent (308); a manifest entry can
        // opt into a temporary (307) redirect with `"permanent": false`.
        permanent: r.permanent !== false,
      }));
  } catch {
    return [];
  }
}

// The editing sandbox runs `next dev` behind the Caddy/preview proxy, served
// to the browser on the public `*.sandbox.kite.ai` host (a port-prefixed e2b
// host masked by the proxy — see backend `e2b_service`). Next sees an internal
// host, so for any cross-origin check the request's `Origin` (the public host)
// won't match Next's own host. Both Next allowlists below must carry this host:
//   - `allowedDevOrigins`        — dev assets / HMR / RSC fetches.
//   - `serverActions.allowedOrigins` — the Server Actions CSRF check. Payload's
//     admin drives its post-save re-render and the live-preview toggle through
//     Server Actions; without this they fail with "Invalid Server Actions
//     request", which silently collapses the Live Preview pane on save (the doc
//     itself still saves over the `/cms-api` REST route). These are SEPARATE
//     allowlists — `allowedDevOrigins` does not cover Server Actions.
const sandboxPreviewOrigins = ['*.sandbox.kite.ai'];

// Customer integrations may use inline scripts and eval, in previews and on
// published sites. Keep that compatibility and align with vercel.ts, which
// publish stamps into existing sites. Editor origins follow script-injector.
const contentSecurityPolicy = [
  "default-src 'self'",
  "script-src 'self' https: 'unsafe-inline' 'unsafe-eval'",
  "style-src 'self' https: 'unsafe-inline'",
  "img-src 'self' https: data: blob:",
  "font-src 'self' https: data:",
  `connect-src 'self' https: wss:${process.env.NODE_ENV === 'development' ? ' ws:' : ''}`,
  "media-src 'self' https: data: blob:",
  "frame-src 'self' https:",
  "worker-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self' https:",
  "frame-ancestors 'self' https://kite.ai https://staging.kite.ai https://*.dp.appsmith.com https://v2.local.com https://v2.local.com:8443 http://localhost:3000 https://kite.appsmith.com https://ship.appsmith.com https://*.kite.localhost",
].join('; ');

/** @type {import('next').NextConfig} */
const nextConfig = {
  // sharp's libvips shared library is opened by the OS dynamic linker through
  // the native binding's rpath, never by a JS `require`, so Next's file tracing
  // cannot see it: it traces the binding `.node` and the package's
  // `index.js`/`package.json` and stops there. The deployed bundle then ships
  // sharp without its library, and because `payload.config.ts` imports sharp at
  // module scope the resulting ERR_DLOPEN_FAILED throws inside Payload init —
  // killing every SSR route of the site, not just image handling.
  //
  // Names one real directory, which requires the hoisted node_modules layout
  // set in `.npmrc`: globbing the library out of pnpm's default store instead
  // pulls in symlinked directories, and Vercel rejects a serverless package
  // that contains those ("invalid deployment package for a Serverless
  // Function") — failing the deploy rather than fixing the site.
  outputFileTracingIncludes: {
    '**/*': ['./node_modules/@img/sharp-libvips-*/lib/**'],
  },
  reactStrictMode: true,
  devIndicators: false,
  // next/image asks the platform CDN for each srcset width instead of Next's
  // own optimiser (which would bill every image through the host). Template
  // components draw images through KiteImage, which does not depend on this.
  // Every width listed is one more derivation the CDN creates per image, so
  // the lists are short; deviceSizes matches RESPONSIVE_WIDTHS in
  // src/lib/kite-image.ts.
  images: {
    loader: 'custom',
    loaderFile: './src/lib/kite-image-loader.ts',
    deviceSizes: [640, 1080, 1320, 1920],
    imageSizes: [64, 128, 256, 384],
  },
  allowedDevOrigins: sandboxPreviewOrigins,
  experimental: {
    serverActions: {
      allowedOrigins: sandboxPreviewOrigins,
    },
    // Firefox reports transferSize=0 for cross-site iframe navigations, which
    // the dev client's debug channel misreads as an HTTP-cache restore and
    // answers with location.reload() — an infinite reload loop inside the
    // preview iframe. The channel only streams React debug info in dev.
    reactDebugChannel: false,
  },

  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'Content-Security-Policy', value: contentSecurityPolicy },
          // The sandbox proxy preserves this policy and removes the marker.
          { key: 'X-Kite-Preview-Framing', value: 'payload' },
          // Customer subdomains are outside this site's control.
          { key: 'Strict-Transport-Security', value: 'max-age=31536000' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          {
            key: 'Permissions-Policy',
            value: 'camera=(), microphone=(), geolocation=()',
          },
        ],
      },
    ];
  },

  // Content-derived per-slug redirects from the generated `redirects.json`
  // manifest (legacy URLs → new slugs). Empty when no manifest is present.
  async redirects() {
    return loadGeneratedRedirects();
  },

  // Legacy: serve the chosen design as the live site. The backend writes
  // ``public/prototype.html`` (with its content JSONs in ``public/content/``)
  // and this rewrite makes any non-API, non-static request fall through to
  // that single static file. The prototype's own client-side router handles
  // route changes by reading ``window.location.pathname``, so multi-page
  // sites work without per-route server handlers.
  async rewrites() {
    // `/favicon.ico` has no file on disk (the icon ships as `favicon.svg`,
    // linked via the frontend layout's `metadata.icons`), so a browser's
    // automatic request for it would fall through the `[[...slug]]` catch-all
    // into a full CMS-backed not-found render on every tab load. Serve the
    // static SVG instead — clients that honor the icon link never ask.
    const faviconFallback = {
      source: '/favicon.ico',
      destination: '/favicon.svg',
    };
    const legacyPrototype = hasPrototypeHtml
      ? [
          {
            source:
              '/((?!api|cms-api|admin|_next|content|images|js|favicon|robots|sitemap|prototype).*)',
            destination: '/prototype.html',
          },
        ]
      : [];
    return [faviconFallback, ...legacyPrototype];
  },
};

// Query strings the cached CMS page cannot see go to its per-request variant,
// except on URLs a hand-coded route serves (see route-ownership.mjs).
export default withCmsFacetRewrites(withPayload(nextConfig));
