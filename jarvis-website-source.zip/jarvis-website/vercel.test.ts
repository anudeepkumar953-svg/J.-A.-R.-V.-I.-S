import assert from 'node:assert/strict';
import { test } from 'node:test';
import { execFileSync } from 'node:child_process';

import { config } from './vercel';

test('only marketing copies are excluded; customer sites and CloudFront remain indexable', () => {
  const indexingRules = config.headers.filter((rule) =>
    rule.headers.some((header) => header.key === 'X-Robots-Tag'),
  );

  // Vercel consumes this shape directly; pin the domain and proxy boundary.
  assert.deepEqual(
    indexingRules,
    ['kite-v3.kite.space', 'kite-marketing-website.kite.space'].map((host) => ({
      source: '/(.*)',
      has: [{ type: 'host', value: { eq: host } }],
      missing: [{ type: 'header', key: 'x-amz-cf-id' }],
      headers: [{ key: 'X-Robots-Tag', value: 'noindex' }],
    })),
  );
});

test('published and locally served pages share the production security policy', () => {
  const nextHeaders = JSON.parse(
    execFileSync(
      process.execPath,
      [
        '--input-type=module',
        '-e',
        "const {default: config} = await import('./next.config.mjs'); console.log(JSON.stringify(await config.headers()));",
      ],
      { env: { ...process.env, NODE_ENV: 'production' }, encoding: 'utf8' },
    ),
  );
  const vercelHeaders = config.headers.find(
    (rule) => rule.source === '/(.*)',
  )?.headers;
  assert.ok(vercelHeaders);
  const securityHeaders = Object.fromEntries(
    vercelHeaders.map(({ key, value }) => [key, value]),
  );
  assert.deepEqual(
    nextHeaders.filter((rule: { headers: { key: string }[] }) =>
      rule.headers.some(({ key }) => key === 'Content-Security-Policy'),
    ),
    [{ source: '/:path*', headers: nextHeaders[0].headers }],
  );
  assert.deepEqual(
    Object.fromEntries(
      nextHeaders[0].headers
        .filter(({ key }: { key: string }) => key !== 'X-Kite-Preview-Framing')
        .map(({ key, value }: { key: string; value: string }) => [key, value]),
    ),
    securityHeaders,
  );
  assert.ok(
    nextHeaders[0].headers.some(
      ({ key, value }: { key: string; value: string }) =>
        key === 'X-Kite-Preview-Framing' && value === 'payload',
    ),
  );
  assert.equal(
    securityHeaders['Strict-Transport-Security'],
    'max-age=31536000',
  );
  const csp = securityHeaders['Content-Security-Policy'];
  assert.ok(csp);
  const directives = new Map(
    csp.split('; ').map((directive) => {
      const [name, ...sources] = directive.split(' ');
      return [name, sources];
    }),
  );
  assert.deepEqual(directives.get('default-src'), ["'self'"]);
  assert.deepEqual(directives.get('object-src'), ["'none'"]);
  assert.deepEqual(directives.get('base-uri'), ["'self'"]);
  assert.ok(csp.includes("'unsafe-eval'"));
  assert.ok(!csp.split(' ').includes('*'));
});

test('Next dev keeps production script permissions and adds its websocket tooling', () => {
  const output = execFileSync(
    process.execPath,
    [
      '--input-type=module',
      '-e',
      "const {default: config} = await import('./next.config.mjs'); console.log(JSON.stringify(await config.headers()));",
    ],
    { env: { ...process.env, NODE_ENV: 'development' }, encoding: 'utf8' },
  );
  const [{ headers }] = JSON.parse(output);
  const csp = headers.find(
    ({ key }: { key: string }) => key === 'Content-Security-Policy',
  ).value;
  assert.ok(csp.includes("'unsafe-eval'"));
  assert.ok(csp.includes(' ws:'));
  const production = config.headers
    .flatMap((rule) => rule.headers)
    .find(({ key }) => key === 'Content-Security-Policy')?.value;
  assert.equal(
    csp.match(/script-src[^;]*/)?.[0],
    production?.match(/script-src[^;]*/)?.[0],
  );
  assert.equal(
    csp.match(/frame-ancestors[^;]*/)?.[0],
    production?.match(/frame-ancestors[^;]*/)?.[0],
  );
});
