// Contract for which URLs next.config.mjs sends to the per-request variant of
// the CMS page (route-ownership.mjs). The per-request rewrite runs before
// dynamic routes, so a URL under a hand-coded route must never be taken by it,
// or that route 404s whenever its URL carries `?tag=`. A URL under the CMS
// catch-all must be taken, or the cached page renders as if the parameter
// were absent.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml). Exits non-zero on
// any failure.
//
// Run locally: pnpm exec tsx route-ownership.test.ts

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { normalizeMetadataRoute } from 'next/dist/lib/metadata/get-metadata-route';
import { getPathMatch } from 'next/dist/shared/lib/router/utils/path-match';
import { safeCompile } from 'next/dist/shared/lib/router/utils/route-match-utils';
import {
  FACET_QUERY_PARAMS,
  facetRewrites,
  scanRouteOwnership,
  withCmsFacetRewrites,
} from './route-ownership.mjs';

let failures = 0;
function check(name: string, condition: boolean, detail = ''): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

// An app directory holding exactly `files` (paths relative to it).
function appDir(files: string[]): string {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'route-ownership-'));
  for (const file of files) {
    fs.mkdirSync(path.join(root, path.dirname(file)), { recursive: true });
    fs.writeFileSync(path.join(root, file), '');
  }
  return root;
}

// The template's own routes.
const STOCK = [
  '(frontend)/layout.tsx',
  '(frontend)/[[...slug]]/page.tsx',
  '(frontend)/kite-facet/[[...slug]]/page.tsx',
  '(frontend)/admin/kite-proposal/[[...slug]]/page.tsx',
  '(payload)/admin/[[...segments]]/page.tsx',
  '(payload)/admin-login/route.ts',
  '(payload)/cms-api/[...slug]/route.ts',
  '(recover)/admin-relogin/page.tsx',
  'api/v1/health/route.ts',
  'cms-revalidate/route.ts',
  'sitemap.ts',
  'robots.ts',
  'globals.css',
];

type Rewrite = {
  source: string;
  destination: string;
  has?: { type: string; key: string }[];
};

// Where the rewrites send `url`: the destination path, or null when none
// applies. Matching and destination building are Next's own.
function rewrite(rules: Rewrite[], url: string): string | null {
  const parsed = new URL(url, 'https://site.test');
  for (const rule of rules) {
    const match = getPathMatch(rule.source, {
      removeUnnamedParams: true,
      strict: true,
    })(parsed.pathname);
    if (!match) continue;
    if (rule.has?.some((h) => !parsed.searchParams.has(h.key))) continue;
    return safeCompile(rule.destination, { validate: false })(match);
  }
  return null;
}

console.log('the stock app directory');
{
  const ownership = scanRouteOwnership(appDir(STOCK));
  check(
    'route groups are flattened; catch-all, kite-facet and files are ignored',
    JSON.stringify(ownership.ownedRoutes) ===
      JSON.stringify([
        'admin-login',
        'admin-relogin',
        'admin/[[...segments]]',
        'admin/kite-proposal/[[...slug]]',
        'api/v1/health',
        'cms-api/[...slug]',
        'cms-revalidate',
        'robots.txt',
        'sitemap.xml',
        'sitemap/[id]',
      ]),
    JSON.stringify(ownership.ownedRoutes),
  );
  check('no dynamic root', ownership.dynamicRoot === null);

  const { beforeFiles, afterFiles } = facetRewrites(ownership);
  const after = (url: string) => rewrite(afterFiles, url);
  const before = (url: string) => rewrite(beforeFiles, url);

  check('`?tag=` on the root page', after('/?tag=x') === '/kite-facet');
  check('`?tag=` on a page', after('/pricing?tag=x') === '/kite-facet/pricing');
  check(
    '`?tag=` on a nested page keeps every segment',
    after('/blog/2026/post?tag=x') === '/kite-facet/blog/2026/post',
  );
  check('an empty `?tag=` counts', after('/blog?tag=') === '/kite-facet/blog');
  check('no query → cached page', after('/pricing') === null);
  check(
    'the AI tab preview route keeps its page',
    after('/admin/kite-proposal/catering?tag=x') === null &&
      after('/admin/kite-proposal/menu/catering?kite-preview=1') === null,
  );
  check(
    'other parameters → cached page',
    after('/pricing?utm_source=x') === null,
  );
  check(
    'the parameters are the tag facet and the AI tab preview',
    FACET_QUERY_PARAMS.join() === 'tag,kite-preview',
  );
  check(
    'a preview URL renders per request, so the editor sees their proposal',
    after('/catering?kite-preview=1') !== null,
  );
  for (const url of [
    '/admin?tag=x',
    '/admin/collections/pages?tag=x',
    '/ADMIN/collections?tag=x',
    '/admin-login?tag=x',
    '/admin-relogin?tag=x',
    '/cms-api/pages?tag=x',
    '/api/v1/health?tag=x',
    '/cms-revalidate?tag=x',
  ]) {
    check(
      `${url} is left to its own route`,
      after(url) === null,
      `${after(url)}`,
    );
  }
  check(
    'a page whose slug only starts with an owned name is still taken',
    after('/administration?tag=x') === '/kite-facet/administration',
  );
  check(
    '`/kite-facet` is not found',
    before('/kite-facet') !== null &&
      before('/kite-facet') === before('/kite-facet/home'),
  );
  check('`/kite-facet/a/b` is not found', before('/kite-facet/a/b') !== null);
  check('a normal page is untouched before files', before('/pricing') === null);
}

console.log('hand-coded routes are owned');
{
  const ownership = scanRouteOwnership(
    appDir([
      ...STOCK,
      '(frontend)/zz-q/page.tsx',
      '(frontend)/zz-d/[id]/page.tsx',
      '(frontend)/(marketing)/llms.txt/route.ts',
      '(frontend)/_components/Thing.tsx',
      '(frontend)/@modal/photos/page.tsx',
    ]),
  );
  const owned = new Set(ownership.ownedRoutes);
  check('a static route', owned.has('zz-q'));
  check('a dynamic route under a static segment', owned.has('zz-d/[id]'));
  check('a nested route group', owned.has('llms.txt'));
  check('a parallel slot is flattened', owned.has('photos'));
  check(
    'a private folder is not a route',
    ![...owned].some((route) => route.includes('_components')),
  );
  const { afterFiles } = facetRewrites(ownership);
  check(
    '/zz-q?tag=a keeps its page',
    rewrite(afterFiles, '/zz-q?tag=a') === null,
  );
  check(
    '/zz-d/7?tag=a keeps its page',
    rewrite(afterFiles, '/zz-d/7?tag=a') === null,
  );
  check(
    'a dot in a segment name is literal',
    rewrite(afterFiles, '/llms.txt?tag=a') === null &&
      rewrite(afterFiles, '/llmsxtxt?tag=a') === '/kite-facet/llmsxtxt',
  );
}

console.log('a hand-coded route nested under a CMS page');
{
  const ownership = scanRouteOwnership(
    appDir([
      ...STOCK,
      '(frontend)/blog/feed.xml/route.ts',
      '(frontend)/shop/[category]/page.tsx',
      '(frontend)/docs/[...path]/page.tsx',
      '(frontend)/help/[[...topic]]/page.tsx',
      '(frontend)/components/Card.tsx',
      '(frontend)/news/[slug]/page.tsx',
      '(frontend)/news/[slug]/opengraph-image.tsx',
    ]),
  );
  const { afterFiles } = facetRewrites(ownership);
  const after = (url: string) => rewrite(afterFiles, url);
  check(
    'the CMS page at /blog keeps its filter',
    after('/blog?tag=x') === '/kite-facet/blog',
    `${after('/blog?tag=x')}`,
  );
  check(
    'a CMS post under /blog keeps its filter',
    after('/blog/first-post?tag=x') === '/kite-facet/blog/first-post',
    `${after('/blog/first-post?tag=x')}`,
  );
  check(
    '/blog/feed.xml is left to its own route',
    after('/blog/feed.xml?tag=x') === null,
  );
  check(
    'a path that only starts with the nested route is still taken',
    after('/blog/feed.xml.old?tag=x') === '/kite-facet/blog/feed.xml.old',
  );
  check(
    'a one-segment dynamic route owns one segment below its parent',
    after('/shop/shoes?tag=x') === null &&
      after('/shop?tag=x') === '/kite-facet/shop' &&
      after('/shop/shoes/red?tag=x') === '/kite-facet/shop/shoes/red',
  );
  check(
    'a catch-all owns every depth below its parent, not the parent',
    after('/docs/a?tag=x') === null &&
      after('/docs/a/b/c?tag=x') === null &&
      after('/docs?tag=x') === '/kite-facet/docs',
  );
  check(
    'an optional catch-all owns its parent too',
    after('/help?tag=x') === null && after('/help/a/b?tag=x') === null,
  );
  // The URL Next itself serves for that file: its route path minus groups.
  const ogRoute = normalizeMetadataRoute(
    '/(frontend)/news/[slug]/opengraph-image',
  );
  const ogName = ogRoute.split('/').at(-2)!;
  check(
    `a metadata image keeps the URL Next serves it at (${ogName})`,
    /^opengraph-image-[0-9a-z]{1,6}$/.test(ogName) &&
      after(`/news/a/${ogName}?tag=x`) === null &&
      after(`/news/a/${ogName}/0?tag=x`) === null &&
      after('/news/a/b?tag=x') === '/kite-facet/news/a/b',
  );
  check(
    'a folder with no page or route owns nothing',
    after('/components?tag=x') === '/kite-facet/components',
  );
}

console.log('metadata files own only the URLs they serve');
{
  const ownership = scanRouteOwnership(
    appDir([...STOCK, 'icon.png', 'manifest.ts']),
  );
  const { afterFiles } = facetRewrites(ownership);
  const after = (url: string) => rewrite(afterFiles, url);
  for (const url of [
    '/sitemap.xml',
    '/sitemap/0.xml',
    '/robots.txt',
    '/icon.png',
    '/manifest.webmanifest',
  ]) {
    check(`${url} keeps its own route`, after(`${url}?tag=x`) === null);
  }
  for (const page of [
    'sitemap-guide',
    'icons',
    'robots-team/news',
    'manifesto',
    'robots.guide',
    'manifest.guide',
    'sitemap.html',
  ]) {
    check(
      `a CMS page at /${page} keeps its filter`,
      after(`/${page}?tag=x`) === `/kite-facet/${page}`,
      `${after(`/${page}?tag=x`)}`,
    );
  }
}

console.log('metadata URLs are the ones Next serves');
{
  // Each file's URL comes from Next itself: its metadata-route normaliser,
  // with groups dropped and a code file's optional id segment filled in.
  const files = [
    'robots.ts',
    'manifest.ts',
    'sitemap.ts',
    '(frontend)/news/sitemap.ts',
    '(frontend)/icon.tsx',
    '(frontend)/news/[slug]/opengraph-image.tsx',
    '(frontend)/apple-icon.png',
    'twitter-image2.jpg',
  ];
  const ownership = scanRouteOwnership(appDir([...STOCK, ...files]));
  const { afterFiles } = facetRewrites(ownership);
  const after = (url: string) => rewrite(afterFiles, url);
  const served = (file: string, id?: string): string => {
    const { dir, name, ext } = path.posix.parse(`/${file}`);
    const code = /^\.[jt]sx?$/.test(ext);
    const route = normalizeMetadataRoute(
      code
        ? `${dir === '/' ? '' : dir}/${name}`
        : `${dir === '/' ? '' : dir}/${name}${ext}`,
    ).replace(/\/route$/, '');
    const isSitemap = name.startsWith('sitemap');
    const url = route
      .split('/')
      .filter((part) => !/^\(.*\)$/.test(part))
      .join('/')
      .replace(/\[slug\]/, 'a');
    if (id) return `${url}/${id}`;
    return isSitemap && code ? `${url}.xml` : url;
  };
  for (const file of files) {
    const url = served(file);
    check(`${file} keeps ${url}`, after(`${url}?tag=x`) === null);
  }
  for (const file of files.filter(
    (f) => /\.tsx$/.test(f) || f.endsWith('sitemap.ts'),
  )) {
    const url = served(file, '0');
    check(`${file} keeps its id URL ${url}`, after(`${url}?tag=x`) === null);
  }
}

console.log('a top-level dynamic route');
{
  const ownership = scanRouteOwnership(
    appDir([...STOCK, '(frontend)/[lang]/page.tsx']),
  );
  check('is reported', ownership.dynamicRoot === '[lang]');
  const { beforeFiles, afterFiles } = facetRewrites(ownership);
  check('no per-request rewrite at all', afterFiles.length === 0);
  check(
    '`/kite-facet` is still not found',
    rewrite(beforeFiles, '/kite-facet') !== null,
  );
}

console.log('a migrated site whose classic page still serves `/`');
{
  const migrated = STOCK.map((file) =>
    file.replace('(frontend)/[[...slug]]/', '(frontend)/[...slug]/'),
  );
  const ownership = scanRouteOwnership(
    appDir([...migrated, '(classic)/page.tsx', '(classic)/about/page.tsx']),
  );
  check(
    'the required CMS catch-all is not a dynamic root',
    ownership.dynamicRoot === null,
    `${ownership.dynamicRoot}`,
  );
  const { afterFiles } = facetRewrites(ownership);
  check(
    '`?tag=` on a CMS page is still taken',
    rewrite(afterFiles, '/pricing?tag=x') === '/kite-facet/pricing',
  );
  check(
    'a classic page keeps its URL',
    rewrite(afterFiles, '/about?tag=x') === null,
  );
  check(
    'the classic home page keeps `/`',
    rewrite(afterFiles, '/?tag=x') === null,
  );

  const classicCatchAll = scanRouteOwnership(
    appDir([...STOCK, '(classic)/[...slug]/page.tsx']),
  );
  check(
    'a hand-coded `[...slug]` elsewhere is still a dynamic root',
    classicCatchAll.dynamicRoot === '[...slug]',
  );
}

console.log('a missing app directory');
{
  const ownership = scanRouteOwnership(path.join(os.tmpdir(), 'no-such-dir-x'));
  check(
    'owns nothing',
    ownership.ownedRoutes.length === 0 && ownership.dynamicRoot === null,
  );
  const { afterFiles } = facetRewrites(ownership);
  check(
    'still rewrites `?tag=`',
    rewrite(afterFiles, '/a?tag=x') === '/kite-facet/a',
  );
}

// A site that keeps its own next.config wraps it with withCmsFacetRewrites;
// its own rewrites must survive in every shape Next accepts.
type Phases = {
  beforeFiles: Rewrite[];
  afterFiles: Rewrite[];
  fallback: Rewrite[];
};
type Config = { rewrites?: () => Promise<Rewrite[] | Partial<Phases>> };
async function phasesOf(config: Config | (() => Promise<Config>)) {
  const resolved = typeof config === 'function' ? await config() : config;
  return (await resolved.rewrites!()) as Phases;
}

async function wrappedConfigs(): Promise<void> {
  console.log('a site config wrapped with withCmsFacetRewrites');
  const dir = appDir([...STOCK, '(site)/about/page.tsx']);
  const own: Rewrite = { source: '/old', destination: '/new' };
  const early: Rewrite = { source: '/early', destination: '/e' };
  const late: Rewrite = { source: '/late', destination: '/l' };

  const none = await phasesOf(withCmsFacetRewrites({}, dir) as Config);
  check(
    'a config with no rewrites gets the facet rewrites',
    rewrite(none.afterFiles, '/pricing?tag=x') === '/kite-facet/pricing' &&
      rewrite(none.beforeFiles, '/kite-facet') !== null,
  );
  check(
    'and its hand-coded pages are scanned',
    rewrite(none.afterFiles, '/about?tag=x') === null,
  );

  const list = await phasesOf(
    withCmsFacetRewrites({ rewrites: async () => [own] }, dir) as Config,
  );
  check(
    'a plain rewrite list runs first, after files',
    list.afterFiles[0] === own &&
      rewrite(list.afterFiles, '/pricing?tag=x') === '/kite-facet/pricing',
  );

  const phased = await phasesOf(
    withCmsFacetRewrites(
      {
        rewrites: async () => ({
          beforeFiles: [early],
          afterFiles: [own],
          fallback: [late],
        }),
      },
      dir,
    ) as Config,
  );
  check(
    'each phase keeps the site rewrites',
    phased.beforeFiles.includes(early) &&
      phased.afterFiles[0] === own &&
      phased.fallback.length === 1 &&
      phased.fallback[0] === late,
  );

  const fromFunction = await phasesOf(
    withCmsFacetRewrites(
      async () => ({ rewrites: async () => [own] }),
      dir,
    ) as () => Promise<Config>,
  );
  check(
    'a config function is wrapped too',
    fromFunction.afterFiles[0] === own &&
      rewrite(fromFunction.afterFiles, '/a?tag=x') === '/kite-facet/a',
  );

  const once = withCmsFacetRewrites({ rewrites: async () => [own] }, dir);
  const twice = await phasesOf(withCmsFacetRewrites(once, dir) as Config);
  check(
    'wrapping a wrapped config adds nothing',
    JSON.stringify(twice) === JSON.stringify(await phasesOf(once as Config)),
  );
  const fnOnce = withCmsFacetRewrites(
    async () => ({ rewrites: async () => [own] }),
    dir,
  );
  const fnTwice = await phasesOf(
    withCmsFacetRewrites(fnOnce, dir) as () => Promise<Config>,
  );
  check(
    'wrapping a wrapped config function adds nothing',
    JSON.stringify(fnTwice) ===
      JSON.stringify(await phasesOf(fnOnce as () => Promise<Config>)),
  );
  check(
    'the mark adds no config key Next would validate',
    Object.keys(once as object).join() === 'rewrites',
  );
}
await wrappedConfigs();

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`);
  process.exit(1);
}
console.log('\nall checks passed');
