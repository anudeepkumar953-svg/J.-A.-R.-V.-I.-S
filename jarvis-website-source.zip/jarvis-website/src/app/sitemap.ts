import type { MetadataRoute } from 'next';
import { sitemapEntries } from '../lib/sitemap-entries';
import { readSitemapSource } from '../lib/sitemap-source';
import { getBaseUrl } from '../lib/site-url';

// Next.js serves this at `/sitemap.xml`: every published, indexable `Pages`
// doc plus every published, indexable item of each generation-driven content
// collection (blog posts, podcasts, …), so search engines see CMS content
// without a rebuild.
//
// The Payload queries live in `lib/sitemap-source.ts`. It caches their result
// under the CMS content tag, so a repeat request reads nothing from the
// database and a content save refreshes it at once. A read that could not
// reach the database, or lost the pages, is not cached. The route itself stays
// per-request, so no build-time copy of this file's output is ever served.
//
// Membership — reservation, the shared indexability rule, and the
// no-documents fallback — lives in the pure `sitemapEntries`
// (lib/sitemap-entries.ts). Routes that are not CMS documents belong in a
// separate list concatenated with its result.
export const dynamic = 'force-dynamic';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = getBaseUrl();
  const { indexablePages, noindexPageSlugs, collectionItems } =
    await readSitemapSource();

  return sitemapEntries({
    baseUrl,
    indexablePages,
    noindexPageSlugs,
    collectionItems,
  });
}
