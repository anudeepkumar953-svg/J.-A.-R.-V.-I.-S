import type { Metadata } from 'next';
import { headers } from 'next/headers';
import { notFound } from 'next/navigation';
import { getPayload } from 'payload';
import config from '@payload-config';
import { RenderBlocks } from '@/components/blocks/RenderBlocks';
import { findPreviewPageForEditor, previewSlug } from '@/lib/proposal-preview';
import { RelatedPagesNav } from '@/payload/RelatedPagesNav';

// The AI tab's preview of a page Kite wrote (or one already added), for a
// signed-in editor only; everyone else gets a 404. It sits in `(frontend)`, so
// the site's own layout wraps it with the site's header, footer and styles.
//
// It ships with the Payload layer, so it imports nothing from the site except
// RenderBlocks (the related-page links under the sections are the layer's own), whose `blocks` and `searchParams` props every site the layer
// sync accepts has: the preview then works on sites whose own catch-all never
// reaches the per-request route. It lives under `/admin`, which the Payload
// admin's catch-all already owns on every site, so it never takes the address
// of a public page.
export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  robots: { index: false, follow: false },
};

type Args = {
  params: Promise<{ slug?: string[] }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export default async function ProposalPreviewPage({
  params,
  searchParams,
}: Args) {
  const page = await findPreviewPageForEditor(
    await getPayload({ config }),
    await headers(),
    previewSlug((await params).slug),
  );
  if (!page) notFound();
  return (
    <main data-payload-route={page.slug === 'home' ? '/' : `/${page.slug}`}>
      <RenderBlocks blocks={page.layout} searchParams={await searchParams} />
      <RelatedPagesNav page={page} />
    </main>
  );
}
