import type { Metadata } from 'next';
import {
  CatchAllPage,
  type CatchAllParams,
  type SearchParams,
  catchAllMetadata,
} from '../../../../lib/catch-all-route';

// Per-request variant of the CMS catch-all (`../../[[...slug]]/page.tsx`) for
// a URL carrying a query parameter a block reads (CollectionList's `?tag=`),
// so the block sees it. Reached only through the next.config.mjs rewrite
// (parameters listed in route-ownership.mjs), which keeps the public URL; a
// direct `/kite-facet` request is not found.
export const dynamic = 'force-dynamic';

type Args = {
  params: CatchAllParams;
  searchParams: Promise<SearchParams>;
};

export function generateMetadata({ params }: Args): Promise<Metadata> {
  return catchAllMetadata(params);
}

export default async function FacetPage({ params, searchParams }: Args) {
  return <CatchAllPage params={params} searchParams={await searchParams} />;
}
