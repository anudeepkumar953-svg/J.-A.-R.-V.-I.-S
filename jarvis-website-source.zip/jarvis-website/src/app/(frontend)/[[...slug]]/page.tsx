import type { Metadata } from 'next';
import {
  CatchAllPage,
  type CatchAllParams,
  catchAllMetadata,
} from '../../../lib/catch-all-route';
import { getSiteSettings } from '../../../lib/site-settings';

// The CMS route: every URL without a hand-coded route renders its `Pages` doc
// or content item here (lookup and render in src/lib/catch-all-route.tsx).
//
// Rendered on first request, never at build (the build has no database), then
// served from cache and the CDN. A CMS save expires it at once through the
// content tags (src/payload/revalidate.ts); a write that sends no signal shows
// within `revalidate` seconds. Request-time APIs read empty here: a URL with a
// query parameter a block reads is rewritten by next.config.mjs to the
// per-request variant under `kite-facet/` (see route-ownership.mjs).
export const dynamic = 'force-static';
export const revalidate = 30;

export function generateStaticParams(): { slug?: string[] }[] {
  return [];
}

type Args = { params: CatchAllParams };

export function generateMetadata({ params }: Args): Promise<Metadata> {
  return catchAllMetadata(params);
}

export default async function Page({ params }: Args) {
  // A failed site-settings read makes the layout render without header and
  // footer, and that copy would be cached for every visitor. Throwing here
  // caches nothing instead: a timed refresh keeps the last good copy, and a
  // request with no copy to fall back on fails and is retried by the next
  // one. Not in dev, where nothing is cached.
  if (process.env.NODE_ENV === 'production') await getSiteSettings();
  return <CatchAllPage params={params} />;
}
