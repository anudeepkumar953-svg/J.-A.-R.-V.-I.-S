import { ImageResponse } from 'next/og';
import { getSiteSettings } from '../../../lib/site-settings';
import { ogCardContent } from '../../../lib/site-seo';

// The share image a page falls back to when neither it nor the site settings
// name one: the brand name and tagline on the brand color, drawn from the site
// settings (`ogCardContent`). Pages link it with a `?v=` that changes with
// what it shows, so a cached copy is never stale for the URL that asked.
//
// Rendered on request, never at build (the build has no database), and cached
// by the CDN. Uses Next's bundled `next/og`: no dependency of its own.
export async function GET() {
  let card = null;
  try {
    card = ogCardContent(await getSiteSettings());
  } catch {
    card = null;
  }
  // No brand to draw: no image, and nothing cached, so the next request
  // retries once the settings read works again.
  if (!card) {
    return new Response(null, {
      status: 404,
      headers: { 'Cache-Control': 'no-store' },
    });
  }
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          padding: '80px 96px',
          background: card.background,
          color: card.foreground,
        }}
      >
        <div
          style={{
            width: 96,
            height: 8,
            marginBottom: 40,
            background: card.accent,
          }}
        />
        <div style={{ fontSize: 88, lineHeight: 1.1 }}>{card.brand}</div>
        {card.tagline ? (
          <div
            style={{
              marginTop: 28,
              fontSize: 40,
              lineHeight: 1.3,
              opacity: 0.85,
            }}
          >
            {card.tagline}
          </div>
        ) : null}
      </div>
    ),
    {
      width: 1200,
      height: 630,
      headers: {
        'Cache-Control':
          'public, max-age=3600, s-maxage=86400, stale-while-revalidate=604800',
      },
    },
  );
}
