import { getPayload } from 'payload';
import config from '@payload-config';
import {
  CMS_CONTENT_TAG,
  SITE_SETTINGS_TAG,
  cmsCached,
} from '../../../lib/cms-cache';
import { getBaseUrl } from '../../../lib/site-url';
import { readLlmsTxt } from '../../../payload/llms-txt';

export const dynamic = 'force-dynamic';

const read = cmsCached(
  async () => readLlmsTxt(await getPayload({ config }), getBaseUrl()),
  ['llms-txt', getBaseUrl()],
  [CMS_CONTENT_TAG, SITE_SETTINGS_TAG],
);

export async function GET(): Promise<Response> {
  try {
    return new Response(await read(), {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    console.error('[llms.txt] CMS read failed', error);
    return new Response('Site information is temporarily unavailable.\n', {
      status: 503,
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        'Cache-Control': 'no-store',
        'Retry-After': '30',
      },
    });
  }
}
