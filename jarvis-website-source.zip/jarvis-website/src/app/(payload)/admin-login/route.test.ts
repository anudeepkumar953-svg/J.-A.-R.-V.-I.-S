// Theme-seed contract for the platform auto-login handoff. The Content tab's
// embedded admin is a separate document; `/admin-login?theme=` is the ONE
// request it makes before its first paint, so this route turning that param
// into Payload's own `payload-theme` cookie is what stops the admin from
// flashing light under a dark platform. The cookie must also carry the
// cross-site attributes an always-embedded document needs, and must NOT be
// httpOnly (Payload's client ThemeProvider reads it back). The template ships
// no unit-test runner, so this is a self-contained tsx script (run in CI by
// nextjs-template-code-quality.yml). Exits non-zero on any failure.
//
// Run locally: pnpm exec tsx "src/app/(payload)/admin-login/route.test.ts"

import crypto from 'node:crypto';

// The route reads both at request time; set them before importing it.
const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
process.env.PLATFORM_LOGIN_PUBLIC_KEY = Buffer.from(
  publicKey.export({ format: 'jwk' }).x as string,
  'base64url',
).toString('base64');
process.env.PAYLOAD_SECRET = 'a'.repeat(64);

const { GET } = await import('./route');

// Payload's cookie is `${config.cookiePrefix}-theme`; the template leaves the
// prefix at its default. Pinned literally on purpose — it is Payload's name,
// not ours, and a renamed constant in the route must still produce it.
const PAYLOAD_THEME_COOKIE = 'payload-theme';

function mintPlatformToken(ttlSeconds = 60): string {
  const payload = `app-123.${Math.floor(Date.now() / 1000) + ttlSeconds}`;
  const sig = crypto.sign(null, Buffer.from(payload), privateKey);
  return `${Buffer.from(payload).toString('base64url')}.${sig.toString('base64url')}`;
}

async function login(query: Record<string, string>) {
  const url = new URL('https://sandbox.test/admin-login');
  for (const [k, v] of Object.entries(query)) url.searchParams.set(k, v);
  return GET(new Request(url));
}

let failures = 0;
function check(name: string, condition: boolean, detail = ''): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

// Valid token + valid theme: the handoff succeeds AND seeds the theme cookie.
{
  const response = await login({ token: mintPlatformToken(), theme: 'dark' });
  check('valid handoff redirects to /admin', response.status === 302);
  check(
    'redirect Location is /admin',
    response.headers.get('location') === '/admin',
  );
  const cookie = response.cookies.get(PAYLOAD_THEME_COOKIE);
  check('theme cookie is set', cookie !== undefined);
  check('theme cookie carries the requested theme', cookie?.value === 'dark');
  check(
    'theme cookie is Secure (rides in the https iframe)',
    cookie?.secure === true,
  );
  check(
    'theme cookie is SameSite=None (cross-site iframe)',
    cookie?.sameSite === 'none',
  );
  check(
    'theme cookie is Partitioned (third-party cookie restrictions)',
    cookie?.partitioned === true,
  );
  check(
    'theme cookie is NOT httpOnly (Payload reads it via document.cookie)',
    cookie?.httpOnly !== true,
  );
  check(
    'theme cookie outlives the session (long maxAge)',
    typeof cookie?.maxAge === 'number' && cookie.maxAge > 24 * 60 * 60,
  );
  check(
    'session cookie is still set alongside it',
    response.cookies.get('kite-cms-session') !== undefined,
  );
}

// Light is the other admitted value.
{
  const response = await login({ token: mintPlatformToken(), theme: 'light' });
  check(
    'light is admitted',
    response.cookies.get(PAYLOAD_THEME_COOKIE)?.value === 'light',
  );
}

// No theme: the cookie is left alone. SessionKeepalive's cookie slide and
// `/admin-relogin` call this route without a theme and must not clobber the
// seeded value.
{
  const response = await login({ token: mintPlatformToken() });
  check('handoff without a theme still succeeds', response.status === 302);
  check(
    'no theme param sets no theme cookie',
    response.cookies.get(PAYLOAD_THEME_COOKIE) === undefined,
  );
}

// Unknown value: dropped, never coerced or forwarded to Payload.
{
  const response = await login({ token: mintPlatformToken(), theme: 'purple' });
  check(
    'an unknown theme sets no theme cookie',
    response.cookies.get(PAYLOAD_THEME_COOKIE) === undefined,
  );
  check(
    'an unknown theme does not fail the handoff',
    response.status === 302 && response.headers.get('location') === '/admin',
  );
}

// Invalid token: the recovery redirect, and no cookies of any kind — the theme
// must not be seeded on a handoff that did not authenticate.
{
  const response = await login({ token: 'not-a-token', theme: 'dark' });
  check(
    'invalid token bounces to /admin-relogin',
    response.status === 302 &&
      (response.headers.get('location') ?? '').startsWith('/admin-relogin'),
  );
  check(
    'invalid token seeds no theme cookie',
    response.cookies.get(PAYLOAD_THEME_COOKIE) === undefined,
  );
  check(
    'invalid token sets no session cookie',
    response.cookies.get('kite-cms-session') === undefined,
  );
}

// Restore contract (KITE-7875). The platform records the view the editor was on
// (LocationSync reports it relative to the admin route) and hands it back as
// `?redirect=`; a reload of the content tab must reopen that view, not the
// dashboard. Only collection and global views are restorable, and the value
// can never point outside the admin route.
{
  const location = async (query: Record<string, string>) =>
    (await login({ token: mintPlatformToken(), ...query })).headers.get(
      'location',
    );
  check(
    'a page document is reopened',
    (await location({ redirect: '/collections/pages/42' })) ===
      '/admin/collections/pages/42',
  );
  check(
    'a collection list is reopened',
    (await location({ redirect: '/collections/pages' })) ===
      '/admin/collections/pages',
  );
  // The create screen is a restorable view too, and not only for reloads: the
  // page-ideas panel generates a page inside a DRAFT, so from Main it asks the
  // platform to make one and reopen this exact view there with the idea
  // carried over. Narrowing the pattern to documents (a numeric or uuid last
  // segment, say) would land that hop on the dashboard and lose the idea.
  check(
    'the create screen is reopened, which is where a page idea lands',
    (await location({ redirect: '/collections/pages/create' })) ===
      '/admin/collections/pages/create',
  );
  check(
    'a global is reopened',
    (await location({ redirect: '/globals/site-settings' })) ===
      '/admin/globals/site-settings',
  );
  check(
    'the dashboard (empty redirect) lands on /admin',
    (await location({ redirect: '' })) === '/admin',
  );
  check(
    "Payload's auth views are not restorable",
    (await location({ redirect: '/login' })) === '/admin',
  );
  check(
    'an absolute URL is not honoured',
    (await location({ redirect: 'https://evil.example/x' })) === '/admin',
  );
  check(
    'a path outside the admin route is not honoured',
    (await location({ redirect: '/cms-api/users' })) === '/admin',
  );
  check(
    'a `..` segment cannot climb out of the admin route',
    (await location({ redirect: '/collections/../../cms-api/users' })) ===
      '/admin',
  );
  // D1-F5: the allow-list must hold for the path the browser will actually
  // resolve, not the raw value — `/collections/../logout` is `/admin/logout`.
  check(
    'a `..` segment cannot disguise an auth view as a collection',
    (await location({ redirect: '/collections/../logout' })) === '/admin',
  );
  check(
    'a harmless `.` segment is normalised away',
    (await location({ redirect: '/collections/./pages/1' })) ===
      '/admin/collections/pages/1',
  );
  check(
    'a value with whitespace is dropped',
    (await location({ redirect: '/collections/pages/1\r\nX: y' })) === '/admin',
  );
}

// The restore target survives the stale-token recovery hop: `/admin-login` →
// `/admin-relogin` → `/admin-login`, the path a reload of a long-backgrounded
// tab takes, must not forget where the editor was.
{
  const response = await login({
    token: 'not-a-token',
    redirect: '/collections/pages/42',
    recovery: '1',
  });
  const target = new URL(
    response.headers.get('location') ?? '',
    'https://sandbox.test',
  );
  check(
    'a stale token forwards the restore target to the recovery page',
    target.pathname === '/admin-relogin' &&
      target.searchParams.get('recovery') === '1' &&
      target.searchParams.get('redirect') === '/collections/pages/42',
  );
  const junk = await login({ token: 'not-a-token', redirect: '/login' });
  check(
    'a non-restorable target is not forwarded to the recovery page',
    new URL(
      junk.headers.get('location') ?? '',
      'https://sandbox.test',
    ).searchParams.get('redirect') === null,
  );
}

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`);
  process.exit(1);
}
console.log('\nadmin-login theme-seed and restore contracts OK');
