import { NextResponse } from 'next/server';
import { parseBridgeTheme } from '@/admin/bridgeProtocol';
import {
  CMS_SESSION_COOKIE,
  CMS_SESSION_TTL_SECONDS,
  mintSessionToken,
  verifyPlatformToken,
} from '@/payload/platform-token';

// Auto-login entry for the platform content tab. The platform mints a
// short-lived signed token and points the content-tab iframe at
// `{previewUrl}/admin-login?token=…`. We verify that ONE-TIME token, then mint a
// longer-lived sandbox-signed SESSION token and drop it as a first-party cookie
// on the sandbox origin (SameSite=None; Secure so it rides inside the cross-site
// iframe). The `platform-token` auth strategy on the Users collection verifies
// that session cookie on every admin request — so the session lives for the
// session TTL without the platform being re-contacted each minute. The handoff
// lands on `?redirect=` (a view the platform saw the editor on) or the dashboard.
export const dynamic = 'force-dynamic';

// Payload's own theme cookie: `${config.cookiePrefix}-theme`, and this template
// leaves `cookiePrefix` at its default. With `admin.theme: 'all'` Payload's
// RootLayout reads it to set `data-theme` on `<html>` before the first paint,
// and its client ThemeProvider reads it again on mount. The platform passes its
// resolved appearance as `?theme=` on this handoff so the admin never paints in
// the wrong theme; later switches arrive live via `src/admin/ThemeSync.tsx`,
// which accepts exactly the same values (`parseBridgeTheme`).
const PAYLOAD_THEME_COOKIE = 'payload-theme';
const PAYLOAD_THEME_COOKIE_MAX_AGE_SECONDS = 365 * 24 * 60 * 60;

// Payload's admin route (`config.routes.admin`, left at its default here).
const ADMIN_ROUTE = '/admin';
// The views a reload may reopen, as `?redirect=` carries them: relative to the
// admin route, a collection list or document, or a global. The platform stores
// what `src/admin/LocationSync.tsx` reported and hands it back verbatim on the
// next handoff; anything else — the dashboard, Payload's auth views, junk —
// lands on the dashboard as before.
const RESTORABLE_VIEW = /^\/(collections|globals)\/[\w\-/]*$/;

// The admin path to land on after a successful handoff. The allow-list is
// applied to the path AFTER URL normalisation, so a `.` or `..` segment can
// neither climb out of the admin route nor smuggle in a view the raw value
// disguised (`/collections/../logout`).
function landingPath(redirect: string | null): string {
  if (!redirect?.startsWith('/')) return ADMIN_ROUTE;
  const { pathname } = new URL(
    `${ADMIN_ROUTE}${redirect}`,
    'http://placeholder',
  );
  const view = pathname.slice(ADMIN_ROUTE.length);
  return pathname.startsWith(`${ADMIN_ROUTE}/`) && RESTORABLE_VIEW.test(view)
    ? pathname
    : ADMIN_ROUTE;
}

export async function GET(request: Request) {
  const url = new URL(request.url);
  const token = url.searchParams.get('token') ?? undefined;
  const theme = parseBridgeTheme(url.searchParams.get('theme'));
  const redirect = url.searchParams.get('redirect');
  const result = verifyPlatformToken(
    token,
    process.env.PLATFORM_LOGIN_PUBLIC_KEY,
  );

  // Exchange the verified one-time token for a session token. Fails closed
  // (null) if PAYLOAD_SECRET is missing/misprovisioned — treat that like an
  // invalid token rather than setting a forgeable cookie.
  const sessionToken = result.valid
    ? mintSessionToken(
        process.env.PAYLOAD_SECRET,
        result.appId ?? '',
        CMS_SESSION_TTL_SECONDS,
      )
    : null;

  if (!result.valid || !token || !sessionToken) {
    // The iframe src freezes a ~60s token, so any later document-level reload of
    // that src re-hits this route with a long-expired token: returning to a
    // long-backgrounded tab whose sandbox paused/resumed, or a preview-host
    // rotation that changes the iframe URL. Without recovery that strands the
    // embedded admin on a dead "Invalid or expired login token" page until a
    // full parent refresh. Hand off to the self-recovering `/admin-relogin`
    // page (a client route that reuses the same CMS-token bridge
    // SessionKeepalive does), forwarding the recovery hop count so it can cap
    // retries — and the restore target, so the view the editor was on survives
    // the recovery hop too. Relative Location for the same reason as the
    // success redirect below.
    const recovery = Number(url.searchParams.get('recovery'));
    const hops = Number.isInteger(recovery) && recovery >= 0 ? recovery : 0;
    const relogin = new URLSearchParams({ recovery: String(hops) });
    if (redirect && landingPath(redirect) !== ADMIN_ROUTE) {
      relogin.set('redirect', redirect);
    }
    return new NextResponse(null, {
      status: 302,
      headers: { Location: `/admin-relogin?${relogin}` },
    });
  }

  // Redirect with a RELATIVE Location so the browser resolves it against the
  // iframe's current origin (https sandbox host). An absolute URL built from
  // `request.url` would carry the internal `http` scheme `next dev` sees behind
  // the Caddy/preview proxy, and the public host only serves https — which the
  // browser refuses (ERR_CONNECTION_REFUSED).
  const response = new NextResponse(null, {
    status: 302,
    headers: { Location: landingPath(redirect) },
  });
  response.cookies.set(CMS_SESSION_COOKIE, sessionToken, {
    httpOnly: true,
    secure: true,
    // SameSite=None is REQUIRED: the admin runs in a cross-site iframe (sandbox
    // origin embedded under the platform), so a Lax/Strict cookie would not be
    // sent. The session token is signed and short-lived; the strategy re-checks
    // its exp on every request.
    sameSite: 'none',
    // CHIPS. `SameSite=None` alone is no longer enough: browsers restricting
    // third-party cookies drop an unpartitioned one in an embedded context, and
    // the admin is ALWAYS embedded. Losing it is silent and looks like nothing
    // at all — Payload bounces to `/admin/login`, which renders an empty page
    // here because the local/JWT strategy is disabled and `platform-token` is
    // the only way in, so there is no form to draw. A blank Content tab is the
    // symptom.
    //
    // Partitioning is also the correct semantics rather than a workaround: this
    // session only ever exists inside the platform's top-level site, so keying
    // it to that partition is what it already meant. Browsers without CHIPS
    // ignore the attribute.
    partitioned: true,
    path: '/',
    // Drop the cookie at the signed token's own expiry — the strategy enforces
    // exp regardless, this just avoids sending a dead cookie.
    maxAge: CMS_SESSION_TTL_SECONDS,
  });
  if (theme) {
    // Same cross-site attributes as the session cookie, for the same reason:
    // the admin only ever lives in the platform's iframe. NOT httpOnly —
    // Payload's client ThemeProvider reads it through `document.cookie`.
    // Omitted from the URL (SessionKeepalive's cookie slide, `/admin-relogin`),
    // the cookie set at the initial handoff is left as it is.
    response.cookies.set(PAYLOAD_THEME_COOKIE, theme, {
      secure: true,
      sameSite: 'none',
      partitioned: true,
      path: '/',
      maxAge: PAYLOAD_THEME_COOKIE_MAX_AGE_SECONDS,
    });
  }
  return response;
}
