import { revalidateTag } from 'next/cache';
import { handleRevalidateRequest } from '../../payload/revalidate-signal';
import { resolveSchemaName } from '../../payload/schema-name';

// Called by the editing sandbox after a Content tab save, so the published site
// refreshes its CMS cache right away instead of after the cache window. Kept
// off /api: a site's domain can route /api/* away from this app.
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

export function POST(request: Request): Promise<Response> {
  return handleRevalidateRequest(request, {
    secret: process.env.PAYLOAD_SECRET,
    schema: resolveSchemaName() ?? '',
    // Same immediate expiry the in-process save hooks use.
    revalidate: (tag) => revalidateTag(tag, { expire: 0 }),
  });
}
