// Contract for the structured data the template generates (structured-data.ts):
// an Organization and a WebSite from the site settings, a BreadcrumbList from
// the documents on the URL path, an FAQPage from the page's FAQ blocks, and a
// typed entry with a modification date and a publisher for each content item.
// It pins the properties Google requires of each rich-result type it uses
// (BreadcrumbList, FAQPage; Article has none required, so its recommended
// ones), that nothing is asserted the settings or the document do not hold,
// and that a page's stored JSON-LD is never duplicated or contradicted.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml). Exits non-zero on
// any failure.
//
// Run locally: pnpm exec tsx src/lib/structured-data.test.ts

import type { Page } from '../payload-types';
import { jsonLdScriptHtml } from './page-metadata';
import type { ContentItem } from './related';
import type { SiteSeo } from './site-seo';
import {
  breadcrumbJsonLd,
  faqPageJsonLd,
  generatedBlocks,
  itemJsonLd,
  jsonLdTypes,
  organizationJsonLd,
  websiteJsonLd,
} from './structured-data';

const BASE = 'https://example-site.kite.space';

let failures = 0;
function check(name: string, condition: boolean): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}`);
  }
}

type Json = Record<string, unknown>;
// What a consumer of the served script sees: undefined keys dropped.
const served = (block: unknown) => JSON.parse(jsonLdScriptHtml(block)) as Json;

const SITE: SiteSeo = {
  brandName: 'Acme Floors',
  logoUrl: '/logo.png',
  socialLinks: [
    { platform: 'x', href: 'https://x.com/acme' },
    { platform: 'mail', href: 'mailto:hi@acme.test' },
  ],
  contact: { email: 'hi@acme.test', phone: '+1 555 0100', address: '' },
  defaultSeo: { description: 'Floors in Oswego.' },
};

// --- Organization / WebSite --------------------------------------------------

const org = served(organizationJsonLd(SITE, BASE));
check(
  'Organization names the brand, the site URL and an absolute logo',
  org['@type'] === 'Organization' &&
    org['@context'] === 'https://schema.org' &&
    org.name === 'Acme Floors' &&
    org.url === BASE &&
    org.logo === `${BASE}/logo.png`,
);
check(
  'Organization sameAs holds only web profile URLs',
  JSON.stringify(org.sameAs) === JSON.stringify(['https://x.com/acme']),
);
check(
  'contact details appear only when the settings hold them',
  org.email === 'hi@acme.test' &&
    org.telephone === '+1 555 0100' &&
    !('address' in org),
);
check(
  'a bare brand asserts nothing else',
  JSON.stringify(
    Object.keys(served(organizationJsonLd({ brandName: 'Acme' }, BASE))).sort(),
  ) === JSON.stringify(['@context', '@id', '@type', 'name', 'url']),
);
check(
  'no brand name, no Organization or WebSite',
  organizationJsonLd({ brandName: ' ' }, BASE) === null &&
    websiteJsonLd(null, BASE) === null,
);
const site = served(websiteJsonLd(SITE, BASE));
check(
  'WebSite names the site and points its publisher at the Organization',
  site['@type'] === 'WebSite' &&
    site.name === 'Acme Floors' &&
    site.url === BASE &&
    (site.publisher as Json)['@id'] === org['@id'],
);

// --- BreadcrumbList ------------------------------------------------------------

const crumbs = served(
  breadcrumbJsonLd([
    { name: 'Home', url: BASE },
    { name: 'Services', url: `${BASE}/services` },
    { name: 'Flooring installation', url: `${BASE}/services/flooring` },
  ]),
);
const list = crumbs.itemListElement as Json[];
check(
  'BreadcrumbList has the required ListItem properties, positions from 1',
  crumbs['@type'] === 'BreadcrumbList' &&
    list.length === 3 &&
    list.every(
      (item, i) =>
        item['@type'] === 'ListItem' &&
        item.position === i + 1 &&
        typeof item.name === 'string' &&
        typeof item.item === 'string',
    ),
);
check(
  'a trail of fewer than two documents is no BreadcrumbList',
  breadcrumbJsonLd([{ name: 'Home', url: BASE }]) === null &&
    breadcrumbJsonLd([]) === null,
);

// --- FAQPage -----------------------------------------------------------------

const layout: Page['layout'] = [
  { blockType: 'hero', heading: 'Floors' },
  {
    blockType: 'faq',
    heading: 'Questions',
    items: [
      { question: 'Do you install on weekends?', answer: 'Yes, on Saturdays.' },
      { question: 'Blank answer', answer: '  ' },
    ],
  },
  {
    blockType: 'faq',
    items: [
      { question: 'Is there a guarantee?', answer: 'Ten years.\nIn writing.' },
    ],
  },
];
const faq = served(faqPageJsonLd(layout));
const questions = faq.mainEntity as Json[];
check(
  'FAQPage collects every FAQ block in order, with the required properties',
  faq['@type'] === 'FAQPage' &&
    questions.length === 2 &&
    questions.every(
      (q) =>
        q['@type'] === 'Question' &&
        typeof q.name === 'string' &&
        (q.acceptedAnswer as Json)['@type'] === 'Answer' &&
        typeof (q.acceptedAnswer as Json).text === 'string',
    ) &&
    questions[0].name === 'Do you install on weekends?' &&
    (questions[1].acceptedAnswer as Json).text === 'Ten years.\nIn writing.',
);
check(
  'a page with no answered question has no FAQPage',
  faqPageJsonLd([{ blockType: 'hero', heading: 'x' }]) === null &&
    faqPageJsonLd(undefined) === null,
);

// --- content items -------------------------------------------------------------

const post: ContentItem = {
  id: 1,
  title: 'Choosing a hardwood floor',
  slug: 'blog/choosing-hardwood',
  author: 'Jane Smith',
  publishDate: '2026-09-01T00:00:00.000Z',
  updatedAt: '2026-09-20T10:00:00.000Z',
  featuredImage: '/img/hardwood.jpg',
  metaDescription: 'How to choose.',
};
const url = `${BASE}/blog/choosing-hardwood`;
const article = served(itemJsonLd(post, 'BlogPosting', url, SITE, BASE));
check(
  'an article carries headline, dates, author, publisher and image',
  article['@type'] === 'BlogPosting' &&
    article.headline === 'Choosing a hardwood floor' &&
    article.datePublished === '2026-09-01T00:00:00.000Z' &&
    article.dateModified === '2026-09-20T10:00:00.000Z' &&
    article.image === `${BASE}/img/hardwood.jpg` &&
    (article.mainEntityOfPage as Json)['@id'] === url,
);
check(
  'the author stays the stored name, as a Person',
  JSON.stringify(article.author) ===
    JSON.stringify({ '@type': 'Person', name: 'Jane Smith' }),
);
check(
  'the publisher is the site Organization, with its logo',
  JSON.stringify(article.publisher) ===
    JSON.stringify({
      '@type': 'Organization',
      '@id': org['@id'],
      name: 'Acme Floors',
      logo: { '@type': 'ImageObject', url: `${BASE}/logo.png` },
    }),
);
const event = served(itemJsonLd(post, 'Event', url, SITE, BASE));
check(
  'a type that is not an editorial work gains no publisher or modification date',
  !('publisher' in event) && !('dateModified' in event),
);
check(
  'no author stored, no author asserted; no title, no block',
  !(
    'author' in
    served(itemJsonLd({ ...post, author: null }, 'Article', url, SITE, BASE))
  ) &&
    itemJsonLd({ ...post, title: null }, 'Article', url, SITE, BASE) === null,
);
check(
  'a blank stored description asserts no description',
  ['', '   ', null].every(
    (metaDescription) =>
      !(
        'description' in
        served(
          itemJsonLd(
            { ...post, metaDescription },
            'BlogPosting',
            url,
            SITE,
            BASE,
          ),
        )
      ),
  ),
);

// --- stored JSON-LD always wins ------------------------------------------------

const orgBlock = organizationJsonLd(SITE, BASE);
const webBlock = websiteJsonLd(SITE, BASE);
const crumbBlock = breadcrumbJsonLd([
  { name: 'Home', url: BASE },
  { name: 'FAQ', url: `${BASE}/faq` },
]);
const faqBlock = faqPageJsonLd(layout);
const candidates = { site: [orgBlock, webBlock], page: [crumbBlock, faqBlock] };
const typesOf = (blocks: unknown[]) =>
  [...jsonLdTypes(blocks)].sort().join(',');

check(
  'a page that stores nothing gets every generated block',
  typesOf(generatedBlocks([], candidates)) ===
    'Answer,BreadcrumbList,FAQPage,ListItem,Organization,Question,WebSite',
);
// A Yoast-style graph: the business is a LocalBusiness subtype the template
// cannot enumerate, so no second entity may be added beside it.
const yoast = {
  '@context': 'https://schema.org',
  '@graph': [
    { '@type': 'Dentist', name: 'Smile Co', address: '1 High St' },
    { '@type': 'WebPage', name: 'FAQ' },
  ],
};
check(
  'a page storing any block gets no generated Organization or WebSite',
  typesOf(generatedBlocks([yoast], candidates)) ===
    'Answer,BreadcrumbList,FAQPage,ListItem,Question',
);
check(
  'a bare stored LocalBusiness also suppresses the generated Organization',
  !jsonLdTypes(
    generatedBlocks(
      [{ '@type': 'LocalBusiness', name: 'Smile Co' }],
      candidates,
    ),
  ).has('Organization'),
);
check(
  'a stored FAQPage or BreadcrumbList is never generated a second time',
  typesOf(
    generatedBlocks(
      [
        { '@type': 'FAQPage', mainEntity: [] },
        { '@graph': [{ '@type': 'BreadcrumbList', itemListElement: [] }] },
      ],
      candidates,
    ),
  ) === '',
);
check(
  'no candidate is ever null in the output',
  generatedBlocks([], { site: [null], page: [null] }).length === 0,
);

if (failures > 0) {
  console.error(`${failures} check(s) failed`);
  process.exit(1);
}
console.log('structured-data contract OK');
