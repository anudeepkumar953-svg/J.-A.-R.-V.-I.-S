// Contract for the reads behind `/sitemap.xml` (lib/sitemap-source.ts): every
// indexable document is read, not just the first window of them; the read
// stops at the one-file limit of 50,000 URLs and says so; the pages query
// never drags each page's `layout` JSON along; and each failure still hands
// `sitemapEntries` the input that keeps the site root advertised. A degraded
// read must not escape into the cache, where every visitor would get it.
//
// Driven with a fake `payload.find`, so it needs no database. The template
// ships no unit-test runner, so this is a self-contained tsx script. Exits
// non-zero on any failure.
//
// Run locally: pnpm exec tsx src/lib/sitemap-source.test.ts

import type { BasePayload } from 'payload';
import {
  SITEMAP_URL_CAP,
  createSitemapSource,
  readSitemapInputs,
} from './sitemap-source';
import type { SitemapInputs } from './sitemap-source';
import { sitemapEntries } from './sitemap-entries';
import { ADDED_PAGES_ONLY } from '../payload/proposals';

const BASE = 'https://example-site.kite.space';

let failures = 0;
function check(name: string, condition: boolean): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}`);
  }
}

// --- a fake Payload ----------------------------------------------------------

type FindArgs = {
  collection: string;
  sort?: string | string[];
  where?: Record<string, unknown>;
  limit?: number;
  page?: number;
  select?: Record<string, unknown>;
};

type FakeSite = {
  indexablePages?: number;
  noindexPages?: number;
  // collection slug -> number of published items
  collections?: Record<string, number>;
  // Adds documents that withdrew themselves from the sitemap: pages whose
  // robots or canonical say so, and items that are noindex or canonical
  // elsewhere. They reach the reads, so only membership can drop them.
  withdrawn?: boolean;
  // Pages the indexable query returns whose carried robots say noindex, read
  // before every other page.
  robotsNoindexPages?: number;
  // collection slug -> number of noindex items read before its published ones
  noindexItems?: Record<string, number>;
  // Throws for the matching query. `window` limits it to one page number.
  fail?: {
    query: 'indexable' | 'noindex' | string;
    window?: number;
  }[];
};

const pageDoc = (i: number, noindex: boolean) => ({
  id: i,
  slug: noindex ? `hidden-${i}` : i === 0 ? 'home' : `page-${i}`,
  title: `Page ${i}`,
  layout: [{ blockType: 'hero', heading: 'x'.repeat(200) }],
  seo: { title: 't', noindex, robots: null, canonicalUrl: null },
  updatedAt: '2026-10-05T00:00:00.000Z',
});

// The noindex read asks only for `seo.noindex: true`; every other pages read
// is the indexable one.
const isNoindexQuery = (args: FindArgs): boolean =>
  JSON.stringify(args.where) ===
  JSON.stringify({ 'seo.noindex': { equals: true } });

function fakePayload(site: FakeSite): {
  payload: BasePayload;
  calls: FindArgs[];
} {
  const calls: FindArgs[] = [];
  const collections = Object.fromEntries(
    Object.keys(site.collections ?? {}).map((slug) => [
      slug,
      {
        config: {
          fields: [
            { name: 'slug' },
            { name: 'status' },
            { name: 'noindex' },
            { name: 'canonicalUrl' },
            { name: 'publishDate' },
          ],
        },
      },
    ]),
  );
  const rows = (args: FindArgs): unknown[] => {
    if (args.collection === 'pages') {
      const noindex = isNoindexQuery(args);
      const count = noindex ? site.noindexPages : site.indexablePages;
      const docs: unknown[] = Array.from({ length: count ?? 0 }, (_, i) =>
        pageDoc(noindex ? 100_000 + i : i, Boolean(noindex)),
      );
      if (!noindex && site.robotsNoindexPages) {
        docs.unshift(
          ...Array.from({ length: site.robotsNoindexPages }, (_, i) => ({
            ...pageDoc(300_000 + i, false),
            slug: `robots-hidden-${i}`,
            seo: { noindex: false, robots: 'noindex' },
          })),
        );
      }
      if (site.withdrawn && !noindex) {
        docs.push(
          {
            ...pageDoc(200_001, false),
            slug: 'robots-noindex',
            seo: { noindex: null, robots: 'noindex, follow' },
          },
          {
            ...pageDoc(200_002, false),
            slug: 'canonical-away',
            seo: { canonicalUrl: 'https://elsewhere.example/page' },
          },
        );
      }
      return docs;
    }
    const items: unknown[] = Array.from(
      { length: site.collections?.[args.collection] ?? 0 },
      (_, i) => ({
        id: i,
        slug: `${args.collection}-${i}`,
        body: 'x'.repeat(200),
        updatedAt: '2026-10-05T00:00:00.000Z',
      }),
    );
    items.unshift(
      ...Array.from(
        { length: site.noindexItems?.[args.collection] ?? 0 },
        (_, i) => ({
          id: `hidden-${i}`,
          slug: `${args.collection}-hidden-${i}`,
          noindex: true,
        }),
      ),
    );
    if (site.withdrawn) {
      items.push(
        { id: 'a', slug: `${args.collection}-noindex`, noindex: true },
        {
          id: 'b',
          slug: `${args.collection}-canonical-away`,
          canonicalUrl: 'https://medium.example/post',
        },
      );
    }
    return items;
  };
  const queryName = (args: FindArgs): string =>
    args.collection !== 'pages'
      ? args.collection
      : isNoindexQuery(args)
        ? 'noindex'
        : 'indexable';
  const payload = {
    collections,
    async find(args: FindArgs) {
      calls.push(args);
      const page = args.page ?? 1;
      for (const f of site.fail ?? []) {
        if (f.query === queryName(args) && (f.window ?? page) === page) {
          throw new Error(`connection reset (${f.query})`);
        }
      }
      const all = rows(args);
      const limit = args.limit ?? 10;
      const docs = all.slice((page - 1) * limit, page * limit);
      return { docs, hasNextPage: page * limit < all.length };
    },
  };
  return { payload: payload as unknown as BasePayload, calls };
}

// Runs `fn` with console.warn captured, returning what was warned.
async function warnings<T>(fn: () => Promise<T>): Promise<[T, string[]]> {
  const seen: string[] = [];
  const original = console.warn;
  console.warn = (...args: unknown[]) => {
    seen.push(args.map(String).join(' '));
  };
  try {
    return [await fn(), seen];
  } finally {
    console.warn = original;
  }
}

const urls = (inputs: SitemapInputs): string[] =>
  sitemapEntries({ baseUrl: BASE, ...inputs }).map((entry) => entry.url);

async function main(): Promise<void> {
  // --- every document is read ------------------------------------------------

  {
    const { payload, calls } = fakePayload({
      indexablePages: 12_345,
      noindexPages: 7_000,
      collections: { posts: 9_000 },
    });
    const [inputs, warned] = await warnings(() =>
      readSitemapInputs(payload, { collectionSlugs: ['posts'] }),
    );
    const slugs = new Set(inputs.indexablePages?.map((page) => page.slug));
    check(
      'a site with more than 1,000 pages gets every indexable page back, each once',
      inputs.indexablePages?.length === 12_345 && slugs.size === 12_345,
    );
    check(
      'every noindex slug past the first window is reserved',
      inputs.noindexPageSlugs.length === 7_000 &&
        new Set(inputs.noindexPageSlugs).size === 7_000,
    );
    check(
      'a collection with more than 5,000 items is read whole',
      inputs.collectionItems.length === 1 &&
        inputs.collectionItems[0].length === 9_000,
    );
    check('a site under the cap logs no warning', warned.length === 0);

    const indexableRead = calls.find(
      (call) => call.collection === 'pages' && !isNoindexQuery(call),
    );
    const pagesSelect = indexableRead?.select;
    check(
      'a page still waiting as an unadded proposal is not listed',
      JSON.stringify(indexableRead?.where).includes(
        JSON.stringify(ADDED_PAGES_ONLY),
      ),
    );
    check(
      'the indexable-pages query asks for a projection, and it leaves out `layout`',
      pagesSelect !== undefined && !('layout' in pagesSelect),
    );
    check(
      'the projection still carries what membership reads',
      JSON.stringify(pagesSelect) ===
        JSON.stringify({
          slug: true,
          updatedAt: true,
          seo: { noindex: true, robots: true, canonicalUrl: true },
        }),
    );
    check(
      'a successful read is plain JSON, so the data cache returns it unchanged',
      JSON.stringify(JSON.parse(JSON.stringify(inputs))) ===
        JSON.stringify(inputs),
    );
    check(
      'what is held per page is only what membership and the entry need',
      inputs.indexablePages?.every(
        (page) => !('layout' in page) && !('title' in page),
      ) === true &&
        inputs.collectionItems[0].every((item) => !('body' in item)),
    );
  }

  // --- what a document says about itself survives the read ----------------

  {
    const { payload } = fakePayload({
      indexablePages: 2,
      collections: { posts: 1 },
      withdrawn: true,
    });
    const inputs = await readSitemapInputs(payload, {
      collectionSlugs: ['posts'],
    });
    check(
      'pages and items that withdrew themselves (robots, canonical, noindex) stay out of the sitemap',
      JSON.stringify(urls(inputs)) ===
        JSON.stringify([BASE, `${BASE}/page-1`, `${BASE}/posts-0`]),
    );
  }

  // --- the one-file cap ------------------------------------------------------

  {
    const { payload } = fakePayload({ indexablePages: SITEMAP_URL_CAP + 10 });
    const [inputs, warned] = await warnings(() =>
      readSitemapInputs(payload, { collectionSlugs: [] }),
    );
    check(
      'the read stops at the 50,000 URLs one sitemap file may list',
      SITEMAP_URL_CAP === 50_000 &&
        inputs.indexablePages?.length === SITEMAP_URL_CAP,
    );
    check(
      'hitting the cap is reported, once',
      warned.length === 1 && warned[0].includes('50000'),
    );
  }

  {
    const { payload } = fakePayload({
      indexablePages: 60,
      collections: { posts: 30, events: 30 },
    });
    const [inputs, warned] = await warnings(() =>
      readSitemapInputs(payload, {
        collectionSlugs: ['posts', 'events'],
        cap: 100,
      }),
    );
    const total =
      (inputs.indexablePages?.length ?? 0) +
      inputs.collectionItems.reduce((sum, items) => sum + items.length, 0);
    check(
      'pages and collection items share one budget, filled in order',
      total === 100 &&
        inputs.collectionItems[0].length === 30 &&
        inputs.collectionItems[1].length === 10,
    );
    check(
      'the warning names what was cut short',
      warned.length === 1 &&
        warned[0].includes('events') &&
        !warned[0].includes('posts'),
    );
  }

  {
    const { payload } = fakePayload({
      indexablePages: 60,
      collections: { posts: 40 },
    });
    const [inputs, warned] = await warnings(() =>
      readSitemapInputs(payload, { collectionSlugs: ['posts'], cap: 100 }),
    );
    check(
      'a site exactly at the cap is complete and not reported',
      inputs.collectionItems[0].length === 40 && warned.length === 0,
    );
  }

  {
    const { payload } = fakePayload({
      collections: { posts: 20 },
      fail: [{ query: 'indexable' }],
    });
    const [inputs] = await warnings(() =>
      readSitemapInputs(payload, { collectionSlugs: ['posts'], cap: 10 }),
    );
    check(
      'with the pages lost, the site root added in their place still fits under the cap',
      urls(inputs).length === 10 && urls(inputs)[0] === BASE,
    );
  }

  {
    const { payload } = fakePayload({
      robotsNoindexPages: 100,
      indexablePages: 1,
      collections: { posts: 1 },
    });
    const inputs = await readSitemapInputs(payload, {
      collectionSlugs: ['posts'],
      cap: 100,
    });
    check(
      'pages that withdrew themselves do not spend the budget a later item needs',
      urls(inputs).includes(`${BASE}/posts-0`),
    );
    check(
      '…and their slugs are still reserved',
      inputs.noindexPageSlugs.includes('robots-hidden-0'),
    );
  }

  {
    const { payload } = fakePayload({
      indexablePages: 1,
      collections: { posts: 5 },
      noindexItems: { posts: 8 },
    });
    const [inputs, warned] = await warnings(() =>
      readSitemapInputs(payload, { collectionSlugs: ['posts'], cap: 10 }),
    );
    check(
      'noindex items read first do not spend the budget either',
      urls(inputs).length === 6 &&
        urls(inputs).includes(`${BASE}/posts-4`) &&
        warned.length === 0,
    );
  }

  {
    const { payload } = fakePayload({
      indexablePages: 1,
      collections: { posts: 20 },
      noindexItems: { posts: 8 },
    });
    const [inputs, warned] = await warnings(() =>
      readSitemapInputs(payload, { collectionSlugs: ['posts'], cap: 10 }),
    );
    check(
      'the read goes on until the listed URLs reach the cap',
      urls(inputs).length === 10 && warned.length === 1,
    );
  }

  {
    const { payload, calls } = fakePayload({
      indexablePages: 1,
      collections: { posts: 5 },
      noindexItems: { posts: 50_000 },
    });
    const [inputs, warned] = await warnings(() =>
      readSitemapInputs(payload, { collectionSlugs: ['posts'], cap: 10 }),
    );
    check(
      'a collection of withdrawn items is read no further than twice the cap',
      calls.filter((call) => call.collection === 'posts').length === 1 &&
        inputs.collectionItems[0].length === 0 &&
        warned.length === 1,
    );
  }

  {
    const { payload, calls } = fakePayload({
      indexablePages: 10,
      collections: { posts: 5, events: 5 },
    });
    const [, warned] = await warnings(() =>
      readSitemapInputs(payload, {
        collectionSlugs: ['posts', 'events'],
        cap: 10,
      }),
    );
    check(
      'a collection read once the file is full asks for one row',
      calls
        .filter((call) => call.collection !== 'pages')
        .every((call) => call.limit === 1) && warned.length === 1,
    );
  }

  {
    const { payload, calls } = fakePayload({ collections: { posts: 3 } });
    await readSitemapInputs(payload, { collectionSlugs: ['posts'] });
    check(
      'items are read newest first, with the id as a tie-breaker',
      JSON.stringify(calls.find((c) => c.collection === 'posts')?.sort) ===
        JSON.stringify(['-publishDate', '-id']),
    );
  }

  // --- each failure degrades on its own -------------------------------------

  const site: FakeSite = {
    indexablePages: 3,
    noindexPages: 2,
    collections: { posts: 2, events: 2 },
  };
  const collectionSlugs = ['posts', 'events'];

  {
    const { payload } = fakePayload({
      ...site,
      fail: [{ query: 'indexable' }],
    });
    const inputs = await readSitemapInputs(payload, { collectionSlugs });
    check(
      'a failed indexable-pages read yields null, and the other reads still land',
      inputs.indexablePages === null &&
        inputs.noindexPageSlugs.length === 2 &&
        inputs.collectionItems.length === 2,
    );
    check('…which still advertises the site root', urls(inputs)[0] === BASE);
  }

  {
    const { payload } = fakePayload({
      indexablePages: 6_000,
      fail: [{ query: 'indexable', window: 2 }],
    });
    const inputs = await readSitemapInputs(payload, { collectionSlugs: [] });
    check(
      'a failure on a later window fails the whole indexable read rather than returning part of it',
      inputs.indexablePages === null,
    );
  }

  {
    const { payload } = fakePayload({ ...site, fail: [{ query: 'noindex' }] });
    const inputs = await readSitemapInputs(payload, { collectionSlugs });
    check(
      'a failed noindex read degrades to no reservations, nothing else lost',
      inputs.noindexPageSlugs.length === 0 &&
        inputs.indexablePages?.length === 3 &&
        inputs.collectionItems.length === 2,
    );
  }

  {
    const { payload } = fakePayload({ ...site, fail: [{ query: 'posts' }] });
    const inputs = await readSitemapInputs(payload, { collectionSlugs });
    check(
      'a failed collection contributes nothing and the others are kept',
      inputs.collectionItems.length === 1 &&
        inputs.collectionItems[0][0]?.slug === 'events-0' &&
        inputs.indexablePages?.length === 3,
    );
  }

  // --- what may and may not be cached ---------------------------------------

  {
    const source = createSitemapSource(
      async () => {
        throw new Error('database unreachable');
      },
      { collectionSlugs },
    );
    let rejected = false;
    await source.cachedRead().catch(() => {
      rejected = true;
    });
    check(
      'an unreachable database escapes the cached function, so it is never stored',
      rejected,
    );
    const inputs = await source.read();
    check(
      'an unreachable database still yields the root-only sitemap',
      JSON.stringify(urls(inputs)) === JSON.stringify([BASE]),
    );
  }

  {
    const { payload } = fakePayload({
      ...site,
      fail: [{ query: 'indexable' }],
    });
    const source = createSitemapSource(async () => payload, {
      collectionSlugs,
    });
    let rejected = false;
    await source.cachedRead().catch(() => {
      rejected = true;
    });
    check(
      'a failed indexable-pages read escapes the cached function too',
      rejected,
    );
    const inputs = await source.read();
    check(
      '…and the caller still gets that degraded input, with what did succeed',
      inputs.indexablePages === null &&
        inputs.noindexPageSlugs.length === 2 &&
        inputs.collectionItems.length === 2,
    );
  }

  {
    const { payload } = fakePayload(site);
    const source = createSitemapSource(async () => payload, {
      collectionSlugs,
    });
    const inputs = await source.read();
    check(
      'a healthy read comes through the source unchanged',
      inputs.indexablePages?.length === 3 &&
        JSON.stringify(urls(inputs).slice(0, 2)) ===
          JSON.stringify([BASE, `${BASE}/page-1`]),
    );
  }

  // --- verdict ---------------------------------------------------------------

  if (failures > 0) {
    console.error(`${failures} check(s) failed`);
    process.exit(1);
  }
  console.log('sitemap-source contract OK');
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
