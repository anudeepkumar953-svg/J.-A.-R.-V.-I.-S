import type { Page } from '@/payload-types';
import type { ContentItem } from './related';
import type { SiteSeo } from './site-seo';

// Structured data the template builds from what the CMS already holds: the
// site's Organization and WebSite from its settings, a BreadcrumbList from the
// URL path and the titles of the pages on it, an FAQPage from the page's FAQ
// blocks, and a typed entry for each content item. Pure, so the contract test
// (`structured-data.test.ts`) drives it without a database; the catch-all
// route renders the result through `jsonLdScriptHtml`.
//
// It asserts only what the settings and the document state. A page's stored
// JSON-LD (`seo.jsonLd`, carried verbatim from a migrated source) is the
// page's own claim and always wins: nothing is generated with a type the
// stored blocks already carry, and a page that stores any block gets no
// generated Organization or WebSite, because its stored blocks may describe
// the business under a type we cannot list (`LocalBusiness`, `Dentist`, …)
// and a second entity beside it could contradict its name or address.

type JsonLd = Record<string, unknown>;

const CONTEXT = 'https://schema.org';

/** Every `@type` named anywhere in `blocks`, `@graph` members included. */
export function jsonLdTypes(blocks: unknown[]): Set<string> {
  const types = new Set<string>();
  const walk = (node: unknown) => {
    if (Array.isArray(node)) {
      node.forEach(walk);
      return;
    }
    if (!node || typeof node !== 'object') return;
    for (const [key, value] of Object.entries(node)) {
      if (key === '@type') {
        for (const t of Array.isArray(value) ? value : [value]) {
          if (typeof t === 'string') types.add(t);
        }
      } else {
        walk(value);
      }
    }
  };
  walk(blocks);
  return types;
}

const absolute = (url: string | null | undefined, baseUrl: string) => {
  if (!url) return undefined;
  try {
    return new URL(url, `${baseUrl}/`).href;
  } catch {
    return undefined;
  }
};

const organizationId = (baseUrl: string) => `${baseUrl}/#organization`;

/** The business as its settings describe it; null without a brand name. */
export function organizationJsonLd(
  site: SiteSeo,
  baseUrl: string,
): JsonLd | null {
  const name = site?.brandName?.trim();
  if (!name) return null;
  const sameAs = (site?.socialLinks ?? [])
    .map((link) => link.href?.trim())
    .filter((href): href is string => !!href && /^https?:\/\//i.test(href));
  return {
    '@context': CONTEXT,
    '@type': 'Organization',
    '@id': organizationId(baseUrl),
    name,
    url: baseUrl,
    logo: absolute(site?.logoUrl, baseUrl),
    sameAs: sameAs.length ? sameAs : undefined,
    email: site?.contact?.email?.trim() || undefined,
    telephone: site?.contact?.phone?.trim() || undefined,
    address: site?.contact?.address?.trim() || undefined,
  };
}

export function websiteJsonLd(site: SiteSeo, baseUrl: string): JsonLd | null {
  const name = site?.brandName?.trim();
  if (!name) return null;
  return {
    '@context': CONTEXT,
    '@type': 'WebSite',
    '@id': `${baseUrl}/#website`,
    name,
    url: baseUrl,
    description: site?.defaultSeo?.description?.trim() || undefined,
    publisher: { '@id': organizationId(baseUrl) },
  };
}

/** One step of a breadcrumb trail: a document that exists at `url`. */
export type Crumb = { name: string; url: string };

/**
 * The trail from the home page to the current document. `trail` holds only
 * documents that exist — a path segment with no page of its own is left out
 * rather than linked to a URL that would not be found. Fewer than two steps is
 * no trail.
 */
export function breadcrumbJsonLd(trail: Crumb[]): JsonLd | null {
  const steps = trail.filter((c) => c.name.trim());
  if (steps.length < 2) return null;
  return {
    '@context': CONTEXT,
    '@type': 'BreadcrumbList',
    itemListElement: steps.map((step, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: step.name.trim(),
      item: step.url,
    })),
  };
}

/** The questions and answers of every FAQ block on the page, as written. */
export function faqPageJsonLd(layout: Page['layout']): JsonLd | null {
  const questions = (layout ?? [])
    .flatMap((block) => (block.blockType === 'faq' ? (block.items ?? []) : []))
    .map((item) => ({
      question: item.question?.trim(),
      answer: item.answer?.trim(),
    }))
    .filter((qa) => qa.question && qa.answer)
    .map((qa) => ({
      '@type': 'Question',
      name: qa.question,
      acceptedAnswer: { '@type': 'Answer', text: qa.answer },
    }));
  if (!questions.length) return null;
  return { '@context': CONTEXT, '@type': 'FAQPage', mainEntity: questions };
}

// Types whose items are editorial works, where a modification date and a
// publisher are schema.org properties. Any other declared type (an Event, a
// JobPosting) keeps only the properties it had.
const CREATIVE_WORK_TYPES = new Set([
  'CreativeWork',
  'Article',
  'BlogPosting',
  'NewsArticle',
  'TechArticle',
  'Report',
  'ScholarlyArticle',
  'PodcastEpisode',
  'Episode',
  'Review',
  'HowTo',
]);

/**
 * Typed markup for a content item. `@type` is the collection's declared
 * schema type. The author stays the free-text name the item stores, as a
 * Person, since that is all the CMS knows about them.
 */
export function itemJsonLd(
  item: ContentItem,
  schemaType: string,
  url: string,
  site: SiteSeo,
  baseUrl: string,
): JsonLd | null {
  if (!item.title) return null;
  const creativeWork = CREATIVE_WORK_TYPES.has(schemaType);
  const brand = site?.brandName?.trim();
  const logo = absolute(site?.logoUrl, baseUrl);
  return {
    '@context': CONTEXT,
    '@type': schemaType,
    headline: item.title,
    description: item.metaDescription?.trim() || undefined,
    datePublished: item.publishDate ?? undefined,
    dateModified: creativeWork ? (item.updatedAt ?? undefined) : undefined,
    author: item.author ? { '@type': 'Person', name: item.author } : undefined,
    publisher:
      creativeWork && brand
        ? {
            '@type': 'Organization',
            '@id': organizationId(baseUrl),
            name: brand,
            logo: logo ? { '@type': 'ImageObject', url: logo } : undefined,
          }
        : undefined,
    image: absolute(item.ogImageUrl || item.featuredImage, baseUrl),
    url,
    mainEntityOfPage: { '@type': 'WebPage', '@id': url },
  };
}

/**
 * The generated blocks a document may add beside what it stores: none whose
 * type the stored blocks already name, and no site entity when it stores any.
 */
export function generatedBlocks(
  stored: unknown[],
  candidates: { site: (JsonLd | null)[]; page: (JsonLd | null)[] },
): JsonLd[] {
  const taken = jsonLdTypes(stored);
  const allowed = [
    ...(stored.length ? [] : candidates.site),
    ...candidates.page,
  ];
  return allowed.filter(
    (block): block is JsonLd => !!block && !taken.has(String(block['@type'])),
  );
}
