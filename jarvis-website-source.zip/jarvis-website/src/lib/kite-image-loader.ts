'use client';

import type { ImageLoaderProps } from 'next/image';
import { kiteImageUrl } from './kite-image';

// next/image loader (next.config.mjs `images.loaderFile`): every <Image> of a
// CDN-hosted upload gets a srcset of resized WebP/AVIF from the CDN instead of
// the original file, without going through Next's own image optimiser. Any
// other src (local /public files, other hosts, SVGs) is served as written.
export default function kiteImageLoader({ src, width }: ImageLoaderProps) {
  return kiteImageUrl(src, { width });
}
