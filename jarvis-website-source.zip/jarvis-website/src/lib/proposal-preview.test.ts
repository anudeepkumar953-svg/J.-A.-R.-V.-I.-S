// Contract for previewing a page Kite proposed (lib/proposal-preview.ts): a
// signed-in editor sees it, whether it is a `proposed` Pages row (a draft) or
// a `page-proposals` document (Main); anyone else gets nothing, so the route
// answers 404. The AI tab's preview route (`/admin/kite-proposal/<slug>`) also shows
// the editor a page already added, and still nothing to anyone else. And the `page-proposals` collection itself, read from the real
// config, refuses every REST operation without a session and stays out of
// the admin nav.
//
// Driven with a fake Payload, so it needs no database.
//
// Run locally: pnpm exec tsx src/lib/proposal-preview.test.ts

import type { BasePayload, PayloadRequest } from 'payload';
import config from '../payload.config';
import {
  findPreviewPageForEditor,
  findProposalForEditor,
  previewSlug,
} from './proposal-preview';

let failures = 0;
function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

type FindArgs = { collection: string; where?: unknown };

const proposedRow = {
  id: 7,
  title: 'Catering (draft proposal)',
  slug: 'catering',
  proposed: true,
  layout: [],
  updatedAt: '2026-10-06T00:00:00.000Z',
  createdAt: '2026-10-06T00:00:00.000Z',
};

const mainProposal = {
  id: 3,
  title: 'Catering',
  slug: 'home/catering',
  parentSlug: 'home',
  layout: [{ blockType: 'hero', heading: 'We cater' }],
  seo: { title: 'Catering | Cafe', noindex: false },
  updatedAt: '2026-10-06T00:00:00.000Z',
  createdAt: '2026-10-06T00:00:00.000Z',
};

function fakePayload(opts: {
  signedIn: boolean;
  pages?: Record<string, unknown>[];
  proposals?: Record<string, unknown>[];
}): { payload: BasePayload; finds: FindArgs[] } {
  const finds: FindArgs[] = [];
  const slugOf = (where: unknown): string | undefined =>
    JSON.stringify(where).match(/"slug":\{"equals":"([^"]+)"/)?.[1];
  const payload = {
    auth: async () => ({ user: opts.signedIn ? { id: 1 } : null }),
    find: async (args: FindArgs) => {
      finds.push(args);
      const rows =
        args.collection === 'pages'
          ? (opts.pages ?? [])
          : args.collection === 'page-proposals'
            ? (opts.proposals ?? [])
            : [];
      const where = JSON.stringify(args.where);
      const wanted = (row: Record<string, unknown>) =>
        where.includes('"proposed":{"equals":true}')
          ? row.proposed === true
          : where.includes('"proposed":{"not_equals":true}')
            ? row.proposed !== true
            : true;
      return {
        docs: rows.filter(
          (row) => row.slug === slugOf(args.where) && wanted(row),
        ),
      };
    },
  };
  return { payload: payload as unknown as BasePayload, finds };
}

const headers = new Headers({ cookie: 'payload-token=x' });

{
  console.log('a page proposed on Main');
  const editor = fakePayload({ signedIn: true, proposals: [mainProposal] });
  const found = await findProposalForEditor(
    editor.payload,
    headers,
    'home/catering',
  );
  check(
    'a signed-in editor gets it, rendered as a page',
    found?.kind === 'page' &&
      found.doc.title === 'Catering' &&
      found.doc.slug === 'home/catering' &&
      JSON.stringify(found.doc.layout) ===
        JSON.stringify(mainProposal.layout) &&
      found.doc.seo?.title === 'Catering | Cafe',
    JSON.stringify(found),
  );

  const visitor = fakePayload({ signedIn: false, proposals: [mainProposal] });
  check(
    'an anonymous visitor gets nothing',
    (await findProposalForEditor(visitor.payload, headers, 'home/catering')) ===
      null,
  );
  check('and nothing is read for them', visitor.finds.length === 0);

  check(
    'a slug nobody proposed is nothing, even for the editor',
    (await findProposalForEditor(editor.payload, headers, 'gift-cards')) ===
      null,
  );
}

{
  console.log('a page proposed inside a draft');
  const editor = fakePayload({
    signedIn: true,
    pages: [proposedRow],
    proposals: [{ ...mainProposal, slug: 'catering' }],
  });
  const found = await findProposalForEditor(
    editor.payload,
    headers,
    'catering',
  );
  check(
    'the proposed Pages row wins over a copy of Main’s proposal',
    found?.doc.title === 'Catering (draft proposal)',
    JSON.stringify(found),
  );
  check(
    'the draft row is the only read',
    editor.finds.map((f) => f.collection).join(',') === 'pages',
  );
}

{
  console.log('the preview route');
  const addedRow = {
    ...proposedRow,
    id: 8,
    title: 'Catering (added)',
    slug: 'menu/catering',
    proposed: false,
  };
  const editor = fakePayload({
    signedIn: true,
    pages: [proposedRow, addedRow],
    proposals: [mainProposal],
  });
  check(
    'shows the editor a proposal in a draft',
    (await findPreviewPageForEditor(editor.payload, headers, 'catering'))
      ?.title === 'Catering (draft proposal)',
  );
  check(
    'shows the editor a proposal on Main',
    (await findPreviewPageForEditor(editor.payload, headers, 'home/catering'))
      ?.title === 'Catering',
  );
  check(
    'shows the editor a page already added',
    (await findPreviewPageForEditor(editor.payload, headers, 'menu/catering'))
      ?.title === 'Catering (added)',
  );
  check(
    'a slug with no page is nothing',
    (await findPreviewPageForEditor(editor.payload, headers, 'gift-cards')) ===
      null,
  );
  check(
    'an added page wins over a proposal at the same address, as on the site',
    (
      await findPreviewPageForEditor(
        fakePayload({
          signedIn: true,
          pages: [{ ...addedRow, slug: 'catering' }],
          proposals: [{ ...mainProposal, slug: 'catering' }],
        }).payload,
        headers,
        'catering',
      )
    )?.title === 'Catering (added)',
  );

  const visitor = fakePayload({
    signedIn: false,
    pages: [proposedRow, addedRow],
    proposals: [mainProposal],
  });
  for (const slug of ['catering', 'home/catering', 'menu/catering']) {
    check(
      `an anonymous visitor gets nothing at ${slug}`,
      (await findPreviewPageForEditor(visitor.payload, headers, slug)) === null,
    );
  }
  check('and nothing is read for them', visitor.finds.length === 0);

  check(
    'the bare route is the home page, a nested address keeps its path',
    previewSlug(undefined) === 'home' &&
      previewSlug([]) === 'home' &&
      previewSlug(['home', 'catering']) === 'home/catering',
  );
}

{
  console.log('the page-proposals collection');
  const sanitized = await config;
  const collection = sanitized.collections.find(
    (c) => c.slug === 'page-proposals',
  );
  check('is registered', collection !== undefined);
  check('is hidden from the admin nav', collection?.admin?.hidden === true);
  for (const op of ['read', 'create', 'update', 'delete'] as const) {
    const access = collection?.access?.[op];
    const allowed = async (user: unknown) =>
      access
        ? await access({ req: { user } as unknown as PayloadRequest })
        : true;
    check(
      `${op} needs a session`,
      (await allowed(null)) === false && (await allowed({ id: 1 })) === true,
    );
  }
}

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`);
  process.exit(1);
}
console.log('\nall checks passed');
process.exit(0);
