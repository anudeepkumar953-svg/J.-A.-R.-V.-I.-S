// Contract for how template components deliver CMS images (lib/kite-image.ts,
// components/blocks/KiteImage.tsx). What it pins:
//   - an original upload on the platform CDN is requested resized, in the
//     browser's best format, with a srcset — never as the multi-megabyte file;
//   - every other URL is served exactly as written: another host, a local
//     file, an SVG or GIF, and an upload whose author chose a crop, trim or
//     overlay (re-deriving those changes the image or chains a derivation the
//     CDN never refreshes);
//   - the page's main image is fetched eagerly at high priority, every other
//     image lazily, and fixed-size images carry their width and height;
//   - a CDN-hosted hero video gets a still poster frame and plays a re-encoded,
//     width-capped rendition, with the original as the fallback source;
//   - the baked block renderer hands every block its CMS video URLs as the
//     rendition, so a generated block with a plain <video> never fetches the
//     original.
//
// Self-contained tsx script (the template ships no unit-test runner), run in CI
// by nextjs-template-code-quality.yml. Exits non-zero on any failure.
//
// Run locally: pnpm exec tsx src/lib/kite-image.test.tsx

// Explicit React import: this file sits outside tsconfig.json's scope, so the
// runner uses the classic JSX transform (see Footer.test.tsx).
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import { Hero } from '../components/blocks/Hero';
import { KiteImage } from '../components/blocks/KiteImage';
import { KiteVideo } from '../components/blocks/KiteVideo';
import kiteImageLoader from './kite-image-loader';
import {
  kiteImageUrl,
  kiteVideoPosterUrl,
  kiteVideoSources,
  kiteVideoUrl,
  withVideoRenditions,
} from './kite-image';
import { RenderBlocks } from '../components/blocks/RenderBlocks';

let failures = 0;
function check(name: string, condition: boolean): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}`);
  }
}

const CDN = 'https://static.kite.ai/image/upload/';
const ASSET = 'v1789396035/app/5faed0c9/hero-sep2026/counter-r1.png';
const ORIGINAL = `${CDN}${ASSET}`;
const at = (width: number) => `${CDN}c_limit,w_${width},f_auto,q_auto/${ASSET}`;

check(
  'an original upload is requested resized and format-negotiated',
  kiteImageUrl(ORIGINAL, { width: 1080 }) === at(1080),
);
check(
  'a height bound is honoured for fixed-height images',
  kiteImageUrl(ORIGINAL, { height: 56 }) ===
    `${CDN}c_limit,h_56,f_auto,q_auto/${ASSET}`,
);
check(
  'delivery-only transforms are replaced, not chained',
  kiteImageUrl(`${CDN}f_auto,q_auto/${ASSET}`, { width: 640 }) === at(640) &&
    kiteImageUrl(`${CDN}w_800/${ASSET}`, { width: 640 }) === at(640),
);
check(
  'an unversioned asset path keeps its folders, underscored ones included',
  kiteImageUrl(`${CDN}app/my_folder/hero_bg.png`, { width: 640 }) ===
    `${CDN}c_limit,w_640,f_auto,q_auto/app/my_folder/hero_bg.png`,
);
check(
  'a transform-shaped filename stays the asset',
  kiteImageUrl(`${CDN}e_sunset.png`, { width: 640 }) ===
    `${CDN}c_limit,w_640,f_auto,q_auto/e_sunset.png`,
);

const untouched = [
  `${CDN}e_trim/f_auto,q_auto,h_80/${ASSET}`,
  `${CDN}e_trim/f_auto,q_auto/c_pad,w_1024,h_1024,b_transparent/${ASSET}`,
  `${CDN}c_fill,w_1200,h_630,g_north/${ASSET}`,
  `${CDN}h_400/${ASSET}`,
  `${CDN}l_app:x:logo,w_220/fl_layer_apply,g_north_west/${ASSET}`,
  `${CDN}v1769585012/app/x/logo.svg`,
  `${CDN}v1769585012/app/x/loop.gif`,
  `${CDN}v1769585012/app/x/no-extension`,
  `${ORIGINAL}?v=2`,
  'https://static.kite.ai/video/upload/app/x/clip.mp4',
  'https://res.cloudinary.com/other/image/upload/app/x/photo.png',
  'https://images.unsplash.com/photo-1.jpg',
  '/images/team.png',
];
for (const url of untouched) {
  check(`served as written: ${url}`, kiteImageUrl(url, { width: 640 }) === url);
}

check(
  'the next/image loader uses the same rule',
  kiteImageLoader({ src: ORIGINAL, width: 1320 }) === at(1320) &&
    kiteImageLoader({ src: '/images/team.png', width: 1320 }) ===
      '/images/team.png',
);

function imgTag(element: React.ReactElement): Record<string, string> {
  const html = renderToStaticMarkup(element);
  const tag = html.match(/<img [^>]*>/)?.[0] ?? '';
  return Object.fromEntries(
    [...tag.matchAll(/([a-zA-Z-]+)="([^"]*)"/g)].map((m) => [
      m[1].toLowerCase(),
      m[2],
    ]),
  );
}

const hero = imgTag(<KiteImage src={ORIGINAL} alt="" sizes="100vw" preload />);
check(
  'a responsive image offers resized candidates and never the original',
  hero.srcset?.includes(`${at(640)} 640w`) &&
    hero.srcset?.includes(`${at(1920)} 1920w`) &&
    !hero.srcset?.includes(`${ORIGINAL} `) &&
    hero.src !== ORIGINAL &&
    hero.sizes === '100vw',
);
check(
  'the main image is fetched eagerly at high priority',
  hero.loading === 'eager' && hero.fetchpriority === 'high',
);

const card = imgTag(
  <KiteImage src={ORIGINAL} alt="Product" sizes="(min-width: 768px) 33vw" />,
);
check(
  'any other image loads lazily at normal priority',
  card.loading === 'lazy' && card.fetchpriority === undefined,
);

const avatar = imgTag(
  <KiteImage src={ORIGINAL} alt="Ada" width={40} height={40} />,
);
// The CDN copy that covers a w x h box: a landscape source limited by its
// height, any other by its width (checked against static.kite.ai: a 1344x768
// source asked for 128x128 comes back 224x128).
const cover = (w: number, h: number, ratio: string) =>
  `${CDN}if_ar_gt_${ratio}/c_limit,h_${h}/if_else/c_limit,w_${w}/if_end/f_auto,q_auto/${ASSET}`;
check(
  'a fixed-size image carries its box size and a 1x/2x pair that covers the box',
  avatar.width === '40' &&
    avatar.height === '40' &&
    avatar.srcset === `${cover(40, 40, '1')} 1x, ${cover(80, 80, '1')} 2x`,
);
check(
  'a box that is not square compares the source to its own ratio',
  kiteImageUrl(ORIGINAL, { width: 64, height: 48 }) === cover(64, 48, '1.333'),
);
check(
  'a folder that only starts like a condition is still an asset path',
  kiteImageUrl(`${CDN}if_studio/hero.png`, { width: 640 }) ===
    `${CDN}c_limit,w_640,f_auto,q_auto/if_studio/hero.png`,
);
check(
  'a covering URL is not resized again',
  kiteImageUrl(cover(80, 80, '1'), { width: 640 }) === cover(80, 80, '1'),
);

const logo = imgTag(<KiteImage src={ORIGINAL} alt="Brand" height={32} />);
check(
  'a fixed-height image claims no width it does not know',
  logo.width === undefined &&
    logo.height === undefined &&
    logo.srcset?.includes(`${CDN}c_limit,h_64,f_auto,q_auto/${ASSET} 2x`),
);

const external = imgTag(
  <KiteImage
    src="https://images.unsplash.com/photo-1.jpg"
    alt=""
    sizes="100vw"
  />,
);
check(
  'an image the CDN cannot resize is drawn as written, without a srcset',
  external.src === 'https://images.unsplash.com/photo-1.jpg' &&
    external.srcset === undefined &&
    external.sizes === undefined,
);

check(
  'a CDN-hosted video gets a resized still of its first frame as poster',
  kiteVideoPosterUrl(
    'https://static.kite.ai/video/upload/v123/app/x/videos/hero.mp4',
  ) ===
    'https://static.kite.ai/video/upload/so_0,c_limit,w_1920,f_auto,q_auto/v123/app/x/videos/hero.jpg',
);
check(
  'a video carrying only delivery transforms still gets a poster',
  kiteVideoPosterUrl(
    'https://static.kite.ai/video/upload/f_auto,q_auto/v123/app/x/videos/hero.mp4',
  ) ===
    'https://static.kite.ai/video/upload/so_0,c_limit,w_1920,f_auto,q_auto/v123/app/x/videos/hero.jpg',
);
check(
  'no poster for a video hosted elsewhere or cropped by its author',
  kiteVideoPosterUrl('https://cdn.example.com/hero.mp4') === null &&
    kiteVideoPosterUrl(
      'https://static.kite.ai/video/upload/c_fill,w_1200,h_750/app/x/hero.mp4',
    ) === null,
);

const VIDEO_CDN = 'https://static.kite.ai/video/upload/';
const VIDEO_ASSET = 'v123/app/x/videos/hero.mp4';
const VIDEO = `${VIDEO_CDN}${VIDEO_ASSET}`;
const PLAYBACK = `${VIDEO_CDN}c_limit,w_1280,q_auto,vc_auto/${VIDEO_ASSET}`;

check(
  'an uploaded video plays re-encoded and width-capped, never upscaled',
  kiteVideoUrl(VIDEO) === PLAYBACK,
);
check(
  'a video carrying only delivery transforms has them replaced, not chained',
  kiteVideoUrl(`${VIDEO_CDN}q_auto,vc_auto/${VIDEO_ASSET}`) === PLAYBACK &&
    kiteVideoUrl(`${VIDEO_CDN}w_1920/${VIDEO_ASSET}`) === PLAYBACK &&
    kiteVideoUrl(PLAYBACK) === PLAYBACK,
);
check(
  'a video keeps the container it was uploaded in',
  kiteVideoUrl(`${VIDEO_CDN}v1/app/x/clip.webm`) ===
    `${VIDEO_CDN}c_limit,w_1280,q_auto,vc_auto/v1/app/x/clip.webm`,
);
const untouchedVideos = [
  `${VIDEO_CDN}so_2,du_5/${VIDEO_ASSET}`,
  `${VIDEO_CDN}e_reverse/${VIDEO_ASSET}`,
  `${VIDEO_CDN}c_fill,w_1200,h_750/${VIDEO_ASSET}`,
  `${VIDEO}?v=2`,
  `${VIDEO}#t=3`,
  'https://cdn.example.com/hero.mp4',
  'https://res.cloudinary.com/other/video/upload/v1/app/x/hero.mp4',
  '/videos/hero.mp4',
  ORIGINAL,
];
for (const url of untouchedVideos) {
  check(`video served as written: ${url}`, kiteVideoUrl(url) === url);
}

function videoSources(element: React.ReactElement): string[] {
  const html = renderToStaticMarkup(element);
  return [...html.matchAll(/<source src="([^"]*)"/g)].map((m) => m[1]);
}

const heroProps = { blockType: 'hero', heading: 'Welcome' } as const;
check(
  'the hero video plays the re-encoded rendition first, the original as fallback',
  JSON.stringify(videoSources(<Hero {...heroProps} imageUrl={VIDEO} />)) ===
    JSON.stringify([PLAYBACK, VIDEO]),
);
check(
  'a hero video the CDN cannot re-encode is offered once, as written',
  JSON.stringify(
    videoSources(
      <Hero {...heroProps} imageUrl="https://cdn.example.com/hero.mp4" />,
    ),
  ) === JSON.stringify(['https://cdn.example.com/hero.mp4']),
);

function videoTag(element: React.ReactElement): Record<string, string> {
  const tag = renderToStaticMarkup(element).match(/<video[^>]*>/)?.[0] ?? '';
  return Object.fromEntries(
    [...tag.matchAll(/([a-zA-Z-]+)(?:="([^"]*)")?/g)]
      .slice(1)
      .map((m) => [m[1].toLowerCase(), m[2] ?? '']),
  );
}

const background = videoTag(<KiteVideo src={VIDEO} muted autoPlay loop />);
check(
  'a CMS video plays the rendition with the original as fallback',
  JSON.stringify(videoSources(<KiteVideo src={VIDEO} />)) ===
    JSON.stringify([PLAYBACK, VIDEO]),
);
check(
  'a CMS video paints a CDN poster and fetches only metadata up front',
  background.poster === kiteVideoPosterUrl(VIDEO) &&
    background.preload === 'metadata' &&
    'playsinline' in background &&
    'autoplay' in background &&
    'loop' in background,
);
const content = videoTag(
  <KiteVideo src={VIDEO} controls poster="/still.jpg" preload="none" />,
);
check(
  'a content video keeps the playback options its caller chose',
  'controls' in content &&
    !('autoplay' in content) &&
    content.poster === '/still.jpg' &&
    content.preload === 'none',
);
check(
  'a video the CDN does not host is drawn once, as written, without a poster',
  JSON.stringify(
    videoSources(<KiteVideo src="https://cdn.example.com/hero.mp4" />),
  ) === JSON.stringify(['https://cdn.example.com/hero.mp4']) &&
    videoTag(<KiteVideo src="https://cdn.example.com/hero.mp4" />).poster ===
      undefined,
);

check(
  'a rendition URL still offers the original as its fallback source',
  JSON.stringify(kiteVideoSources(PLAYBACK)) ===
    JSON.stringify([PLAYBACK, VIDEO]) &&
    JSON.stringify(kiteVideoSources('/videos/hero.mp4')) ===
      JSON.stringify(['/videos/hero.mp4']),
);

const OTHER_HOST_VIDEO = 'https://cdn.example.com/hero.mp4';
const blockData = {
  blockType: 'hero',
  heading: 'Welcome',
  imageUrl: VIDEO,
  primaryCtaLabel: 'Download the film',
  primaryCtaHref: VIDEO,
  items: [
    {
      videoSrc: VIDEO,
      videoLink: VIDEO,
      ctaTarget: VIDEO,
      href: VIDEO,
      photoUrl: ORIGINAL,
      externalClip: OTHER_HOST_VIDEO,
    },
  ],
  body: {
    root: {
      children: [{ type: 'link', fields: { url: VIDEO }, children: [] }],
    },
  },
  count: 3,
  hidden: null,
};
const rewritten = withVideoRenditions(blockData);
check(
  'every CDN video URL, in a playback field or a link, nested or not, becomes the rendition',
  rewritten.imageUrl === PLAYBACK &&
    rewritten.primaryCtaHref === PLAYBACK &&
    rewritten.items[0].videoSrc === PLAYBACK &&
    rewritten.items[0].videoLink === PLAYBACK &&
    rewritten.items[0].ctaTarget === PLAYBACK &&
    rewritten.items[0].href === PLAYBACK &&
    rewritten.body.root.children[0].fields.url === PLAYBACK,
);
check(
  'an image, a video on another host and non-URL values are untouched, and the CMS data is not mutated',
  rewritten.items[0].photoUrl === ORIGINAL &&
    rewritten.items[0].externalClip === OTHER_HOST_VIDEO &&
    rewritten.heading === 'Welcome' &&
    rewritten.count === 3 &&
    rewritten.hidden === null &&
    blockData.imageUrl === VIDEO &&
    blockData.items[0].href === VIDEO,
);
const collectionItem = withVideoRenditions({
  slug: 'spring-retreat',
  title: 'Spring retreat',
  gallery: [{ clipUrl: VIDEO }],
});
check(
  'a collection item gets the same rendition as a block',
  collectionItem.gallery[0].clipUrl === PLAYBACK &&
    collectionItem.slug === 'spring-retreat',
);

// Gallery draws its items' URL field as written (KiteImage leaves a non-image
// URL alone), standing in for a generated block with a plain <video src>: the
// rendition can only appear here if the renderer rewrote the block's data.
const rendered = renderToStaticMarkup(
  <RenderBlocks
    blocks={[
      { blockType: 'gallery', images: [{ imageUrl: VIDEO, alt: 'Clip' }] },
      {
        blockType: 'hero',
        heading: 'Welcome',
        imageUrl: VIDEO,
        primaryCtaLabel: 'Download the film',
        primaryCtaHref: VIDEO,
      },
    ]}
  />,
);
check(
  'the block renderer hands blocks the rendition, never the original, as a field value',
  JSON.stringify(
    [...rendered.matchAll(/<img [^>]*src="([^"]*)"/g)].map((m) => m[1]),
  ) === JSON.stringify([PLAYBACK]),
);
check(
  'a hero CTA linking to the uploaded video links to the rendition',
  rendered.includes(`href="${PLAYBACK}"`) &&
    !rendered.includes(`href="${VIDEO}"`),
);
check(
  'a rewritten hero video still falls back to the original',
  JSON.stringify(
    [...rendered.matchAll(/<source src="([^"]*)"/g)].map((m) => m[1]),
  ) === JSON.stringify([PLAYBACK, VIDEO]),
);

if (failures > 0) {
  console.error(`\n${failures} image delivery check(s) failed`);
  process.exit(1);
}
console.log('\nimage delivery contract OK');
