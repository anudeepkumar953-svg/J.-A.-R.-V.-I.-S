import config from '@payload-config';
import { getPayload } from 'payload';

import { SITE_SETTINGS_TAG, cmsCached } from './cms-cache';
import type { SiteSeo } from './site-seo';

/**
 * The site settings the head and structured data read (`SiteSeo`): brand,
 * logo, social links, contact details and the default SEO a page does not set
 * itself.
 *
 * Its own read rather than a prop threaded down from the layout:
 * `generateMetadata` runs outside the layout's render, and Next gives it no
 * access to it. It is a second read of the same global, not a shared one —
 * `unstable_cache` keys on the callback as well as the key parts, so this
 * entry is separate from the layout's. Sharing the same tag is what matters:
 * one revalidation clears both, and neither can serve the other's stale copy.
 *
 * Never throws. Metadata is not worth a 500: a page with no og:image renders,
 * a page that fails to render does not.
 *
 * Only the fields `SiteSeo` names are kept, so the cached entry stays small.
 */
export const seoDefaults = cmsCached(
  async () => {
    try {
      const payload = await getPayload({ config });
      const settings = await payload.findGlobal({ slug: 'site-settings' });
      if (!settings) return null;
      const seo: SiteSeo = {
        brandName: settings.brandName,
        logoUrl: settings.logoUrl,
        colors: settings.colors,
        footer: { tagline: settings.footer?.tagline },
        socialLinks: settings.socialLinks,
        contact: settings.contact,
        defaultSeo: settings.defaultSeo,
      };
      return seo;
    } catch {
      return null;
    }
  },
  ['site-seo'],
  [SITE_SETTINGS_TAG],
);
