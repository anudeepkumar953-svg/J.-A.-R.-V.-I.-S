import type { BasePayload } from 'payload';
import type { Page, PageProposal } from '../payload-types';

// The one exception to hiding proposals: a signed-in editor previewing one
// from the AI tab. Inside a draft a proposal is a `proposed` Pages row; on
// Main it lives in `page-proposals` (see that collection for why). The Local
// API skips access control, so the session check here is the only guard, and
// the caller must never cache the result — a cached proposal would reach
// every visitor.
export async function findProposalForEditor(
  payload: BasePayload,
  headers: Headers,
  slug: string,
): Promise<{ kind: 'page'; doc: Page } | null> {
  if (!(await isEditor(payload, headers))) return null;
  const doc = await findProposal(payload, slug);
  return doc ? { kind: 'page', doc } : null;
}

/**
 * What the AI tab's preview route shows a signed-in editor at `slug`: the page
 * already added there, which the tab keeps previewing after Add and after the
 * draft merges, or else the proposal. The order the site's own catch-all
 * uses. Anyone else gets nothing. Never cache the result, for the same reason
 * as `findProposalForEditor`.
 */
export async function findPreviewPageForEditor(
  payload: BasePayload,
  headers: Headers,
  slug: string,
): Promise<Page | null> {
  if (!(await isEditor(payload, headers))) return null;
  // One round trip for both Pages rows and Main's proposal: each read pays
  // the database's latency.
  const [pages, proposals] = await Promise.all([
    payload.find({
      collection: 'pages',
      where: { slug: { equals: slug } },
      limit: 2,
    }),
    payload.find({
      collection: 'page-proposals',
      where: { slug: { equals: slug } },
      limit: 1,
    }),
  ]);
  const proposal = proposals.docs[0];
  return (
    pages.docs.find((page) => page.proposed !== true) ??
    pages.docs.find((page) => page.proposed === true) ??
    (proposal ? asPage(proposal) : null)
  );
}

/** The slug a preview URL's path segments name: none is the home page. */
export function previewSlug(segments: string[] | undefined): string {
  return segments?.length ? segments.join('/') : 'home';
}

async function isEditor(
  payload: BasePayload,
  headers: Headers,
): Promise<boolean> {
  const { user } = await payload.auth({ headers });
  return Boolean(user);
}

async function findProposal(
  payload: BasePayload,
  slug: string,
): Promise<Page | null> {
  const page = await payload.find({
    collection: 'pages',
    where: {
      and: [{ slug: { equals: slug } }, { proposed: { equals: true } }],
    },
    limit: 1,
  });
  if (page.docs[0]) return page.docs[0];
  const proposal = await payload.find({
    collection: 'page-proposals',
    where: { slug: { equals: slug } },
    limit: 1,
  });
  const doc = proposal.docs[0];
  return doc ? asPage(doc) : null;
}

// Rendered exactly like a page: the renderer reads title, slug, layout,
// related pages and seo, which a proposal stores in the Pages shape.
function asPage(doc: PageProposal): Page {
  return {
    id: doc.id,
    title: doc.title,
    slug: doc.slug,
    layout: doc.layout,
    relatedPages: doc.relatedPages,
    seo: doc.seo,
    proposed: true,
    updatedAt: doc.updatedAt,
    createdAt: doc.createdAt,
  };
}
