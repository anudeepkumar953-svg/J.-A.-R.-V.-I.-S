import { CMS_CONTENT_TAG, cmsCached } from './cms-cache';
import { contentCollectionSlugs, findPublishedItems } from './related';
import { ADDED_PAGES_ONLY } from '../payload/proposals';

// Every slug the catch-all route can serve, read once and cached under the
// content tag, so a URL that matches no document is not found without a
// database read. Without it each new unknown URL costs a page lookup plus one
// per content collection, and random URLs never repeat.

// Next's data cache refuses items over 2 MB and the read then runs uncached on
// every request; 1 MB of serialised slugs (tens of thousands of documents)
// leaves room for the envelope. A bigger site falls back to per-slug lookups.
export const KNOWN_SLUGS_MAX_BYTES = 1_000_000;

const BATCH_SIZE = 500;

// `tooLarge` means "unknown": the list cannot decide whether a slug exists.
export type KnownSlugs = { slugs: string[] } | { tooLarge: true };

/**
 * Collect slugs from `batches` until they run out or the serialised list would
 * pass `maxBytes`. Stops pulling batches as soon as the cap is crossed, so an
 * oversized site does not read the rest of its documents for nothing.
 */
export async function collectKnownSlugs(
  batches: AsyncIterable<ReadonlyArray<string | null | undefined>>,
  maxBytes: number = KNOWN_SLUGS_MAX_BYTES,
): Promise<KnownSlugs> {
  const slugs: string[] = [];
  // Bytes of `JSON.stringify({ slugs })`, which is what the cache stores.
  let bytes = Buffer.byteLength(JSON.stringify({ slugs: [] }));
  for await (const batch of batches) {
    for (const slug of batch) {
      // A document with no slug is unreachable by URL.
      if (!slug) continue;
      bytes += Buffer.byteLength(JSON.stringify(slug)) + (slugs.length ? 1 : 0);
      if (bytes > maxBytes) return { tooLarge: true };
      slugs.push(slug);
    }
  }
  return { slugs };
}

/**
 * Build `slugMayExist(slug)`: false only when a complete slug list was loaded
 * and does not contain `slug`. A disabled gate, an oversized list or a failed
 * load all answer true, leaving the decision to the per-slug lookup. `load`
 * must throw on failure rather than return an empty list, so the failure is
 * never cached as "nothing exists".
 */
export function makeSlugGate({
  load,
  enabled,
}: {
  load: () => Promise<KnownSlugs>;
  enabled: boolean;
}): (slug: string) => Promise<boolean> {
  return async (slug) => {
    if (!enabled) return true;
    let known: KnownSlugs;
    try {
      known = await load();
    } catch (error) {
      console.warn('[known-slugs] slug list read failed', error);
      return true;
    }
    if ('tooLarge' in known) return true;
    // Exact match: the per-slug lookup compares the raw joined route param
    // with `equals`, so any normalisation here would disagree with it.
    return known.slugs.includes(slug);
  };
}

// Keyset-paged reads of every routable slug: all `pages` (the lookup applies
// no status filter to pages) and the published items of each content
// collection (through `findPublishedItems`, the same filter the lookup uses).
async function* routableSlugBatches(): AsyncGenerator<
  ReadonlyArray<string | null | undefined>
> {
  // Imported here so the pure part above loads without the Payload config.
  const [{ getPayload }, { default: config }] = await Promise.all([
    import('payload'),
    import('@payload-config'),
  ]);
  const payload = await getPayload({ config });

  let lastId: number | string | undefined;
  for (;;) {
    const res = await payload.find({
      collection: 'pages',
      where:
        lastId === undefined
          ? ADDED_PAGES_ONLY
          : { and: [ADDED_PAGES_ONLY, { id: { greater_than: lastId } }] },
      sort: 'id',
      limit: BATCH_SIZE,
      pagination: false,
      depth: 0,
      select: { slug: true },
    });
    yield res.docs.map((doc) => doc.slug);
    if (res.docs.length < BATCH_SIZE) break;
    lastId = res.docs[res.docs.length - 1].id;
  }

  for (const collection of contentCollectionSlugs) {
    let lastItemId: number | string | undefined;
    for (;;) {
      const docs = await findPublishedItems(payload, collection, {
        where:
          lastItemId === undefined ? {} : { id: { greater_than: lastItemId } },
        sort: 'id',
        limit: BATCH_SIZE,
        select: { slug: true },
      });
      yield docs.map((doc) => doc.slug);
      if (docs.length < BATCH_SIZE) break;
      lastItemId = docs[docs.length - 1].id;
    }
  }
}

// Tagged like the content it mirrors, so a save that adds a page or item
// refreshes the list together with the lookups. A thrown read is not cached.
const loadKnownSlugs = cmsCached(
  () => collectKnownSlugs(routableSlugBatches()),
  ['known-slugs'],
  [CMS_CONTENT_TAG],
);

// Off outside production: `cmsCached` does not cache there, so the list would
// be a full read on every lookup, and seeding flows check pages right after
// writing them.
export const slugMayExist = makeSlugGate({
  load: loadKnownSlugs,
  enabled: process.env.NODE_ENV === 'production',
});
