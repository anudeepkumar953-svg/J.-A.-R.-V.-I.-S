// Contract for the negative cache in front of the catch-all lookup
// (lib/known-slugs.ts). It may only answer "this slug does not exist" when it
// holds a complete list; any doubt (an oversized site, a failed read, dev) must
// fall back to the per-slug lookup, or real pages 404. And it must compare
// slugs exactly as that lookup does, or it disagrees with it about which URLs
// exist.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml). Exits non-zero on
// any failure.
//
// Run locally: pnpm exec tsx src/lib/known-slugs.test.ts

import {
  KNOWN_SLUGS_MAX_BYTES,
  type KnownSlugs,
  collectKnownSlugs,
  makeSlugGate,
} from './known-slugs';

let failures = 0;
function check(name: string, condition: boolean, detail = ''): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

// Batches as the Payload reads yield them, counting how many were read.
function batches(
  list: ReadonlyArray<ReadonlyArray<string | null | undefined>>,
) {
  const read = { count: 0 };
  async function* gen() {
    for (const batch of list) {
      read.count++;
      yield batch;
    }
  }
  return { iterable: gen(), read };
}

async function gateFor(
  slugs: ReadonlyArray<ReadonlyArray<string | null | undefined>>,
  maxBytes?: number,
) {
  const known = await collectKnownSlugs(batches(slugs).iterable, maxBytes);
  return makeSlugGate({ load: async () => known, enabled: true });
}

console.log('a complete list decides');
{
  const mayExist = await gateFor([
    ['home', 'about', null, ''],
    [undefined, 'blog/first-post', 'café'],
  ]);
  check('a listed page may exist', await mayExist('home'));
  check('a listed item may exist', await mayExist('blog/first-post'));
  check('a later batch is included', await mayExist('café'));
  check('an unlisted slug does not exist', !(await mayExist('nope')));
  check('an empty slug is never listed', !(await mayExist('')));
}

console.log('slugs compare exactly, as the per-slug lookup does');
{
  const mayExist = await gateFor([['home', 'café', 'a b']]);
  check('case differs → absent', !(await mayExist('Home')));
  check('trailing space → absent', !(await mayExist('home ')));
  check('percent-encoded form → absent', !(await mayExist('caf%C3%A9')));
  check('raw form with a space → present', await mayExist('a b'));
  check('prefix of a slug → absent', !(await mayExist('hom')));
}

console.log('a site with no documents');
{
  const mayExist = await gateFor([]);
  check('every slug is absent', !(await mayExist('home')));
}

console.log('a list over the byte cap is unknown, and reading stops');
{
  const many = Array.from({ length: 100 }, (_, i) => `page-${i}`);
  const source = batches([many, many, many]);
  const known = await collectKnownSlugs(source.iterable, 500);
  check('over the cap → too large', 'tooLarge' in known);
  check('stops before reading the remaining batches', source.read.count === 1);
  const mayExist = makeSlugGate({ load: async () => known, enabled: true });
  check('any slug may exist', await mayExist('not-in-any-batch'));

  // The cap bounds what the cache stores, so it is measured on the
  // serialised value.
  const fits = await collectKnownSlugs(batches([many]).iterable, 10_000);
  check(
    'a list under the cap serialises within it',
    !('tooLarge' in fits) && JSON.stringify(fits).length <= 10_000,
  );
  const exact = Buffer.byteLength(JSON.stringify({ slugs: many }));
  const atCap = await collectKnownSlugs(batches([many]).iterable, exact);
  const underCap = await collectKnownSlugs(batches([many]).iterable, exact - 1);
  check('a list exactly at the cap fits', !('tooLarge' in atCap));
  check('one byte under it does not', 'tooLarge' in underCap);
  check(
    'the default cap stays under the 2 MB data-cache item limit',
    KNOWN_SLUGS_MAX_BYTES < 2 * 1024 * 1024,
  );
}

console.log('a failed read falls back to the per-slug lookup');
{
  let attempts = 0;
  const mayExist = makeSlugGate({
    load: async (): Promise<KnownSlugs> => {
      attempts++;
      if (attempts === 1) throw new Error('database unreachable');
      return { slugs: ['home'] };
    },
    enabled: true,
  });
  const warn = console.warn;
  console.warn = () => {};
  const duringFailure = await mayExist('anything');
  console.warn = warn;
  check('any slug may exist while the read fails', duringFailure);
  check('the next successful read decides', !(await mayExist('anything')));
  check('…and still finds listed slugs', await mayExist('home'));
}

console.log('disabled outside production');
{
  let loads = 0;
  const mayExist = makeSlugGate({
    load: async () => {
      loads++;
      return { slugs: [] };
    },
    enabled: false,
  });
  check('any slug may exist', await mayExist('anything'));
  check('no list is read', loads === 0);
}

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`);
  process.exit(1);
}
console.log('\nall checks passed');
