// Contract for the metadata surface of both document kinds the catch-all route
// serves (V2-6704). Every URL of a migrated site is a `Pages` doc, and the
// original pages branch emitted only title/description/noindex — no canonical,
// no OG/Twitter, no JSON-LD, no carried robots. This script pins the repaired
// contract: self-referential canonical with a per-page override, source robots
// carried verbatim under the noindex switch, and stored JSON-LD returned
// verbatim. It pins the site-level fallbacks too: a stored value always wins
// and is served as written; the brand suffix is added once; a missing
// description comes from the page's own text, then the site default; a missing
// share image is the site default, then the generated brand card; and with no
// site settings nothing is invented. It also pins the content-collection item
// surface, whose emitted metadata must resolve its URLs against the same
// origin app/sitemap.ts judges them against.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml, like the
// platform-token forge contract). Exits non-zero on any failure.
//
// Run locally: pnpm exec tsx src/lib/page-metadata.test.ts

import {
  canonicalPointsElsewhere,
  describeFromText,
  itemMetadata,
  itemUrl,
  jsonLdScriptHtml,
  pageInSitemap,
  pageJsonLdBlocks,
  pageMetadata,
  pageUrl,
  robotsDeclaresNoindex,
} from './page-metadata';
import type { Metadata } from 'next';
import type { Page } from '../payload-types';
import type { ContentItem } from './related';
import {
  type SiteSeo,
  brandedTitle,
  generatedOgImageUrl,
  layoutMetadata,
} from './site-seo';

const BASE = 'https://example-site.kite.space';

function makePage(overrides: Partial<Page> = {}): Page {
  return {
    id: 1,
    title: 'About',
    slug: 'about',
    updatedAt: '2026-08-14T00:00:00.000Z',
    createdAt: '2026-08-14T00:00:00.000Z',
    ...overrides,
  };
}

let failures = 0;
function check(name: string, condition: boolean): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}`);
  }
}

// --- canonical -------------------------------------------------------------

const bare = pageMetadata(makePage(), BASE);
check(
  'canonical is self-referential on the deployed origin',
  bare.alternates?.canonical === `${BASE}/about`,
);
check(
  'home canonicalizes to the bare origin, the same string the sitemap emits',
  pageMetadata(makePage({ slug: 'home' }), BASE).alternates?.canonical === BASE,
);
check(
  'nested slugs keep their full path',
  pageUrl(BASE, 'services/flooring-installation') ===
    `${BASE}/services/flooring-installation`,
);
const overridden = pageMetadata(
  makePage({ seo: { canonicalUrl: 'https://elsewhere.example/about' } }),
  BASE,
);
check(
  'a seeded canonical override survives',
  overridden.alternates?.canonical === 'https://elsewhere.example/about',
);
check(
  'og:url follows the canonical override',
  overridden.openGraph?.url === 'https://elsewhere.example/about',
);

// --- OG / Twitter with no site settings: nothing invented -----------------

check('og title comes from the page title', bare.openGraph?.title === 'About');
check(
  'og description absent when the page has no text and no site default',
  bare.openGraph?.description === undefined && bare.description === undefined,
);
check(
  'no og image without a page image or site settings',
  (bare.openGraph as { images?: unknown })?.images === undefined,
);
check(
  'no twitter image without a page image or site settings',
  (bare.twitter as { images?: unknown })?.images === undefined,
);
check(
  'twitter card is a plain summary without an image',
  (bare.twitter as { card?: string })?.card === 'summary',
);
const withSeo = pageMetadata(
  makePage({
    seo: {
      title: 'About us — Acme',
      description: 'What Acme does.',
      ogImageUrl: 'https://cdn.example/acme.png',
    },
  }),
  BASE,
);
check(
  'seo title wins over the page title',
  withSeo.openGraph?.title === 'About us — Acme',
);
check(
  'description flows into OG',
  withSeo.openGraph?.description === 'What Acme does.',
);
check(
  'an explicit OG image is used',
  JSON.stringify((withSeo.openGraph as { images?: unknown })?.images) ===
    JSON.stringify([{ url: 'https://cdn.example/acme.png' }]),
);
check(
  'metadataBase is the deployed origin',
  bare.metadataBase instanceof URL && bare.metadataBase.origin === BASE,
);

// --- robots ----------------------------------------------------------------

check('no robots emitted when none stored', bare.robots === undefined);
check(
  'source robots directives are carried verbatim',
  pageMetadata(makePage({ seo: { robots: 'max-image-preview:large' } }), BASE)
    .robots === 'max-image-preview:large',
);
check(
  'the noindex switch keeps carried directives, prepending noindex',
  pageMetadata(
    makePage({ seo: { noindex: true, robots: 'max-image-preview:large' } }),
    BASE,
  ).robots === 'noindex, max-image-preview:large',
);
check(
  'a source robots string already declaring noindex is served verbatim',
  pageMetadata(
    makePage({
      seo: { noindex: true, robots: 'noindex, follow, noarchive' },
    }),
    BASE,
  ).robots === 'noindex, follow, noarchive',
);
check(
  'the noindex switch alone keeps the structured form',
  JSON.stringify(
    pageMetadata(makePage({ seo: { noindex: true } }), BASE).robots,
  ) === JSON.stringify({ index: false, follow: false }),
);
check(
  'robotsDeclaresNoindex matches the token, not a substring',
  robotsDeclaresNoindex('noindex, follow') &&
    robotsDeclaresNoindex('NOINDEX') &&
    !robotsDeclaresNoindex('max-image-preview:large') &&
    !robotsDeclaresNoindex('nonoindexy'),
);
check(
  'robots "none" means noindex',
  robotsDeclaresNoindex('none') && robotsDeclaresNoindex('none, noarchive'),
);

// --- sitemap membership: one decision, shared with app/sitemap.ts ----------

check('a plain page is advertised', pageInSitemap(makePage(), BASE));
check(
  'the noindex switch withdraws a page',
  !pageInSitemap(makePage({ seo: { noindex: true } }), BASE),
);
check(
  'carried robots noindex withdraws a page',
  !pageInSitemap(makePage({ seo: { robots: 'noindex, follow' } }), BASE),
);
check(
  'carried robots "none" withdraws a page',
  !pageInSitemap(makePage({ seo: { robots: 'none' } }), BASE),
);
check(
  'benign carried directives keep a page advertised',
  pageInSitemap(makePage({ seo: { robots: 'max-image-preview:large' } }), BASE),
);
check(
  'a canonical override pointing elsewhere withdraws a page',
  !pageInSitemap(
    makePage({ seo: { canonicalUrl: 'https://elsewhere.example/about' } }),
    BASE,
  ),
);
check(
  'a redundant self-canonical keeps a page advertised',
  pageInSitemap(makePage({ seo: { canonicalUrl: `${BASE}/about/` } }), BASE) &&
    pageInSitemap(
      makePage({ slug: 'home', seo: { canonicalUrl: `${BASE}/` } }),
      BASE,
    ),
);
// A stored canonical may be relative: `pageMetadata` sets `metadataBase`, so
// Next resolves `/about` in the served head to the page's own absolute URL. The
// sitemap decision must resolve it the same way or the head and the sitemap
// contradict each other (D1-F7).
check(
  'a RELATIVE self-canonical keeps a page advertised',
  pageInSitemap(makePage({ seo: { canonicalUrl: '/about' } }), BASE),
);
check(
  'a relative canonical pointing at another path withdraws a page',
  !pageInSitemap(makePage({ seo: { canonicalUrl: '/services' } }), BASE),
);
check(
  'an override that will not parse withdraws a page',
  !pageInSitemap(makePage({ seo: { canonicalUrl: 'https://' } }), BASE),
);

// The same decision on the OTHER document kind. A content-collection item keeps
// its override at the TOP level (`canonicalUrl`, from payload/collectionMeta.ts)
// rather than nested under `seo`, and renders at `/<slug>` — app/sitemap.ts
// feeds those two values in (D1-F8).
const itemUrlFor = (slug: string) => `${BASE}/${slug}`;
check(
  'an item canonicalizing elsewhere is excluded from the sitemap',
  canonicalPointsElsewhere(
    'https://medium.example/syndicated-post',
    itemUrlFor('my-post'),
    BASE,
  ),
);
check(
  'an item with a redundant self-canonical stays in the sitemap',
  !canonicalPointsElsewhere(`${BASE}/my-post`, itemUrlFor('my-post'), BASE) &&
    !canonicalPointsElsewhere('/my-post', itemUrlFor('my-post'), BASE) &&
    !canonicalPointsElsewhere(null, itemUrlFor('my-post'), BASE),
);

// --- content-collection items: one origin with the sitemap -----------------

// The item branch of `generateMetadata` builds its own metadata surface, and a
// stored `canonicalUrl` or `ogImageUrl` may be written RELATIVE. Next resolves
// those against the emitted `metadataBase`, while app/sitemap.ts judges the
// same stored string against `getBaseUrl()` — so the two contradict each other
// unless the item's metadata carries that origin. These checks therefore assert
// the RESOLVED absolute URL, which is what a reader of the served head sees.
function makeItem(overrides: Partial<ContentItem> = {}): ContentItem {
  return { id: 1, title: 'My Post', slug: 'my-post', ...overrides };
}

// Resolve one URL out of a metadata object exactly as a consumer of the head
// would. Metadata that cannot resolve its own URLs — the regression these
// checks exist for — reports a failed check instead of aborting the script.
function resolvedIn(md: Metadata, value: unknown): string {
  try {
    return new URL(String(value), md.metadataBase ?? undefined).href;
  } catch {
    return 'unresolvable';
  }
}

const bareItem = itemMetadata(makeItem(), BASE, 'article');
check(
  'an item with no override canonicalizes to its own URL on the deployed origin',
  resolvedIn(bareItem, bareItem.alternates?.canonical) === `${BASE}/my-post`,
);
const relativeItem = itemMetadata(
  makeItem({ canonicalUrl: '/my-post', ogImageUrl: '/img/cover.png' }),
  BASE,
  'article',
);
check(
  "an item's relative self-canonical resolves to the URL the sitemap judges it against",
  resolvedIn(relativeItem, relativeItem.alternates?.canonical) ===
    `${BASE}/my-post` &&
    !canonicalPointsElsewhere('/my-post', itemUrl(BASE, 'my-post'), BASE),
);
check(
  "an item's relative OG image resolves onto the deployed origin",
  resolvedIn(
    relativeItem,
    (relativeItem.openGraph as { images?: { url: string }[] })?.images?.[0]
      ?.url,
  ) === `${BASE}/img/cover.png`,
);
const syndicatedItem = itemMetadata(
  makeItem({ canonicalUrl: 'https://medium.example/syndicated-post' }),
  BASE,
  'article',
);
check(
  "an item's absolute canonical override reaches the head untouched",
  syndicatedItem.alternates?.canonical ===
    'https://medium.example/syndicated-post' &&
    resolvedIn(syndicatedItem, syndicatedItem.alternates?.canonical) ===
      'https://medium.example/syndicated-post',
);

// --- JSON-LD: verbatim round-trip ------------------------------------------

// A realistic seeded block: real-world assertions (address, phone, hours) that
// must round-trip exactly — never be regenerated or approximated.
const localBusiness = {
  '@context': 'https://schema.org',
  '@type': 'LocalBusiness',
  name: 'Example Flooring Co.',
  telephone: '+1-555-010-0100',
  address: {
    '@type': 'PostalAddress',
    streetAddress: '123 Main St',
    addressLocality: 'Oswego',
  },
  openingHours: 'Mo-Fr 09:00-17:00',
};
const nav = { '@type': 'SiteNavigationElement', name: 'Home', url: '/' };

check('no JSON-LD when none stored', pageJsonLdBlocks(makePage()).length === 0);
check(
  'a stored array round-trips verbatim',
  JSON.stringify(
    pageJsonLdBlocks(makePage({ seo: { jsonLd: [localBusiness, nav] } })),
  ) === JSON.stringify([localBusiness, nav]),
);
check(
  'a single stored object is served as one block',
  JSON.stringify(
    pageJsonLdBlocks(makePage({ seo: { jsonLd: localBusiness } })),
  ) === JSON.stringify([localBusiness]),
);
check(
  'JSON text stored by the admin editor round-trips as blocks',
  JSON.stringify(
    pageJsonLdBlocks(
      makePage({ seo: { jsonLd: JSON.stringify([localBusiness, nav]) } }),
    ),
  ) === JSON.stringify([localBusiness, nav]),
);
check(
  'unparseable JSON text yields no blocks',
  pageJsonLdBlocks(makePage({ seo: { jsonLd: 'not json {' } })).length === 0,
);
const escaped = jsonLdScriptHtml({ name: 'x</script><script>alert(1)' });
check('script HTML contains no raw "<"', !escaped.includes('<'));
check(
  'escaped JSON parses back to the identical value',
  (JSON.parse(escaped) as { name: string }).name ===
    'x</script><script>alert(1)',
);

// --- verdict ---------------------------------------------------------------

// A classic site declares its og:image once, in a root layout, and every page
// inherits it. Payload stores SEO per page, so a migration that reads only
// `page.seo` drops that image from every page — and no per-page edit restores
// it, because the value lives in a file no page names. Measured: 32 migrated
// pages each reporting "og:image is None" and "twitter:card is 'summary'".
const SITE_OG = {
  brandName: 'Acme',
  defaultSeo: { ogImageUrl: 'https://static.example/site-og.png' },
};

const inherited = pageMetadata(makePage(), BASE, SITE_OG);
check(
  'a page with no og:image of its own inherits the site default',
  (inherited.openGraph?.images as { url: string }[] | undefined)?.[0]?.url ===
    SITE_OG.defaultSeo.ogImageUrl,
);
check(
  'and its twitter card follows the inherited image',
  (inherited.twitter as { card?: string })?.card === 'summary_large_image',
);

const ownImage = pageMetadata(
  makePage({ seo: { ogImageUrl: 'https://cdn.example/this-page.png' } }),
  BASE,
  SITE_OG,
);
check(
  'a page that sets its own og:image still wins over the site default',
  (ownImage.openGraph?.images as { url: string }[] | undefined)?.[0]?.url ===
    'https://cdn.example/this-page.png',
);

check(
  'no settings and no page image is still a plain summary',
  (pageMetadata(makePage(), BASE, null).twitter as { card?: string })?.card ===
    'summary',
);

// --- share image: page, then site default, then the generated card ----------

const ogUrl = (md: Metadata) =>
  (md.openGraph?.images as { url: string }[] | undefined)?.[0]?.url;
const BRAND: SiteSeo = {
  brandName: 'Acme',
  colors: { primary: '#0f172a', accent: '#6366f1' },
  footer: { tagline: 'Floors that last.' },
};
const generated = pageMetadata(makePage(), BASE, BRAND);
check(
  'with no page image and no site default, the generated card is used',
  ogUrl(generated)?.startsWith(`${BASE}/og-image.png?v=`) === true &&
    (generated.twitter as { card?: string })?.card === 'summary_large_image' &&
    (generated.twitter as { images?: string[] })?.images?.[0] ===
      ogUrl(generated),
);
check(
  'the generated card URL is absolute on the published origin',
  new URL(ogUrl(generated)!).origin === BASE,
);
check(
  'the generated card URL changes when what it shows changes',
  generatedOgImageUrl(BASE, BRAND) !==
    generatedOgImageUrl(BASE, { ...BRAND, brandName: 'Acme Floors' }) &&
    generatedOgImageUrl(BASE, BRAND) === generatedOgImageUrl(BASE, BRAND),
);
check(
  'a site default image wins over the generated card',
  ogUrl(
    pageMetadata(makePage(), BASE, {
      ...BRAND,
      defaultSeo: { ogImageUrl: 'https://cdn.example/default.png' },
    }),
  ) === 'https://cdn.example/default.png',
);
check(
  'a site with no brand name gets no generated card',
  generatedOgImageUrl(BASE, { brandName: '' }) === null &&
    ogUrl(pageMetadata(makePage(), BASE, { brandName: ' ' })) === undefined,
);

// --- title template: the brand once ----------------------------------------

check(
  'a page title gains the brand suffix',
  pageMetadata(makePage(), BASE, BRAND).title === 'About | Acme',
);
check(
  'og and twitter titles carry the same branded title',
  generated.openGraph?.title === 'About | Acme' &&
    (generated.twitter as { title?: string })?.title === 'About | Acme',
);
// Real stored titles that already name the brand (talentism.com, 2026-10-05,
// and the cms-management golden seed): none may gain it again.
for (const [stored, brand] of [
  [
    'Who We Are | Talentism | Leadership Advisory for Hyper-Growth',
    'Talentism',
  ],
  ['Then One Day, I Was Just Like my Boss | Talentism Podcast', 'Talentism'],
  ['Talentism | Executive Coaching &amp; Leadership Advisory', 'Talentism'],
  ['Northwind Studio — Home', 'Northwind Studio'],
  ['northwind studio pricing', 'Northwind  Studio'],
  ['Smith &amp; Co — Contact', 'Smith & Co'],
] as const) {
  check(
    `a stored title naming the brand is served as written: "${stored}"`,
    pageMetadata(makePage({ seo: { title: stored } }), BASE, {
      brandName: brand,
    }).title === stored,
  );
}
check(
  'the brand counts only as a whole word in the title',
  brandedTitle('Kitesurfing lessons', 'Kite') ===
    'Kitesurfing lessons | Kite' &&
    brandedTitle('Fly with Kite.', 'Kite') === 'Fly with Kite.' &&
    brandedTitle('Blooming gardens', 'Bloom') === 'Blooming gardens | Bloom',
);
check(
  'a stored title without the brand gains it once',
  pageMetadata(makePage({ seo: { title: 'About us' } }), BASE, BRAND).title ===
    'About us | Acme',
);
check(
  'the suffix is applied once, never to an already-suffixed title',
  brandedTitle(brandedTitle('About', 'Acme'), 'Acme') === 'About | Acme',
);
check(
  'with no brand the title is served as written',
  pageMetadata(makePage(), BASE, null).title === 'About',
);
check(
  'a home page with no stored title uses the site default title',
  pageMetadata(makePage({ slug: 'home', title: 'Home' }), BASE, {
    brandName: 'Acme',
    defaultSeo: { title: 'Acme — Hardwood floors in Oswego' },
  }).title === 'Acme — Hardwood floors in Oswego',
);
check(
  'a home page with no stored title and no site title is "Home | Brand"',
  pageMetadata(makePage({ slug: 'home', title: 'Home' }), BASE, BRAND).title ===
    'Home | Acme',
);
check(
  'an inner page never takes the site default title',
  pageMetadata(makePage(), BASE, {
    brandName: 'Acme',
    defaultSeo: { title: 'Acme — Floors' },
  }).title === 'About | Acme',
);

// --- description: stored, then the page's text, then the site default --------

const hero = (subheading: string) => ({
  blockType: 'hero' as const,
  heading: 'Floors that last',
  subheading,
});
const longCopy =
  'We install hardwood, laminate and tile floors across Oswego County, with a ' +
  'written ten-year guarantee on every job and same-week quotes for homes and ' +
  'small businesses alike.';
const derived = pageMetadata(
  makePage({ layout: [hero(longCopy)] }),
  BASE,
  BRAND,
);
check(
  'a page with no stored description gets one from its own text',
  typeof derived.description === 'string' &&
    longCopy.startsWith(derived.description.replace(/…$/, '')),
);
check(
  'the derived description fits a search result and ends on a word',
  typeof derived.description === 'string' &&
    derived.description.length <= 160 &&
    derived.description.endsWith('…') &&
    !/\s…$/.test(derived.description),
);
check(
  'the derived description flows into OG and Twitter',
  derived.openGraph?.description === derived.description &&
    (derived.twitter as { description?: string })?.description ===
      derived.description,
);
check(
  'a stored description is served as written, even over 160 characters',
  pageMetadata(
    makePage({
      seo: { description: `${longCopy} ${longCopy}` },
      layout: [hero('Other words entirely, long enough to count as text.')],
    }),
    BASE,
    BRAND,
  ).description === `${longCopy} ${longCopy}`,
);
check(
  'headings, testimonials and FAQ answers are not the description',
  pageMetadata(
    makePage({
      layout: [
        {
          blockType: 'hero',
          heading: 'A heading long enough to be counted here',
        },
        {
          blockType: 'testimonialList',
          testimonials: [
            {
              quote: 'Best floor company in the whole county, by far.',
              authorName: 'A',
            },
          ],
        },
        {
          blockType: 'faq',
          items: [
            {
              question: 'Q?',
              answer: 'An answer that is long enough to count as prose.',
            },
          ],
        },
      ],
    }),
    BASE,
    null,
  ).description === undefined,
);
check(
  'rich text paragraphs count as page text',
  describeFromText([
    'Short.',
    'A rich-text paragraph that describes the page well.',
  ]) === 'A rich-text paragraph that describes the page well.' &&
    pageMetadata(
      makePage({
        layout: [
          {
            blockType: 'richText',
            content: {
              root: {
                type: 'root',
                children: [
                  {
                    type: 'paragraph',
                    children: [
                      {
                        type: 'text',
                        text: 'Our story began in 1998 in a garage ',
                      },
                      { type: 'text', text: 'with two saws and a van.' },
                    ],
                  },
                ],
              },
            },
          } as unknown as NonNullable<Page['layout']>[number],
        ],
      }),
      BASE,
      null,
    ).description ===
      'Our story began in 1998 in a garage with two saws and a van.',
);
check(
  'segments are joined in reading order until there is enough',
  describeFromText([
    'We build kitchens in Leeds',
    'Every cabinet is made to measure in our own workshop!',
  ]) ===
    'We build kitchens in Leeds. Every cabinet is made to measure in our own workshop!',
);
check(
  'too little page text loses to the site default description',
  pageMetadata(
    makePage({ layout: [hero('Quality floors, fair prices.')] }),
    BASE,
    {
      brandName: 'Acme',
      defaultSeo: { description: 'Acme installs floors in Oswego County.' },
    },
  ).description === 'Acme installs floors in Oswego County.',
);
check(
  'with no site default, the little text there is still used',
  pageMetadata(
    makePage({ layout: [hero('Quality floors, fair prices.')] }),
    BASE,
    null,
  ).description === 'Quality floors, fair prices.',
);
check(
  'an empty stored description is treated as none',
  pageMetadata(makePage({ seo: { description: '  ' } }), BASE, {
    brandName: 'Acme',
    defaultSeo: { description: 'Site default.' },
  }).description === 'Site default.',
);

// --- items: the same fallbacks ----------------------------------------------

const itemWithText = itemMetadata(
  makeItem({ excerpt: longCopy }),
  BASE,
  'article',
  BRAND,
);
check(
  'an item title gains the brand suffix, and its seo title wins when set',
  itemWithText.title === 'My Post | Acme' &&
    itemMetadata(
      makeItem({ seoTitle: 'Acme guide to floors' }),
      BASE,
      'article',
      BRAND,
    ).title === 'Acme guide to floors',
);
check(
  'an item with no meta description gets one from its excerpt',
  typeof itemWithText.description === 'string' &&
    longCopy.startsWith(itemWithText.description.replace(/…$/, '')),
);
check(
  'an item with no image gets the generated card; its own image wins',
  ogUrl(itemWithText)?.startsWith(`${BASE}/og-image.png?v=`) === true &&
    ogUrl(
      itemMetadata(
        makeItem({ featuredImage: 'https://cdn.example/cover.png' }),
        BASE,
        'article',
        BRAND,
      ),
    ) === 'https://cdn.example/cover.png',
);

// --- layout defaults: what a hand-coded route or a not-found page shows -------

const layoutBare = layoutMetadata(null, BASE);
check(
  'with no readable settings the layout emits no title (never a placeholder)',
  layoutBare.title === undefined &&
    layoutBare.description === undefined &&
    layoutBare.openGraph === undefined,
);
const layoutBrand = layoutMetadata(
  {
    ...BRAND,
    defaultSeo: { title: 'Acme Floors', description: 'Floors in Oswego.' },
  },
  BASE,
);
check(
  'the layout title and description are the site defaults',
  layoutBrand.title === 'Acme Floors' &&
    layoutBrand.description === 'Floors in Oswego.',
);
const layoutRelative = layoutMetadata(
  { brandName: 'Acme', defaultSeo: { ogImageUrl: '/og.png' } },
  BASE,
);
check(
  'a relative site default image is made absolute on the site origin in the layout',
  (layoutRelative.openGraph?.images as { url: string }[] | undefined)?.[0]
    ?.url === `${BASE}/og.png` &&
    (layoutRelative.twitter as { images?: string[] })?.images?.[0] ===
      `${BASE}/og.png`,
);
check(
  'a site default image without a brand name still reaches og:image',
  (
    layoutMetadata(
      { defaultSeo: { ogImageUrl: 'https://cdn.example/og.png' } },
      BASE,
    ).openGraph?.images as { url: string }[] | undefined
  )?.[0]?.url === 'https://cdn.example/og.png',
);
check(
  'the layout title falls back to the brand name',
  layoutMetadata(BRAND, BASE).title === 'Acme',
);
check(
  'the layout carries the share image but no og:title of its own',
  (layoutBrand.openGraph?.images as { url: string }[] | undefined)?.[0]?.url ===
    generatedOgImageUrl(BASE, {
      ...BRAND,
      defaultSeo: { title: 'Acme Floors', description: 'Floors in Oswego.' },
    }) && layoutBrand.openGraph?.title === undefined,
);

if (failures > 0) {
  console.error(`${failures} check(s) failed`);
  process.exit(1);
}
console.log('page-metadata contract OK');
