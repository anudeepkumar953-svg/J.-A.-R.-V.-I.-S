import { cache } from 'react';
import { getPayload } from 'payload';
import config from '@payload-config';
import { SITE_SETTINGS_TAG, cmsCached } from './cms-cache';

// The one site-settings read, shared by the frontend layout and the cached
// catch-all page so both hit the same cache entry. Only a CMS save changes it,
// so it is cached in production and invalidated by the SiteSettings
// afterChange hook (see cms-cache.ts). React `cache()` makes the layout and the
// page share one read per render instead of racing two on a cold entry.
export const getSiteSettings = cache(
  cmsCached(
    async () => {
      const payload = await getPayload({ config });
      return payload.findGlobal({ slug: 'site-settings' });
    },
    ['site-settings'],
    [SITE_SETTINGS_TAG],
  ),
);
