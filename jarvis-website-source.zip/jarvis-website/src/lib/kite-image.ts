// Responsive delivery for images hosted on the platform CDN (static.kite.ai,
// a Cloudinary CNAME). A CMS image field holds the URL of the original upload,
// which is often a multi-megabyte PNG; the CDN serves a resized WebP/AVIF of it
// when the URL carries a transform segment after `/upload/`:
//
//   https://static.kite.ai/image/upload/c_limit,w_1080,f_auto,q_auto/v123/app/<id>/hero.png
//
// `c_limit` never upscales past the original, `f_auto,q_auto` negotiates the
// format and quality from the browser's Accept header. Any other URL — another
// host, a local `/public` path, an SVG (f_auto would rasterise it), a GIF, a
// video, or an upload whose author already chose a crop/trim/overlay — is
// returned unchanged: re-deriving those would either change how the image
// looks or chain a second derivation that the CDN's overwrite-invalidation
// never refreshes.
//
// Pure and request-independent, so it is safe on the cached catch-all page.
// The parsing rules mirror the platform frontend's Cloudinary helper.

const CDN_IMAGE_PREFIX = 'https://static.kite.ai/image/upload/';
const CDN_VIDEO_PREFIX = 'https://static.kite.ai/video/upload/';

// Raster formats the transform re-encodes without changing what the image is.
const RASTER_RE = /\.(?:png|jpe?g|webp|avif)$/i;
const VIDEO_RE = /\.(?:mp4|mov|webm|m4v|ogg)$/i;

// A segment ending in a media extension is the filename, never a transform,
// even when its stem looks like one (`e_sunset.png`).
const FILENAME_EXTENSION_RE =
  /\.(?:png|jpe?g|webp|svg|gif|avif|ico|bmp|tiff?|heic|heif|mp4|webm|mov|m4v|avi|mkv|ogv|mp3|wav|m4a|aac|flac|ogg|pdf)$/i;

// Closed set of transform keys, so underscored folder names such as
// `my_folder` stay part of the asset path.
const TRANSFORM_KEY_RE =
  /^(?:a|ac|af|ar|b|bo|br|c|dpr|du|e|eo|f|fl|fps|g|h|l|o|q|r|so|u|vc|w)_[^/]+/;

// A conditional transform segment (`if_ar_gt_1`, `if_else`, `if_end`), such as
// the one `kiteImageUrl` writes for a fixed box. Narrow, so a folder named
// `if_studio` stays part of the asset path.
const CONDITION_RE = /^if_(?:else|end|[a-z]+_(?:eq|ne|lt|gt|lte|gte)_[^/]+)$/;

// Transforms that only choose delivery size/format/quality. A URL carrying
// nothing else can have them replaced without changing what it shows.
const DELIVERY_PARAM_RE =
  /^(?:f_[a-z0-9]+|q_[a-z0-9:]+|vc_[a-z0-9:]+|w_\d+|c_limit|dpr_[\d.]+)$/;

// Widest rendition of a background video. A full-bleed hero sits under a dark
// overlay, so 1280px is enough on a desktop and still covers a 390-430px phone
// at 3x; a 1080p, 9-second hero measured 11.9 MB as uploaded, 3.1 MB
// re-encoded at full size and 1.7 MB at this width.
const VIDEO_MAX_WIDTH = 1280;

// srcset candidates for an image whose rendered width depends on the viewport:
// half-width images on phones, a full-width image on a 360px or a 390-430px
// phone at 3x, and a full-bleed desktop image. Every extra width is another
// derivation the CDN must create and cache per image.
export const RESPONSIVE_WIDTHS = [640, 1080, 1320, 1920] as const;

type ParsedCdnUrl = {
  prefix: string;
  transforms: string[];
  // Version segment (`v123`) plus the asset path, joined.
  asset: string;
};

function parseCdnUrl(url: string, prefix: string): ParsedCdnUrl | null {
  if (!url.startsWith(prefix) || /[?#]/.test(url)) return null;
  const segments = url.slice(prefix.length).split('/');
  const transforms: string[] = [];
  let i = 0;
  for (; i < segments.length; i++) {
    const segment = segments[i];
    if (/^v\d+$/.test(segment)) break;
    const transformShaped =
      TRANSFORM_KEY_RE.test(segment) ||
      CONDITION_RE.test(segment) ||
      segment.includes(',');
    if (!transformShaped || FILENAME_EXTENSION_RE.test(segment)) break;
    transforms.push(segment);
  }
  const asset = segments.slice(i).join('/');
  if (!asset) return null;
  return { prefix, transforms, asset };
}

function isDeliveryOnly(transforms: string[]): boolean {
  return transforms.every((segment) =>
    segment.split(',').every((param) => DELIVERY_PARAM_RE.test(param)),
  );
}

function resizable(url: string): ParsedCdnUrl | null {
  const parsed = parseCdnUrl(url, CDN_IMAGE_PREFIX);
  if (!parsed || !RASTER_RE.test(parsed.asset)) return null;
  return isDeliveryOnly(parsed.transforms) ? parsed : null;
}

/**
 * The CDN URL that reports `url`'s rendered size as JSON (`fl_getinfo`):
 * `{ output: { width, height } }` for the image those transforms deliver.
 * `null` when `url` is not a platform CDN image.
 */
export function imageInfoUrl(url: string): string | null {
  const parsed = parseCdnUrl(url, CDN_IMAGE_PREFIX);
  if (!parsed) return null;
  return `${parsed.prefix}${[...parsed.transforms, 'fl_getinfo'].join('/')}/${parsed.asset}`;
}

/** Whether `kiteImageUrl` can serve `url` at a requested size. */
export function isResizable(url: string): boolean {
  return resizable(url) !== null;
}

/**
 * The CDN URL of `url` limited to `width` (or `height`) pixels, in the
 * browser's best format. With both, the smallest copy that still covers a
 * `width` x `height` box at the image's own ratio, uncropped so
 * `object-fit: cover` and `object-position` still decide what shows: the CDN
 * limits a source wider than the box by its height and any other by its
 * width. Returns `url` unchanged when it is not a resizable CDN image (see the
 * header comment).
 */
export function kiteImageUrl(
  url: string,
  size:
    | { width: number; height?: number }
    | { height: number; width?: undefined },
): string {
  const parsed = resizable(url);
  if (!parsed) return url;
  const delivery = `f_auto,q_auto/${parsed.asset}`;
  if (size.width === undefined) {
    return `${parsed.prefix}c_limit,h_${Math.round(size.height)},${delivery}`;
  }
  const width = Math.round(size.width);
  if (size.height === undefined) {
    return `${parsed.prefix}c_limit,w_${width},${delivery}`;
  }
  const height = Math.round(size.height);
  const boxRatio = Number((width / height).toFixed(3));
  return (
    `${parsed.prefix}if_ar_gt_${boxRatio}/c_limit,h_${height}/` +
    `if_else/c_limit,w_${width}/if_end/${delivery}`
  );
}

function playable(url: string): ParsedCdnUrl | null {
  const parsed = parseCdnUrl(url, CDN_VIDEO_PREFIX);
  if (!parsed || !isDeliveryOnly(parsed.transforms)) return null;
  return VIDEO_RE.test(parsed.asset) ? parsed : null;
}

/**
 * The CDN URL of a CDN-hosted video re-encoded for playback (automatic quality
 * and codec, no wider than VIDEO_MAX_WIDTH), in the uploaded container. Returns
 * `url` unchanged for a video the CDN does not host, one whose author cropped,
 * trimmed or overlaid it, or anything that is not a video.
 */
export function kiteVideoUrl(url: string): string {
  const parsed = playable(url);
  if (!parsed) return url;
  return `${parsed.prefix}c_limit,w_${VIDEO_MAX_WIDTH},q_auto,vc_auto/${parsed.asset}`;
}

/**
 * `<source>` URLs for a video, in order: the re-encoded rendition, then the
 * uploaded original the browser falls back to when the CDN refuses to derive
 * the rendition (a very long video). Works from either URL, so a component
 * handed an already-rewritten URL still offers the original.
 */
export function kiteVideoSources(url: string): string[] {
  const parsed = playable(url);
  if (!parsed) return [url];
  return [kiteVideoUrl(url), `${parsed.prefix}${parsed.asset}`];
}

/**
 * A copy of CMS data in which every CDN-hosted video URL is its delivery
 * rendition (`kiteVideoUrl`), wherever it sits: a playback field, a link or a
 * nested item. A generated site never hands a visitor the original upload;
 * the original stays in the CMS and on the CDN. Applied once, where block and
 * collection-item data enters rendering (RenderBlocks, RenderItem), so no
 * component, generated ones included, has to know which fields are videos.
 */
export function withVideoRenditions<T>(value: T): T {
  if (typeof value === 'string') return kiteVideoUrl(value) as T;
  if (Array.isArray(value)) return value.map(withVideoRenditions) as T;
  if (
    value !== null &&
    typeof value === 'object' &&
    Object.getPrototypeOf(value) === Object.prototype
  ) {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [
        key,
        withVideoRenditions(item),
      ]),
    ) as T;
  }
  return value;
}

/**
 * A still frame for a CDN-hosted video (its first frame, resized), used as the
 * `<video poster>` so the hero paints before any video bytes arrive. Null for a
 * video the CDN does not host, or one whose author cropped or trimmed it (the
 * poster would not match what plays).
 */
export function kiteVideoPosterUrl(url: string): string | null {
  const parsed = parseCdnUrl(url, CDN_VIDEO_PREFIX);
  if (!parsed || !isDeliveryOnly(parsed.transforms)) return null;
  if (!VIDEO_RE.test(parsed.asset)) return null;
  const still = parsed.asset.replace(VIDEO_RE, '.jpg');
  return `${parsed.prefix}so_0,c_limit,w_1920,f_auto,q_auto/${still}`;
}
