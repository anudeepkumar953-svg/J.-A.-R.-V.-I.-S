import type { Metadata } from 'next';
import type { SiteSetting } from '@/payload-types';

// The site-level half of every page's head: the brand suffix on titles, the
// site's default description, and the social image a page falls back to. Pure,
// so the layout, the catch-all route and the generated-image route agree, and
// the contract test (`page-metadata.test.ts`) can drive it without a database.
//
// Every value comes from the site's own settings. Nothing here invents a fact
// about the business; with no readable settings, nothing is emitted.

/** The parts of the `site-settings` global the head and structured data read. */
export type SiteSeo =
  | Partial<
      Pick<
        SiteSetting,
        | 'brandName'
        | 'logoUrl'
        | 'colors'
        | 'footer'
        | 'socialLinks'
        | 'contact'
        | 'defaultSeo'
      >
    >
  | null
  | undefined;

export const TITLE_SEPARATOR = ' | ';

// Path of the generated social card (`app/(frontend)/og-image.png/route.tsx`).
export const GENERATED_OG_IMAGE_PATH = '/og-image.png';

// HTML-escaped text reaches the CMS when a title is copied out of page source;
// compare the words, not their escaping.
function comparable(text: string): string {
  return text
    .replace(/&amp;/gi, '&')
    .replace(/&(#39|#x27|apos);/gi, "'")
    .replace(/&quot;/gi, '"')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

/**
 * The site's title template, applied once: `<title> | <brand>`, unless the
 * title already names the brand anywhere ("Acme — Home", "About | Acme",
 * "Who we are | Acme | Advisory"). That guard is what keeps a title someone
 * already branded by hand from gaining the brand a second time.
 */
export function brandedTitle(
  title: string | null | undefined,
  brand: string | null | undefined,
): string | undefined {
  const own = title?.trim();
  const name = brand?.trim();
  if (!own) return name || undefined;
  if (!name || namesBrand(comparable(own), comparable(name))) return own;
  return `${own}${TITLE_SEPARATOR}${name}`;
}

// The brand as a whole word: "Kite" names it in "About | Kite", not in
// "Kitesurfing lessons".
function namesBrand(title: string, brand: string): boolean {
  const wordChar = /[\p{L}\p{N}]/u;
  for (
    let i = title.indexOf(brand);
    i !== -1;
    i = title.indexOf(brand, i + 1)
  ) {
    const before = title[i - 1];
    const after = title[i + brand.length];
    if (
      (!before || !wordChar.test(before)) &&
      (!after || !wordChar.test(after))
    ) {
      return true;
    }
  }
  return false;
}

function hash(text: string): string {
  // FNV-1a: stable across runtimes, enough to tell two brand cards apart.
  let h = 0x811c9dc5;
  for (let i = 0; i < text.length; i++) {
    h ^= text.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16);
}

/** What the generated card shows, shared by its URL and its renderer. */
export function ogCardContent(site: SiteSeo): {
  brand: string;
  tagline: string;
  background: string;
  foreground: string;
  accent: string;
} | null {
  const brand = site?.brandName?.trim();
  if (!brand) return null;
  const background = hexColor(site?.colors?.primary) ?? '#111827';
  const foreground = isLight(background) ? '#111827' : '#ffffff';
  const tagline = (
    site?.footer?.tagline ||
    site?.defaultSeo?.description ||
    ''
  ).trim();
  return {
    brand,
    tagline: clampAtWord(tagline, 140),
    background,
    foreground,
    accent: hexColor(site?.colors?.accent) ?? foreground,
  };
}

/**
 * The generated card's absolute URL, versioned by what it shows: social
 * networks cache a share image by URL, so a brand edit must change the URL to
 * reach them. Null when the site has no brand to draw.
 */
export function generatedOgImageUrl(
  baseUrl: string,
  site: SiteSeo,
): string | null {
  const card = ogCardContent(site);
  if (!card) return null;
  const version = hash(
    [card.brand, card.tagline, card.background, card.accent].join('\u0000'),
  );
  return `${baseUrl}${GENERATED_OG_IMAGE_PATH}?v=${version}`;
}

/**
 * The share image for a document: its own, else the site default, else the
 * generated brand card.
 */
export function shareImage(
  own: string | null | undefined,
  baseUrl: string,
  site: SiteSeo,
): string | undefined {
  return (
    own ||
    site?.defaultSeo?.ogImageUrl ||
    generatedOgImageUrl(baseUrl, site) ||
    undefined
  );
}

/**
 * Head defaults for every route under the frontend layout: what a hand-coded
 * route or a not-found page shows when it sets nothing itself. A CMS page
 * replaces each of these with its own (`page-metadata.ts`).
 */
export function layoutMetadata(site: SiteSeo, baseUrl: string): Metadata {
  const brand = site?.brandName?.trim() || undefined;
  const title = site?.defaultSeo?.title?.trim() || brand;
  const description = site?.defaultSeo?.description?.trim() || undefined;
  // Absolute here: unlike a CMS page's metadata, the layout sets no
  // `metadataBase`, so a relative stored default would resolve against Next's
  // fallback origin instead of the site's.
  const stored = shareImage(undefined, baseUrl, site);
  let image: string | undefined;
  try {
    image = stored ? new URL(stored, `${baseUrl}/`).href : undefined;
  } catch {
    image = undefined;
  }
  return {
    title,
    description,
    // No og:title / og:description: a route that sets only its own `title`
    // inherits this object, and the site's title there would contradict it.
    // Share previews fall back to the page's <title> and description.
    openGraph:
      brand || image
        ? { siteName: brand, images: image ? [{ url: image }] : undefined }
        : undefined,
    twitter: image
      ? { card: 'summary_large_image', images: [image] }
      : undefined,
  };
}

/** Cut `text` to at most `max` characters on a word boundary, marking the cut. */
export function clampAtWord(text: string, max: number): string {
  if (text.length <= max) return text;
  const room = text.slice(0, max - 1);
  const space = room.lastIndexOf(' ');
  const cut = (space > max / 2 ? room.slice(0, space) : room).replace(
    /[\s,;:.\-–—]+$/,
    '',
  );
  return `${cut}…`;
}

function hexColor(value: string | null | undefined): string | null {
  const v = value?.trim();
  if (!v || !/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(v)) return null;
  return v.length === 4
    ? `#${v[1]}${v[1]}${v[2]}${v[2]}${v[3]}${v[3]}`.toLowerCase()
    : v.toLowerCase();
}

function isLight(hex: string): boolean {
  const n = parseInt(hex.slice(1), 16);
  const [r, g, b] = [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  return 0.299 * r + 0.587 * g + 0.114 * b > 160;
}
