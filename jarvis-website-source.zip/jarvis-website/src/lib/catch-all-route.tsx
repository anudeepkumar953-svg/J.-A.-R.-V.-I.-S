import { cache } from 'react';
import type { Metadata } from 'next';
import { headers } from 'next/headers';
import { notFound } from 'next/navigation';
import { getPayload } from 'payload';
import config from '@payload-config';
import { RenderBlocks } from '@/components/blocks/RenderBlocks';
import { RenderItem } from '@/components/collections/RenderItem';
// Full configs are still needed here for the per-collection `custom.schemaType`
// lookup; the routable-slug SET is the shared `contentCollectionSlugs`.
import { generatedCollections } from '@/payload/collections/generated';
import { ADDED_PAGES_ONLY, PREVIEW_PARAM } from '@/payload/proposals';
import { RelatedPagesNav } from '@/payload/RelatedPagesNav';
import type { ContentItem } from './related';
import { contentCollectionSlugs, findPublishedItems } from './related';
import { CMS_CONTENT_TAG, cmsCached } from './cms-cache';
import { slugMayExist } from './known-slugs';
import { findProposalForEditor } from './proposal-preview';
import {
  itemMetadata,
  itemUrl,
  jsonLdScriptHtml,
  pageJsonLdBlocks,
  pageMetadata,
  pageUrl,
} from './page-metadata';
import { seoDefaults } from './seo-defaults';
import { getBaseUrl } from './site-url';
import {
  type Crumb,
  breadcrumbJsonLd,
  faqPageJsonLd,
  generatedBlocks,
  itemJsonLd,
  organizationJsonLd,
  websiteJsonLd,
} from './structured-data';

// The lookup, metadata and render behind the CMS catch-all route
// (`app/(frontend)/[[...slug]]/page.tsx`, cached) and its per-request variant
// for query strings (`app/(frontend)/kite-facet/[[...slug]]/page.tsx`). The
// generated design authors block components only — never this data fetch.
//
// A `Pages` doc always wins; a slug that matches no page falls back to the
// content collections (`contentCollectionSlugs` — the shared definition that
// also drives the sitemap; see its doc comment in `lib/related.ts`).

export type SearchParams = Record<string, string | string[] | undefined>;

export type CatchAllParams = Promise<{ slug?: string[] }>;

// Cross-request cached in production (tag-invalidated by the Pages /
// content-collection afterChange hooks, TTL backstop — see
// src/lib/cms-cache.ts); a live DB read in the dev sandbox.
const fetchDoc = cmsCached(
  async (slug: string) => {
    const payload = await getPayload({ config });
    const page = await payload.find({
      collection: 'pages',
      where: { and: [{ slug: { equals: slug } }, ADDED_PAGES_ONLY] },
      limit: 1,
    });
    if (page.docs[0]) return { kind: 'page' as const, doc: page.docs[0] };
    // A slug that matches no page scans the content collections. Concurrent —
    // each find is an independent round trip to the remote DB, and a serial
    // walk made misses pay collections × RTT. First match in
    // `contentCollectionSlugs` order still wins, preserving the serial walk's
    // precedence.
    const items = await Promise.all(
      contentCollectionSlugs.map((collection) =>
        findPublishedItems(payload, collection, {
          where: { slug: { equals: slug } },
          limit: 1,
        }),
      ),
    );
    for (let i = 0; i < items.length; i++) {
      const [doc] = items[i];
      if (doc) {
        return {
          kind: 'item' as const,
          collection: contentCollectionSlugs[i],
          doc,
        };
      }
    }
    return null;
  },
  ['query-doc'],
  [CMS_CONTENT_TAG],
);

// Per-render memoized via React `cache()`: `generateMetadata` and the page
// both need the lookup. Keyed by the joined slug string so the two call sites
// share one lookup regardless of `params` identity. A slug missing from the
// cached list of every routable slug is not found without a database read.
const queryDoc = cache(async (slug: string) =>
  (await slugMayExist(slug)) ? fetchDoc(slug) : null,
);

function slugKey(slugParts?: string[]): string {
  return slugParts?.length ? slugParts.join('/') : 'home';
}

// schema.org `@type` for a collection's items, declared per collection via
// `makeCollection`'s `schemaType` (carried on the config's `custom`).
// 'CreativeWork' is the truthful generic fallback — a podcast or case-study
// item must not be asserted to search engines as an 'Article'.
const schemaTypeBySlug = new Map(
  generatedCollections.map((c) => [
    c.slug,
    (c.custom as { schemaType?: string } | undefined)?.schemaType,
  ]),
);
function schemaTypeFor(collection: string): string {
  return schemaTypeBySlug.get(collection) ?? 'CreativeWork';
}

// og:type has a small fixed vocabulary with no podcast/case-study entries —
// only these schema.org types may assert `article`; everything else is the
// generic `website`. An explicit set, not a substring sniff: the two
// vocabularies are independent, and a future schemaType must opt in here
// rather than silently matching.
const ARTICLE_SCHEMA_TYPES = new Set([
  'Article',
  'BlogPosting',
  'NewsArticle',
  'TechArticle',
  'JobPosting',
]);

// One `<script type="application/ld+json">` per block. jsonLdScriptHtml
// escapes '<' so a literal '</script>' in any CMS string cannot close the
// element (stored XSS).
function JsonLdScripts({ blocks }: { blocks: unknown[] }) {
  return (
    <>
      {blocks.map((block, i) => (
        <script
          key={i}
          type="application/ld+json"
          // eslint-disable-next-line react/no-danger
          dangerouslySetInnerHTML={{ __html: jsonLdScriptHtml(block) }}
        />
      ))}
    </>
  );
}

// The documents on the way from the home page to `slug`, each with the URL it
// is served at. A path segment with no document of its own is skipped, so the
// trail never links to a URL that is not found. Every lookup is the route's
// own cached one.
async function breadcrumbTrail(
  slug: string,
  baseUrl: string,
): Promise<Crumb[]> {
  if (slug === 'home') return [];
  const parts = slug.split('/');
  const paths = [
    'home',
    ...parts.map((_, i) => parts.slice(0, i + 1).join('/')),
  ];
  const docs = await Promise.all(paths.map((path) => queryDoc(path)));
  const trail: Crumb[] = [];
  docs.forEach((found, i) => {
    if (!found) return;
    const name = found.doc.title;
    if (!name) return;
    trail.push({
      name,
      url:
        found.kind === 'page'
          ? pageUrl(baseUrl, paths[i])
          : itemUrl(baseUrl, paths[i]),
    });
  });
  return trail;
}

export async function catchAllMetadata(
  params: CatchAllParams,
): Promise<Metadata> {
  const { slug } = await params;
  const found = await queryDoc(slugKey(slug));
  if (!found) return {};
  if (found.kind === 'page') {
    // Canonical, OG/Twitter, robots, and metadataBase for a `Pages` doc — the
    // pure builder in src/lib/page-metadata.ts (contract-tested there). Every
    // URL of a migrated site is a `Pages` doc, so this branch must carry the
    // full metadata surface, not just title/description. The canonical is
    // built from the document, so the per-request variant still names the
    // public URL.
    return pageMetadata(found.doc, getBaseUrl(), await seoDefaults());
  }
  // Canonical, OG/Twitter, robots and metadataBase for a content-collection
  // item — the pure builder in src/lib/page-metadata.ts, beside the pages one
  // and contract-tested with it. og:type is resolved here because it reads the
  // collection's generation-driven `schemaType`.
  const ogType = ARTICLE_SCHEMA_TYPES.has(schemaTypeFor(found.collection))
    ? ('article' as const)
    : ('website' as const);
  return itemMetadata(found.doc, getBaseUrl(), ogType, await seoDefaults());
}

export async function CatchAllPage({
  params,
  searchParams,
}: {
  params: CatchAllParams;
  // Only the per-request variant passes these; the cached route has none.
  searchParams?: SearchParams;
}) {
  const { slug } = await params;
  const key = slugKey(slug);
  // Only the per-request variant passes `searchParams`, so the cached route
  // never looks a proposal up.
  const found =
    (await queryDoc(key)) ??
    (searchParams?.[PREVIEW_PARAM] !== undefined
      ? await findProposalForEditor(
          await getPayload({ config }),
          await headers(),
          key,
        )
      : null);
  if (!found) notFound();

  const baseUrl = getBaseUrl();
  const [site, trail] = await Promise.all([
    seoDefaults(),
    breadcrumbTrail(key, baseUrl),
  ]);
  const siteBlocks = [
    organizationJsonLd(site, baseUrl),
    websiteJsonLd(site, baseUrl),
  ];

  if (found.kind === 'page') {
    const page = found.doc;
    // Seeded structured data is served verbatim — a migration seeds the
    // source page's real-world assertions (LocalBusiness address, phone,
    // hours) and the platform never regenerates them. What the template
    // generates follows it, minus anything the stored blocks already cover.
    const stored = pageJsonLdBlocks(page);
    const generated = generatedBlocks(stored, {
      site: siteBlocks,
      page: [breadcrumbJsonLd(trail), faqPageJsonLd(page.layout)],
    });
    return (
      <>
        <JsonLdScripts blocks={[...stored, ...generated]} />
        <main data-payload-route={page.slug === 'home' ? '/' : `/${page.slug}`}>
          <RenderBlocks blocks={page.layout} searchParams={searchParams} />
          <RelatedPagesNav page={page} />
        </main>
      </>
    );
  }

  // Collection item: rendered through the per-collection item registry,
  // which dispatches to a custom layout when one is registered for this
  // collection and falls back to the neutral DefaultItemLayout otherwise. The
  // JSON-LD gives search engines the typed markup the layout doesn't express.
  const item = found.doc;
  // Same canonical resolution as generateMetadata: a syndicated item's
  // canonicalUrl override must reach JSON-LD's @id too, or structured data
  // contradicts the <link rel=canonical> the same page advertises.
  const canonical = item.canonicalUrl || itemUrl(baseUrl, item.slug);
  const generated = generatedBlocks([], {
    site: siteBlocks,
    page: [
      itemJsonLd(
        item,
        schemaTypeFor(found.collection),
        canonical,
        site,
        baseUrl,
      ),
      breadcrumbJsonLd(trail),
    ],
  });
  return (
    <>
      <JsonLdScripts blocks={generated} />
      <RenderItem collection={found.collection} doc={item} />
    </>
  );
}
