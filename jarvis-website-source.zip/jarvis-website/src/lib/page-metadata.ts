import type { Metadata } from 'next';
import type { Page } from '@/payload-types';
import type { ContentItem } from './related';
import {
  type SiteSeo,
  brandedTitle,
  clampAtWord,
  shareImage,
} from './site-seo';

import { pageUrl, robotsDeclaresNoindex } from '../payload/indexability';
export {
  pageUrl,
  robotsDeclaresNoindex,
  canonicalPointsElsewhere,
  pageInSitemap,
  itemInSitemap,
} from '../payload/indexability';

// Metadata for the two kinds of document the catch-all route serves: a `Pages`
// doc (`pageMetadata`) and a content-collection item (`itemMetadata`). Both are
// built pure from the doc plus the resolved site origin (`getBaseUrl()` at the
// call site) so the contract test (`page-metadata.test.ts`) can drive them
// without a database. The catch-all route is the only intended caller.
//
// Every value is read off the document, cut from the document's own visible
// text, or taken from the site's settings (`site-seo.ts`): the brand suffix,
// the default description and the share image the owner set, and a share card
// drawn from the brand name. Nothing asserts a fact the site did not state.
//
// A page's stored values always win, and a stored title or description is
// served as written: a migrated page keeps its source's words. What a migrated
// page that declared nothing now gains (a description from its own text, the
// site's share image) is reported by the migration's findings gate as an
// addition, not as a loss.

// Serialized form of a JSON-LD block for `<script type="application/ld+json">`.
// Escape '<' — JSON.stringify does not, and a literal '</script>' in any CMS
// string would close the element and execute what follows (stored XSS). '<' is
// valid JSON and parses identically.
export function jsonLdScriptHtml(value: unknown): string {
  return JSON.stringify(value).replace(/</g, '\\u003c');
}

// The page's stored JSON-LD, normalized to a list of blocks. Stored verbatim
// at seed time and re-emitted verbatim — never regenerated: these blocks
// assert real-world facts (a LocalBusiness address, phone, opening hours).
// The canonical shape is an array of objects; a single object is accepted,
// and so is JSON text — Payload's json field stores any JSON value and the
// admin editor can hand back a quoted string, so dropping it silently would
// lose exactly the data this field exists to preserve. Text that does not
// parse yields no blocks.
export function pageJsonLdBlocks(page: Page): unknown[] {
  let stored = page.seo?.jsonLd;
  if (typeof stored === 'string') {
    try {
      stored = JSON.parse(stored);
    } catch {
      return [];
    }
  }
  if (Array.isArray(stored)) return stored;
  if (stored && typeof stored === 'object') return [stored];
  return [];
}

// The `noindex` admin switch always wins on indexability, but it must not
// discard the carried source directives: a source `noindex, follow,
// max-image-preview:large` keeps its own words, and a page noindexed in the
// admin keeps its carried directives with `noindex` prepended. Only with no
// carried string does the switch fall back to the structured form.
function pageRobots(page: Page): Metadata['robots'] {
  const carried = page.seo?.robots || undefined;
  if (page.seo?.noindex) {
    if (!carried) return { index: false, follow: false };
    return robotsDeclaresNoindex(carried) ? carried : `noindex, ${carried}`;
  }
  return carried;
}

// Prose fields of the block library, and the names a generated block most
// often gives its prose. Headings are left out: the title already carries them.
const PROSE_KEYS = new Set([
  'subheading',
  'body',
  'description',
  'text',
  'intro',
  'summary',
  'lead',
  'paragraph',
  'content',
]);
// Other people's words (testimonials) and Q&A do not describe the page.
const SKIPPED_BLOCKS = new Set(['testimonialList', 'faq']);

const DESCRIPTION_MAX = 160;
// Shorter than this reads as a label ("Book now"), not as a description.
const SEGMENT_MIN = 20;
// Shorter than this loses to the site's own default description.
const DESCRIPTION_MIN = 50;

/** Plain text of a Lexical rich-text document, one entry per paragraph. */
function lexicalParagraphs(doc: unknown): string[] {
  const out: string[] = [];
  const text = (node: unknown): string => {
    if (!node || typeof node !== 'object') return '';
    const n = node as { text?: unknown; children?: unknown[] };
    if (typeof n.text === 'string') return n.text;
    return (n.children ?? []).map(text).join('');
  };
  const walk = (node: unknown) => {
    if (!node || typeof node !== 'object') return;
    const n = node as { type?: string; children?: unknown[] };
    if (n.type === 'paragraph' || n.type === 'quote' || n.type === 'listitem') {
      out.push(text(n));
      return;
    }
    for (const child of n.children ?? []) walk(child);
  };
  walk((doc as { root?: unknown } | null)?.root);
  return out;
}

function proseSegments(
  value: unknown,
  key: string | null,
  out: string[],
): void {
  if (typeof value === 'string') {
    if (key && PROSE_KEYS.has(key)) out.push(value);
    return;
  }
  if (Array.isArray(value)) {
    for (const entry of value) proseSegments(entry, null, out);
    return;
  }
  if (!value || typeof value !== 'object') return;
  if ('root' in value) {
    out.push(...lexicalParagraphs(value));
    return;
  }
  for (const [k, v] of Object.entries(value)) proseSegments(v, k, out);
}

/**
 * A description cut from the page's own visible prose, in reading order:
 * whole segments until there is enough to describe the page, then bounded to
 * what a search result shows, on a word boundary. Plain text, and a function of
 * the stored document alone, so the cached page carries the same one for
 * every visitor.
 */
export function describeFromText(segments: string[]): string | undefined {
  let description = '';
  for (const raw of segments) {
    const segment = raw.replace(/\s+/g, ' ').trim();
    if (segment.length < SEGMENT_MIN) continue;
    if (description) {
      description += /[.!?…:]$/.test(description) ? ' ' : '. ';
    }
    description += segment;
    if (description.length >= DESCRIPTION_MAX * 0.75) break;
  }
  return description ? clampAtWord(description, DESCRIPTION_MAX) : undefined;
}

export function pageText(layout: Page['layout']): string[] {
  const out: string[] = [];
  for (const block of layout ?? []) {
    if (SKIPPED_BLOCKS.has(block.blockType)) continue;
    proseSegments(block, null, out);
  }
  return out;
}

// Stored first, then the page's own text when there is enough of it, then the
// site default, then whatever little text the page has.
function fallbackDescription(
  stored: string | null | undefined,
  text: string[],
  site: SiteSeo,
): string | undefined {
  if (stored?.trim()) return stored;
  const derived = describeFromText(text);
  if (derived && derived.length >= DESCRIPTION_MIN) return derived;
  return site?.defaultSeo?.description?.trim() || derived;
}

export function pageMetadata(
  page: Page,
  baseUrl: string,
  site?: SiteSeo,
): Metadata {
  const brand = site?.brandName;
  // A home page with no title of its own is the site's: its default title.
  const ownTitle =
    page.seo?.title ||
    (page.slug === 'home' ? site?.defaultSeo?.title : null) ||
    page.title;
  const title = brandedTitle(ownTitle, brand);
  const description = fallbackDescription(
    page.seo?.description,
    pageText(page.layout),
    site,
  );
  const canonical = page.seo?.canonicalUrl || pageUrl(baseUrl, page.slug);
  // A page's own image, else the site default (a classic site declares its
  // og:image once, in a root layout, and the migration carries it there),
  // else the generated brand card.
  const ogImage = shareImage(page.seo?.ogImageUrl, baseUrl, site);
  return {
    // Resolves any relative image URL against the deployed origin instead of
    // the request host.
    metadataBase: new URL(baseUrl),
    title,
    description,
    alternates: { canonical },
    robots: pageRobots(page),
    openGraph: {
      title,
      description,
      type: 'website',
      url: canonical,
      siteName: brand || undefined,
      images: ogImage ? [{ url: ogImage }] : undefined,
    },
    twitter: {
      card: ogImage ? 'summary_large_image' : 'summary',
      title,
      description,
      images: ogImage ? [ogImage] : undefined,
    },
  };
}

// The one item→URL rule, the content-collection counterpart of `pageUrl`: an
// item renders at `/<slug>`, with no `home` special case — a `Pages` doc always
// owns that slug. Shared by the canonical link, og:url and the item's JSON-LD
// so the three cannot drift from each other.
export function itemUrl(
  baseUrl: string,
  slug: string | null | undefined,
): string {
  return `${baseUrl}${slug ? `/${slug}` : ''}`;
}

// The item's own prose: its excerpt, then its body.
export function itemText(item: ContentItem): string[] {
  const out: string[] = [];
  if (item.excerpt) out.push(item.excerpt);
  if (item.body) out.push(...lexicalParagraphs(item.body));
  return out;
}

// Metadata for a content-collection item — the counterpart of `pageMetadata`,
// pure for the same reason. `ogType` is passed in rather than derived here: it
// comes from the collection's `schemaType`, and collections are
// generation-driven, so that lookup belongs with the route.
export function itemMetadata(
  item: ContentItem,
  baseUrl: string,
  ogType: 'article' | 'website',
  site?: SiteSeo,
): Metadata {
  const brand = site?.brandName;
  const title = brandedTitle(item.seoTitle || item.title, brand);
  const description = fallbackDescription(
    item.metaDescription,
    itemText(item),
    site,
  );
  const canonical = item.canonicalUrl || itemUrl(baseUrl, item.slug);
  const ogImage = shareImage(
    item.ogImageUrl || item.featuredImage,
    baseUrl,
    site,
  );
  return {
    // Same reason as `pageMetadata`, and the reason this branch must set it at
    // all: an item's stored `canonicalUrl` or `ogImageUrl` may be RELATIVE, and
    // app/sitemap.ts judges that same stored string against this base URL. With
    // no `metadataBase` anywhere in the item branch's ancestry Next resolves it
    // against its own default origin instead, so the served head and the
    // sitemap disagree about the same item.
    metadataBase: new URL(baseUrl),
    title,
    description,
    alternates: { canonical },
    robots: item.noindex ? { index: false, follow: false } : undefined,
    openGraph: {
      title,
      description,
      type: ogType,
      url: canonical,
      siteName: brand || undefined,
      images: ogImage ? [{ url: ogImage }] : undefined,
    },
    twitter: {
      card: ogImage ? 'summary_large_image' : 'summary',
      title,
      description,
      images: ogImage ? [ogImage] : undefined,
    },
  };
}
