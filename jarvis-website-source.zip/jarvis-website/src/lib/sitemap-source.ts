import type { BasePayload } from 'payload';
import { getPayload } from 'payload';
import config from '@payload-config';
import { CMS_CONTENT_TAG, cmsCached } from './cms-cache';
import { itemInSitemap, pageInSitemap } from './page-metadata';
import type { ContentItem } from './related';
import { contentCollectionSlugs, findPublishedItems } from './related';
import type { SitemapPageDoc } from './sitemap-entries';
import { getBaseUrl } from './site-url';
import { ADDED_PAGES_ONLY } from '../payload/proposals';

// The Payload reads behind `/sitemap.xml`, returning exactly what the pure
// `sitemapEntries` (lib/sitemap-entries.ts) takes. Every decision about what
// is advertised stays there; this file only decides what is read, how much,
// and when a read may be reused.

export type SitemapInputs = {
  indexablePages: SitemapPageDoc[] | null;
  noindexPageSlugs: string[];
  collectionItems: ContentItem[][];
};

// One sitemap file may list at most 50,000 URLs (sitemaps.org protocol).
// Reading past it would only produce a file crawlers reject.
export const SITEMAP_URL_CAP = 50_000;

// Large windows keep the number of round trips small when the result is too
// big for the data cache (2 MB per entry) and every request reads again.
const PAGE_SIZE = 5_000;

// What an unreachable database hands `sitemapEntries`: it then advertises the
// site root alone.
const rootOnly = (): SitemapInputs => ({
  indexablePages: null,
  noindexPageSlugs: [],
  collectionItems: [],
});

type Window<T> = { docs: T[]; hasNextPage: boolean };

// A source made mostly of documents that withdrew themselves is read no
// further than this many rows per URL one file may list.
const READ_LIMIT_FACTOR = 2;

// Reads consecutive windows until the result runs out, `budget` rows are
// listed, or `readLimit` rows were read. `lists` decides per row whether it will appear in the sitemap; a
// row it rejects is dropped and spends nothing, so rows the sitemap would
// leave out cannot crowd out ones it would list. Each window must be requested
// with the same size and a total sort order, or rows shift between windows and
// are skipped or repeated.
async function readWindows<T>(
  fetchWindow: (page: number) => Promise<Window<T>>,
  budget: number,
  readLimit: number,
  lists: (doc: T) => boolean = () => true,
): Promise<{ docs: T[]; truncated: boolean }> {
  const docs: T[] = [];
  let read = 0;
  for (let page = 1; ; page++) {
    const window = await fetchWindow(page);
    for (const doc of window.docs) {
      if (docs.length >= budget || read >= readLimit) {
        return { docs, truncated: true };
      }
      read++;
      if (lists(doc)) docs.push(doc);
    }
    if (!window.hasNextPage || window.docs.length === 0) {
      return { docs, truncated: false };
    }
    if (docs.length >= budget || read >= readLimit) {
      return { docs, truncated: true };
    }
  }
}

// The cached value is serialised twice into a 2 MB entry, so only the fields
// `sitemapEntries` reads are kept, and empty ones are dropped.
function compactPage(doc: SitemapPageDoc): SitemapPageDoc {
  const seo: NonNullable<SitemapPageDoc['seo']> = {};
  if (doc.seo?.noindex) seo.noindex = doc.seo.noindex;
  if (doc.seo?.robots) seo.robots = doc.seo.robots;
  if (doc.seo?.canonicalUrl) seo.canonicalUrl = doc.seo.canonicalUrl;
  return {
    slug: doc.slug,
    ...(doc.updatedAt ? { updatedAt: doc.updatedAt } : {}),
    ...(Object.keys(seo).length > 0 ? { seo } : {}),
  };
}

function compactItem(item: ContentItem): ContentItem {
  return {
    id: item.id,
    ...(item.slug ? { slug: item.slug } : {}),
    ...(item.updatedAt ? { updatedAt: item.updatedAt } : {}),
    ...(item.noindex ? { noindex: item.noindex } : {}),
    ...(item.canonicalUrl ? { canonicalUrl: item.canonicalUrl } : {}),
  };
}

// The uncached read. Each query fails independently: `null` for the
// indexable pages is how that failure reaches `sitemapEntries`, which then
// guarantees the site root; the noindex slugs and each collection degrade to
// empty, because losing them costs dedup and reach, never the root.
export async function readSitemapInputs(
  payload: BasePayload,
  {
    collectionSlugs = contentCollectionSlugs,
    cap = SITEMAP_URL_CAP,
    baseUrl = getBaseUrl(),
  }: {
    collectionSlugs?: readonly string[];
    cap?: number;
    baseUrl?: string;
  } = {},
): Promise<SitemapInputs> {
  const cutShort: string[] = [];
  const readLimit = cap * READ_LIMIT_FACTOR;
  // Slugs a page holds: an item at one of them is never served, so never
  // listed.
  const reserved = new Set<string>();
  // Indexable by the switch but withdrawn by their robots or canonical: they
  // are not listed, yet still reserve their slug.
  const withdrawnPageSlugs: string[] = [];

  // Two server-side-filtered queries so the URL budget is spent on the right
  // set: indexable pages for EMISSION (an unfiltered read would let noindex
  // pages use up the budget), and noindex page SLUGS for reservation only — a
  // noindex page still shadows a same-slug content item in the router, so its
  // slug must land in seenSlugs even though it is never emitted.
  let indexablePages: SitemapPageDoc[] | null = null;
  try {
    const read = await readWindows(
      async (page) => {
        const result = await payload.find({
          collection: 'pages',
          depth: 0,
          limit: PAGE_SIZE,
          page,
          // The default order (createdAt) is not unique, so rows written in the
          // same millisecond could fall between two windows.
          sort: 'id',
          // SQL `col <> true` is NULL for NULL rows: a directly-inserted page
          // with a null noindex would vanish from BOTH queries while the router
          // (falsy check) still serves it — treat missing as indexable.
          where: {
            and: [
              {
                or: [
                  { 'seo.noindex': { not_equals: true } },
                  { 'seo.noindex': { exists: false } },
                ],
              },
              ADDED_PAGES_ONLY,
            ],
          },
          // Only what `pageInSitemap` and the entry read; never `layout`.
          select: {
            slug: true,
            updatedAt: true,
            seo: { noindex: true, robots: true, canonicalUrl: true },
          },
        });
        return {
          docs: (result.docs as SitemapPageDoc[]).map(compactPage),
          hasNextPage: result.hasNextPage,
        };
      },
      cap,
      readLimit,
      (doc) => {
        reserved.add(doc.slug);
        if (pageInSitemap(doc, baseUrl)) return true;
        withdrawnPageSlugs.push(doc.slug);
        return false;
      },
    );
    indexablePages = read.docs;
    if (read.truncated) cutShort.push('pages');
  } catch {
    indexablePages = null;
  }

  // Reservations are not URLs, so they do not spend the URL budget; the same
  // number still bounds the read.
  let noindexPageSlugs: string[] = [];
  try {
    const read = await readWindows(
      async (page) => {
        const result = await payload.find({
          collection: 'pages',
          depth: 0,
          limit: PAGE_SIZE,
          page,
          sort: 'id',
          where: { 'seo.noindex': { equals: true } },
          select: { slug: true },
        });
        return {
          docs: result.docs.map((doc) => doc.slug),
          hasNextPage: result.hasNextPage,
        };
      },
      cap,
      readLimit,
    );
    noindexPageSlugs = read.docs;
    if (read.truncated) cutShort.push('noindex page slugs');
  } catch {
    noindexPageSlugs = [];
  }
  for (const slug of noindexPageSlugs) reserved.add(slug);
  noindexPageSlugs.push(...withdrawnPageSlugs);

  // Content-collection items via the canonical query primitive: it guards
  // field existence, so a collection authored without `status`/`noindex`
  // degrades to an unfiltered list instead of a QueryError swallowing the
  // collection's whole indexable URL set. Read in windows newest first, with `id`
  // breaking ties so the order is total and no row shifts between windows. The catch only
  // covers infra errors; each collection stays independent so one failure
  // can't blank the sitemap. Membership is `itemInSitemap`, the rule
  // `sitemapEntries` applies too, checked here rather than in the query: SQL `col <> true` is NULL for NULL rows
  // (same hazard the pages query guards against), and findPublishedItems
  // can't carry an `or`-composite clause. A falsy check matches the router's
  // semantics exactly.
  // Without the pages, `sitemapEntries` adds the site root itself.
  if (indexablePages === null) reserved.add('home');
  let remaining = cap - (indexablePages?.length ?? 1);
  const collectionItems: ContentItem[][] = [];
  for (const slug of collectionSlugs) {
    // With the file already full, one row is enough to tell it was cut.
    const windowSize = remaining > 0 ? PAGE_SIZE : 1;
    try {
      const read = await readWindows(
        async (page) => {
          const docs = await findPublishedItems(payload, slug, {
            limit: windowSize,
            page,
            sort: ['-publishDate', '-id'],
            select: {
              slug: true,
              updatedAt: true,
              noindex: true,
              canonicalUrl: true,
            },
          });
          return {
            docs: docs.map(compactItem),
            hasNextPage: docs.length === windowSize,
          };
        },
        remaining,
        readLimit,
        (item) => {
          if (!itemInSitemap(item, baseUrl) || reserved.has(item.slug)) {
            return false;
          }
          reserved.add(item.slug);
          return true;
        },
      );
      if (read.truncated) cutShort.push(`collection "${slug}"`);
      remaining -= read.docs.length;
      collectionItems.push(read.docs);
    } catch {
      // Skip this collection; the rest of the sitemap is unaffected.
    }
  }

  if (cutShort.length > 0) {
    console.warn(
      `[sitemap] stopped at the ${cap}-URL limit of one sitemap file; ` +
        `not every document is listed (cut short: ${cutShort.join(', ')})`,
    );
  }

  return { indexablePages, noindexPageSlugs, collectionItems };
}

// Thrown out of the cached function so a degraded read is never stored; it
// carries what did succeed so the caller need not read again.
class DegradedSitemapRead extends Error {
  constructor(readonly inputs: SitemapInputs) {
    super('sitemap indexable-pages read failed');
  }
}

export function createSitemapSource(
  loadPayload: () => Promise<BasePayload>,
  options?: Parameters<typeof readSitemapInputs>[1],
): {
  cachedRead: () => Promise<SitemapInputs>;
  read: () => Promise<SitemapInputs>;
} {
  // Tagged like the content it mirrors, so a save refreshes it at once and the
  // TTL bounds writes from other processes. A failed `getPayload` or
  // indexable-pages read throws here and is not stored.
  const cachedRead = cmsCached(
    async (): Promise<SitemapInputs> => {
      const payload = await loadPayload();
      const inputs = await readSitemapInputs(payload, options);
      if (inputs.indexablePages === null) throw new DegradedSitemapRead(inputs);
      return inputs;
    },
    // Membership is judged against the site's origin, so a new origin must
    // not reuse rows judged against the old one.
    ['sitemap-source', options?.baseUrl ?? getBaseUrl()],
    [CMS_CONTENT_TAG],
  );

  async function read(): Promise<SitemapInputs> {
    try {
      return await cachedRead();
    } catch (error) {
      if (error instanceof DegradedSitemapRead) return error.inputs;
      // Database unreachable: the site root alone rather than a 500.
      return rootOnly();
    }
  }

  return { cachedRead, read };
}

export const { read: readSitemapSource } = createSitemapSource(() =>
  getPayload({ config }),
);
