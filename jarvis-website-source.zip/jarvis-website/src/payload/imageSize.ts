import { lookup } from 'node:dns/promises';
import https from 'node:https';
import { BlockList, isIP } from 'node:net';
import type { FieldHook } from 'payload';
import { imageInfoUrl } from '../lib/kite-image';

// A CMS image is a bare URL, so its intrinsic size is unknown when the page
// renders, and without it the browser cannot hold the image's box before the
// file arrives. It is measured here, once, when the image is saved: never at
// render time, which would put an external call inside the cached page.
//
// A platform CDN image is measured from the CDN's own size report. Any other
// image is read from its first bytes, and the URL is editable content: the
// CMS server can reach addresses a visitor cannot (loopback, cloud metadata,
// the private network). So another host is fetched only over https, only when
// every address its name resolves to is public, on a connection pinned to the
// address that was checked, with no redirect followed and at most
// PREFIX_BYTES read. Anything else is left unmeasured and renders in a fixed
// box (RichTextContent.tsx).

export type ImageSize = { width: number; height: number };
export type Address = { address: string; family: number };

const MEASURE_TIMEOUT_MS = 5000;
// Enough for a JPEG's EXIF block ahead of its frame header.
const PREFIX_BYTES = 256 * 1024;

const NOT_PUBLIC = new BlockList();
for (const [net, bits] of [
  ['0.0.0.0', 8],
  ['10.0.0.0', 8],
  ['100.64.0.0', 10],
  ['127.0.0.0', 8],
  ['169.254.0.0', 16],
  ['172.16.0.0', 12],
  ['192.0.0.0', 24],
  ['192.0.2.0', 24],
  ['192.168.0.0', 16],
  ['198.18.0.0', 15],
  ['198.51.100.0', 24],
  ['203.0.113.0', 24],
  ['224.0.0.0', 3],
] as const) {
  NOT_PUBLIC.addSubnet(net, bits, 'ipv4');
}
for (const [net, bits] of [
  ['::', 127],
  ['64:ff9b::', 96],
  ['100::', 64],
  ['2001:db8::', 32],
  ['fc00::', 7],
  ['fe80::', 10],
  ['ff00::', 8],
] as const) {
  NOT_PUBLIC.addSubnet(net, bits, 'ipv6');
}

/** The eight 16-bit groups of an IPv6 address, or `null` if it is not one. */
function ipv6Groups(address: string): number[] | null {
  let text = address.toLowerCase();
  const dotted = /(\d+)\.(\d+)\.(\d+)\.(\d+)$/.exec(text);
  if (dotted) {
    const [a, b, c, d] = dotted.slice(1).map(Number);
    if ([a, b, c, d].some((part) => part > 255)) return null;
    text = `${text.slice(0, dotted.index)}${((a << 8) | b).toString(16)}:${((c << 8) | d).toString(16)}`;
  }
  const halves = text.split('::');
  if (halves.length > 2) return null;
  const head = halves[0] ? halves[0].split(':') : [];
  const tail = halves.length === 2 && halves[1] ? halves[1].split(':') : [];
  const missing = 8 - head.length - tail.length;
  if (halves.length === 1 ? missing !== 0 : missing < 1) return null;
  const groups = [
    ...head,
    ...Array<string>(halves.length === 2 ? missing : 0).fill('0'),
    ...tail,
  ];
  if (groups.some((group) => !/^[0-9a-f]{1,4}$/.test(group))) return null;
  return groups.map((group) => parseInt(group, 16));
}

function ipv4From(high: number, low: number): string {
  return `${high >> 8}.${high & 255}.${low >> 8}.${low & 255}`;
}

/**
 * The IPv4 address an IPv6 address reaches, in any spelling (`::ffff:7f00:1`
 * is `::ffff:127.0.0.1`): IPv4-mapped, IPv4-compatible, NAT64 or 6to4.
 * Checked against the IPv4 ranges by value, never by how it was written.
 */
function embeddedIpv4(groups: number[]): string | null {
  const zeros = (from: number, to: number) =>
    groups.slice(from, to).every((g) => g === 0);
  if (zeros(0, 5) && (groups[5] === 0xffff || groups[5] === 0)) {
    return ipv4From(groups[6], groups[7]);
  }
  if (groups[0] === 0x64 && groups[1] === 0xff9b && zeros(2, 6)) {
    return ipv4From(groups[6], groups[7]);
  }
  if (groups[0] === 0x2002) return ipv4From(groups[1], groups[2]);
  return null;
}

/** Whether `address` is a public unicast address the server may connect to. */
export function isPublicAddress(address: string): boolean {
  // A zone id names an interface on this host; never public.
  if (address.includes('%')) return false;
  const family = isIP(address);
  if (family === 4) return !NOT_PUBLIC.check(address, 'ipv4');
  if (family !== 6) return false;
  const groups = ipv6Groups(address);
  if (!groups) return false;
  const ipv4 = embeddedIpv4(groups);
  if (ipv4 !== null) return isPublicAddress(ipv4);
  return !NOT_PUBLIC.check(address, 'ipv6');
}

function positive(value: unknown): value is number {
  return typeof value === 'number' && Number.isFinite(value) && value > 0;
}

function size(width: unknown, height: unknown): ImageSize | null {
  return positive(width) && positive(height)
    ? { width: Math.round(width), height: Math.round(height) }
    : null;
}

/** An image's size from its first bytes: GIF and WebP by their headers, the rest via sharp. */
export async function sizeFromPrefix(bytes: Buffer): Promise<ImageSize | null> {
  if (bytes.length >= 10 && bytes.toString('ascii', 0, 3) === 'GIF') {
    return size(bytes.readUInt16LE(6), bytes.readUInt16LE(8));
  }
  if (
    bytes.length >= 30 &&
    bytes.toString('ascii', 0, 4) === 'RIFF' &&
    bytes.toString('ascii', 8, 12) === 'WEBP'
  ) {
    const chunk = bytes.toString('ascii', 12, 16);
    if (chunk === 'VP8X') {
      return size(bytes.readUIntLE(24, 3) + 1, bytes.readUIntLE(27, 3) + 1);
    }
    if (chunk === 'VP8 ') {
      return size(
        bytes.readUInt16LE(26) & 0x3fff,
        bytes.readUInt16LE(28) & 0x3fff,
      );
    }
    if (chunk === 'VP8L') {
      const bits = bytes.readUInt32LE(21);
      return size((bits & 0x3fff) + 1, ((bits >> 14) & 0x3fff) + 1);
    }
    return null;
  }
  try {
    const { default: sharp } = await import('sharp');
    const meta = await sharp(bytes).metadata();
    // EXIF orientations 5-8 rotate the image a quarter turn on display.
    const turned = (meta.orientation ?? 1) >= 5;
    return turned
      ? size(meta.height, meta.width)
      : size(meta.width, meta.height);
  } catch {
    return null;
  }
}

async function resolvePublic(host: string): Promise<Address[]> {
  return lookup(host, { all: true, verbatim: true });
}

/**
 * The first PREFIX_BYTES of `url`, over a connection pinned to `to`, within
 * one wall-clock deadline. `get` is injectable so a test can drive the read
 * loop over plain http.
 */
export function readPrefix(
  url: URL,
  to: Address,
  {
    timeoutMs = MEASURE_TIMEOUT_MS,
    get = https.get,
  }: { timeoutMs?: number; get?: typeof https.get } = {},
): Promise<Buffer | null> {
  return new Promise((resolve) => {
    let settled = false;
    const done = (value: Buffer | null) => {
      if (!settled) {
        settled = true;
        resolve(value);
      }
    };
    const req = get(
      url,
      {
        // The address already checked, not a second resolution an attacker's
        // DNS could answer differently.
        lookup: (_host, options, callback) => {
          if ((options as { all?: boolean }).all) {
            (callback as unknown as (e: null, a: Address[]) => void)(null, [
              to,
            ]);
          } else {
            callback(null, to.address, to.family);
          }
        },
        headers: { accept: 'image/*', 'user-agent': 'KiteImageSize/1.0' },
      },
      (res) => {
        if (res.statusCode !== 200) {
          res.destroy();
          done(null);
          return;
        }
        const chunks: Buffer[] = [];
        let length = 0;
        res.on('data', (chunk: Buffer) => {
          chunks.push(chunk);
          length += chunk.length;
          if (length >= PREFIX_BYTES) {
            done(Buffer.concat(chunks).subarray(0, PREFIX_BYTES));
            res.destroy();
          }
        });
        res.on('end', () => done(Buffer.concat(chunks)));
        res.on('error', () => done(length ? Buffer.concat(chunks) : null));
      },
    );
    req.on('error', () => done(null));
    // A whole-read deadline: a socket timeout only fires on silence, so a
    // server dripping bytes would otherwise hold the save open.
    const deadline = setTimeout(() => {
      done(null);
      req.destroy();
    }, timeoutMs);
    req.on('close', () => clearTimeout(deadline));
  });
}

function withDeadline<T>(
  work: Promise<T>,
  fallback: T,
  timeoutMs: number,
): Promise<T> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const late = new Promise<T>((resolve) => {
    timer = setTimeout(() => resolve(fallback), timeoutMs);
  });
  return Promise.race([work, late]).finally(() => clearTimeout(timer));
}

export type MeasureDeps = {
  fetchImpl: typeof fetch;
  resolve: (host: string) => Promise<Address[]>;
  read: (
    url: URL,
    to: Address,
    opts: { timeoutMs: number },
  ) => Promise<Buffer | null>;
  timeoutMs: number;
};

/** The size `url` renders at, or `null` when it cannot be read safely. */
export async function measureImage(
  url: string,
  deps: Partial<MeasureDeps> = {},
): Promise<ImageSize | null> {
  const {
    fetchImpl = fetch,
    resolve = resolvePublic,
    read = readPrefix,
    timeoutMs = MEASURE_TIMEOUT_MS,
  } = deps;
  try {
    const info = imageInfoUrl(url);
    if (info) {
      const res = await fetchImpl(info, {
        redirect: 'error',
        signal: AbortSignal.timeout(timeoutMs),
      });
      if (!res.ok) return null;
      const body = (await res.json()) as {
        output?: { width?: unknown; height?: unknown };
      };
      return size(body.output?.width, body.output?.height);
    }
    // One deadline for the whole measurement: the read gets what is left.
    const started = Date.now();
    const target = new URL(url);
    if (target.protocol !== 'https:') return null;
    const host = target.hostname.replace(/^\[|\]$/g, '');
    const addresses = isIP(host)
      ? [{ address: host, family: isIP(host) }]
      : await withDeadline(resolve(host), [], timeoutMs);
    if (
      !addresses.length ||
      !addresses.every((a) => isPublicAddress(a.address))
    ) {
      return null;
    }
    // Every answer was checked; IPv4 first, as many networks have no IPv6 route.
    const bytes = await read(
      target,
      addresses.find((a) => a.family === 4) ?? addresses[0],
      { timeoutMs: Math.max(0, timeoutMs - (Date.now() - started)) },
    );
    return bytes ? await sizeFromPrefix(bytes) : null;
  } catch {
    return null;
  }
}

// One measurement per URL, shared by the fields of the save that asked for it.
// A failure is not kept, so the next save tries again.
const MEMO_LIMIT = 256;
const memos = new WeakMap<
  (url: string) => Promise<ImageSize | null>,
  Map<string, Promise<ImageSize | null>>
>();

function sizeOf(
  url: string,
  measure: (url: string) => Promise<ImageSize | null>,
): Promise<ImageSize | null> {
  let memo = memos.get(measure);
  if (!memo) {
    memo = new Map();
    memos.set(measure, memo);
  }
  let found = memo.get(url);
  if (!found) {
    const pending = measure(url).then((result) => {
      if (!result) memo.delete(url);
      return result;
    });
    found = pending;
    memo.set(url, pending);
    if (memo.size > MEMO_LIMIT) memo.delete(memo.keys().next().value as string);
  }
  return found;
}

type Measure = (url: string) => Promise<ImageSize | null>;

/**
 * `beforeChange` for an image block's hidden `width` or `height` field: the
 * block `url`'s size, measured when the block has none recorded or its URL
 * changed since (`measuredUrl`). `measure` is injectable for tests.
 */
export function recordImageSize(
  dimension: keyof ImageSize,
  measure: Measure = measureImage,
): FieldHook {
  return async ({ siblingData, value }) => {
    const url = typeof siblingData?.url === 'string' ? siblingData.url : '';
    if (!url) return null;
    const current =
      siblingData.measuredUrl === url &&
      positive(siblingData.width) &&
      positive(siblingData.height);
    if (current) return value;
    return (await sizeOf(url, measure))?.[dimension] ?? null;
  };
}

/** `beforeChange` for `measuredUrl`: the URL the recorded size belongs to. */
export const recordMeasuredUrl: FieldHook = ({ siblingData }) =>
  typeof siblingData?.url === 'string' && siblingData.url
    ? siblingData.url
    : null;
