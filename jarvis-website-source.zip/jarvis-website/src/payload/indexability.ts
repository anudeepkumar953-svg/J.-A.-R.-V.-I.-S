import type { Page } from '../payload-types';

export function pageUrl(baseUrl: string, slug: string): string {
  return slug === 'home' ? baseUrl : `${baseUrl}/${slug}`;
}

// Word-match, not substring: `noindex` must not fire on a token that merely
// contains it. `none` is included — it is defined as `noindex, nofollow`.
// Shared with `pageInSitemap` below so the served robots meta and the
// sitemap's indexability decision cannot disagree.
export function robotsDeclaresNoindex(
  robots: string | null | undefined,
): boolean {
  return /(^|[\s,])(noindex|none)([\s,]|$)/i.test(robots ?? '');
}

// Case-insensitive, trailing-slash-insensitive form for comparing a resolved
// canonical override against the document's own URL. Scheme differences are
// intentionally significant: an override on another scheme is still another
// URL.
function normalizedUrl(url: string): string {
  return url.replace(/\/+$/, '').toLowerCase();
}

// Does a stored canonical override send readers to some OTHER URL than the
// document's own? THE shared rule, applied to both document kinds: a `Pages`
// doc (override nested at `seo.canonicalUrl`) and a content-collection item
// (override top-level at `canonicalUrl`, from `payload/collectionMeta.ts`).
//
// Resolve against `baseUrl` before comparing, because that is what the served
// head does: `pageMetadata` sets `metadataBase`, so Next resolves a stored
// RELATIVE canonical like `/about` to the page's own absolute URL. Comparing
// the raw string instead would read a self-canonical as pointing elsewhere and
// withdraw a page whose head says the opposite.
//
// An override that will not parse withdraws the document: nobody can tell where
// it points, so advertising it risks contradicting the head. Silence in the
// sitemap is the recoverable direction.
export function canonicalPointsElsewhere(
  override: string | null | undefined,
  ownUrl: string,
  baseUrl: string,
): boolean {
  if (!override) return false;
  let resolved: string;
  try {
    resolved = new URL(override, baseUrl).href;
  } catch {
    return true;
  }
  return normalizedUrl(resolved) !== normalizedUrl(ownUrl);
}

// The one sitemap-membership decision for a `Pages` doc, used by
// app/sitemap.ts and pinned by the contract test. A page leaves the sitemap
// when it is noindexed (the switch or its carried robots directives — which
// is exactly what `pageMetadata` serves), or when its canonical override
// points at a DIFFERENT URL: advertising it would contradict the page's own
// head. A redundant self-canonical (the page's own URL stored explicitly,
// give or take case, a trailing slash, or being written relative) keeps the
// page advertised.
export function pageInSitemap(
  page: Pick<Page, 'slug' | 'seo'>,
  baseUrl: string,
): boolean {
  if (page.seo?.noindex) return false;
  if (robotsDeclaresNoindex(page.seo?.robots)) return false;
  return !canonicalPointsElsewhere(
    page.seo?.canonicalUrl,
    pageUrl(baseUrl, page.slug),
    baseUrl,
  );
}

// The same decision for a content item, which carries its own top-level
// `noindex` and `canonicalUrl` (payload/collectionMeta.ts) and is served at
// `/<slug>`. A slug a `Pages` doc already holds is the caller's to check: the
// page shadows the item in the router.
export function itemInSitemap<
  T extends {
    slug?: string | null;
    noindex?: boolean | null;
    canonicalUrl?: string | null;
  },
>(item: T, baseUrl: string): item is T & { slug: string } {
  if (item.noindex || !item.slug) return false;
  return !canonicalPointsElsewhere(
    item.canonicalUrl,
    `${baseUrl}/${item.slug}`,
    baseUrl,
  );
}
