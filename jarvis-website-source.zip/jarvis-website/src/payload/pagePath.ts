import {
  APIError,
  type CollectionAfterChangeHook,
  type CollectionBeforeChangeHook,
  type CollectionBeforeDeleteHook,
} from 'payload';

// A page can sit under another page. Its URL is then the parent's path plus
// its own last segment (`menu-visit/catering`), stored whole in `slug`: the
// catch-all route joins the URL's segments and looks the page up by that one
// string, so nested pages need no change to routing or the sitemap.

/** The page's own segment: the last part of whatever slug it was given. */
export function leafSlug(slug: string): string {
  const parts = slug.split('/').filter(Boolean);
  return parts[parts.length - 1] ?? '';
}

/** The full path of a page under `parentSlug`, or its own segment alone. */
export function nestedSlug(
  parentSlug: string | null | undefined,
  slug: string,
): string {
  const leaf = leafSlug(slug);
  return parentSlug ? `${parentSlug}/${leaf}` : leaf;
}

// Shown to the editor as written; a plain Error reaches them as "Something
// went wrong".
function refusal(message: string): APIError {
  return new APIError(message, 400, null, true);
}

type ParentLookup = (
  id: string,
) => Promise<{ id: string; slug: string; parent?: string | null } | null>;

/**
 * The parent's slug, after making sure the page is not being put under itself
 * or under one of its own descendants — either would make a loop no URL can
 * express. Walks at most `maxDepth` ancestors.
 */
export async function parentSlugFor(
  pageId: string | undefined,
  parentId: string,
  findPage: ParentLookup,
  maxDepth = 20,
): Promise<string> {
  const parent = await findPage(parentId);
  if (!parent) throw refusal('The parent page no longer exists.');
  let cursor: typeof parent | null = parent;
  for (let depth = 0; cursor && depth < maxDepth; depth += 1) {
    if (pageId && cursor.id === pageId) {
      throw refusal(
        'A page cannot sit under itself or under one of its own child pages.',
      );
    }
    cursor = cursor.parent ? await findPage(cursor.parent) : null;
  }
  return parent.slug;
}

function relationId(value: unknown): string | null {
  if (typeof value === 'string' || typeof value === 'number') {
    return String(value);
  }
  if (value && typeof value === 'object' && 'id' in value) {
    return String((value as { id: unknown }).id);
  }
  return null;
}

/**
 * The slug a page is stored under after a change, or null to keep the
 * incoming data as is. An update can name only some fields: an omitted
 * parent or slug is the stored one. A parent cleared explicitly takes the
 * page back to its own segment at the top level.
 */
export async function slugAfterChange(
  data: { parent?: unknown; slug?: unknown },
  originalDoc: { id?: unknown; parent?: unknown; slug?: unknown } | undefined,
  findPage: ParentLookup,
): Promise<string | null> {
  const parentNamed = 'parent' in data;
  const parentId = relationId(parentNamed ? data.parent : originalDoc?.parent);
  const slug =
    typeof data.slug === 'string'
      ? data.slug
      : typeof originalDoc?.slug === 'string'
        ? originalDoc.slug
        : null;
  if (slug === null) return null;
  if (!parentId) {
    const hadParent = relationId(originalDoc?.parent) !== null;
    return parentNamed && hadParent ? leafSlug(slug) : null;
  }
  const pageId = relationId(originalDoc?.id) ?? undefined;
  return nestedSlug(await parentSlugFor(pageId, parentId, findPage), slug);
}

/** Keeps a child page's slug at `<parent path>/<own segment>`. */
export const nestUnderParent: CollectionBeforeChangeHook = async ({
  data,
  originalDoc,
  req,
}) => {
  const slug = await slugAfterChange(data, originalDoc, async (id) => {
    try {
      const doc = await req.payload.findByID({
        collection: 'pages',
        id,
        depth: 0,
        req,
      });
      return {
        id: String(doc.id),
        slug: String(doc.slug),
        parent: relationId((doc as { parent?: unknown }).parent),
      };
    } catch {
      return null;
    }
  });
  return slug === null ? data : { ...data, slug };
};

type ChildPages = {
  children: (parentId: string) => Promise<{ id: string; slug: string }[]>;
  move: (id: string, slug: string) => Promise<void>;
};

/**
 * Moves a page's children to its new path: their addresses are the parent's
 * plus their own segment. Each move is itself a change, so grandchildren
 * follow in turn.
 */
export async function moveChildPages(
  doc: { id: unknown; slug?: unknown },
  previousSlug: unknown,
  pages: ChildPages,
): Promise<void> {
  if (typeof doc.slug !== 'string' || doc.slug === previousSlug) return;
  const id = relationId(doc.id);
  if (!id) return;
  for (const child of await pages.children(id)) {
    const slug = nestedSlug(doc.slug, child.slug);
    if (slug !== child.slug) await pages.move(child.id, slug);
  }
}

export const moveChildrenWithParent: CollectionAfterChangeHook = async ({
  doc,
  previousDoc,
  req,
}) => {
  await moveChildPages(doc, previousDoc?.slug, {
    children: async (parentId) => {
      const found = await req.payload.find({
        collection: 'pages',
        where: { parent: { equals: parentId } },
        depth: 0,
        limit: 0,
        pagination: false,
        req,
      });
      return found.docs.map((page) => ({
        id: String(page.id),
        slug: String(page.slug),
      }));
    },
    move: async (id, slug) => {
      await req.payload.update({
        collection: 'pages',
        id,
        data: { slug },
        depth: 0,
        req,
      });
    },
  });
  return doc;
};

const CHILDREN_FIRST =
  'Pages sit under this one. Move or remove them first: the site cannot publish a page whose parent is gone.';

/**
 * Refuses to take away a page that others sit under: hiding it as a proposal
 * or deleting it would leave them pointing at a page the published site does
 * not have. Enforced here so no client, stale or not, can get round it.
 */
export async function refuseIfItHasChildren(
  id: unknown,
  countChildren: (parentId: string) => Promise<number>,
): Promise<void> {
  const pageId = relationId(id);
  if (pageId && (await countChildren(pageId)) > 0)
    throw refusal(CHILDREN_FIRST);
}

const countChildPages =
  (req: Parameters<CollectionBeforeDeleteHook>[0]['req']) =>
  async (parentId: string) =>
    (
      await req.payload.count({
        collection: 'pages',
        where: { parent: { equals: parentId } },
        req,
      })
    ).totalDocs;

export const keepChildrenFromHiding: CollectionBeforeChangeHook = async ({
  data,
  originalDoc,
  req,
}) => {
  if (data.proposed === true && originalDoc && originalDoc.proposed !== true)
    await refuseIfItHasChildren(originalDoc.id, countChildPages(req));
  return data;
};

export const keepChildrenFromDeletion: CollectionBeforeDeleteHook = async ({
  id,
  req,
}) => {
  await refuseIfItHasChildren(id, countChildPages(req));
};
