import type { BasePayload, CollectionSlug, Where } from 'payload';
import { generatedCollections } from './collections/generated';
import { itemInSitemap, pageInSitemap, pageUrl } from './indexability';
import { ADDED_PAGES_ONLY } from './proposals';

// llms.txt is a concise index, not a full export of the site's content.
const LINK_LIMIT = 1_000;
const PAGE_SIZE = 250;
const READ_WINDOWS = 40;

function prose(value: string | null | undefined, limit = 300): string {
  return (value ?? '')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, limit)
    .replace(/[\\`*[\]<>]/g, '\\$&');
}

function link(title: string, url: string, description?: string | null): string {
  const summary = prose(description);
  const target = url.replace(/[()]/g, (c) => (c === '(' ? '%28' : '%29'));
  return `- [${prose(title, 160)}](${target})${summary ? `: ${summary}` : ''}`;
}

function encodedSlug(slug: string): string {
  return slug.split('/').map(encodeURIComponent).join('/');
}

function textField(doc: object, key: string): string | undefined {
  if (!(key in doc)) return undefined;
  const value: unknown = Reflect.get(doc, key);
  return typeof value === 'string' ? value : undefined;
}

export async function readLlmsTxt(
  payload: BasePayload,
  baseUrl: string,
  collections = generatedCollections,
): Promise<string> {
  const settings = await payload.findGlobal({
    slug: 'site-settings',
    depth: 0,
    select: { brandName: true, defaultSeo: { description: true } },
  });
  const lines = [
    `# ${prose(settings.brandName || new URL(baseUrl).hostname, 160)}`,
  ];
  const description = prose(settings.defaultSeo?.description);
  if (description) lines.push('', `> ${description}`);
  const pageLinks: string[] = [];
  for (let page = 1; page <= READ_WINDOWS; page++) {
    const result = await payload.find({
      collection: 'pages',
      depth: 0,
      draft: false,
      limit: PAGE_SIZE,
      page,
      sort: 'id',
      where: {
        and: [
          ADDED_PAGES_ONLY,
          {
            or: [
              { 'seo.noindex': { not_equals: true } },
              { 'seo.noindex': { exists: false } },
            ],
          },
        ],
      },
      select: {
        title: true,
        slug: true,
        seo: {
          description: true,
          noindex: true,
          robots: true,
          canonicalUrl: true,
        },
      },
    });
    for (const doc of result.docs) {
      if (pageInSitemap(doc, baseUrl))
        pageLinks.push(
          link(
            doc.title,
            pageUrl(baseUrl, encodedSlug(doc.slug)),
            doc.seo?.description,
          ),
        );
      if (pageLinks.length >= LINK_LIMIT) break;
    }
    if (
      pageLinks.length >= LINK_LIMIT ||
      !result.hasNextPage ||
      !result.docs.length
    )
      break;
    if (page === READ_WINDOWS)
      payload.logger.warn('llms.txt page scan reached its read limit');
  }
  if (pageLinks.length) lines.push('', '## Pages', '', ...pageLinks);

  let remaining = LINK_LIMIT - pageLinks.length;
  const listedItems = new Set<string>();
  for (const collection of collections) {
    if (remaining <= 0) break;
    const slug = collection.slug as CollectionSlug;
    const registered = payload.collections[slug];
    if (!registered) continue;
    const fields = new Set(
      registered.config.flattenedFields.map((field) => field.name),
    );
    if (!fields.has('slug')) continue;
    const where: Where = {};
    if (fields.has('status')) where.status = { equals: 'published' };
    if (fields.has('_status')) where._status = { equals: 'published' };
    const selected = Object.fromEntries(
      ['title', 'slug', 'metaDescription', 'excerpt', 'noindex', 'canonicalUrl']
        .filter((field) => fields.has(field))
        .map((field) => [field, true]),
    );
    const links: string[] = [];
    try {
      for (let page = 1; page <= READ_WINDOWS; page++) {
        // Stock collections render publicly via Local API. Explicit site
        // access policies still apply, without forwarding a signed-in user.
        const result = await payload.find({
          collection: slug,
          depth: 0,
          draft: false,
          overrideAccess:
            !collection.access?.read &&
            !registered.config.flattenedFields.some(
              (field) => 'access' in field && field.access?.read,
            ),
          where,
          select: selected,
          limit: PAGE_SIZE,
          page,
          sort: 'id',
        });
        const candidates = result.docs.flatMap((doc) => {
          const item = {
            slug: textField(doc, 'slug'),
            canonicalUrl: textField(doc, 'canonicalUrl'),
            noindex: 'noindex' in doc && doc.noindex === true,
          };
          return itemInSitemap(item, baseUrl) && !listedItems.has(item.slug)
            ? [{ doc, slug: item.slug }]
            : [];
        });
        // Even an unlisted Page owns its URL. A targeted reservation query
        // stays complete when the site has more Pages than the link limit.
        const reserved = new Set(
          candidates.length
            ? (
                await payload.find({
                  collection: 'pages',
                  depth: 0,
                  draft: false,
                  where: {
                    and: [
                      ADDED_PAGES_ONLY,
                      { slug: { in: candidates.map((item) => item.slug) } },
                    ],
                  },
                  select: { slug: true },
                  limit: candidates.length,
                })
              ).docs.map((doc) => doc.slug)
            : [],
        );
        for (const item of candidates) {
          if (reserved.has(item.slug) || listedItems.has(item.slug)) continue;
          listedItems.add(item.slug);
          links.push(
            link(
              textField(item.doc, 'title') || item.slug,
              `${baseUrl}/${encodedSlug(item.slug)}`,
              textField(item.doc, 'metaDescription') ||
                textField(item.doc, 'excerpt'),
            ),
          );
          remaining--;
          if (!remaining) break;
        }
        if (!remaining || !result.hasNextPage || !result.docs.length) break;
        if (page === READ_WINDOWS)
          payload.logger.warn(`llms.txt ${slug} scan reached its read limit`);
      }
    } catch (error) {
      if (
        !(error instanceof Error && 'status' in error && error.status === 403)
      )
        payload.logger.warn(
          { err: error, collection: slug },
          'llms.txt collection unavailable',
        );
    }
    if (links.length)
      lines.push('', `## ${prose(collection.slug, 160)}`, '', ...links);
  }
  return `${lines.join('\n')}\n`;
}
