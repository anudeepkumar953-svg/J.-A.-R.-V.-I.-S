// Contract for images inside rich text. Seed bodies are markdown, and
// Payload's markdown import only knows its own upload syntax, so an ordinary
// `![alt](url)` used to land in the admin and on the page as literal text.
// Seeding must turn it into an image block the admin can edit, and the site
// renderer must draw that block as an <img>. Uses the app's real config, so
// dropping the block from the editor fails here.
//
// Self-contained tsx script (the template ships no unit-test runner), run in CI
// by nextjs-template-code-quality.yml. Exits non-zero on any failure.
//
// Run locally: pnpm exec tsx src/payload/richText.test.tsx

// Explicit React import: this file sits outside tsconfig.json's scope, so the
// runner uses the classic JSX transform (see Footer.test.tsx).
import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import config from '../payload.config';
import { RichText } from '../components/blocks/RichTextContent';
import { markdownDoc, markdownEditorConfig } from './lexical';

let failures = 0;
function check(name: string, condition: boolean): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}`);
  }
}

type Node = {
  type: string;
  text?: string;
  fields?: Record<string, unknown>;
  children?: Node[];
};

function textOf(node: Node): string {
  return node.text ?? (node.children ?? []).map(textOf).join('');
}

const editorConfig = await markdownEditorConfig(await config);
const markdown = [
  'Intro paragraph.',
  '![Team photo](https://static.kite.ai/team.png)',
  '## A heading',
  'Text before ![Chart](https://static.kite.ai/chart.png "Q3") and after.',
  '',
  '[![Logo](https://static.kite.ai/logo.png)](https://example.com)',
  '',
  '- a list item ![icon](https://static.kite.ai/icon.png)',
].join('\n');
const doc = markdownDoc(editorConfig, markdown);
const nodes = doc.root.children as unknown as Node[];
const images = nodes.filter((n) => n.type === 'block');

check(
  'each paragraph image becomes an image block with its url and alt',
  JSON.stringify(
    images.map((n) => [n.fields?.blockType, n.fields?.url, n.fields?.alt]),
  ) ===
    JSON.stringify([
      ['richTextImage', 'https://static.kite.ai/team.png', 'Team photo'],
      ['richTextImage', 'https://static.kite.ai/chart.png', 'Chart'],
    ]),
);
check(
  'text around an image stays in the paragraphs before and after it',
  nodes.map(textOf).includes('Intro paragraph.') &&
    nodes.map(textOf).includes('Text before') &&
    nodes.map(textOf).includes('and after.'),
);
check(
  'no image markdown is left as text outside links and lists',
  !nodes
    .filter((n) => n.type === 'paragraph')
    .some((n) => /!\[(Team photo|Chart)\]/.test(textOf(n))),
);

check(
  'a linked image and a list item image are left as written',
  nodes.some((n) => textOf(n).includes('![Logo]')) &&
    nodes.some((n) => n.type === 'list' && textOf(n).includes('![icon]')),
);

const html = renderToStaticMarkup(<RichText data={doc} />);
check(
  'the site renderer draws the block as an image',
  (html.match(/<img [^>]*>/g) ?? []).some(
    (tag) =>
      tag.includes('src="https://static.kite.ai/team.png"') &&
      tag.includes('alt="Team photo"'),
  ),
);
// The size recorded when the block was saved (imageSize.ts) holds the image's
// real box before the file loads; with none recorded, no ratio is made up.
const sized = structuredClone(doc);
for (const node of sized.root.children as unknown as Node[]) {
  if (node.fields?.url === 'https://static.kite.ai/team.png') {
    Object.assign(node.fields, { width: 1080, height: 1920 });
  }
}
const sizedTags =
  renderToStaticMarkup(<RichText data={sized} />).match(/<img [^>]*>/g) ?? [];
check(
  'a measured portrait image holds its own ratio before the file loads',
  sizedTags.some(
    (tag) =>
      tag.includes('team.png') &&
      /style="[^"]*aspect-ratio:1080 \/ 1920/.test(tag) &&
      tag.includes('max-width:1080px'),
  ),
);
check(
  'an unmeasured image gets a fixed box that shows the whole image',
  (html.match(/<img [^>]*>/g) ?? []).every(
    (tag) =>
      !tag.includes('aspect-ratio') &&
      /class="[^"]*aspect-\[16\/9\][^"]*object-contain/.test(tag),
  ),
);

// A layout that brings its own converters must not lose the image block.
const custom = renderToStaticMarkup(
  <RichText
    data={doc}
    converters={({ defaultConverters }) => ({
      ...defaultConverters,
      heading: () => <h2 className="custom-heading" />,
    })}
  />,
);
check(
  'custom converters keep the image and their own overrides',
  custom.includes('alt="Team photo"') && custom.includes('custom-heading'),
);
const replaced = renderToStaticMarkup(
  <RichText data={doc} converters={{ text: ({ node }) => node.text }} />,
);
check(
  'a converters object still draws the image',
  replaced.includes('alt="Team photo"'),
);

if (failures > 0) {
  console.error(`\n${failures} rich-text image check(s) failed`);
  process.exit(1);
}
console.log('\nrich-text image contract OK');
