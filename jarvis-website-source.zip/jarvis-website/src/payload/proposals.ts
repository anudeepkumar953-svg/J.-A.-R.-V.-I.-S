import type { Where } from 'payload';

// A page Kite wrote that the editor has not added yet (`proposed`) lives in
// the draft so the AI tab can preview it, but is not part of the site: every
// public read of Pages — the route lookup, the slug list, the sitemap — skips
// it. `exists: false` keeps rows written before the field visible.
export const ADDED_PAGES_ONLY: Where = {
  or: [{ proposed: { not_equals: true } }, { proposed: { exists: false } }],
};

/**
 * The query parameter a site's catch-all reads to show a signed-in editor a
 * proposal at its own address. The AI tab loads `PREVIEW_ROUTE` instead,
 * which does not depend on the site's catch-all.
 */
export const PREVIEW_PARAM = 'kite-preview';

/**
 * Where the AI tab previews a page, proposal or not:
 * `app/(frontend)/admin/kite-proposal/[[...slug]]`. The route ships with the
 * Payload layer, so the preview works on every site that took the layer,
 * whatever its catch-all looks like. Under `/admin`, which the Payload admin's
 * catch-all already owns, it can never take a public page's address.
 */
export const PREVIEW_ROUTE = '/admin/kite-proposal';
