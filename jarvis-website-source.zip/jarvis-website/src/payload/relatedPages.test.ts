// Contract for the links between related pages (payload/relatedPages.ts): a
// page links to the pages it names and to the pages that name it, and only to
// pages a visitor can open. A proposal, a page hidden from search engines and
// a page that no longer exists drop out on both sides. Needs no database.
//
// Run locally: pnpm exec tsx src/payload/relatedPages.test.ts

import {
  MAX_RELATED_LINKS,
  type RelatedPageRow,
  hasRelations,
  readPageRows,
  readRelatedPageRows,
  relatedLinks,
  relatedSlugs,
  wantedSlugs,
} from './relatedPages';

let failures = 0;
function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

const BASE = 'https://shop.test';
const hrefs = (page: RelatedPageRow, site: RelatedPageRow[]) =>
  relatedLinks(page, site, BASE).map((link) => link.href);

const services: RelatedPageRow = { slug: 'services', title: 'Services' };
const howTo: RelatedPageRow = {
  slug: 'top-up-boiler-pressure',
  title: 'How to top up your boiler pressure',
  relatedPages: ['services'],
};

console.log('\nA how-to page and the page it supports:');
{
  const site = [services, howTo];
  const forward = relatedLinks(howTo, site, BASE);
  check(
    'the how-to links to the page it names, by that page’s title',
    JSON.stringify(forward) ===
      JSON.stringify([{ href: '/services', title: 'Services' }]),
    JSON.stringify(forward),
  );
  const back = relatedLinks(services, site, BASE);
  check(
    'the supported page links back though it stores nothing',
    JSON.stringify(back) ===
      JSON.stringify([
        {
          href: '/top-up-boiler-pressure',
          title: 'How to top up your boiler pressure',
        },
      ]),
    JSON.stringify(back),
  );
}

console.log('\nOnly pages a visitor can open are linked:');
{
  const proposed = { ...howTo, proposed: true };
  check(
    'a proposal gets no link from the page it names',
    hrefs(services, [services, proposed]).length === 0,
  );
  check(
    'a page naming a proposal shows no link to it',
    hrefs({ slug: 'about', relatedPages: [proposed.slug] }, [
      proposed,
      { slug: 'about', title: 'About' },
    ]).length === 0,
  );
  const hidden = { ...howTo, seo: { noindex: true } };
  check(
    'a hidden page shows no links though only the page naming it was read',
    hrefs({ slug: 'services', seo: { noindex: true } }, [howTo]).length === 0,
  );
  check(
    'a hidden proposal previews no links either',
    hrefs({ ...howTo, seo: { robots: 'noindex' } }, [services]).length === 0,
  );
  check(
    'a public page still links when only the page naming it was read',
    hrefs({ slug: 'services', seo: { noindex: false } }, [howTo]).join() ===
      '/top-up-boiler-pressure',
  );
  check(
    'a page hidden from search engines is linked from nowhere',
    hrefs(services, [services, hidden]).length === 0,
  );
  check(
    'and links to nothing itself',
    hrefs(hidden, [services, hidden]).length === 0,
  );
  check(
    'while a proposal, which the site does not hold yet, previews its links',
    hrefs(howTo, [services]).join() === '/services',
  );
  check(
    'a page hidden by its robots line is linked from nowhere',
    hrefs(services, [
      services,
      { ...howTo, seo: { robots: 'noindex, follow' } },
    ]).length === 0,
  );
  check(
    'a page whose canonical is another address is linked from nowhere',
    hrefs(services, [
      services,
      { ...howTo, seo: { canonicalUrl: 'https://elsewhere.test/how-to' } },
    ]).length === 0,
  );
  check(
    'a named page that no longer exists shows no link',
    hrefs(howTo, [howTo]).length === 0,
  );
  check(
    'a named page whose slug changed shows no link',
    hrefs(howTo, [howTo, { slug: 'what-we-do', title: 'Services' }]).length ===
      0,
  );
  check(
    'the link returns once the proposal is added',
    hrefs(services, [services, { ...proposed, proposed: false }]).join() ===
      '/top-up-boiler-pressure',
  );
}

console.log('\nOrder, repeats and bounds:');
{
  const a = { slug: 'a', title: 'A', relatedPages: ['b', 'c', 'a', 'b'] };
  const b = { slug: 'b', title: 'B', relatedPages: ['a'] };
  const c = { slug: 'c', title: 'C' };
  const d = { slug: 'd', title: 'D', relatedPages: ['a'] };
  check(
    'named pages first, then the pages naming it, each once and never itself',
    hrefs(a, [a, b, c, d]).join() === '/b,/c,/d',
    hrefs(a, [a, b, c, d]).join(),
  );
  const home = { slug: 'home', title: 'Home', relatedPages: ['a'] };
  check(
    'the home page is never linked as a related page',
    hrefs({ slug: 'a', relatedPages: ['home'] }, [a, home]).length === 0,
  );
  check(
    'and shows no related pages of its own',
    hrefs(home, [a, home]).length === 0,
  );
  const many = Array.from({ length: 10 }, (_, i) => ({
    slug: `p${i}`,
    title: `P${i}`,
    relatedPages: ['hub'],
  }));
  check(
    `at most ${MAX_RELATED_LINKS} links are shown`,
    hrefs({ slug: 'hub' }, [{ slug: 'hub', title: 'Hub' }, ...many]).length ===
      MAX_RELATED_LINKS,
  );
  check(
    'a nested slug is linked at its full path',
    hrefs({ slug: 'a', relatedPages: ['/guides/setup/'] }, [
      a,
      { slug: 'guides/setup', title: 'Setup' },
    ]).join() === '/guides/setup',
  );
}

console.log('\nWhatever was stored reads as a list of slugs:');
{
  check('nothing stored', relatedSlugs(null).length === 0);
  check('an object', relatedSlugs({ slug: 'a' }).length === 0);
  check(
    'a list with junk in it keeps the slugs',
    relatedSlugs(['a', 3, null, ' /b/ ', '', 'a']).join() === 'a,b',
  );
}

async function main(): Promise<void> {
  console.log('\nReading the site’s pages:');
  type Args = Parameters<Parameters<typeof readRelatedPageRows>[0]>[0];
  const asked: Args[] = [];
  const pages = Array.from({ length: 501 }, (_, i) => ({
    id: i + 1,
    slug: `p${i + 1}`,
    title: `P${i + 1}`,
    relatedPages: i === 0 ? ['p2'] : null,
    layout: [{ blockType: 'hero' }],
  }));
  const find = async (args: Args) => {
    asked.push(args);
    const after = JSON.stringify(args.where).match(/"greater_than":(\d+)/);
    const from = after ? Number(after[1]) : 0;
    return { docs: pages.filter((page) => page.id > from).slice(0, 500) };
  };
  const rows = await readRelatedPageRows(find);
  check(
    'every page that names related pages is read, a batch at a time',
    rows?.length === 501 && asked.length === 2,
  );
  check(
    'only pages that name related pages are asked for',
    asked.every((args) =>
      JSON.stringify(args.where).includes('"relatedPages":{"exists":true}'),
    ),
  );
  check(
    'only added pages are asked for, and only the fields the links need',
    asked.every(
      (args) =>
        JSON.stringify(args.where).includes('"proposed"') &&
        Object.keys(args.select).sort().join() ===
          'relatedPages,seo,slug,title' &&
        JSON.stringify(args.select.seo) ===
          '{"noindex":true,"robots":true,"canonicalUrl":true}',
    ),
  );
  check(
    'a row carries nothing but those fields',
    Object.keys(rows?.[0] ?? {})
      .sort()
      .join() === 'relatedPages,seo,slug,title',
  );
  check(
    'a site past the page bound reads as too large',
    (await readRelatedPageRows(find, 500)) === null,
  );
  check(
    'a site whose rows pass the byte bound reads as too large',
    (await readRelatedPageRows(find, 5_000, 10_000)) === null,
  );

  console.log('\nReading only what one page needs:');
  const naming = [
    { slug: 'a', title: 'A', relatedPages: ['b', 'home'] },
    { slug: 'c', title: 'C', relatedPages: ['b'] },
  ];
  check(
    'a page reads only the pages it names that were not read already',
    wantedSlugs(
      { slug: 'b', relatedPages: ['d', 'a', 'home'] },
      naming,
    ).join() === 'd',
  );
  check(
    'a page named by others has relations though it names none',
    hasRelations({ slug: 'b' }, naming) &&
      wantedSlugs({ slug: 'b' }, naming).length === 0,
  );
  check(
    'a page that names none and is named by none has none',
    !hasRelations({ slug: 'z' }, naming),
  );
  check(
    'the home page has none',
    !hasRelations({ slug: 'home', relatedPages: ['a'] }, naming),
  );
  const crowd = Array.from({ length: 40 }, (_, i) => ({
    slug: `a${String(i).padStart(2, '0')}`,
    title: `A${i}`,
    relatedPages: ['b'],
  }));
  const shown = relatedLinks(
    { slug: 'b', relatedPages: ['zz-named'] },
    [
      ...crowd,
      ...[{ slug: 'zz-named', title: 'Named' }].filter((row) =>
        wantedSlugs({ slug: 'b', relatedPages: ['zz-named'] }, crowd).includes(
          row.slug,
        ),
      ),
    ],
    BASE,
  );
  check(
    'a page named by many others still links first to the page it names',
    shown[0]?.href === '/zz-named',
    JSON.stringify(shown.slice(0, 2)),
  );
  const targetsAsked: Args[] = [];
  const targets = await readPageRows(
    async (args) => {
      targetsAsked.push(args);
      return { docs: [{ id: 4, slug: 'd', title: 'D', layout: [] }] };
    },
    ['d'],
  );
  check(
    'the named pages are read by slug, added pages only',
    targets.length === 1 &&
      JSON.stringify(targetsAsked[0].where).includes('"slug":{"in":["d"]}') &&
      JSON.stringify(targetsAsked[0].where).includes('"proposed"'),
  );
  check(
    'no slug to read means no read',
    (
      await readPageRows(async () => {
        throw new Error('read');
      }, [])
    ).length === 0,
  );

  if (failures > 0) {
    console.error(`\n${failures} check(s) failed`);
    process.exit(1);
  }
  console.log('\nAll related-page checks passed');
}

void main();
