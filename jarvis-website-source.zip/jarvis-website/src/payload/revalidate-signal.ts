import crypto from 'node:crypto';
import { CMS_CONTENT_TAG, SITE_SETTINGS_TAG } from '../lib/cms-cache';

// Cross-process cache refresh for the published site. The Content tab edits
// through a separate Payload process (the editing sandbox, or a seed/merge
// script) that writes the database the published site reads, so its own
// `revalidateTag` cannot reach the published site's cache. That process POSTs
// a signed request to `/cms-revalidate` on the published site instead.
//
// Signed with a key derived from PAYLOAD_SECRET, which both processes already
// hold, rather than with the secret itself: a leaked revalidation key must not
// also sign admin sessions.

export const CMS_REVALIDATE_PATH = '/cms-revalidate';
export const SIGNATURE_HEADER = 'x-kite-signature';
export const TIMESTAMP_HEADER = 'x-kite-timestamp';

export const REVALIDATABLE_TAGS: ReadonlySet<string> = new Set([
  CMS_CONTENT_TAG,
  SITE_SETTINGS_TAG,
]);

// Covers clock skew between the sandbox and the published site. A replay inside
// it only expires the same tags again.
export const MAX_CLOCK_SKEW_SECONDS = 60;

const MAX_BODY_BYTES = 4096;

// Same floor as the session token: an empty or misprovisioned secret must fail
// closed, never sign with a guessable key.
const MIN_SECRET_LENGTH = 32;

function signingKey(secret: string | undefined): Buffer | null {
  if (!secret || secret.length < MIN_SECRET_LENGTH) return null;
  return crypto
    .createHmac('sha256', secret)
    .update('kite-cms-revalidate')
    .digest();
}

function signature(key: Buffer, timestamp: string, body: string): Buffer {
  return crypto
    .createHmac('sha256', key)
    .update(`${timestamp}.${body}`)
    .digest();
}

export type RevalidateBody = { tags: string[]; schema: string };

export type SignedRequest = { body: string; headers: Record<string, string> };

/** Build the signed request body + headers; null when the secret is unusable. */
export function signRevalidateRequest(
  payload: RevalidateBody,
  secret: string | undefined,
  nowMs: number = Date.now(),
): SignedRequest | null {
  const key = signingKey(secret);
  if (!key) return null;
  const body = JSON.stringify(payload);
  const timestamp = String(Math.floor(nowMs / 1000));
  return {
    body,
    headers: {
      'content-type': 'application/json',
      [TIMESTAMP_HEADER]: timestamp,
      [SIGNATURE_HEADER]: signature(key, timestamp, body).toString('hex'),
    },
  };
}

export type RevalidateDeps = {
  secret: string | undefined;
  // The published site's own schema (`resolveSchemaName()`); '' = default.
  schema: string;
  revalidate: (tag: string) => void;
  nowMs?: number;
};

function json(status: number, data: unknown): Response {
  return Response.json(data, {
    status,
    headers: { 'cache-control': 'no-store' },
  });
}

/**
 * Verify and apply one revalidation request. Every authentication failure is
 * the same bare 401, so a caller learns nothing about which check failed.
 */
export async function handleRevalidateRequest(
  request: Request,
  deps: RevalidateDeps,
): Promise<Response> {
  const unauthorized = () => json(401, { error: 'unauthorized' });
  const key = signingKey(deps.secret);
  if (!key) return unauthorized();

  const timestamp = request.headers.get(TIMESTAMP_HEADER) ?? '';
  const provided = request.headers.get(SIGNATURE_HEADER) ?? '';
  const seconds = Number(timestamp);
  const nowSeconds = (deps.nowMs ?? Date.now()) / 1000;
  if (
    !/^\d+$/.test(timestamp) ||
    Math.abs(nowSeconds - seconds) > MAX_CLOCK_SKEW_SECONDS ||
    !/^[0-9a-f]{64}$/.test(provided)
  ) {
    return unauthorized();
  }

  const body = await request.text();
  if (Buffer.byteLength(body) > MAX_BODY_BYTES) return unauthorized();
  // Verify the exact bytes before parsing them.
  const expected = signature(key, timestamp, body);
  if (!crypto.timingSafeEqual(Buffer.from(provided, 'hex'), expected)) {
    return unauthorized();
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(body);
  } catch {
    return json(400, { error: 'invalid body' });
  }
  const { tags, schema } = (parsed ?? {}) as Partial<RevalidateBody>;
  if (
    !Array.isArray(tags) ||
    tags.length === 0 ||
    !tags.every((tag) => typeof tag === 'string' && REVALIDATABLE_TAGS.has(tag))
  ) {
    return json(400, { error: 'unknown tag' });
  }
  // A write to any other schema (a draft, a design iteration, or the edited
  // content of a site that reads only what Publish copied) is content this site
  // does not serve, so there is nothing to refresh. An unset schema on either
  // side names no schema to differ from: refreshing costs one cache miss.
  if (schema && deps.schema && schema !== deps.schema) {
    return json(200, { revalidated: [] });
  }

  const unique = [...new Set(tags)];
  for (const tag of unique) deps.revalidate(tag);
  return json(200, { revalidated: unique });
}
