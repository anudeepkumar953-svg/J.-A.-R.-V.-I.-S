// Contract for measuring a CMS image when it is saved (imageSize.ts). A CMS
// image is a bare URL, so this is the only point where the page can learn the
// box to hold before the file loads. What it pins:
//   - a platform CDN image is measured from the CDN's own size report, for the
//     transforms the URL carries, without downloading the image;
//   - another host is measured from its first bytes, but only over https, only
//     when every address it resolves to is public, on a connection pinned to
//     that address: the URL is editable content, and the CMS server can reach
//     addresses a visitor cannot;
//   - a block keeps its recorded size until its URL changes;
//   - a failure records no size, so the next save measures again.
//
// Self-contained tsx script (the template ships no unit-test runner), run in CI
// by nextjs-template-code-quality.yml. Exits non-zero on any failure.
//
// Run locally: pnpm exec tsx src/payload/imageSize.test.ts

import http from 'node:http';
import type https from 'node:https';
import sharp from 'sharp';
import {
  isPublicAddress,
  measureImage,
  readPrefix,
  sizeFromPrefix,
  recordImageSize,
  recordMeasuredUrl,
  type ImageSize,
} from './imageSize';

let failures = 0;
function check(name: string, condition: boolean): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}`);
  }
}

const requested: string[] = [];
function fakeFetch(routes: Record<string, () => Response>): typeof fetch {
  return (async (input: string | URL | Request) => {
    const url = String(input);
    requested.push(url);
    const route = routes[url];
    return route ? route() : new Response('missing', { status: 404 });
  }) as typeof fetch;
}

const CDN = 'https://static.kite.ai/image/upload/';
const PORTRAIT = `${CDN}e_trim/v1/app/x/iter1/screenshot.png`;
const info = (width: number, height: number) => () =>
  Response.json({ input: { width: 9, height: 9 }, output: { width, height } });

const cdnSize = await measureImage(PORTRAIT, {
  fetchImpl: fakeFetch({
    [`${CDN}e_trim/fl_getinfo/v1/app/x/iter1/screenshot.png`]: info(1080, 1920),
  }),
});
check(
  'a CDN image is measured from the size report for its own transforms',
  JSON.stringify(cdnSize) === JSON.stringify({ width: 1080, height: 1920 }) &&
    requested.at(-1)?.includes('/e_trim/fl_getinfo/v1/') === true,
);

let redirect: RequestRedirect | undefined;
await measureImage(PORTRAIT, {
  fetchImpl: (async (_input: string | URL | Request, init?: RequestInit) => {
    redirect = init?.redirect;
    return Response.json({ output: { width: 1, height: 1 } });
  }) as typeof fetch,
});
check(
  'the CDN size report is not followed through a redirect',
  redirect === 'error',
);

// Which addresses the server may connect to for another host's image.
const blocked = [
  '127.0.0.1',
  '10.1.2.3',
  '172.20.0.1',
  '192.168.1.1',
  '169.254.169.254',
  '100.64.0.1',
  '0.0.0.0',
  '::1',
  '::',
  '::ffff:127.0.0.1',
  'fd00::1',
  'fe80::1',
  'fe80::1%lo0',
  // An IPv4 address hidden in an IPv6 spelling reaches that IPv4 address.
  '::ffff:7f00:1',
  '::FFFF:7F00:1',
  '0:0:0:0:0:ffff:7f00:1',
  '::ffff:a9fe:a9fe',
  '::ffff:169.254.169.254',
  '::ffff:a00:1',
  '::ffff:c0a8:101',
  '::7f00:1',
  '64:ff9b::a9fe:a9fe',
  '2002:7f00:1::1',
  '2002:a00:1::',
];
check(
  'loopback, private, link-local and metadata addresses are not public',
  blocked.every((address) => !isPublicAddress(address)),
);
check(
  'public addresses are',
  [
    '8.8.8.8',
    '151.101.1.69',
    '2606:4700::1111',
    '::ffff:808:808',
    '2002:808:808::1',
  ].every(isPublicAddress),
);

// Another host's image, measured from its first bytes.
const portraitPrefix = async (format: 'png' | 'jpeg' | 'gif') =>
  (
    await sharp({
      create: { width: 30, height: 60, channels: 3, background: '#888' },
    })
      [format]()
      .toBuffer()
  ).subarray(0, 4096);
const webp = (options: object, alpha = false) =>
  sharp({
    create: {
      width: 30,
      height: 60,
      channels: alpha ? 4 : 3,
      background: alpha ? { r: 1, g: 2, b: 3, alpha: 0.5 } : '#888',
    },
  })
    .webp(options)
    .toBuffer();
const tall = JSON.stringify({ width: 30, height: 60 });
const prefixes: [string, Buffer][] = [
  ['png', await portraitPrefix('png')],
  ['jpeg', await portraitPrefix('jpeg')],
  ['gif', await portraitPrefix('gif')],
  ['webp lossy', await webp({})],
  ['webp lossless', await webp({ lossless: true })],
  ['webp with alpha', await webp({}, true)],
];
const misread = [];
for (const [format, bytes] of prefixes) {
  if (JSON.stringify(await sizeFromPrefix(bytes)) !== tall)
    misread.push(format);
}
check(
  `every common format is measured from its first bytes (${misread.join(', ')})`,
  misread.length === 0,
);
const turned = await sharp({
  create: { width: 60, height: 30, channels: 3, background: '#888' },
})
  .jpeg()
  .withMetadata({ orientation: 6 })
  .toBuffer();
check(
  'an EXIF quarter turn swaps the measured sides',
  JSON.stringify(await sizeFromPrefix(turned)) === tall,
);

// The decisions around the read, with name resolution and the read injected.
const png = await portraitPrefix('png');
const reads: string[] = [];
const external = (addresses: string[]) => ({
  resolve: async () =>
    addresses.map((address) => ({
      address,
      family: address.includes(':') ? 6 : 4,
    })),
  read: async (url: URL, to: { address: string }) => {
    reads.push(`${url.href} via ${to.address}`);
    return png;
  },
});
check(
  'a public https image is read on the address that was checked',
  JSON.stringify(
    await measureImage(
      'https://images.example.com/tall.png',
      external(['151.101.1.69']),
    ),
  ) === tall &&
    reads.at(-1) === 'https://images.example.com/tall.png via 151.101.1.69',
);
const readsBefore = reads.length;
const refused = [
  await measureImage(
    'https://internal.example.com/x.png',
    external(['10.0.0.5']),
  ),
  await measureImage(
    'https://split.example.com/x.png',
    external(['151.101.1.69', '127.0.0.1']),
  ),
  await measureImage('https://169.254.169.254/latest/meta-data/', external([])),
  await measureImage('https://[::1]/x.png', external([])),
  await measureImage(
    'http://images.example.com/tall.png',
    external(['151.101.1.69']),
  ),
];
check(
  'a private address, any private answer, a literal internal IP or plain http is never read',
  refused.every((found) => found === null) && reads.length === readsBefore,
);

// One wall-clock deadline: neither a name that never resolves nor a server
// dripping bytes faster than any idle timeout can hold a save open.
const startedHanging = Date.now();
const hanging = await measureImage('https://slow-dns.example.com/x.png', {
  resolve: () => new Promise(() => {}),
  timeoutMs: 300,
});
check(
  'a name that never resolves gives up at the deadline',
  hanging === null && Date.now() - startedHanging < 2000,
);

const trickle = http.createServer((_req, res) => {
  res.writeHead(200, { 'content-type': 'image/png' });
  const drip = setInterval(() => res.write(Buffer.alloc(1)), 20);
  res.on('close', () => clearInterval(drip));
});
await new Promise<void>((ready) => trickle.listen(0, '127.0.0.1', ready));
const port = (trickle.address() as { port: number }).port;
const startedTrickle = Date.now();
const trickled = await readPrefix(
  new URL(`http://trickle.example.com:${port}/x.png`),
  { address: '127.0.0.1', family: 4 },
  { timeoutMs: 300, get: http.get as unknown as typeof https.get },
);
trickle.closeAllConnections();
trickle.close();
check(
  'a server dripping bytes is cut off at the deadline',
  trickled === null && Date.now() - startedTrickle < 2000,
);

// The two steps share the deadline: a slow answer leaves the read only the rest.
const startedShared = Date.now();
let readBudget = -1;
await measureImage('https://slow.example.com/x.png', {
  resolve: () =>
    new Promise((answer) =>
      setTimeout(() => answer([{ address: '151.101.1.69', family: 4 }]), 200),
    ),
  read: async (_url, _to, { timeoutMs }) => {
    readBudget = timeoutMs;
    return null;
  },
  timeoutMs: 300,
});
check(
  'resolution and the read share one deadline',
  readBudget >= 0 && readBudget <= 110 && Date.now() - startedShared < 1000,
);

check(
  'an unreachable image has no size',
  (await measureImage(`${CDN}v1/gone.png`, { fetchImpl: fakeFetch({}) })) ===
    null,
);

// The hooks, as Payload calls them on each field of the saved block.
let measured = 0;
const measure = async (url: string): Promise<ImageSize | null> => {
  measured++;
  return url.endsWith('fail.png') ? null : { width: 1080, height: 1920 };
};
type Args = Parameters<ReturnType<typeof recordImageSize>>[0];
const run = async (data: Record<string, unknown>) => {
  const args = (value: unknown) =>
    ({ siblingData: data, value }) as unknown as Args;
  return {
    width: await recordImageSize('width', measure)(args(data.width)),
    height: await recordImageSize('height', measure)(args(data.height)),
    measuredUrl: await recordMeasuredUrl(args(data.measuredUrl)),
  };
};

const fresh = await run({ url: `${CDN}v1/new.png` });
check(
  'a new image block records its size and the URL it belongs to',
  fresh.width === 1080 &&
    fresh.height === 1920 &&
    fresh.measuredUrl === `${CDN}v1/new.png`,
);
check('both sides come from one measurement', measured === 1);

const before = measured;
const kept = await run({
  url: `${CDN}v1/new.png`,
  width: 800,
  height: 600,
  measuredUrl: `${CDN}v1/new.png`,
});
check(
  'an unchanged URL keeps its recorded size without measuring',
  kept.width === 800 && kept.height === 600 && measured === before,
);

const changed = await run({
  url: `${CDN}v1/other.png`,
  width: 800,
  height: 600,
  measuredUrl: `${CDN}v1/new.png`,
});
check(
  'a changed URL is measured again',
  changed.width === 1080 && changed.height === 1920 && measured === before + 1,
);

const failed = await run({ url: `${CDN}v1/fail.png` });
check(
  'a failed measurement records no size',
  failed.width === null && failed.height === null,
);

if (failures > 0) {
  console.error(`\n${failures} image-size check(s) failed`);
  process.exit(1);
}
console.log('\nimage-size contract OK');
