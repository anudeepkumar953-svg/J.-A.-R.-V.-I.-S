import { revalidateTag } from 'next/cache';
import type {
  CollectionAfterChangeHook,
  CollectionAfterDeleteHook,
  GlobalAfterChangeHook,
  PayloadRequest,
} from 'payload';
import { CMS_CONTENT_TAG, SITE_SETTINGS_TAG } from '../lib/cms-cache';
import {
  CMS_REVALIDATE_PATH,
  signRevalidateRequest,
  type SignedRequest,
} from './revalidate-signal';
import { resolveSchemaName } from './schema-name';

// Instant invalidation for the production read cache (`src/lib/cms-cache.ts`):
// a Payload write that runs inside the Next server (admin saves, `/cms-api`
// route handlers) refreshes the cached frontend reads in the same process.
//
// Payload's local API also runs from standalone scripts (`scripts/seed-payload.ts`,
// migration tooling) where there is no Next request context and `revalidateTag`
// throws — swallow that, since those processes have no cache to invalidate.
// A failed revalidate inside a running Next server would mean production
// silently serving stale reads — worth a signal. But the expected failure
// (standalone scripts) would hit it for every seeded doc, so warn once.
//
// Writes from OTHER processes (the editing sandbox, seed and merge scripts)
// additionally ask the published site to refresh — see notifyPublishedSite.
// The cache TTL stays the backstop when that request is lost. The same signed
// request tells the platform, which counts what the next Publish ships and
// cannot see a save it did not make.
let warnedRevalidateFailure = false;

function safeRevalidate(tag: string, req?: PayloadRequest): void {
  try {
    // `{ expire: 0 }` = expire the tagged entries immediately for every
    // reader. NOT the `'max'` profile: that gives stale-while-revalidate
    // semantics where the next reader after a save can still be served the
    // stale entry while Next refreshes in the background.
    revalidateTag(tag, { expire: 0 });
  } catch (err) {
    // Expected in standalone scripts (seed/migration tooling — no Next
    // server, nothing to invalidate). Logged once so an unexpected failure
    // in a real server isn't indistinguishable from that no-op.
    if (!warnedRevalidateFailure) {
      warnedRevalidateFailure = true;
      console.warn(
        `revalidateTag(${tag}) failed — expected only outside a Next server:`,
        err,
      );
    }
  }
  notifyPublishedSite(tag, req);
}

// Where the published site is. A site can be published, or move, while this
// process runs, so the platform is asked at send time; the address the platform
// handed this process at start is the fallback when it cannot answer. The
// published site itself never sends.
export const PUBLISHED_SITE_URL_ENV = 'KITE_PUBLISHED_SITE_URL';

// Matches the platform's per-draft schema name (`payload_<iter>_draft_<id>`).
const DRAFT_SCHEMA_INFIX = '_draft_';

// Mutable only so tests can shorten the waits.
export const revalidationTiming = {
  // A publish saves many documents in a row; collect them into one request.
  coalesceMs: 250,
  // Hooks run before Payload commits, and a request sent before the commit
  // could make the published site re-cache the old row. Wait for every queued
  // save's transaction to end; a batch still uncommitted this long after its
  // last save is dropped, leaving that edit to the cache window.
  maxCommitWaitMs: 10_000,
  commitPollMs: 100,
  requestTimeoutMs: 5_000,
};

const pendingTags = new Set<string>();
const pendingReqs = new Set<PayloadRequest>();
// Sends already under way, so a script's flush can wait for them before it
// exits.
const inFlight = new Set<Promise<void>>();
let flushTimer: ReturnType<typeof setTimeout> | null = null;
let lastQueuedAt = 0;
// One warning per receiver for the life of the process.
const warned = new Set<'site' | 'platform'>();

function warnOnce(
  receiver: 'site' | 'platform',
  message: string,
  err?: unknown,
): void {
  if (warned.has(receiver)) return;
  warned.add(receiver);
  console.warn(message, ...(err === undefined ? [] : [err]));
}

function warnNotifyFailure(message: string, err?: unknown): void {
  warnOnce(
    'site',
    `Could not refresh the published site (${message}); it updates when its CMS cache expires.`,
    err,
  );
}

function warnPlatformFailure(message: string, err?: unknown): void {
  warnOnce(
    'platform',
    `Could not tell Kite about a CMS save (${message}); the Publish list shows it after Kite's next recount.`,
    err,
  );
}

// The platform's routes for this website: `published-url` answers where the
// site is published, `cms-content-changed` takes the saves.
const PLATFORM_SAVES_ROUTE = 'cms-content-changed';

function platformUrl(route: string): string | null {
  const base = process.env.PLATFORM_BASE_URL?.trim();
  const websiteId = process.env.PLATFORM_API_KEY?.trim();
  if (!base || !websiteId) return null;
  try {
    return new URL(
      `/api/v1/websites/${encodeURIComponent(websiteId)}/${route}`,
      base,
    ).href;
  } catch {
    return null;
  }
}

function mayNotify(): boolean {
  // Vercel runs the published site: it refreshes in-process above.
  if (process.env.VERCEL === '1') return false;
  // A draft's edits must stay off the published site until it is published.
  if ((resolveSchemaName() ?? '').includes(DRAFT_SCHEMA_INFIX)) return false;
  return Boolean(
    platformUrl('published-url') || process.env[PUBLISHED_SITE_URL_ENV]?.trim(),
  );
}

/**
 * The published site's origin now, or null when it is not published. Only an
 * explicit answer from the platform overrides the start-time address: a
 * platform without the lookup route, or one that cannot be reached, must not
 * silence a site that worked before.
 */
async function resolvePublishedOrigin(): Promise<string | null> {
  const lookup = platformUrl('published-url');
  if (lookup) {
    try {
      const response = await fetch(lookup, {
        cache: 'no-store',
        signal: AbortSignal.timeout(revalidationTiming.requestTimeoutMs),
      });
      if (response.ok) {
        const { url } = (await response.json()) as { url?: unknown };
        if (url === null) return null;
        if (typeof url === 'string' && url) return url;
      }
    } catch {
      // Fall back to the start-time address below.
    }
  }
  return process.env[PUBLISHED_SITE_URL_ENV]?.trim() || null;
}

function notifyPublishedSite(tag: string, req?: PayloadRequest): void {
  if (!mayNotify()) return;
  lastQueuedAt = Date.now();
  pendingTags.add(tag);
  if (req) pendingReqs.add(req);
  if (flushTimer) clearTimeout(flushTimer);
  flushTimer = setTimeout(
    () => void flushWhenCommitted(),
    revalidationTiming.coalesceMs,
  );
}

function transactionsOpen(): boolean {
  for (const req of pendingReqs) {
    if (req.transactionID) return true;
  }
  return false;
}

function commitWaitExpired(): boolean {
  return Date.now() - lastQueuedAt >= revalidationTiming.maxCommitWaitMs;
}

function dropPending(): void {
  pendingTags.clear();
  pendingReqs.clear();
  warnNotifyFailure('a save had not committed yet');
  if (platformUrl(PLATFORM_SAVES_ROUTE)) {
    warnPlatformFailure('a save had not committed yet');
  }
}

async function flushWhenCommitted(): Promise<void> {
  flushTimer = null;
  if (transactionsOpen()) {
    if (commitWaitExpired()) {
      dropPending();
      return;
    }
    flushTimer = setTimeout(
      () => void flushWhenCommitted(),
      revalidationTiming.commitPollMs,
    );
    return;
  }
  await startSend();
}

function startSend(): Promise<void> {
  const send = sendPending().finally(() => inFlight.delete(send));
  inFlight.add(send);
  return send;
}

async function sendPending(): Promise<void> {
  const tags = [...pendingTags];
  pendingTags.clear();
  pendingReqs.clear();
  if (!tags.length) return;
  const signed = signRevalidateRequest(
    { tags, schema: resolveSchemaName() ?? '' },
    process.env.PAYLOAD_SECRET,
  );
  if (!signed) {
    warnNotifyFailure('PAYLOAD_SECRET is missing');
    if (platformUrl(PLATFORM_SAVES_ROUTE)) {
      warnPlatformFailure('PAYLOAD_SECRET is missing');
    }
    return;
  }
  await Promise.all([refreshPublishedSite(signed), tellPlatform(signed)]);
}

async function refreshPublishedSite(signed: SignedRequest): Promise<void> {
  const origin = await resolvePublishedOrigin();
  if (!origin) return;
  let endpoint: string;
  try {
    endpoint = new URL(CMS_REVALIDATE_PATH, origin).href;
  } catch {
    warnNotifyFailure(`unusable address ${origin}`);
    return;
  }
  const failure = await post(endpoint, signed);
  if (failure) warnNotifyFailure(failure.message, failure.err);
}

// The platform counts what the next Publish ships. Once the live site reads
// only what Publish copied, a save waits for Publish, and this request is how
// the platform hears of a save it did not make.
async function tellPlatform(signed: SignedRequest): Promise<void> {
  const endpoint = platformUrl(PLATFORM_SAVES_ROUTE);
  if (!endpoint) return;
  const failure = await post(endpoint, signed);
  if (failure) warnPlatformFailure(failure.message, failure.err);
}

async function post(
  endpoint: string,
  signed: SignedRequest,
): Promise<{ message: string; err?: unknown } | null> {
  try {
    const response = await fetch(endpoint, {
      method: 'POST',
      headers: signed.headers,
      body: signed.body,
      cache: 'no-store',
      signal: AbortSignal.timeout(revalidationTiming.requestTimeoutMs),
    });
    return response.ok ? null : { message: `HTTP ${response.status}` };
  } catch (err) {
    return { message: 'request failed', err };
  }
}

/**
 * Send any queued refresh now. Scripts that end with `process.exit` call this
 * first (through the global below, so a script copied onto an older site that
 * lacks it still runs).
 */
export async function flushPublishedSiteRevalidation(): Promise<void> {
  if (flushTimer) {
    clearTimeout(flushTimer);
    flushTimer = null;
  }
  while (transactionsOpen() && !commitWaitExpired()) {
    await new Promise((resolve) =>
      setTimeout(resolve, revalidationTiming.commitPollMs),
    );
  }
  if (transactionsOpen()) {
    dropPending();
  } else {
    void startSend();
  }
  await Promise.all(inFlight);
}

(globalThis as Record<symbol, unknown>)[
  Symbol.for('kite.flushPublishedSiteRevalidation')
] = flushPublishedSiteRevalidation;

export const revalidateContentAfterChange: CollectionAfterChangeHook = ({
  doc,
  req,
}) => {
  safeRevalidate(CMS_CONTENT_TAG, req);
  return doc;
};

export const revalidateContentAfterDelete: CollectionAfterDeleteHook = ({
  doc,
  req,
}) => {
  safeRevalidate(CMS_CONTENT_TAG, req);
  return doc;
};

export const revalidateSiteSettingsAfterChange: GlobalAfterChangeHook = ({
  doc,
  req,
}) => {
  safeRevalidate(SITE_SETTINGS_TAG, req);
  return doc;
};
