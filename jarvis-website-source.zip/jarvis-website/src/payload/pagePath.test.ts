// Contract for nested pages: a page under a parent lives at the parent's path
// plus its own segment, re-parenting keeps only its own segment, and a page
// can never be put under itself or one of its own children — the loop has no
// URL.
//
// Run locally: pnpm exec tsx src/payload/pagePath.test.ts

import {
  leafSlug,
  moveChildPages,
  nestedSlug,
  parentSlugFor,
  refuseIfItHasChildren,
  slugAfterChange,
} from './pagePath';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

type Row = { id: string; slug: string; parent?: string | null };
const pages: Record<string, Row> = {
  a: { id: 'a', slug: 'menu-visit' },
  b: { id: 'b', slug: 'menu-visit/catering', parent: 'a' },
  c: { id: 'c', slug: 'menu-visit/catering/office', parent: 'b' },
};
const find = async (id: string) => pages[id] ?? null;

{
  console.log('a child page lives under its parent');
  check(
    'own segment of a nested slug',
    leafSlug('menu-visit/catering') === 'catering',
  );
  check(
    'parent path plus own segment',
    nestedSlug('menu-visit', 'catering') === 'menu-visit/catering',
  );
  check(
    'moving a page keeps only its own segment',
    nestedSlug('events', 'menu-visit/catering') === 'events/catering',
  );
  check(
    'no parent means a top-level page',
    nestedSlug(null, 'menu-visit/catering') === 'catering',
  );
}

await (async () => {
  console.log('a page cannot be put under itself or its own children');
  check(
    'a real parent gives its slug',
    (await parentSlugFor('b', 'a', find)) === 'menu-visit',
  );
  let refused = false;
  try {
    await parentSlugFor('a', 'c', find);
  } catch {
    refused = true;
  }
  check('under its own grandchild is refused', refused);
  refused = false;
  try {
    await parentSlugFor('a', 'a', find);
  } catch {
    refused = true;
  }
  check('under itself is refused', refused);
  refused = false;
  try {
    await parentSlugFor('a', 'gone', find);
  } catch {
    refused = true;
  }
  check('a parent that no longer exists is refused', refused);
  check(
    'a new page (no id yet) can go anywhere',
    (await parentSlugFor(undefined, 'c', find)) ===
      'menu-visit/catering/office',
  );
})();

await (async () => {
  console.log('\nan update that names only some fields keeps the path whole');
  const child = { id: 'b', slug: 'menu-visit/catering', parent: 'a' };
  check(
    'a slug-only edit stays under the stored parent',
    (await slugAfterChange({ slug: 'events' }, child, find)) ===
      'menu-visit/events',
  );
  check(
    'a parent-only edit keeps the page’s own segment',
    (await slugAfterChange({ parent: 'c' }, { ...child, id: 'x' }, find)) ===
      'menu-visit/catering/office/catering',
  );
  check(
    'clearing the parent takes the page back to the top level',
    (await slugAfterChange({ parent: null }, child, find)) === 'catering',
  );
  check(
    'a top-level page keeps the slug it was given',
    (await slugAfterChange(
      { slug: 'blog/launch' },
      { id: 'z', slug: 'x' },
      find,
    )) === null,
  );

  console.log('\nchildren follow a parent whose path changed');
  const stored: Record<string, { slug: string; parent: string | null }> = {
    a: { slug: 'menu-visit', parent: null },
    b: { slug: 'menu-visit/catering', parent: 'a' },
    c: { slug: 'menu-visit/catering/office', parent: 'b' },
  };
  const tree = {
    children: async (parentId: string) =>
      Object.entries(stored)
        .filter(([, page]) => page.parent === parentId)
        .map(([id, page]) => ({ id, slug: page.slug })),
    // A move is a change too, so the moved page's children follow it.
    move: async (id: string, slug: string): Promise<void> => {
      const before = stored[id].slug;
      stored[id].slug = slug;
      await moveChildPages({ id, slug }, before, tree);
    },
  };
  stored.a.slug = 'visit';
  await moveChildPages({ id: 'a', slug: 'visit' }, 'menu-visit', tree);
  check(
    'a child and a grandchild move with it',
    stored.b.slug === 'visit/catering' &&
      stored.c.slug === 'visit/catering/office',
  );
  let asked = false;
  await moveChildPages({ id: 'a', slug: 'visit' }, 'visit', {
    children: async () => {
      asked = true;
      return [];
    },
    move: async () => {},
  });
  check('an edit that keeps the path moves nothing', !asked);
})();

await (async () => {
  console.log('\na page others sit under cannot be hidden or deleted');
  const children: Record<string, number> = { parent: 2, leaf: 0 };
  const count = async (id: string) => children[id] ?? 0;
  let refused = false;
  try {
    await refuseIfItHasChildren('parent', count);
  } catch {
    refused = true;
  }
  check('a page with children is refused', refused);
  refused = false;
  try {
    await refuseIfItHasChildren('leaf', count);
  } catch {
    refused = true;
  }
  check('a page with none goes ahead', !refused);
})();

if (failures > 0) {
  console.error(`\n${failures} failure(s)`);
  process.exit(1);
}
console.log('\nall checks passed');
