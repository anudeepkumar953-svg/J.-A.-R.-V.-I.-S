import type { Block } from 'payload';

// Icons for the "Add Layout" picker. Payload renders a block's
// `admin.images.thumbnail` as an <img> on its picker card; with none it draws
// the same grey placeholder picture for every block, which editors read as
// broken images. Every layout block gets a small line icon instead, and
// `src/admin/admin-skin.css` turns each card into a compact icon + name row.
//
// Icon geometry is lucide's, the icon set the admin already uses through
// lucide-react (ISC licence, https://lucide.dev — Copyright (c) 2022 Lucide
// Contributors; portions Copyright (c) 2013-2022 Cole Bemis, MIT). The shapes
// are copied rather than imported: lucide-react publishes no `exports` map, so
// reaching a raw `__iconNode` means a deep path into `dist/esm/icons/` that is
// private by convention and unversioned, and a thumbnail has to be a plain
// image URL inside the block config anyway.

type IconNode = [tag: string, attrs: Record<string, string>][];

const ICONS = {
  panelTop: [
    ['rect', { width: '18', height: '18', x: '3', y: '3', rx: '2' }],
    ['path', { d: 'M3 9h18' }],
  ],
  layoutGrid: [
    ['rect', { width: '7', height: '7', x: '3', y: '3', rx: '1' }],
    ['rect', { width: '7', height: '7', x: '14', y: '3', rx: '1' }],
    ['rect', { width: '7', height: '7', x: '14', y: '14', rx: '1' }],
    ['rect', { width: '7', height: '7', x: '3', y: '14', rx: '1' }],
  ],
  mousePointerClick: [
    ['path', { d: 'M14 4.1 12 6' }],
    ['path', { d: 'm5.1 8-2.9-.8' }],
    ['path', { d: 'm6 12-1.9 2' }],
    ['path', { d: 'M7.2 2.2 8 5.1' }],
    [
      'path',
      {
        d: 'M9.037 9.69a.498.498 0 0 1 .653-.653l11 4.5a.5.5 0 0 1-.074.949l-4.349 1.041a1 1 0 0 0-.74.739l-1.04 4.35a.5.5 0 0 1-.95.074z',
      },
    ],
  ],
  quote: [
    [
      'path',
      {
        d: 'M16 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z',
      },
    ],
    [
      'path',
      {
        d: 'M5 3a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2 1 1 0 0 1 1 1v1a2 2 0 0 1-2 2 1 1 0 0 0-1 1v2a1 1 0 0 0 1 1 6 6 0 0 0 6-6V5a2 2 0 0 0-2-2z',
      },
    ],
  ],
  circleQuestionMark: [
    ['circle', { cx: '12', cy: '12', r: '10' }],
    ['path', { d: 'M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3' }],
    ['path', { d: 'M12 17h.01' }],
  ],
  images: [
    ['path', { d: 'M18 22H4a2 2 0 0 1-2-2V6' }],
    ['path', { d: 'm22 13-1.296-1.296a2.41 2.41 0 0 0-3.408 0L11 18' }],
    ['circle', { cx: '12', cy: '8', r: '2' }],
    ['rect', { width: '16', height: '16', x: '6', y: '2', rx: '2' }],
  ],
  chartColumn: [
    ['path', { d: 'M3 3v16a2 2 0 0 0 2 2h16' }],
    ['path', { d: 'M18 17V9' }],
    ['path', { d: 'M13 17V5' }],
    ['path', { d: 'M8 17v-3' }],
  ],
  badgeCheck: [
    [
      'path',
      {
        d: 'M3.85 8.62a4 4 0 0 1 4.78-4.77 4 4 0 0 1 6.74 0 4 4 0 0 1 4.78 4.78 4 4 0 0 1 0 6.74 4 4 0 0 1-4.77 4.78 4 4 0 0 1-6.75 0 4 4 0 0 1-4.78-4.77 4 4 0 0 1 0-6.76Z',
      },
    ],
    ['path', { d: 'm9 12 2 2 4-4' }],
  ],
  text: [
    ['path', { d: 'M15 18H3' }],
    ['path', { d: 'M17 6H3' }],
    ['path', { d: 'M21 12H3' }],
  ],
  mail: [
    ['path', { d: 'm22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7' }],
    ['rect', { x: '2', y: '4', width: '20', height: '16', rx: '2' }],
  ],
  list: [
    ['path', { d: 'M3 12h.01' }],
    ['path', { d: 'M3 18h.01' }],
    ['path', { d: 'M3 6h.01' }],
    ['path', { d: 'M8 12h13' }],
    ['path', { d: 'M8 18h13' }],
    ['path', { d: 'M8 6h13' }],
  ],
  audioLines: [
    ['path', { d: 'M2 10v3' }],
    ['path', { d: 'M6 6v11' }],
    ['path', { d: 'M10 3v18' }],
    ['path', { d: 'M14 8v7' }],
    ['path', { d: 'M18 5v13' }],
    ['path', { d: 'M22 10v3' }],
  ],
  users: [
    ['path', { d: 'M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2' }],
    ['path', { d: 'M16 3.128a4 4 0 0 1 0 7.744' }],
    ['path', { d: 'M22 21v-2a4 4 0 0 0-3-3.87' }],
    ['circle', { cx: '9', cy: '7', r: '4' }],
  ],
  link: [
    [
      'path',
      { d: 'M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71' },
    ],
    [
      'path',
      { d: 'M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71' },
    ],
  ],
  box: [
    [
      'path',
      {
        d: 'M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z',
      },
    ],
    ['path', { d: 'm3.3 7 8.7 5 8.7-5' }],
    ['path', { d: 'M12 22V12' }],
  ],
} satisfies Record<string, IconNode>;

export type PickerIconName = keyof typeof ICONS;

// The fixed block library, by slug. Exported so the contract test can check it
// against the blocks actually registered, in both directions.
export const LIBRARY_ICONS: Record<string, PickerIconName> = {
  hero: 'panelTop',
  featureGrid: 'layoutGrid',
  cta: 'mousePointerClick',
  testimonialList: 'quote',
  faq: 'circleQuestionMark',
  gallery: 'images',
  stats: 'chartColumn',
  logoCloud: 'badgeCheck',
  richText: 'text',
  contact: 'mail',
  collectionList: 'list',
  audioEmbed: 'audioLines',
  peopleList: 'users',
  relatedItems: 'link',
};

// Per-site generated blocks are named by the design (`retailHero`,
// `menuHighlights`, ...), so they get an icon from a word in their slug. The
// slug is split on camelCase first and every word is matched whole, so a name
// that merely contains a keyword doesn't borrow its icon: `blogPreview` is not
// a testimonial ("review" inside "preview") and `statementBlock` is not a
// statistic. The first match wins; more specific words come first.
const KEYWORD_ICONS: [RegExp, PickerIconName][] = [
  [/\b(hero|banner|masthead)s?\b/i, 'panelTop'],
  [/\b(testimonial|review|quote)s?\b/i, 'quote'],
  [/\b(faq|question)s?\b/i, 'circleQuestionMark'],
  [/\b(gallery|galleries|image|photo|portfolio)s?\b/i, 'images'],
  [/\b(stat|metric|number|counter)s?\b/i, 'chartColumn'],
  [/\b(logo|partner|client)s?\b/i, 'badgeCheck'],
  [/\b(contact|newsletter|signup)s?\b/i, 'mail'],
  [/\b(audio|podcast|music|episode)s?\b/i, 'audioLines'],
  [/\b(people|team|staff|person|member)s?\b/i, 'users'],
  [/\b(related|link)s?\b/i, 'link'],
  [/\b(cta|button)s?\b/i, 'mousePointerClick'],
  [/\b(grid|feature|card|tile|service)s?\b/i, 'layoutGrid'],
  [/\b(list|collection|post|article|menu)s?\b/i, 'list'],
  [/\b(text|content|story|stories|about|copy)\b/i, 'text'],
];

// `retailHero` -> `retail hero`, so the patterns above can anchor on \b.
const slugWords = (slug: string): string =>
  slug.replace(/([a-z\d])([A-Z])/g, '$1 $2').toLowerCase();

export const FALLBACK_PICKER_ICON: PickerIconName = 'box';

// The admin's primary foreground: kite-ui's `--color-fg-primary`, which is the
// brand colour oklch(0.65 0.2 41) and the colour the dashboard's entity icons
// use. A thumbnail is an <img>, so it can't inherit `currentColor` and needs
// the value spelled out.
const ICON_STROKE = '#ee5700';

export function pickerIconName(slug: string): PickerIconName {
  const words = slugWords(slug);
  return (
    // Own-property check, not a bare lookup: a generated slug that collides
    // with an inherited name (`constructor`, `toString`, ...) would otherwise
    // resolve up the prototype chain to a non-icon that `??` happily accepts.
    (Object.hasOwn(LIBRARY_ICONS, slug) ? LIBRARY_ICONS[slug] : undefined) ??
    KEYWORD_ICONS.find(([pattern]) => pattern.test(words))?.[1] ??
    FALLBACK_PICKER_ICON
  );
}

export function pickerIconUrl(name: PickerIconName): string {
  // Same guard, and it keeps a miss local: an unknown name draws the generic
  // icon instead of throwing. These run at module scope from `index.ts`, so a
  // throw here takes down the whole site config — admin and public pages.
  const icon = (
    Object.hasOwn(ICONS, name) ? ICONS[name] : ICONS[FALLBACK_PICKER_ICON]
  ) as IconNode;
  const shapes = icon
    .map(([tag, attrs]) => {
      const attributes = Object.entries(attrs)
        .map(([key, value]) => `${key}="${value}"`)
        .join(' ');
      return `<${tag} ${attributes}/>`;
    })
    .join('');
  const svg =
    `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" ` +
    `fill="none" stroke="${ICON_STROKE}" stroke-width="2" stroke-linecap="round" ` +
    `stroke-linejoin="round">${shapes}</svg>`;
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

// Adds a picker icon unless the block already brings its own thumbnail. The
// empty alt marks the icon as decorative: the block name sits right next to it.
export const withPickerIcon = (block: Block): Block =>
  block.admin?.images?.thumbnail
    ? block
    : {
        ...block,
        admin: {
          ...block.admin,
          images: {
            ...block.admin?.images,
            thumbnail: {
              url: pickerIconUrl(pickerIconName(block.slug)),
              alt: '',
            },
          },
        },
      };
