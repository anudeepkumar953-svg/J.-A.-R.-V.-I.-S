// Contract for the "Add Layout" picker icons. Without a thumbnail Payload draws
// the same grey placeholder picture on every block's picker card, which editors
// read as broken images. The pins: every layout block reaches the picker with
// an icon, the fixed library blocks each get their own, and a per-site
// generated block gets a sensible icon from its name.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml). Exits non-zero on
// any failure.
//
// Run locally: pnpm exec tsx src/payload/blocks/pickerIcons.test.ts

import type { Block } from 'payload';
import { generatedBlocks } from './generated';
import { layoutBlocks } from './index';
import {
  FALLBACK_PICKER_ICON,
  LIBRARY_ICONS,
  pickerIconName,
  pickerIconUrl,
  withPickerIcon,
} from './pickerIcons';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

function thumbnailUrl(block: Block): string | undefined {
  const thumbnail = block.admin?.images?.thumbnail;
  return typeof thumbnail === 'string' ? thumbnail : thumbnail?.url;
}

// Derived, never listed: a library block added to `index.ts` without an entry
// in LIBRARY_ICONS would otherwise ship the generic cube and still pass.
const generatedSlugs = new Set(generatedBlocks.map((block) => block.slug));
const LIBRARY_SLUGS = layoutBlocks
  .map((block) => block.slug)
  .filter((slug) => !generatedSlugs.has(slug));

console.log('every layout block has a picker icon');
for (const block of layoutBlocks) {
  const url = thumbnailUrl(block);
  const svg = url?.startsWith('data:image/svg+xml,')
    ? decodeURIComponent(url.slice('data:image/svg+xml,'.length))
    : '';
  check(
    `${block.slug} has an SVG icon`,
    svg.startsWith('<svg') && svg.endsWith('</svg>'),
    `thumbnail: ${String(url).slice(0, 80)}`,
  );
}

console.log('library blocks get their own icons');
check(
  'the fixed library reaches the picker at all',
  LIBRARY_SLUGS.length > 0,
  `derived ${LIBRARY_SLUGS.length} library slugs from layoutBlocks`,
);
// Both directions, so neither side can drift silently: a library block added
// without an icon entry, or an entry left behind when its block is removed.
const withoutIcon = LIBRARY_SLUGS.filter(
  (slug) => !Object.hasOwn(LIBRARY_ICONS, slug),
);
check(
  'every library block has its own icon entry',
  withoutIcon.length === 0,
  `no entry for: ${withoutIcon.join(', ')}`,
);
const stale = Object.keys(LIBRARY_ICONS).filter(
  (slug) => !LIBRARY_SLUGS.includes(slug),
);
check(
  'every icon entry names a registered library block',
  stale.length === 0,
  `no such block: ${stale.join(', ')}`,
);
const libraryIcons = LIBRARY_SLUGS.map(pickerIconName);
check(
  'no library block falls back to the generic icon',
  !libraryIcons.includes(FALLBACK_PICKER_ICON),
  libraryIcons.join(', '),
);
check(
  'library icons are all distinct',
  new Set(libraryIcons).size === libraryIcons.length,
  libraryIcons.join(', '),
);

console.log('generated blocks get an icon from their name');
check(
  'retailHero looks like a hero',
  pickerIconName('retailHero') === pickerIconName('hero'),
);
check(
  'customerReviews looks like testimonials',
  pickerIconName('customerReviews') === pickerIconName('testimonialList'),
);
check(
  'an unrecognised name gets the generic icon',
  pickerIconName('zqxBespoke') === FALLBACK_PICKER_ICON,
);
// Whole-word matching: a keyword sitting inside a longer word must not lend
// its icon.
check(
  'blogPreview is not read as a testimonial',
  pickerIconName('blogPreview') !== pickerIconName('testimonialList'),
  `got ${pickerIconName('blogPreview')}`,
);
check(
  'statementBlock is not read as statistics',
  pickerIconName('statementBlock') !== pickerIconName('stats'),
  `got ${pickerIconName('statementBlock')}`,
);

// A generated slug can be any word the design agent picks. If one collides
// with an inherited property name, the icon lookup must still yield an icon:
// these run at module scope, so a throw stops the site config from loading.
console.log('a slug named after a built-in property still gets an icon');
for (const slug of ['constructor', 'toString', 'valueOf', 'hasOwnProperty']) {
  const name = pickerIconName(slug);
  check(
    `${slug} falls back to the generic icon`,
    name === FALLBACK_PICKER_ICON,
    `got ${String(name)}`,
  );
  let url = '';
  try {
    url = pickerIconUrl(name);
  } catch (error) {
    url = `threw: ${String(error)}`;
  }
  check(
    `${slug} renders an icon without throwing`,
    url.startsWith('data:image/svg+xml,'),
    url.slice(0, 80),
  );
}

console.log('a block that brings its own thumbnail keeps it');
const own = withPickerIcon({
  slug: 'custom',
  fields: [],
  admin: { images: { thumbnail: 'https://example.com/custom.png' } },
});
check(
  'own thumbnail is untouched',
  thumbnailUrl(own) === 'https://example.com/custom.png',
);

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`);
  process.exit(1);
}
console.log('\nall picker icon checks passed');
