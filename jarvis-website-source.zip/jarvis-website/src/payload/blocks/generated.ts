import type { Block } from 'payload';

// Custom blocks for the J.A.R.V.I.S. holographic console. Each one is a matched
// triple: this schema + src/components/blocks/<Name>.tsx + the RenderBlocks
// registry entry written by the injector. Field names equal component props.

const STATE_OPTIONS = [
  { label: 'Idle', value: 'idle' },
  { label: 'Listening', value: 'listening' },
  { label: 'Processing', value: 'processing' },
  { label: 'Speaking', value: 'speaking' },
  { label: 'Error', value: 'error' },
];

export const generatedBlocks: Block[] = [
  {
    slug: 'coreStates',
    interfaceName: 'CoreStatesBlock',
    fields: [
      { name: 'kicker', type: 'text' },
      { name: 'heading', type: 'text', required: true },
      { name: 'subheading', type: 'textarea' },
      { name: 'hint', type: 'text' },
      {
        name: 'states',
        type: 'array',
        fields: [
          {
            name: 'stateKey',
            type: 'select',
            required: true,
            options: STATE_OPTIONS,
          },
          { name: 'label', type: 'text', required: true },
          { name: 'summary', type: 'textarea' },
          { name: 'behaviour', type: 'textarea' },
          { name: 'trigger', type: 'textarea' },
        ],
      },
    ],
  },
  {
    slug: 'gestureControl',
    interfaceName: 'GestureControlBlock',
    fields: [
      { name: 'kicker', type: 'text' },
      { name: 'heading', type: 'text', required: true },
      { name: 'subheading', type: 'textarea' },
      { name: 'privacyNote', type: 'text' },
      { name: 'fallbackNote', type: 'textarea' },
      {
        name: 'gestures',
        type: 'array',
        fields: [
          { name: 'gesture', type: 'text', required: true },
          { name: 'action', type: 'text', required: true },
          { name: 'fallback', type: 'text' },
        ],
      },
    ],
  },
  {
    slug: 'voiceConsole',
    interfaceName: 'VoiceConsoleBlock',
    fields: [
      { name: 'kicker', type: 'text' },
      { name: 'heading', type: 'text', required: true },
      { name: 'subheading', type: 'textarea' },
      { name: 'demoBadge', type: 'text' },
      { name: 'welcomeMessage', type: 'textarea' },
      { name: 'inputPlaceholder', type: 'text' },
      { name: 'commandsHeading', type: 'text' },
      {
        name: 'commands',
        type: 'array',
        fields: [
          { name: 'phrase', type: 'text', required: true },
          { name: 'description', type: 'text' },
        ],
      },
    ],
  },
  {
    slug: 'capabilities',
    interfaceName: 'CapabilitiesBlock',
    fields: [
      { name: 'kicker', type: 'text' },
      { name: 'heading', type: 'text', required: true },
      { name: 'subheading', type: 'textarea' },
      { name: 'note', type: 'text' },
      {
        name: 'items',
        type: 'array',
        fields: [
          {
            name: 'capability',
            type: 'select',
            required: true,
            options: [
              { label: 'Camera', value: 'camera' },
              { label: 'Microphone / speech recognition', value: 'microphone' },
              { label: 'Speech synthesis', value: 'synthesis' },
              { label: 'AI provider', value: 'provider' },
            ],
          },
          { name: 'label', type: 'text', required: true },
          { name: 'description', type: 'textarea' },
        ],
      },
    ],
  },
  {
    slug: 'providerAdapter',
    interfaceName: 'ProviderAdapterBlock',
    fields: [
      { name: 'kicker', type: 'text' },
      { name: 'heading', type: 'text', required: true },
      { name: 'subheading', type: 'textarea' },
      { name: 'note', type: 'textarea' },
      {
        name: 'layers',
        type: 'array',
        fields: [
          { name: 'label', type: 'text', required: true },
          {
            name: 'status',
            type: 'select',
            required: true,
            options: [
              { label: 'Implemented in this demo', value: 'implemented' },
              { label: 'Open slot', value: 'slot' },
              { label: 'Not connected', value: 'not-connected' },
            ],
          },
          { name: 'detail', type: 'textarea' },
        ],
      },
    ],
  },
];
