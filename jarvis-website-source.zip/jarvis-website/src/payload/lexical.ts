import type { DefaultTypedEditorState } from '@payloadcms/richtext-lexical';

// The seed's markdown conversion lives beside it in `scripts/`, which the
// platform copies into sites made from every template version. Re-exported
// for code that reads it from here.
export {
  isolateMarkdownImages,
  markdownDoc,
  markdownEditorConfig,
} from '../../scripts/markdown-lexical';

// Builds a minimal lexical richText document from plain-text paragraphs. A
// Payload `richText` value is a lexical JSON tree (`{ root: { ... } }`), never a
// plain string — seed content and field `defaultValue`s use this helper so the
// shape always matches what the admin's lexical editor reads and writes.
//
//   lexicalDoc('First paragraph.', 'Second paragraph.')
export function lexicalDoc(...paragraphs: string[]): DefaultTypedEditorState {
  return {
    root: {
      type: 'root',
      format: '',
      indent: 0,
      version: 1,
      direction: 'ltr',
      children: paragraphs.map((text) => ({
        type: 'paragraph',
        format: '',
        indent: 0,
        version: 1,
        direction: 'ltr',
        textFormat: 0,
        children: [
          {
            type: 'text',
            text,
            format: 0,
            detail: 0,
            mode: 'normal',
            style: '',
            version: 1,
          },
        ],
      })),
    },
  } as DefaultTypedEditorState;
}
