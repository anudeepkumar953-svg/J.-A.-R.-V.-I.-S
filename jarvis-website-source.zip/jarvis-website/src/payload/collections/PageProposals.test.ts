// Contract: a page Kite wrote on Main that nobody has added yet is readable
// and changeable only by a signed-in editor. Its REST endpoints answer an
// anonymous caller with nothing.
//
// Run locally: pnpm exec tsx src/payload/collections/PageProposals.test.ts

import type { Access } from 'payload';

import { PageProposals } from './PageProposals';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

const allows = (rule: Access | undefined, user: unknown): boolean =>
  rule !== undefined &&
  // The rules read only the request's user.
  rule({ req: { user } } as Parameters<Access>[0]) === true;

console.log('page proposals need a signed-in editor');
for (const op of ['read', 'create', 'update', 'delete'] as const) {
  const rule = PageProposals.access?.[op] as Access | undefined;
  check(
    `${op} is refused without a session`,
    rule !== undefined && !allows(rule, null),
  );
  check(
    `${op} is allowed for a signed-in editor`,
    allows(rule, { id: 1, collection: 'users' }),
  );
}

if (failures > 0) {
  console.error(`\n${failures} failure(s)`);
  process.exit(1);
}
console.log('\nall checks passed');
