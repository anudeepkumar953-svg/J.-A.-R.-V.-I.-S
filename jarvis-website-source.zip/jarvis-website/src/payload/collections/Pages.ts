import type { CollectionConfig, Where } from 'payload';
import { layoutBlocks } from '../blocks';
import { pageSeoGroup, relatedPagesField } from '../fields';
import {
  keepChildrenFromDeletion,
  keepChildrenFromHiding,
  moveChildrenWithParent,
  nestUnderParent,
} from '../pagePath';
import {
  revalidateContentAfterChange,
  revalidateContentAfterDelete,
} from '../revalidate';

// One document per route. `slug` is the route path without a leading slash
// (the home page uses `home`). The page renderer maps `layout` blocks to React
// components; `sitemap`/`robots` read this collection instead of static arrays.
export const Pages: CollectionConfig = {
  slug: 'pages',
  hooks: {
    beforeChange: [nestUnderParent, keepChildrenFromHiding],
    beforeDelete: [keepChildrenFromDeletion],
    afterChange: [moveChildrenWithParent, revalidateContentAfterChange],
    afterDelete: [revalidateContentAfterDelete],
  },
  admin: {
    useAsTitle: 'title',
    defaultColumns: ['title', 'slug', 'updatedAt'],
    hideAPIURL: true,
    // Renders as the list-view sub-header (styled by admin-skin.css) to match
    // the Kite content editor's "title + description" page header.
    description: 'Create and manage the pages for your website.',
    components: {
      // Custom save controls: an explicit Save button plus a save-state badge
      // (Saved / Unsaved changes / Saving). Drafts are off, so Save writes
      // straight to the live page. See src/admin/SaveControls.
      // The Back control that replaces the hidden breadcrumb is applied to
      // every collection centrally (`withKiteAdmin` in src/payload/kiteAdmin),
      // so it is deliberately not repeated here.
      edit: { SaveButton: '/admin/SaveControls#SaveControls' },
      // The design-system list view is applied to every collection centrally
      // (`withKiteAdmin` in src/payload/kiteAdmin.ts) rather than wired per
      // collection here. See src/admin/KiteListView for why it owns the whole
      // view: Payload's list-controls row (search, Columns, Filters) renders
      // above every override slot, so it cannot be replaced piecemeal.
    },
  },
  fields: [
    {
      // "Start from an idea" — the panel above the form on the create screen
      // (see src/admin/IdeaPanel.tsx). First in the list because it is what
      // the editor reaches for before the empty form below it, and it renders
      // nowhere else: on an existing page it draws nothing. Carries no data
      // (ui field).
      name: 'ideaPanel',
      type: 'ui',
      admin: {
        components: { Field: '/admin/IdeaPanel#IdeaPanel' },
      },
    },
    // Presentational grouping only — an UNNAMED group does not nest data, so the
    // `title`/`slug` paths stay top-level (the frontend renderer, seed manifest,
    // and autosave/autofill all still reference them unchanged). The header
    // icon + label render via a custom Label component; admin-skin.css cards the
    // `.kite-section` wrapper. `admin.width` lays the two fields side by side.
    {
      type: 'group',
      label: 'Page Details',
      admin: {
        className: 'kite-section',
        components: { Label: '/admin/SectionLabel#PageDetailsLabel' },
      },
      // `admin.width` only lays fields side by side inside a `row` (Payload's
      // `.render-fields` otherwise stacks them); the row is presentational and
      // does not nest data, so `title`/`slug` stay top-level paths.
      fields: [
        {
          // Title, parent and slug on one line: the parent decides the path the
          // slug is appended to, so it sits right before it.
          type: 'row',
          fields: [
            {
              name: 'title',
              type: 'text',
              required: true,
              admin: { width: '34%' },
            },
            {
              // Optional. A page under another one lives at the parent's path
              // plus its own segment; the hook keeps `slug` in that shape
              // (pagePath.ts). The homepage is never offered: it is served at
              // `/`, and a page under it would get an address like
              // `/home/catering`.
              name: 'parent',
              type: 'relationship',
              relationTo: 'pages',
              filterOptions: ({ id }) => {
                const notHome: Where = { slug: { not_equals: 'home' } };
                // A proposal can be discarded, which would strand a child
                // nested under it.
                const added: Where = {
                  or: [
                    { proposed: { not_equals: true } },
                    { proposed: { exists: false } },
                  ],
                };
                return id
                  ? { and: [notHome, added, { id: { not_equals: id } }] }
                  : { and: [notHome, added] };
              },
              admin: {
                width: '33%',
                placeholder: 'Top level (no parent)',
                allowCreate: false,
                allowEdit: false,
              },
            },
            {
              name: 'slug',
              type: 'text',
              required: true,
              unique: true,
              index: true,
              admin: { width: '33%' },
            },
          ],
        },
      ],
    },
    {
      // Layout sits directly under Page Details (UX review: the sections a
      // user edits most come first; SEO reads as metadata and goes last).
      // Field order here is presentational only — `layout`/`seo` stay the
      // same top-level data paths wherever they appear in this array.
      name: 'layout',
      type: 'blocks',
      label: 'Layout',
      admin: {
        className: 'kite-section',
        // Block rows start collapsed so the page reads as a tidy section list.
        initCollapsed: true,
        components: { Label: '/admin/SectionLabel#LayoutLabel' },
      },
      blocks: layoutBlocks,
    },
    {
      // A page Kite wrote that the editor has not added yet: it lives in the
      // draft so it can be previewed, but the site serves it to nobody else
      // (the catch-all route and the sitemap skip it) until the AI tab's
      // "Add to draft" clears this. Pages saved any other way are never
      // proposed.
      name: 'proposed',
      type: 'checkbox',
      defaultValue: false,
      admin: { hidden: true },
    },
    relatedPagesField(),
    pageSeoGroup(),
    {
      // Invisible watcher: auto-fills a block with AI content when one is added
      // via the native "Add Layout" (see src/admin/SectionAutofill.tsx). Carries
      // no data (ui field).
      name: 'sectionAutofill',
      type: 'ui',
      admin: {
        components: { Field: '/admin/SectionAutofill#SectionAutofill' },
      },
    },
  ],
};
