import type { AuthStrategyResult, CollectionConfig } from 'payload';
import {
  CMS_SESSION_COOKIE,
  readCookie,
  verifySessionToken,
} from '../platform-token';

// Minimal auth-enabled collection backing the Payload admin session. One
// admin user is provisioned per schema at seed time, with no password. The
// `platform-token` strategy below (a signed cookie minted by the platform) is
// the ONLY way to authenticate: the local email/password strategy is disabled
// because `/admin` is publicly served on every deployed site and a password
// login surface would have to be provisioned with per-site credentials nobody
// ever uses.
export const Users: CollectionConfig = {
  slug: 'users',
  auth: {
    // `enableFields` keeps the `email` column (used as the admin title and by
    // the seed) while removing password verification and the login endpoint.
    disableLocalStrategy: { enableFields: true, optionalPassword: true },
    // On each admin/API request, verify the sandbox-signed session cookie
    // (minted at /admin-login after the one-time platform-token handoff) and
    // resolve it to the auto-provisioned admin user. Only the session cookie is
    // accepted — never the raw platform token — so there is no path back to the
    // 60s-churn credential.
    strategies: [
      {
        name: 'platform-token',
        authenticate: async ({
          headers,
          payload,
        }): Promise<AuthStrategyResult> => {
          const token = readCookie(headers.get('cookie'), CMS_SESSION_COOKIE);
          const result = verifySessionToken(token, process.env.PAYLOAD_SECRET);
          if (!result.valid) return { user: null };
          // `result.appId` is intentionally not checked against this app's own id:
          // PAYLOAD_SECRET is per-app, so a valid HMAC could only have been minted
          // by THIS app's own /admin-login. Add an appId equality check here only
          // if the secret ever becomes shared across apps/environments.
          const found = await payload.find({
            collection: 'users',
            limit: 1,
            sort: 'createdAt',
            depth: 0,
          });
          const user = found.docs[0];
          if (!user) return { user: null };
          return { user: { ...user, collection: 'users' } };
        },
      },
    ],
  },
  admin: {
    useAsTitle: 'email',
    hideAPIURL: true,
    // Hidden from the Content tab: the single admin user is auto-provisioned per
    // schema and never edited by hand. `hidden` only affects admin-UI visibility
    // (nav, dashboard, direct routes) — the platform-token auth strategy still
    // reads this collection via the Local API, so login keeps working.
    hidden: true,
  },
  fields: [],
};
