import type { Access, CollectionConfig } from 'payload';
import { layoutBlocks } from '../blocks';
import { pageSeoGroup, relatedPagesField } from '../fields';

// Pages Kite wrote on Main that the editor has not added yet. Kept out of
// `pages` because a published site reads the live schema, and one built
// before proposals existed has no filter that would hide them. Nothing public
// reads this collection: the only reader is the signed-in editor's preview
// (src/lib/proposal-preview.ts), and a draft merge never carries it
// (scripts/page-merge.ts). Every operation needs a signed-in editor, stated
// here rather than left to Payload's default so nothing loosens it unseen.
const signedIn: Access = ({ req }) => Boolean(req.user);

export const PageProposals: CollectionConfig = {
  slug: 'page-proposals',
  access: {
    read: signedIn,
    create: signedIn,
    update: signedIn,
    delete: signedIn,
  },
  admin: {
    useAsTitle: 'title',
    hidden: true,
  },
  fields: [
    { name: 'title', type: 'text', required: true },
    {
      // The full route path, already nested (`home/catering`), so the page
      // can be added at its address without resolving the parent again.
      name: 'slug',
      type: 'text',
      required: true,
      unique: true,
      index: true,
    },
    // The parent page's slug when the page goes under one.
    { name: 'parentSlug', type: 'text' },
    { name: 'layout', type: 'blocks', blocks: layoutBlocks },
    relatedPagesField(),
    pageSeoGroup(),
  ],
};
