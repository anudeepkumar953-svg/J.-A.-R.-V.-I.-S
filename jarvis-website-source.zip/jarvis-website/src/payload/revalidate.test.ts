// Contract for refreshing the published site after a save made in another
// process (the Content tab's editing sandbox, seed and merge scripts). Without
// it the published site shows an edit only once its CMS cache expires.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml). Exits non-zero on
// any failure.
//
// Run locally: pnpm exec tsx src/payload/revalidate.test.ts

import {
  CMS_REVALIDATE_PATH,
  SIGNATURE_HEADER,
  TIMESTAMP_HEADER,
  handleRevalidateRequest,
  signRevalidateRequest,
  type RevalidateBody,
} from './revalidate-signal';

const SECRET = 'a'.repeat(64);
const LIVE = 'payload_iter3';
const PUBLISHED = 'https://published.test';

// The module reads these when a hook fires; set before importing it.
process.env.PAYLOAD_SECRET = SECRET;
process.env.PAYLOAD_SCHEMA = LIVE;
process.env.KITE_PUBLISHED_SITE_URL = PUBLISHED;
delete process.env.VERCEL;

const {
  flushPublishedSiteRevalidation,
  revalidateContentAfterChange,
  revalidateSiteSettingsAfterChange,
  revalidationTiming,
} = await import('./revalidate');

let failures = 0;
function check(name: string, condition: boolean, detail = ''): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// The published site's side, with the tags it expired captured.
async function deliver(
  request: Request,
  options: { schema?: string; secret?: string; nowMs?: number } = {},
) {
  const { schema = LIVE, nowMs = Date.now() } = options;
  // An explicit `secret: undefined` means "the site has none".
  const secret = 'secret' in options ? options.secret : SECRET;
  const expired: string[] = [];
  const response = await handleRevalidateRequest(request, {
    secret,
    schema,
    revalidate: (tag) => expired.push(tag),
    nowMs,
  });
  return { status: response.status, expired };
}

function signedRequest(
  body: RevalidateBody,
  { nowMs = Date.now(), secret = SECRET } = {},
): Request {
  const signed = signRevalidateRequest(body, secret, nowMs)!;
  return new Request(`${PUBLISHED}${CMS_REVALIDATE_PATH}`, {
    method: 'POST',
    headers: signed.headers,
    body: signed.body,
  });
}

console.log('route');
{
  const ok = await deliver(
    signedRequest({ tags: ['cms-content', 'site-settings'], schema: LIVE }),
  );
  check('valid request is accepted', ok.status === 200, `status ${ok.status}`);
  check(
    'valid request expires exactly the named tags',
    JSON.stringify(ok.expired) ===
      JSON.stringify(['cms-content', 'site-settings']),
    JSON.stringify(ok.expired),
  );

  const stale = await deliver(
    signedRequest(
      { tags: ['cms-content'], schema: LIVE },
      { nowMs: Date.now() - 120_000 },
    ),
  );
  check(
    'stale timestamp is rejected',
    stale.status === 401 && stale.expired.length === 0,
  );

  const future = await deliver(
    signedRequest(
      { tags: ['cms-content'], schema: LIVE },
      { nowMs: Date.now() + 120_000 },
    ),
  );
  check(
    'future timestamp is rejected',
    future.status === 401 && future.expired.length === 0,
  );

  const wrongKey = await deliver(
    signedRequest(
      { tags: ['cms-content'], schema: LIVE },
      { secret: 'b'.repeat(64) },
    ),
  );
  check(
    'signature from another secret is rejected',
    wrongKey.status === 401 && wrongKey.expired.length === 0,
  );

  // Same signature, different body: the signature covers the body bytes.
  const signed = signRevalidateRequest(
    { tags: ['cms-content'], schema: LIVE },
    SECRET,
  )!;
  const tampered = await deliver(
    new Request(`${PUBLISHED}${CMS_REVALIDATE_PATH}`, {
      method: 'POST',
      headers: signed.headers,
      body: signed.body.replace('cms-content', 'site-settings'),
    }),
  );
  check(
    'tampered body is rejected',
    tampered.status === 401 && tampered.expired.length === 0,
  );

  const unsigned = await deliver(
    new Request(`${PUBLISHED}${CMS_REVALIDATE_PATH}`, {
      method: 'POST',
      headers: { [TIMESTAMP_HEADER]: String(Math.floor(Date.now() / 1000)) },
      body: signed.body,
    }),
  );
  check('missing signature is rejected', unsigned.status === 401);

  const malformed = await deliver(
    new Request(`${PUBLISHED}${CMS_REVALIDATE_PATH}`, {
      method: 'POST',
      headers: { ...signed.headers, [SIGNATURE_HEADER]: 'zz' },
      body: signed.body,
    }),
  );
  check('malformed signature is rejected', malformed.status === 401);

  const noSecret = await deliver(
    signedRequest({ tags: ['cms-content'], schema: LIVE }),
    { secret: undefined },
  );
  check(
    'a site without PAYLOAD_SECRET rejects everything',
    noSecret.status === 401,
  );
  check(
    'signing fails closed on a short secret',
    signRevalidateRequest({ tags: ['cms-content'], schema: LIVE }, 'short') ===
      null,
  );

  const unknownTag = await deliver(
    signedRequest({ tags: ['cms-content', 'everything'], schema: LIVE }),
  );
  check(
    'an unknown tag rejects the whole request',
    unknownTag.status === 400 && unknownTag.expired.length === 0,
    `status ${unknownTag.status}, expired ${unknownTag.expired}`,
  );

  const otherSchema = await deliver(
    signedRequest({ tags: ['cms-content'], schema: 'payload_iter1' }),
  );
  check(
    'a write to a schema the site does not serve expires nothing',
    otherSchema.status === 200 && otherSchema.expired.length === 0,
  );

  // A site that reads only what Publish copied ignores saves to the edited
  // content, and refreshes when Publish names its own copy.
  const copy = `${LIVE}_pub_20261008120000`;
  const editedContent = await deliver(
    signedRequest({ tags: ['cms-content'], schema: LIVE }),
    { schema: copy },
  );
  check(
    'a published site ignores a save to the content editors write',
    editedContent.status === 200 && editedContent.expired.length === 0,
  );
  const published = await deliver(
    signedRequest({ tags: ['cms-content'], schema: copy }),
    { schema: copy },
  );
  check(
    'a published site refreshes when Publish names its copy',
    JSON.stringify(published.expired) === JSON.stringify(['cms-content']),
    JSON.stringify(published.expired),
  );

  // The platform signs the Publish refresh in Python
  // (`payload_secrets.sign_revalidate_request`); its test pins this same vector.
  const vector = signRevalidateRequest(
    { tags: ['cms-content'], schema: 'payload_iter3_pub_20261008120000' },
    SECRET,
    1_700_000_000_000,
  )!;
  check(
    'the signature matches the vector the platform signs',
    vector.body ===
      '{"tags":["cms-content"],"schema":"payload_iter3_pub_20261008120000"}' &&
      vector.headers[TIMESTAMP_HEADER] === '1700000000' &&
      vector.headers[SIGNATURE_HEADER] ===
        'a1afd63abf63d711badede54176105df4fb9f54d8f9ac382aedaad980371f1eb',
    JSON.stringify(vector),
  );

  for (const [sent, served] of [
    ['', LIVE],
    [LIVE, ''],
  ]) {
    const unset = await deliver(
      signedRequest({ tags: ['cms-content'], schema: sent }),
      { schema: served },
    );
    check(
      `an unset schema (sent ${JSON.stringify(sent)}, served ${JSON.stringify(served)}) still refreshes`,
      JSON.stringify(unset.expired) === JSON.stringify(['cms-content']),
      JSON.stringify(unset.expired),
    );
  }
}

// Record what the sender posts, and answer its address lookups, instead of
// reaching the network. `sent` holds what reached the published site, `told`
// what reached the platform.
type Sent = { url: string; request: Request };
const sent: Sent[] = [];
const told: Sent[] = [];
const lookups: { url: string; cache?: RequestCache }[] = [];
// What the platform answers to "where is this site published?".
let platformAnswer: () => Response = () =>
  new Response('{"url":null}', { status: 200 });
// Network latency, so a request can still be under way when a script flushes.
let latencyMs = 0;
globalThis.fetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
  if (latencyMs) await sleep(latencyMs);
  if ((init?.method ?? 'GET') === 'GET') {
    lookups.push({ url: String(input), cache: init?.cache });
    return platformAnswer();
  }
  // Recorded on arrival: a request cut short by process exit never lands.
  const posted = {
    url: String(input),
    request: new Request(String(input), init),
  };
  (posted.url.endsWith('/cms-content-changed') ? told : sent).push(posted);
  return new Response('{}', { status: 200 });
}) as typeof fetch;

type FakeReq = { transactionID?: unknown };
function save(req: FakeReq = {}): void {
  revalidateContentAfterChange({ doc: {}, req } as unknown as Parameters<
    typeof revalidateContentAfterChange
  >[0]);
}
function saveSettings(req: FakeReq = {}): void {
  revalidateSiteSettingsAfterChange({ doc: {}, req } as unknown as Parameters<
    typeof revalidateSiteSettingsAfterChange
  >[0]);
}

console.log('sender');
{
  sent.length = 0;
  // A burst, as a publish produces: one request carrying both tags.
  save();
  save();
  saveSettings();
  save();
  await sleep(500);
  check(
    'a burst of saves sends one request',
    sent.length === 1,
    `sent ${sent.length}`,
  );
  check(
    'the request goes to the published site route',
    sent[0]?.url === `${PUBLISHED}${CMS_REVALIDATE_PATH}`,
    sent[0]?.url,
  );
  if (sent[0]) {
    const delivered = await deliver(sent[0].request);
    check(
      'the published site accepts it and expires both tags',
      delivered.status === 200 &&
        JSON.stringify([...delivered.expired].sort()) ===
          JSON.stringify(['cms-content', 'site-settings']),
      `status ${delivered.status}, expired ${delivered.expired}`,
    );
  }
}

{
  sent.length = 0;
  // Payload runs afterChange before it commits; sending then could re-cache
  // the old row on the published site.
  const req: FakeReq = { transactionID: 'tx-1' };
  save(req);
  await sleep(600);
  check(
    'nothing is sent while the save is uncommitted',
    sent.length === 0,
    `sent ${sent.length}`,
  );
  delete req.transactionID;
  await sleep(300);
  check(
    'the request is sent once the save commits',
    sent.length === 1,
    `sent ${sent.length}`,
  );
}

{
  sent.length = 0;
  // Scripts exit right after their last save.
  save();
  await flushPublishedSiteRevalidation();
  check(
    'flush sends the queued refresh immediately',
    sent.length === 1,
    `sent ${sent.length}`,
  );
  await sleep(400);
  check(
    'flush leaves nothing behind to send twice',
    sent.length === 1,
    `sent ${sent.length}`,
  );
}

{
  sent.length = 0;
  process.env.PAYLOAD_SCHEMA = 'payload_iter3_draft_0123456789ab';
  save();
  await sleep(500);
  check(
    'a save into a draft schema does not refresh the published site',
    sent.length === 0,
  );
  process.env.PAYLOAD_SCHEMA = LIVE;
}

{
  sent.length = 0;
  process.env.VERCEL = '1';
  save();
  await sleep(500);
  check('the published site itself does not post to itself', sent.length === 0);
  delete process.env.VERCEL;
}

{
  sent.length = 0;
  // The seed script does other work after its last save, so the coalescing
  // timer can start the send before the script flushes and exits.
  latencyMs = 300;
  save();
  await sleep(400);
  await flushPublishedSiteRevalidation();
  check(
    'flush waits for a send the timer already started',
    sent.length === 1,
    `sent ${sent.length}`,
  );
  latencyMs = 0;
}

// A save whose transaction outlives the wait is never sent: sending before the
// commit would let the published site re-cache the old row, and a late send
// after the cap could do the same for whatever it raced with.
{
  sent.length = 0;
  revalidationTiming.maxCommitWaitMs = 400;
  const req: FakeReq = { transactionID: 'tx-long' };
  save(req);
  await sleep(900);
  check(
    'a save still uncommitted after the wait is not sent',
    sent.length === 0,
    `sent ${sent.length}`,
  );
  delete req.transactionID;
  await sleep(500);
  check(
    'nor is it sent when that transaction finally ends',
    sent.length === 0,
    `sent ${sent.length}`,
  );

  const scriptReq: FakeReq = { transactionID: 'tx-script' };
  save(scriptReq);
  await flushPublishedSiteRevalidation();
  delete scriptReq.transactionID;
  await sleep(500);
  check(
    'flush gives up on an uncommitted save instead of sending it',
    sent.length === 0,
    `sent ${sent.length}`,
  );
  revalidationTiming.maxCommitWaitMs = 10_000;
}

// Where to send is asked of the platform at send time, so a site published or
// moved while the editing sandbox runs is reached at its current address.
const PLATFORM = 'https://platform.test';
const WEBSITE_ID = '3dc0f8fc-b22d-43da-89fc-86ea6f794ef2';
process.env.PLATFORM_BASE_URL = PLATFORM;
process.env.PLATFORM_API_KEY = WEBSITE_ID;
const lookupUrl = `${PLATFORM}/api/v1/websites/${WEBSITE_ID}/published-url`;

{
  sent.length = 0;
  told.length = 0;
  lookups.length = 0;
  // Booted before the first publish: no start-time address at all.
  delete process.env.KITE_PUBLISHED_SITE_URL;
  platformAnswer = () =>
    new Response('{"url":"https://first-publish.test"}', { status: 200 });
  save();
  await sleep(500);
  check(
    'a site published after the sandbox started is refreshed at its new address',
    sent.length === 1 &&
      sent[0].url === `https://first-publish.test${CMS_REVALIDATE_PATH}`,
    sent.map((x) => x.url).join(', '),
  );
  check(
    'the address is asked for uncached, under this website',
    lookups.length === 1 &&
      lookups[0].url === lookupUrl &&
      lookups[0].cache === 'no-store',
    JSON.stringify(lookups),
  );
  // The platform counts what the next Publish ships, and a save made here
  // reaches that count only through this report.
  check(
    'the save is reported to the platform under this website',
    told.length === 1 &&
      told[0].url ===
        `${PLATFORM}/api/v1/websites/${WEBSITE_ID}/cms-content-changed`,
    told.map((x) => x.url).join(', '),
  );
  if (told[0]) {
    const verified = await deliver(told[0].request);
    check(
      'the report names the saved schema under the site signature',
      verified.status === 200 &&
        JSON.stringify(verified.expired) === JSON.stringify(['cms-content']),
      `status ${verified.status}, expired ${verified.expired}`,
    );
  }
}

{
  told.length = 0;
  // A recount that ran before the commit would read the row without the save.
  const req: FakeReq = { transactionID: 'tx-platform' };
  save(req);
  await sleep(600);
  const toldBeforeCommit = told.length;
  delete req.transactionID;
  await sleep(300);
  check(
    'the platform hears of a save only once it commits',
    toldBeforeCommit === 0 && told.length === 1,
    `before ${toldBeforeCommit}, after ${told.length}`,
  );
}

{
  sent.length = 0;
  process.env.KITE_PUBLISHED_SITE_URL = 'https://old-address.test';
  platformAnswer = () =>
    new Response('{"url":"https://moved.test"}', { status: 200 });
  save();
  await sleep(500);
  check(
    'a site that moved is refreshed at its current address, not the start-time one',
    sent.length === 1 &&
      sent[0].url === `https://moved.test${CMS_REVALIDATE_PATH}`,
    sent.map((x) => x.url).join(', '),
  );
}

{
  sent.length = 0;
  told.length = 0;
  platformAnswer = () => new Response('{"url":null}', { status: 200 });
  save();
  await sleep(500);
  check(
    'a site the platform reports unpublished is not sent to',
    sent.length === 0,
    sent.map((x) => x.url).join(', '),
  );
  check(
    'the platform still hears of the save, and decides what it changes',
    told.length === 1,
    `told ${told.length}`,
  );
}

{
  sent.length = 0;
  // A platform without the route, or one that cannot be reached, must not
  // silence a site that has a start-time address.
  platformAnswer = () => new Response('Not Found', { status: 404 });
  save();
  await sleep(500);
  const afterNotFound = sent.map((x) => x.url);
  sent.length = 0;
  platformAnswer = () => {
    throw new TypeError('fetch failed');
  };
  save();
  await sleep(500);
  check(
    'when the platform cannot answer, the start-time address is used',
    afterNotFound.length === 1 &&
      afterNotFound[0] === `https://old-address.test${CMS_REVALIDATE_PATH}` &&
      sent.length === 1 &&
      sent[0].url === `https://old-address.test${CMS_REVALIDATE_PATH}`,
    `${afterNotFound.join(', ')} | ${sent.map((x) => x.url).join(', ')}`,
  );
}

{
  sent.length = 0;
  told.length = 0;
  lookups.length = 0;
  process.env.PAYLOAD_SCHEMA = 'payload_iter3_draft_0123456789ab';
  platformAnswer = () =>
    new Response('{"url":"https://moved.test"}', { status: 200 });
  save();
  await sleep(500);
  check(
    'a draft-schema save neither asks for the address nor sends nor reports',
    sent.length === 0 && lookups.length === 0 && told.length === 0,
  );
  process.env.PAYLOAD_SCHEMA = LIVE;
}

{
  sent.length = 0;
  delete process.env.KITE_PUBLISHED_SITE_URL;
  delete process.env.PLATFORM_BASE_URL;
  delete process.env.PLATFORM_API_KEY;
  save();
  await sleep(500);
  check(
    'with neither the platform nor a start-time address nothing is sent',
    sent.length === 0,
  );
}

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`);
  process.exit(1);
}
console.log('\nall checks passed');
