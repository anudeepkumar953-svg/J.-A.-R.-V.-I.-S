import { getPayload } from 'payload';
import config from '@payload-config';
import { CMS_CONTENT_TAG, cmsCached } from '../lib/cms-cache';
import { getBaseUrl } from '../lib/site-url';
import {
  type RelatedPageRow,
  readPageRows,
  hasRelations,
  readRelatedPageRows,
  relatedLinks,
  wantedSlugs,
} from './relatedPages';

// Both reads are kept with the rest of the CMS content, so adding, hiding or
// deleting a page refreshes the links of every page that named it or was
// named by it. The first reads only the pages that name related pages; a
// page that names none and is named by none reads nothing more.
const loadNamingRows = cmsCached(
  async (): Promise<RelatedPageRow[] | null> => {
    const payload = await getPayload({ config });
    return readRelatedPageRows((args) => payload.find(args));
  },
  ['related-page-rows'],
  [CMS_CONTENT_TAG],
);

const loadPageRows = cmsCached(
  async (slugs: string[]): Promise<RelatedPageRow[]> => {
    const payload = await getPayload({ config });
    return readPageRows((args) => payload.find(args), slugs);
  },
  ['related-page-targets'],
  [CMS_CONTENT_TAG],
);

/**
 * The links between a page and its related pages, shown under its sections.
 * It carries no words of its own, only the pages' titles, so it reads right
 * in any language, and it inherits the site's type and colours. Renders
 * nothing for a page with no related page a visitor can open. A failed read
 * shows the page without links.
 */
export async function RelatedPagesNav({
  page,
}: {
  page: Pick<RelatedPageRow, 'slug' | 'relatedPages' | 'seo'>;
}) {
  // The home page links with none, so it reads nothing.
  if (!page.slug || page.slug === 'home') return null;
  let rows: RelatedPageRow[];
  try {
    const naming = await loadNamingRows();
    if (!naming) return null;
    if (!hasRelations(page, naming)) return null;
    const wanted = wantedSlugs(page, naming);
    rows = [...naming, ...(wanted.length ? await loadPageRows(wanted) : [])];
  } catch (error) {
    console.warn('[related-pages] page list read failed', error);
    return null;
  }
  const links = relatedLinks(page, rows, getBaseUrl());
  if (links.length === 0) return null;
  return (
    <nav
      aria-label="Related pages"
      data-kite-related-pages=""
      // The room below clears a footer that curves up over the page's end.
      className="mx-auto w-full max-w-7xl px-6 pt-10 pb-24"
    >
      <ul className="flex flex-wrap gap-x-8 gap-y-3">
        {links.map((link) => (
          <li key={link.href}>
            <a
              href={link.href}
              className="underline underline-offset-4 hover:no-underline"
            >
              {link.title}
            </a>
          </li>
        ))}
      </ul>
    </nav>
  );
}
