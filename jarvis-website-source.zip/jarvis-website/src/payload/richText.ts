import { BlocksFeature, lexicalEditor } from '@payloadcms/richtext-lexical';
import type { Block } from 'payload';
import { imageUrlField, KITE_FIELD_COMPONENTS } from './fields';
import { recordImageSize, recordMeasuredUrl } from './imageSize';

// A markdown image alone on its line: `![alt](url)` or `![alt](url "title")`.
// `markdownDoc` moves every image onto its own line before converting.
const MARKDOWN_IMAGE_LINE =
  /^[ \t]*!\[([^\]]*)\]\(\s*<?([^\s)>]+)>?(?:\s+"[^"]*")?\s*\)[ \t]*$/;

// An image inside rich text (article and page bodies). Images in this template
// are Cloudinary URL fields, not uploads, so the block holds the URL and the
// admin edits it with the same image field and thumbnail as every other image.
// Render it through `RichTextContent`, which carries the block's converter.
export const richTextImageBlock: Block = {
  slug: 'richTextImage',
  interfaceName: 'RichTextImageBlock',
  labels: { singular: 'Image', plural: 'Images' },
  fields: [
    imageUrlField('url', { label: 'Image URL', required: true }),
    {
      name: 'alt',
      type: 'text',
      label: 'Alt text',
      admin: { components: KITE_FIELD_COMPONENTS.text },
    },
    {
      name: 'caption',
      type: 'text',
      admin: { components: KITE_FIELD_COMPONENTS.text },
    },
    // The image's size, measured when the block is saved (see imageSize.ts),
    // so the page can hold its box before the file loads. `measuredUrl` is
    // the URL they belong to: a changed URL is measured again.
    {
      name: 'width',
      type: 'number',
      admin: { hidden: true },
      hooks: { beforeChange: [recordImageSize('width')] },
    },
    {
      name: 'height',
      type: 'number',
      admin: { hidden: true },
      hooks: { beforeChange: [recordImageSize('height')] },
    },
    {
      name: 'measuredUrl',
      type: 'text',
      admin: { hidden: true },
      hooks: { beforeChange: [recordMeasuredUrl] },
    },
  ],
  jsx: {
    customStartRegex: MARKDOWN_IMAGE_LINE,
    // Zero-width, so the block closes on the line it opened on.
    customEndRegex: /$/,
    import: ({ openMatch }) =>
      openMatch ? { url: openMatch[2], alt: openMatch[1] } : false,
    export: ({ fields }) => `![${fields.alt ?? ''}](${fields.url})`,
  },
};

export const richTextEditor = lexicalEditor({
  features: ({ defaultFeatures }) => [
    ...defaultFeatures,
    BlocksFeature({ blocks: [richTextImageBlock] }),
  ],
});
