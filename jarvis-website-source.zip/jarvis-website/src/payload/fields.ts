import type { GroupField, JSONField, TextField } from 'payload';

// Design-system field renderers (src/admin/KiteField.tsx). Spread into a
// field's `admin.components` so the control is kite-ui's Input / Textarea /
// Switch instead of Payload's own — see the rationale at the top of
// KiteField.tsx. Declared once here so every collection and global references
// the same component paths; a typo'd path resolves to nothing at runtime
// rather than failing the build.
export const KITE_FIELD_COMPONENTS = {
  switch: { Field: '/admin/KiteField#KiteSwitchField' },
  text: { Field: '/admin/KiteField#KiteTextField' },
  textarea: { Field: '/admin/KiteField#KiteTextareaField' },
} as const;

// A text field holding a Cloudinary image URL, with the admin ImagePreview
// thumbnail wired in via `afterInput`. Use this for every image/logo/avatar/
// og-image field so editors see the actual image in the admin. The component
// path resolves through the config importMap (baseDir = src).
export function imageUrlField(
  name: string,
  opts: { label?: string; required?: boolean; width?: string } = {},
): TextField {
  return {
    name,
    type: 'text',
    label: opts.label,
    required: opts.required,
    admin: {
      width: opts.width,
      // Single source of truth for "this text field holds an image URL".
      // Readers (e.g. the admin section-autofill serializer) consult this
      // marker instead of sniffing the afterInput component reference.
      custom: { isImage: true },
      components: {
        ...KITE_FIELD_COMPONENTS.text,
        // KiteTextField renders `customComponents.AfterInput` explicitly, so
        // the thumbnail survives the Field override. A custom Field that
        // forgot to would drop this slot silently.
        afterInput: ['/admin/ImagePreview#ImagePreview'],
      },
    },
  };
}

// The pages this one belongs with, as a list of their slugs. Kite sets it when
// it writes a page from an idea that names related pages. Nothing here is a
// link yet: the site works the links out when a page is shown
// (src/payload/relatedPages.ts), in both directions and only between pages
// visitors can open, so a slug that names a proposal, a hidden page or a page
// since deleted shows nothing. Slugs, not a relationship: a draft and the live
// site number their pages apart, and the slug is what both share.
export function relatedPagesField(): JSONField {
  return {
    name: 'relatedPages',
    type: 'json',
    admin: { hidden: true },
  };
}

// A page's SEO group, shared by Pages and the page proposals Kite writes on
// Main so a proposal carries the same data a page does when it is added. A
// factory, not a shared object: Payload sanitizes field configs in place.
export function pageSeoGroup(): GroupField {
  return {
    name: 'seo',
    type: 'group',
    label: 'SEO',
    admin: {
      className: 'kite-section',
      components: { Label: '/admin/SectionLabel#SeoLabel' },
    },
    // Single-column, full-width stacked fields — no `row`/`width` so each
    // field spans the card.
    fields: [
      {
        name: 'title',
        type: 'text',
        admin: {
          description:
            'The title shown in search results and link previews. Your site name is added after it unless the title already includes it.',
        },
      },
      {
        name: 'description',
        type: 'textarea',
        admin: {
          description:
            'The summary shown in search results. Leave it empty to use the first lines of this page.',
        },
      },
      imageUrlField('ogImageUrl', { label: 'OG Image URL' }),
      {
        // Mirrors the content-collection items' `canonicalUrl` override
        // (src/payload/collectionMeta.ts). Read by the catch-all route's
        // `generateMetadata`; empty means the page canonicalizes to its own
        // URL on the deployed origin.
        name: 'canonicalUrl',
        type: 'text',
        label: 'Canonical URL',
        admin: {
          description:
            'Override the canonical URL. Leave empty to use this page’s own URL.',
        },
      },
      {
        name: 'noindex',
        type: 'checkbox',
        defaultValue: false,
        // Renders the design system's Switch (see src/admin/KiteField),
        // wired by `withKiteAdmin` along with every other checkbox.
        admin: {
          description: 'Prevent search engines from indexing this page',
        },
      },
      {
        // Robots meta directives beyond indexability, carried verbatim from
        // a migrated source page (e.g. `max-image-preview:large`). The
        // `noindex` switch above wins when set — see `pageMetadata`
        // (src/lib/page-metadata.ts).
        name: 'robots',
        type: 'text',
        label: 'Robots directives',
        admin: {
          description:
            'Robots meta content, e.g. max-image-preview:large. The noindex switch above takes precedence.',
        },
      },
      {
        // Structured-data blocks emitted verbatim as
        // `<script type="application/ld+json">` by the catch-all route. A
        // migration seeds the source page's blocks here so real-world
        // assertions (a LocalBusiness address, phone, opening hours) round-
        // trip instead of being regenerated. An array of JSON-LD objects;
        // a single object is also accepted.
        name: 'jsonLd',
        type: 'json',
        label: 'Structured data (JSON-LD)',
        admin: {
          description:
            'JSON-LD blocks served with this page, exactly as stored.',
        },
      },
    ],
  };
}
