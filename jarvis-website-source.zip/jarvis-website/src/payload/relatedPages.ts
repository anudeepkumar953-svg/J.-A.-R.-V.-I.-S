import type { Where } from 'payload';
import { pageInSitemap } from './indexability';
import { ADDED_PAGES_ONLY } from './proposals';

// Which pages a page links to as "related", worked out when the page is shown
// and never stored as links. A page names its related pages by slug
// (`relatedPages`, set when Kite writes it from an idea). The link runs both
// ways: a page lists the pages it names and the pages that name it, so the
// page an idea supports links back without anyone editing it. Only pages a
// visitor can open are linked: one still waiting as a proposal, one hidden
// from search engines or one that no longer exists drops out on both sides,
// and comes back by itself when that changes.

/** What the link graph needs to know about one page. */
export type RelatedPageRow = {
  slug?: string | null;
  title?: string | null;
  proposed?: boolean | null;
  relatedPages?: unknown;
  seo?: {
    noindex?: boolean | null;
    robots?: string | null;
    canonicalUrl?: string | null;
  } | null;
};

export type RelatedLink = { href: string; title: string };

const HOME_SLUG = 'home';

// More than a reader scans, and more than Kite stores for one page.
export const MAX_RELATED_LINKS = 6;
// Past this many pages that name related pages, or this many bytes of them,
// no related links are shown.
// The byte bound keeps the cached read under Next's 2 MB data-cache limit,
// past which it would run uncached on every request (as in known-slugs.ts).
export const MAX_PAGES_SCANNED = 5_000;
export const MAX_BYTES_SCANNED = 1_000_000;
const BATCH_SIZE = 500;

/** The slugs a stored `relatedPages` value names, whatever was saved there. */
export function relatedSlugs(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  const slugs: string[] = [];
  for (const item of value) {
    if (typeof item !== 'string') continue;
    const slug = item.trim().replace(/^\/+|\/+$/g, '');
    if (slug && !slugs.includes(slug)) slugs.push(slug);
  }
  return slugs;
}

function linkable(row: RelatedPageRow, baseUrl: string): boolean {
  if (!row.slug || !row.title || row.proposed === true) return false;
  return pageInSitemap({ slug: row.slug, seo: row.seo ?? undefined }, baseUrl);
}

/**
 * The related links `page` shows, given every page of the site: first the
 * pages it names, in the order stored, then the pages that name it, in the
 * site's order. A page never links to itself or twice to the same page, and
 * one hidden from search engines shows no links at all.
 */
export function relatedLinks(
  page: Pick<RelatedPageRow, 'slug' | 'relatedPages' | 'seo'>,
  sitePages: RelatedPageRow[],
  baseUrl: string,
): RelatedLink[] {
  const own = page.slug ?? '';
  // Every page already leads back to the home page, which links to none.
  if (!own || own === HOME_SLUG) return [];
  const bySlug = new Map<string, RelatedPageRow>();
  for (const row of sitePages) {
    if (row.slug && row.slug !== HOME_SLUG && linkable(row, baseUrl)) {
      bySlug.set(row.slug, row);
    }
  }
  // A page a visitor cannot find gives no links either. Only a page the site
  // holds is judged: a proposal is not among `sitePages`, and its preview
  // still shows the editor where it will link.
  // The page's own search settings decide first: the rows read for the links
  // hold only pages that name related pages, so the page itself may be absent.
  if (page.seo && !pageInSitemap({ slug: own, seo: page.seo }, baseUrl)) {
    return [];
  }
  const self = sitePages.find((row) => row.slug === own);
  if (self && !bySlug.has(own)) return [];
  const wanted = [
    ...relatedSlugs(page.relatedPages),
    ...[...bySlug.values()]
      .filter((row) => relatedSlugs(row.relatedPages).includes(own))
      .map((row) => row.slug as string),
  ];
  const links: RelatedLink[] = [];
  const seen = new Set<string>([own]);
  for (const slug of wanted) {
    const row = bySlug.get(slug);
    if (!row || seen.has(slug)) continue;
    seen.add(slug);
    links.push({
      href: `/${slug}`,
      title: row.title as string,
    });
    if (links.length === MAX_RELATED_LINKS) break;
  }
  return links;
}

type Find = (args: {
  collection: 'pages';
  where: Where;
  sort: string;
  limit: number;
  pagination: false;
  depth: 0;
  select: Record<string, true | Record<string, true>>;
}) => Promise<{ docs: (RelatedPageRow & { id: number | string })[] }>;

// Only the search settings that decide whether a page may be linked: the SEO
// group also holds seeded structured data, often kilobytes a page.
const SEARCH_SETTINGS = {
  noindex: true,
  robots: true,
  canonicalUrl: true,
} as const;

const ROW_SELECT = {
  slug: true,
  title: true,
  relatedPages: true,
  seo: SEARCH_SETTINGS,
} as const;

function asRow({ slug, title, relatedPages, seo }: RelatedPageRow) {
  return { slug, title, relatedPages, seo };
}

/**
 * Every added page that names related pages, with its slug, title, related
 * slugs and search settings, or null when there are more than `maxPages` of
 * them or the rows pass `maxBytes`. Pages that name none are not read: on a
 * site with no related pages this reads nothing.
 */
export async function readRelatedPageRows(
  find: Find,
  maxPages: number = MAX_PAGES_SCANNED,
  maxBytes: number = MAX_BYTES_SCANNED,
): Promise<RelatedPageRow[] | null> {
  const naming: Where = { relatedPages: { exists: true } };
  const rows: RelatedPageRow[] = [];
  let bytes = 0;
  let lastId: number | string | undefined;
  for (;;) {
    const res = await find({
      collection: 'pages',
      where:
        lastId === undefined
          ? { and: [ADDED_PAGES_ONLY, naming] }
          : {
              and: [ADDED_PAGES_ONLY, naming, { id: { greater_than: lastId } }],
            },
      sort: 'id',
      limit: BATCH_SIZE,
      pagination: false,
      depth: 0,
      select: ROW_SELECT,
    });
    for (const doc of res.docs) {
      const row = asRow(doc);
      bytes += Buffer.byteLength(JSON.stringify(row));
      rows.push(row);
    }
    if (rows.length > maxPages || bytes > maxBytes) return null;
    if (res.docs.length < BATCH_SIZE) return rows;
    lastId = res.docs[res.docs.length - 1].id;
  }
}

/**
 * The pages `page` names that are not among `naming` yet, so still to be
 * read. Pages that name it are already among `naming`, with everything a
 * link needs, so they are never read again; nothing is dropped to make room.
 */
export function wantedSlugs(
  page: Pick<RelatedPageRow, 'slug' | 'relatedPages'>,
  naming: RelatedPageRow[],
): string[] {
  const own = page.slug ?? '';
  if (!own || own === HOME_SLUG) return [];
  const read = new Set(naming.map((row) => row.slug));
  return relatedSlugs(page.relatedPages)
    .filter((slug) => slug !== own && slug !== HOME_SLUG && !read.has(slug))
    .slice(0, MAX_RELATED_LINKS);
}

/** Whether `page` names a related page or is named by one of `naming`. */
export function hasRelations(
  page: Pick<RelatedPageRow, 'slug' | 'relatedPages'>,
  naming: RelatedPageRow[],
): boolean {
  const own = page.slug ?? '';
  if (!own || own === HOME_SLUG) return false;
  return (
    relatedSlugs(page.relatedPages).length > 0 ||
    naming.some((row) => relatedSlugs(row.relatedPages).includes(own))
  );
}

/** The added pages at `slugs`, as rows the links are worked out from. */
export async function readPageRows(
  find: Find,
  slugs: string[],
): Promise<RelatedPageRow[]> {
  if (slugs.length === 0) return [];
  const res = await find({
    collection: 'pages',
    where: { and: [ADDED_PAGES_ONLY, { slug: { in: slugs } }] },
    sort: 'id',
    limit: slugs.length,
    pagination: false,
    depth: 0,
    select: ROW_SELECT,
  });
  return res.docs.map(asRow);
}
