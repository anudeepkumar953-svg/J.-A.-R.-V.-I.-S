// Contract for how a rich-text body looks. `prose` classes only exist while
// globals.css loads the typography plugin, and a site may rewrite globals.css
// without it. This builds the site's real stylesheet with the plugin line
// removed and checks the richText block's body still gets heading, list and
// quote styling.
//
// Self-contained tsx script (the template ships no unit-test runner), run in CI
// by nextjs-template-code-quality.yml. Exits non-zero on any failure.
//
// Run locally: pnpm exec tsx src/components/blocks/richTextBody.test.tsx

// Explicit React import: this file sits outside tsconfig.json's scope, so the
// runner uses the classic JSX transform (see Footer.test.tsx).
import React from 'react';
import { readFileSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import postcss, { type Rule } from 'postcss';
import tailwind from '@tailwindcss/postcss';
import { renderToStaticMarkup } from 'react-dom/server';
import { RichText } from './RichText';

let failed = 0;
function check(name: string, ok: boolean) {
  console.log(`${ok ? 'PASS' : 'FAIL'}  ${name}`);
  if (!ok) failed += 1;
}

const text = (t: string) => ({
  type: 'text',
  text: t,
  format: 0,
  detail: 0,
  mode: 'normal',
  style: '',
  version: 1,
});
const element = (type: string, children: unknown[], extra = {}) => ({
  type,
  children,
  format: '',
  indent: 0,
  version: 1,
  direction: 'ltr',
  ...extra,
});
const content = {
  root: element('root', [
    element('heading', [text('Set the test before you spend')], { tag: 'h2' }),
    element('paragraph', [text('Decide how you will judge the spend.')]),
    element('heading', [text('Price the work delivered')], { tag: 'h3' }),
    element(
      'list',
      [
        element('listitem', [text('Pages shipped')], { value: 1 }),
        element('listitem', [text('Emails sent')], { value: 2 }),
      ],
      { listType: 'bullet', tag: 'ul', start: 1 },
    ),
    element(
      'list',
      [element('listitem', [text('A freelancer')], { value: 1 })],
      { listType: 'number', tag: 'ol', start: 1 },
    ),
    element('quote', [text('Is it comparable work for less?')]),
  ]),
};

const html = renderToStaticMarkup(
  // The generated payload type is stricter than this hand-built document.
  <RichText
    blockType="richText"
    content={content as never}
    background="dark"
  />,
);
check(
  'the block renders its headings, lists and quote as elements',
  ['<h2', '<h3', '<ul', '<ol', '<blockquote'].every((tag) =>
    html.includes(tag),
  ),
);
check(
  'the body takes its colour from the section, not a stock prose palette',
  !/\bprose(-\w+)?\b/.test(html) && html.includes('bg-neutral-900 text-white'),
);

// The site's real stylesheet, minus the typography plugin.
const root = path.resolve(
  path.dirname(fileURLToPath(import.meta.url)),
  '../../..',
);
const globalsPath = path.join(root, 'src/app/globals.css');
const globals = readFileSync(globalsPath, 'utf8').replace(
  /^@plugin\s+["']@tailwindcss\/typography["'];$/m,
  '',
);
check(
  'the stylesheet under test has no typography plugin',
  !globals.includes('@tailwindcss/typography'),
);
const css = await postcss([tailwind({ base: root })]).process(globals, {
  from: globalsPath,
});

// Declarations that apply to `element` inside the body wrapper.
const wrapperClasses = (
  /class="([^"]*\[&amp;_h2\][^"]*)"/.exec(html)?.[1] ?? ''
).replaceAll('&amp;', '&');
const escape = (cls: string) => cls.replace(/[^a-zA-Z0-9_-]/g, (c) => `\\${c}`);
const wrapperSelectors = new Set(
  wrapperClasses.split(/\s+/).map((c) => `.${escape(c)}`),
);
// Tailwind emits a descendant variant nested: `.cls { & h2 { ... } }`. Rules
// that reach an element only as a first or last child do not count.
function declsFor(element: string): Map<string, string> {
  const found = new Map<string, string>();
  const targets = new RegExp(`(^|[\\s>(,])${element}(?![\\w-])`);
  css.root.walkRules((rule: Rule) => {
    if (!wrapperSelectors.has(rule.selector)) return;
    rule.walkRules((inner) => {
      const target = inner.selector.replace(/^&/, '');
      if (/:(first|last)-child/.test(target) || !targets.test(target)) return;
      inner.walkDecls((d) => {
        found.set(d.prop, d.value);
      });
    });
  });
  return found;
}

check(
  'the body wrapper carries the rich-text classes',
  wrapperSelectors.size > 5,
);
const sizedAndBold = (element: string) => {
  const decls = declsFor(element);
  return decls.has('font-size') && decls.has('font-weight');
};
const h2 = declsFor('h2');
for (const heading of ['h1', 'h2', 'h3', 'h4']) {
  check(`an ${heading} is sized and bold`, sizedAndBold(heading));
}
for (const heading of ['h5', 'h6']) {
  check(`an ${heading} is bold`, declsFor(heading).has('font-weight'));
}
check(
  'a bulleted list shows bullets',
  declsFor('ul').get('list-style-type') === 'disc',
);
check(
  'a numbered list shows numbers',
  declsFor('ol').get('list-style-type') === 'decimal',
);
check(
  'a quote is set off from the text',
  declsFor('blockquote').has('border-left-width'),
);
check(
  'no heading sets its own font family, so the site font applies',
  !h2.has('font-family'),
);

if (failed) {
  console.error(`\n${failed} check(s) failed`);
  process.exit(1);
}
console.log('\nall checks passed');
