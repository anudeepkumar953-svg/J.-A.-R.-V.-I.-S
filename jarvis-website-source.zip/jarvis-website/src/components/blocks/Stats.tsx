import type { StatsBlock as StatsBlockType } from '@/payload-types';
import { Section } from './Section';

export function Stats({ heading, stats, background }: StatsBlockType) {
  const items = stats ?? [];
  // 2 cols on mobile; up to 4 across on desktop, but never more columns than cells.
  const cols = Math.min(items.length || 1, 4);
  const lgCols = [
    '',
    'lg:grid-cols-1',
    'lg:grid-cols-2',
    'lg:grid-cols-3',
    'lg:grid-cols-4',
  ][cols];

  return (
    <Section
      background={background}
      fallback="muted"
      innerClassName="max-w-5xl"
    >
      {heading ? (
        <h2 className="text-center text-3xl font-bold tracking-tight">
          {heading}
        </h2>
      ) : null}
      <dl
        className={`grid grid-cols-2 gap-8 text-center md:grid-cols-4 ${lgCols} ${
          heading ? 'mt-10' : ''
        }`}
      >
        {items.map((stat) => (
          <div key={stat.id}>
            <dt className="text-3xl font-bold md:text-4xl">{stat.value}</dt>
            <dd className="mt-1 text-sm opacity-60">{stat.label}</dd>
          </div>
        ))}
      </dl>
    </Section>
  );
}
