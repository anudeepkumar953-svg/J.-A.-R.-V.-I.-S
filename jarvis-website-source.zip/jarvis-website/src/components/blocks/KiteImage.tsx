import type { ImgHTMLAttributes } from 'react';
import { preload } from 'react-dom';
import {
  isResizable,
  kiteImageUrl,
  RESPONSIVE_WIDTHS,
} from '../../lib/kite-image';

// The one way template components draw a CMS image: a plain `<img>` whose
// `srcset` asks the CDN for a resized WebP/AVIF instead of the original upload
// (see lib/kite-image.ts), lazy unless it is the page's main image. A plain
// `<img>` rather than next/image so the output does not depend on the site's
// next.config, and nothing here reads the request, so the cached page is the
// same for every visitor.
//
// Size the image one of three ways:
//   sizes            — width follows the layout; `sizes` is the rendered width
//                      per breakpoint, exactly as in the HTML attribute.
//   width + height   — a fixed pixel box (avatar, icon). Both are emitted, and
//                      the CDN copy covers the box whatever the image's ratio.
//   height           — fixed height, width from the image's own ratio (logos).
// `width`/`height` are emitted only where the layout fixes them: a CMS image
// field is a bare URL, so its intrinsic size is unknown here. In fixed-height
// mode pair it with the matching `h-*` class: Tailwind's preflight sets `img`
// height to auto, so only the class reserves the row before the file loads.
type Sizing =
  | { sizes: string; width?: never; height?: never }
  | { width: number; height: number; sizes?: never }
  | { height: number; width?: never; sizes?: never };

export type KiteImageProps = Omit<
  ImgHTMLAttributes<HTMLImageElement>,
  'src' | 'srcSet' | 'sizes' | 'width' | 'height' | 'fetchPriority'
> & {
  src: string;
  alt: string;
  // The page's largest above-the-fold image: fetched first and preloaded, as
  // next/image's `preload` does. Use it on one image per page.
  preload?: boolean;
} & Sizing;

export function KiteImage({
  src,
  alt,
  preload: isMain = false,
  loading,
  sizes,
  width,
  height,
  ...rest
}: KiteImageProps) {
  let srcSet: string | undefined;
  let resolvedSrc = src;
  if (isResizable(src)) {
    if (sizes) {
      srcSet = RESPONSIVE_WIDTHS.map(
        (w) => `${kiteImageUrl(src, { width: w })} ${w}w`,
      ).join(', ');
      resolvedSrc = kiteImageUrl(src, { width: RESPONSIVE_WIDTHS[1] });
    } else {
      const at = (scale: number) =>
        width !== undefined
          ? kiteImageUrl(src, {
              width: width * scale,
              height: height === undefined ? undefined : height * scale,
            })
          : kiteImageUrl(src, { height: (height ?? 0) * scale });
      srcSet = `${at(1)} 1x, ${at(2)} 2x`;
      resolvedSrc = at(2);
    }
  }
  if (isMain) {
    preload(resolvedSrc, {
      as: 'image',
      fetchPriority: 'high',
      imageSrcSet: srcSet,
      imageSizes: srcSet ? sizes : undefined,
    });
  }
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      {...rest}
      alt={alt}
      width={width}
      height={width !== undefined ? height : undefined}
      sizes={srcSet ? sizes : undefined}
      srcSet={srcSet}
      src={resolvedSrc}
      loading={isMain ? 'eager' : (loading ?? 'lazy')}
      fetchPriority={isMain ? 'high' : undefined}
      decoding={rest.decoding ?? 'async'}
    />
  );
}
