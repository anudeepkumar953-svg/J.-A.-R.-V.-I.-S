import type { TestimonialListBlock as TestimonialListBlockType } from '@/payload-types';
import { KiteImage } from './KiteImage';
import { Section } from './Section';

// Testimonials: a responsive grid of quote cards with an optional author avatar.
// Surface-relative borders keep cards legible on any background.
export function TestimonialList({
  heading,
  testimonials,
  background,
}: TestimonialListBlockType) {
  return (
    <Section
      background={background}
      fallback="muted"
      innerClassName="max-w-6xl"
    >
      {heading ? (
        <h2 className="text-center text-3xl font-bold tracking-tight">
          {heading}
        </h2>
      ) : null}
      <div className="mt-10 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {(testimonials ?? []).map((testimonial) => (
          <figure
            key={testimonial.id}
            className="flex h-full flex-col rounded-xl border border-current/15 p-6"
          >
            <blockquote className="flex-1 whitespace-pre-line opacity-90">
              “{testimonial.quote}”
            </blockquote>
            <figcaption className="mt-4 flex items-center gap-3">
              {testimonial.avatarUrl ? (
                <KiteImage
                  src={testimonial.avatarUrl}
                  alt={testimonial.authorName}
                  width={40}
                  height={40}
                  className="h-10 w-10 rounded-full object-cover"
                />
              ) : null}
              <div>
                <div className="font-semibold">{testimonial.authorName}</div>
                {testimonial.authorTitle ? (
                  <div className="text-sm opacity-60">
                    {testimonial.authorTitle}
                  </div>
                ) : null}
              </div>
            </figcaption>
          </figure>
        ))}
      </div>
    </Section>
  );
}
