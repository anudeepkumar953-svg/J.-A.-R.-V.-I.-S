import type { SerializedBlockNode } from '@payloadcms/richtext-lexical';
import {
  type JSXConverters,
  type JSXConvertersFunction,
  RichText as LexicalRichText,
} from '@payloadcms/richtext-lexical/react';
import type { ComponentProps } from 'react';
import { KiteImage } from './KiteImage';

// Drop-in for `@payloadcms/richtext-lexical/react`: the same exports, but
// `RichText` also renders the image blocks rich text can hold
// (src/payload/richText.ts). Without the converter, Payload renders nothing
// for those blocks. Render every richText value through this module.
export * from '@payloadcms/richtext-lexical/react';

type RichTextImageFields = {
  url?: string | null;
  alt?: string | null;
  caption?: string | null;
  width?: number | null;
  height?: number | null;
};

type Props = ComponentProps<typeof LexicalRichText>;

function RichTextImage({
  node,
}: {
  node: SerializedBlockNode<RichTextImageFields>;
}) {
  const { url, alt, caption, width, height } = node.fields;
  if (!url) return null;
  // The size recorded when the block was saved (src/payload/imageSize.ts)
  // gives the box its real ratio before the file arrives, so the text below
  // never moves; the image keeps its natural width, capped by the column. An
  // image with no recorded size (not on the platform CDN, or not measurable)
  // gets a fixed 16:9 box showing the whole image: it never moves either.
  const measured = !!width && !!height;
  return (
    <figure>
      <KiteImage
        src={url}
        alt={alt ?? ''}
        sizes="(min-width: 768px) 768px, 100vw"
        style={
          measured
            ? {
                aspectRatio: `${width} / ${height}`,
                width: '100%',
                maxWidth: width,
              }
            : undefined
        }
        className={measured ? undefined : 'aspect-[16/9] w-full object-contain'}
      />
      {caption ? <figcaption>{caption}</figcaption> : null}
    </figure>
  );
}

// Resolves the caller's converters the way Payload does (a function gets the
// defaults, an object replaces them), then adds the image converter unless the
// caller already renders that block. A layout with its own converters still
// draws images.
function withImageConverter(
  converters: Props['converters'],
): JSXConvertersFunction {
  return ({ defaultConverters }) => {
    const base: JSXConverters =
      typeof converters === 'function'
        ? converters({ defaultConverters })
        : (converters ?? defaultConverters);
    return {
      ...base,
      blocks: { richTextImage: RichTextImage, ...base.blocks },
    };
  };
}

export function RichText({ converters, ...props }: Props) {
  return (
    <LexicalRichText {...props} converters={withImageConverter(converters)} />
  );
}

// Element styling for a rich-text body. Plain utilities, so it needs no
// typography plugin: a site that rewrites globals.css can drop that plugin, and
// its `prose` classes then render headings and lists as flat text. Fonts and
// colours are inherited, so the body follows the site's type and the section
// surface instead of a stock grey palette.
export const richTextBodyClassName = [
  'text-[1.0625rem] leading-relaxed',
  '[&_:is(h1,h2,h3,h4,h5,h6,p,ul,ol,blockquote,figure,hr,img):first-child]:mt-0',
  '[&_:is(h1,h2,h3,h4,h5,h6,p,ul,ol,blockquote,figure,hr,img):last-child]:mb-0',
  '[&_h1]:mt-12 [&_h1]:mb-5 [&_h1]:text-4xl [&_h1]:leading-tight [&_h1]:font-bold [&_h1]:tracking-tight',
  '[&_h2]:mt-12 [&_h2]:mb-4 [&_h2]:text-3xl [&_h2]:leading-tight [&_h2]:font-bold [&_h2]:tracking-tight',
  '[&_h3]:mt-8 [&_h3]:mb-3 [&_h3]:text-xl [&_h3]:leading-snug [&_h3]:font-semibold',
  '[&_:is(h4,h5,h6)]:mt-6 [&_:is(h4,h5,h6)]:mb-2 [&_:is(h4,h5,h6)]:font-semibold [&_h4]:text-lg',
  '[&_p]:my-5',
  '[&_ul]:my-5 [&_ul]:list-disc [&_ul]:pl-6 [&_ol]:my-5 [&_ol]:list-decimal [&_ol]:pl-6',
  '[&_li]:my-2 [&_li]:pl-1 [&_li]:marker:text-current/50 [&_li_:is(ul,ol)]:my-2',
  '[&_a]:font-medium [&_a]:underline [&_a]:underline-offset-2',
  '[&_strong]:font-semibold',
  '[&_blockquote]:my-6 [&_blockquote]:border-l-4 [&_blockquote]:border-current/20 [&_blockquote]:pl-5 [&_blockquote]:italic',
  '[&_hr]:my-10 [&_hr]:border-current/15',
  '[&_code]:rounded [&_code]:bg-current/10 [&_code]:px-1.5 [&_code]:py-0.5 [&_code]:text-[0.9em]',
  '[&_img]:my-8 [&_img]:rounded-xl [&_figure]:my-8 [&_figure_img]:my-0',
  '[&_figcaption]:mt-2 [&_figcaption]:text-sm [&_figcaption]:opacity-70',
].join(' ');
