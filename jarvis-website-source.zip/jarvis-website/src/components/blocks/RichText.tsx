import {
  RichText as LexicalRichText,
  richTextBodyClassName,
} from './RichTextContent';
import type { RichTextBlock as RichTextBlockType } from '@/payload-types';
import { Section } from './Section';

export function RichText({ content, background }: RichTextBlockType) {
  if (!content) return null;
  return (
    <Section
      background={background}
      fallback="light"
      innerClassName="max-w-3xl"
    >
      <div className={richTextBodyClassName}>
        <LexicalRichText data={content} />
      </div>
    </Section>
  );
}
