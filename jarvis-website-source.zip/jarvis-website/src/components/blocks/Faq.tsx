import type { FaqBlock as FaqBlockType } from '@/payload-types';
import { Section } from './Section';

export function Faq({ heading, items, background }: FaqBlockType) {
  return (
    <Section
      background={background}
      fallback="light"
      innerClassName="max-w-3xl"
    >
      {heading ? (
        <h2 className="text-center text-3xl font-bold tracking-tight">
          {heading}
        </h2>
      ) : null}
      <div className="mt-8 divide-y divide-current/15">
        {(items ?? []).map((item) => (
          <details key={item.id} className="py-4">
            <summary className="cursor-pointer font-medium">
              {item.question}
            </summary>
            <p className="mt-2 whitespace-pre-line opacity-70">{item.answer}</p>
          </details>
        ))}
      </div>
    </Section>
  );
}
