import type { ReactNode } from 'react';

// Section background variants → neutral surface classes. The optional per-block
// `background` field (schema in payload/blocks/index.ts) selects one; when empty
// the block component passes its own `fallback`. This is the reusable mechanism
// for a light/dark section rhythm — surfaces are neutral by default, and a
// generated design overrides the look per brand.
export type SectionBackground = 'light' | 'muted' | 'dark' | null;

const SURFACE: Record<NonNullable<SectionBackground>, string> = {
  light: 'bg-transparent text-ice',
  muted: 'bg-navy/50 text-ice',
  dark: 'bg-black/40 text-ice',
};

// Every J.A.R.V.I.S. surface is dark; the helper stays for library blocks.
export function isDarkSurface(_bg?: SectionBackground): boolean {
  return true;
}

export function resolveBackground(
  background: SectionBackground | undefined,
  fallback: NonNullable<SectionBackground>,
): NonNullable<SectionBackground> {
  return background && SURFACE[background] ? background : fallback;
}

// A solid button that inverts against its surface: white on dark, dark on light.
// Single source for the contrast rule shared by Hero and Cta.
export function surfaceButtonClasses(dark: boolean): string {
  return dark
    ? 'border border-cyan-2 bg-cyan/15 text-ice hover:bg-cyan/30'
    : 'border border-cyan-2 bg-cyan/15 text-ice hover:bg-cyan/30';
}

export function Section({
  background,
  fallback = 'light',
  className = '',
  innerClassName = 'max-w-7xl',
  children,
}: {
  background?: SectionBackground;
  /** Variant used when `background` is empty — the block's default surface. */
  fallback?: NonNullable<SectionBackground>;
  className?: string;
  innerClassName?: string;
  /**
   * Section content. Pass a function to receive the resolved surface
   * (`{ dark }`) so a block can style against the same surface Section paints —
   * one source of truth instead of resolving the background twice.
   */
  children: ReactNode | ((surface: { dark: boolean }) => ReactNode);
}) {
  const bg = resolveBackground(background, fallback);
  const content =
    typeof children === 'function'
      ? children({ dark: isDarkSurface(bg) })
      : children;
  return (
    <section
      className={`relative ${SURFACE[bg]} px-5 py-16 sm:px-8 md:px-10 md:py-24 ${className}`}
    >
      <div className={`relative mx-auto ${innerClassName}`}>{content}</div>
    </section>
  );
}
