'use client';

import { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Send, Volume2, VolumeX } from 'lucide-react';
import type { VoiceConsoleBlock as VoiceConsoleBlockType } from '@/payload-types';
import { HolographicCore } from '../jarvis/HolographicCore';
import { StatusPill } from '../jarvis/Live';
import { GlassPanel, Lockup, SectionShell, btnPrimary } from '../jarvis/ui';
import { capabilityRows } from '../jarvis/status';
import { STATE_READOUT, setState, useJarvis } from '../jarvis/store';
import { cancelSpeech, runCommand, startListening, stopListening } from '../jarvis/voice';

export function VoiceConsole({
  kicker,
  heading,
  subheading,
  demoBadge,
  welcomeMessage,
  inputPlaceholder,
  commandsHeading,
  commands,
}: VoiceConsoleBlockType) {
  const s = useJarvis();
  const [input, setInput] = useState('');
  const logRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = logRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [s.messages.length]);

  useEffect(
    () => () => {
      stopListening();
      cancelSpeech();
    },
    [],
  );

  const micRow = capabilityRows(s)[1];
  const micUnavailable = ['unsupported', 'denied', 'nomic'].includes(s.mic);
  const listening = s.mic === 'listening';
  const synthUnavailable = s.synth === 'unsupported';

  const toggleMic = () => {
    if (listening) {
      stopListening();
      return;
    }
    startListening({
      onInterim: (t) => setInput(t),
      onFinal: (t) => {
        setInput('');
        runCommand(t);
      },
    });
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = input.trim();
    if (!text) return;
    setInput('');
    runCommand(text);
  };

  return (
    <SectionShell id="console" orb="a">
      <Lockup kicker={kicker} heading={heading} subheading={subheading} />

      <div className="mt-12 grid gap-6 lg:grid-cols-[minmax(0,1.35fr)_minmax(0,0.85fr)]">
        {/* chat console */}
        <GlassPanel as="section" label="Conversation console" className="reveal flex flex-col overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-cyan/15 px-4 py-3 sm:px-5">
            <p className="font-display text-[12px] font-semibold uppercase tracking-[0.18em] text-ice">
              J.A.R.V.I.S. console
            </p>
            {demoBadge ? (
              <span className="inline-flex items-center gap-2 rounded-full border border-cyan-2/60 bg-cyan/10 px-3 py-1 font-mono text-[10.5px] font-medium uppercase tracking-[0.14em] text-cyan-2">
                <span aria-hidden="true" className="h-1.5 w-1.5 animate-pulse-dot rounded-full bg-cyan-2" />
                {demoBadge}
              </span>
            ) : null}
          </div>

          <div
            ref={logRef}
            role="log"
            aria-live="polite"
            aria-label="Conversation"
            tabIndex={0}
            className="h-[340px] space-y-3 overflow-y-auto px-4 py-4 sm:px-5 sm:h-[380px]"
          >
            {welcomeMessage ? (
              <Bubble role="jarvis" text={welcomeMessage} />
            ) : null}
            {s.messages.map((m) => (
              <Bubble key={m.id} role={m.role} text={m.text} />
            ))}
          </div>

          <form onSubmit={submit} className="border-t border-cyan/15 p-3 sm:p-4">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={toggleMic}
                disabled={micUnavailable}
                aria-pressed={listening}
                aria-label={listening ? 'Stop microphone' : 'Start microphone and listen'}
                className={`inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-[10px] border transition-[transform,background-color,border-color,box-shadow] duration-200 active:scale-[0.94] disabled:cursor-not-allowed disabled:opacity-40 ${
                  listening
                    ? 'border-cyan-2 bg-cyan/25 text-ice shadow-glow'
                    : 'border-cyan/35 bg-white/[0.03] text-ice hover:border-cyan-2 hover:bg-cyan/15'
                }`}
              >
                {micUnavailable ? <MicOff size={18} aria-hidden="true" /> : <Mic size={18} aria-hidden="true" />}
              </button>
              <label htmlFor="jarvis-input" className="sr-only">
                Type a command
              </label>
              <input
                id="jarvis-input"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={listening ? 'Listening…' : (inputPlaceholder ?? 'Type a command')}
                autoComplete="off"
                className="h-11 min-w-0 flex-1 rounded-[10px] border border-cyan/25 bg-[#02050B]/80 px-3.5 font-mono text-[13px] text-ice placeholder:text-mist/80 transition-[border-color,box-shadow] duration-200 focus:border-cyan-2 focus:shadow-glow"
              />
              <button type="submit" className={`${btnPrimary} !px-4`} aria-label="Send command">
                <Send size={16} aria-hidden="true" />
                <span className="hidden sm:inline">Send</span>
              </button>
              <button
                type="button"
                disabled={synthUnavailable}
                aria-pressed={s.voiceReplies}
                aria-label={s.voiceReplies ? 'Turn spoken replies off' : 'Turn spoken replies on'}
                onClick={() => {
                  if (s.voiceReplies) cancelSpeech();
                  setState({ voiceReplies: !s.voiceReplies });
                }}
                className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-[10px] border border-cyan/35 bg-white/[0.03] text-ice transition-[transform,background-color,border-color] duration-200 hover:border-cyan-2 hover:bg-cyan/15 active:scale-[0.94] disabled:cursor-not-allowed disabled:opacity-40"
              >
                {s.voiceReplies && !synthUnavailable ? <Volume2 size={18} aria-hidden="true" /> : <VolumeX size={18} aria-hidden="true" />}
              </button>
            </div>
            <p className="mt-2.5 font-mono text-[11px] leading-relaxed text-mist">
              <span className="text-cyan-2">MIC</span> {micRow.status} — {s.micMessage}
            </p>
          </form>
        </GlassPanel>

        {/* core + command chips */}
        <div className="space-y-6">
          <GlassPanel as="section" label="Core response" className="reveal p-4 sm:p-5">
            <div className="mx-auto w-full max-w-[230px]">
              <HolographicCore variant="compact" />
            </div>
            <p className="mt-3 text-center font-mono text-[11px] uppercase tracking-[0.18em] text-cyan-2">
              {STATE_READOUT[s.core]}
            </p>
            <div className="mt-3 flex flex-wrap justify-center gap-2">
              <StatusPill tone={listening ? 'on' : 'idle'}>{listening ? 'Mic live' : 'Mic off'}</StatusPill>
              <StatusPill tone="idle">AI provider · not connected</StatusPill>
            </div>
          </GlassPanel>

          <GlassPanel as="section" label="Commands" className="reveal p-4 sm:p-5" style={{ transitionDelay: '100ms' }}>
            <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-mist">
              {commandsHeading ?? 'Try these commands'}
            </p>
            <ul className="mt-3 grid gap-2">
              {(commands ?? []).map((c) => (
                <li key={c.id ?? c.phrase}>
                  <button
                    type="button"
                    onClick={() => runCommand(c.phrase)}
                    className="group flex w-full items-baseline justify-between gap-3 rounded-[10px] border border-cyan/20 bg-white/[0.02] px-3 py-2 text-left transition-[transform,background-color,border-color] duration-200 hover:-translate-y-0.5 hover:border-cyan-2/70 hover:bg-cyan/10 active:scale-[0.98]"
                  >
                    <span className="font-mono text-[12.5px] text-cyan-2">“{c.phrase}”</span>
                    {c.description ? <span className="text-right text-[12px] leading-tight text-mist">{c.description}</span> : null}
                  </button>
                </li>
              ))}
            </ul>
          </GlassPanel>
        </div>
      </div>
    </SectionShell>
  );
}

function Bubble({ role, text }: { role: 'user' | 'jarvis' | 'system'; text: string }) {
  const user = role === 'user';
  return (
    <div className={`flex ${user ? 'justify-end' : 'justify-start'}`}>
      <div
        className={`max-w-[88%] rounded-[12px] border px-3.5 py-2.5 text-[14px] leading-relaxed ${
          user
            ? 'border-holo-2/50 bg-holo/20 text-ice'
            : role === 'system'
              ? 'border-mist/25 bg-white/[0.03] font-mono text-[12.5px] text-mist'
              : 'border-cyan/30 bg-cyan/[0.07] text-ice'
        }`}
      >
        <p className="mb-1 font-mono text-[10px] uppercase tracking-[0.2em] text-cyan-2">
          {user ? 'You' : role === 'system' ? 'System' : 'J.A.R.V.I.S. · demo'}
        </p>
        {text}
      </div>
    </div>
  );
}
