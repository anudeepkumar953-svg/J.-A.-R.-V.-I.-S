import type { ProviderAdapterBlock as ProviderAdapterBlockType } from '@/payload-types';
import { StatusPill } from '../jarvis/Live';
import { GlassPanel, Lockup, SectionShell } from '../jarvis/ui';

type Status = 'implemented' | 'slot' | 'not-connected';

const STATUS: Record<Status, { label: string; tone: 'on' | 'idle' }> = {
  implemented: { label: 'Implemented in this demo', tone: 'on' },
  slot: { label: 'Open slot', tone: 'idle' },
  'not-connected': { label: 'Not connected', tone: 'idle' },
};

// "Connect a provider": an honest architecture map. Layers marked implemented
// exist in this page; the provider adapter is an open slot and the language
// model is not connected. Nothing here claims an integration.
export function ProviderAdapter({
  kicker,
  heading,
  subheading,
  note,
  layers,
}: ProviderAdapterBlockType) {
  const list = layers ?? [];
  return (
    <SectionShell id="provider" orb="c">
      <Lockup kicker={kicker} heading={heading} subheading={subheading} />

      <ol className="mt-12 grid list-none gap-0 lg:grid-cols-4 lg:gap-14">
        {list.map((layer, i) => {
          const st = STATUS[(layer.status as Status) ?? 'slot'];
          const solid = layer.status === 'implemented';
          const nextSolid = list[i + 1]?.status === 'implemented';
          const last = i === list.length - 1;
          return (
            <li key={layer.id ?? layer.label} className="relative">
              <GlassPanel
                as="article"
                className={`reveal h-full p-5 ${solid ? '' : '!border-dashed !border-mist/45'}`}
                style={{ transitionDelay: `${i * 90}ms` }}
              >
                <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-mist">
                  Layer {String(i + 1).padStart(2, '0')}
                </p>
                <h3 className="mt-2 font-heading text-xl font-semibold tracking-[-0.02em] text-ice">
                  {layer.label}
                </h3>
                <div className="mt-3">
                  <StatusPill tone={st.tone}>{st.label}</StatusPill>
                </div>
                {layer.detail ? (
                  <p className="mt-3 text-sm leading-relaxed text-mist">{layer.detail}</p>
                ) : null}
              </GlassPanel>
              {!last ? (
                <>
                  <span
                    aria-hidden="true"
                    className={`absolute -right-14 top-1/2 hidden h-px w-14 border-t border-dashed lg:block ${
                      solid && nextSolid ? 'border-cyan-2/70' : 'border-mist/45'
                    }`}
                  />
                  <span
                    aria-hidden="true"
                    className={`mx-auto block h-9 w-px border-l border-dashed lg:hidden ${
                      solid && nextSolid ? 'border-cyan-2/70' : 'border-mist/45'
                    }`}
                  />
                </>
              ) : null}
            </li>
          );
        })}
      </ol>

      {note ? (
        <GlassPanel className="reveal mx-auto mt-10 max-w-3xl p-5 text-center">
          <p className="text-[15px] leading-relaxed text-ice/90">{note}</p>
        </GlassPanel>
      ) : null}
    </SectionShell>
  );
}
