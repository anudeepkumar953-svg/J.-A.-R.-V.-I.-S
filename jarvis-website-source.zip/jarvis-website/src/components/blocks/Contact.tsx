import { Briefcase, Mail, MapPin, Phone, Scale, type LucideIcon } from 'lucide-react';
import type { ContactBlock as ContactBlockType } from '@/payload-types';
import { GlassPanel, Lockup, SectionShell } from '../jarvis/ui';

const PROVISIONAL = 'Provisional — to be confirmed';

// Project / contact block. Real values render as links; every missing value is
// shown as a clearly labelled provisional placeholder, never as an invented fact.
export function Contact({ heading, body, email, phone, address }: ContactBlockType) {
  const rows: { Icon: LucideIcon; label: string; value?: string | null; href?: string }[] = [
    { Icon: Briefcase, label: 'Company / organisation' },
    { Icon: Mail, label: 'Email', value: email, href: email ? `mailto:${email}` : undefined },
    { Icon: Phone, label: 'Phone', value: phone, href: phone ? `tel:${phone}` : undefined },
    { Icon: MapPin, label: 'Address', value: address },
    { Icon: Scale, label: 'Legal & privacy terms' },
  ];
  return (
    <SectionShell id="project" orb="b" width="max-w-5xl">
      <div className="grid gap-10 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)] lg:items-center">
        <div>
          <Lockup kicker="Project" heading={heading ?? 'Project & contact'} subheading={body} />
        </div>
        <GlassPanel as="section" label="Project and contact details" className="reveal p-5 sm:p-6">
          <p className="mb-4 inline-flex rounded-full border border-cyan-2/50 bg-cyan/10 px-3 py-1 font-mono text-[10.5px] uppercase tracking-[0.18em] text-cyan-2">
            Provisional details
          </p>
          <dl className="divide-y divide-cyan/15">
            {rows.map(({ Icon, label, value, href }) => (
              <div key={label} className="flex items-start gap-3 py-3.5">
                <span className="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-[8px] border border-cyan/30 bg-cyan/10 text-cyan-2">
                  <Icon size={15} aria-hidden="true" />
                </span>
                <div className="min-w-0">
                  <dt className="font-mono text-[10.5px] uppercase tracking-[0.2em] text-mist">{label}</dt>
                  <dd className="mt-1 text-[15px] text-ice">
                    {value ? (
                      href ? (
                        <a href={href} className="underline decoration-cyan-2/50 underline-offset-4 transition-colors hover:text-cyan-2">
                          {value}
                        </a>
                      ) : (
                        <span className="whitespace-pre-line">{value}</span>
                      )
                    ) : (
                      <span className="text-mist">{PROVISIONAL}</span>
                    )}
                  </dd>
                </div>
              </div>
            ))}
          </dl>
        </GlassPanel>
      </div>
    </SectionShell>
  );
}
