'use client';

import { useRef, useState } from 'react';
import { AudioLines, Circle, Cpu, Mic, TriangleAlert } from 'lucide-react';
import type { CoreStatesBlock as CoreStatesBlockType } from '@/payload-types';
import { HolographicCore } from '../jarvis/HolographicCore';
import { GlassPanel, Lockup, SectionShell } from '../jarvis/ui';
import { STATE_LABEL, STATE_READOUT, setCore, useJarvis, type CoreState } from '../jarvis/store';
import { useInView } from '../scroll-reveal';

const ICONS: Record<CoreState, typeof Circle> = {
  idle: Circle,
  listening: Mic,
  processing: Cpu,
  speaking: AudioLines,
  error: TriangleAlert,
};

const ORBIT_RADIUS_CQW = 40;
const STAGGER_MS = 90;

export function CoreStates({
  kicker,
  heading,
  subheading,
  hint,
  states,
}: CoreStatesBlockType) {
  const s = useJarvis();
  const ref = useRef<HTMLDivElement>(null);
  const [entered, setEntered] = useState(false);
  useInView(ref, () => setEntered(true), { threshold: 0.25 });

  const items = (states ?? []).filter((x) => x.stateKey);
  const n = Math.max(items.length, 1);
  const active = items.find((x) => x.stateKey === s.core) ?? items[0];
  const err = s.core === 'error';

  return (
    <SectionShell id="states" orb="b">
      <div className="grid items-center gap-12 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)] lg:gap-16">
        {/* radial orbit */}
        <div
          ref={ref}
          className={`orbit @container relative mx-auto aspect-square w-full max-w-[560px] ${entered ? 'is-in' : ''}`}
        >
          <svg aria-hidden="true" viewBox="0 0 100 100" className="pointer-events-none absolute inset-0 h-full w-full">
            <circle cx="50" cy="50" r={ORBIT_RADIUS_CQW} fill="none" stroke="rgba(0,229,255,0.22)" strokeWidth="0.25" />
            <circle cx="50" cy="50" r={ORBIT_RADIUS_CQW + 7} fill="none" stroke="rgba(47,140,255,0.2)" strokeWidth="0.2" strokeDasharray="0.6 2.2" />
            <circle cx="50" cy="50" r={ORBIT_RADIUS_CQW - 12} fill="none" stroke="rgba(0,229,255,0.12)" strokeWidth="0.2" strokeDasharray="3 3" />
          </svg>
          <div className="absolute left-1/2 top-1/2 w-[40%] -translate-x-1/2 -translate-y-1/2">
            <HolographicCore variant="compact" />
          </div>
          {items.map((it, i) => {
            const key = it.stateKey as CoreState;
            const Icon = ICONS[key];
            const angle = -Math.PI / 2 + (i * 2 * Math.PI) / n;
            const dx = (Math.cos(angle) * ORBIT_RADIUS_CQW).toFixed(3);
            const dy = (Math.sin(angle) * ORBIT_RADIUS_CQW).toFixed(3);
            const isActive = s.core === key;
            const isErr = key === 'error';
            return (
              <div
                key={it.id ?? key}
                className="absolute left-1/2 top-1/2 h-0 w-0"
              >
                <div
                  className="orbit-node-inner absolute left-0 top-0 -translate-x-1/2 -translate-y-1/2"
                  style={
                    {
                      '--dx': `${dx}cqw`,
                      '--dy': `${dy}cqw`,
                      '--delay': `${i * STAGGER_MS}ms`,
                    } as React.CSSProperties
                  }
                >
                  <div
                    style={{ animation: `float ${5 + (i % 3) * 1.3}s ease-in-out ${i * -1.1}s infinite` }}
                  >
                    <button
                      type="button"
                      aria-pressed={isActive}
                      onClick={() => setCore(key, isErr ? 'SIMULATED FAULT' : 'MANUAL SELECT')}
                      className={`flex aspect-square w-[clamp(66px,19cqw,104px)] flex-col items-center justify-center gap-1 rounded-full border bg-[rgba(5,11,26,0.78)] backdrop-blur-md transition-[transform,border-color,box-shadow,background-color] duration-200 hover:scale-105 active:scale-95 ${
                        isActive
                          ? isErr
                            ? 'border-alert text-alert shadow-[0_0_28px_-4px_rgba(255,45,85,0.8)]'
                            : 'border-cyan-2 text-cyan-2 shadow-glow'
                          : 'border-cyan/30 text-mist hover:border-cyan-2/70 hover:text-ice'
                      }`}
                    >
                      <Icon aria-hidden="true" className="h-[22%] w-[22%] min-h-4 min-w-4" />
                      <span className="font-display text-[clamp(8.5px,2.2cqw,12px)] font-semibold uppercase tracking-[0.1em]">
                        {it.label ?? STATE_LABEL[key]}
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* explainer */}
        <div>
          <Lockup kicker={kicker} heading={heading} subheading={subheading} />
          {active ? (
            <GlassPanel
              as="article"
              className="reveal mt-8 p-5 sm:p-6"
              style={{ transitionDelay: '200ms' }}
            >
              <div aria-live="polite">
                <p
                  className={`font-mono text-[11px] uppercase tracking-[0.24em] ${err ? 'text-alert' : 'text-cyan-2'}`}
                >
                  {STATE_READOUT[active.stateKey as CoreState]}
                </p>
                <h3 className="mt-2 font-heading text-2xl font-semibold tracking-[-0.02em] text-ice">
                  {active.label}
                </h3>
                {active.summary ? (
                  <p className="mt-2 text-[15px] leading-relaxed text-mist">{active.summary}</p>
                ) : null}
                <dl className="mt-5 grid gap-4 sm:grid-cols-2">
                  {active.behaviour ? (
                    <div>
                      <dt className="font-mono text-[10.5px] uppercase tracking-[0.22em] text-mist">What you see</dt>
                      <dd className="mt-1.5 text-sm leading-relaxed text-ice/90">{active.behaviour}</dd>
                    </div>
                  ) : null}
                  {active.trigger ? (
                    <div>
                      <dt className="font-mono text-[10.5px] uppercase tracking-[0.22em] text-mist">What triggers it</dt>
                      <dd className="mt-1.5 text-sm leading-relaxed text-ice/90">{active.trigger}</dd>
                    </div>
                  ) : null}
                </dl>
              </div>
            </GlassPanel>
          ) : null}
          {hint ? <p className="mt-4 font-mono text-[11.5px] uppercase tracking-[0.16em] text-mist">{hint}</p> : null}
        </div>
      </div>
    </SectionShell>
  );
}
