import { Hand, Plug, Power, Sparkles, type LucideIcon } from 'lucide-react';
import type { FeatureGridBlock as FeatureGridBlockType } from '@/payload-types';
import { GlassPanel, Lockup, SectionShell } from '../jarvis/ui';

// "How it works": numbered steps joined by a circuit trace. Used for the
// three-step Initialize → Interact → Connect a provider flow.
const STEP_ICONS: LucideIcon[] = [Power, Hand, Plug, Sparkles];

export function FeatureGrid({ heading, subheading, features }: FeatureGridBlockType) {
  const list = features ?? [];
  return (
    <SectionShell id="how-it-works" orb="a" width="max-w-6xl">
      {heading ? (
        <Lockup kicker="How it works" heading={heading} subheading={subheading} align="center" />
      ) : null}
      <ol className="relative mt-14 grid list-none gap-6 md:grid-cols-3 md:gap-10">
        <span
          aria-hidden="true"
          className="pointer-events-none absolute left-[16%] right-[16%] top-[3.1rem] hidden border-t border-dashed border-cyan-2/50 md:block"
        />
        {list.map((f, i) => {
          const Icon = STEP_ICONS[i % STEP_ICONS.length];
          return (
            <li key={f.id ?? f.title} className="reveal" style={{ transitionDelay: `${i * 80}ms` }}>
              <GlassPanel
                as="article"
                className="h-full p-6 transition-[transform,box-shadow] duration-200 hover:-translate-y-1 hover:shadow-glow"
              >
                <div className="flex items-center justify-between">
                  <span className="inline-flex h-12 w-12 items-center justify-center rounded-full border border-cyan-2/60 bg-[#050B1A] text-cyan-2 shadow-glow">
                    <Icon size={20} aria-hidden="true" />
                  </span>
                  <span className="font-display text-4xl font-bold tracking-[-0.04em] text-ice/15">
                    {String(i + 1).padStart(2, '0')}
                  </span>
                </div>
                <h3 className="mt-5 font-heading text-2xl font-semibold tracking-[-0.025em] text-ice">
                  {f.title}
                </h3>
                {f.description ? (
                  <p className="mt-2 whitespace-pre-line text-[15px] leading-relaxed text-mist">
                    {f.description}
                  </p>
                ) : null}
              </GlassPanel>
            </li>
          );
        })}
      </ol>
    </SectionShell>
  );
}
