import type { VideoHTMLAttributes } from 'react';
import { kiteVideoPosterUrl, kiteVideoSources } from '../../lib/kite-image';

// The one way template components draw a CMS video. A CDN-hosted upload plays
// as a re-encoded, width-capped rendition (see lib/kite-image.ts) instead of
// the original file, with the original as a second source the browser falls
// back to when the CDN refuses to derive one (a very long video). It also
// gets a still poster from the CDN, and only metadata is fetched up front
// unless the caller asks otherwise. Any other URL is drawn as written. `src`
// may be the original or the rendition: the block renderer rewrites CMS video
// URLs before blocks see them.
//
// Playback is the caller's choice: a background hero passes
// `muted autoPlay loop`, a content video passes `controls`.
export type KiteVideoProps = Omit<
  VideoHTMLAttributes<HTMLVideoElement>,
  'src' | 'children'
> & {
  src: string;
};

export function KiteVideo({
  src,
  poster,
  preload = 'metadata',
  playsInline = true,
  ...rest
}: KiteVideoProps) {
  return (
    <video
      poster={poster ?? kiteVideoPosterUrl(src) ?? undefined}
      preload={preload}
      playsInline={playsInline}
      {...rest}
    >
      {kiteVideoSources(src).map((url) => (
        <source key={url} src={url} />
      ))}
    </video>
  );
}
