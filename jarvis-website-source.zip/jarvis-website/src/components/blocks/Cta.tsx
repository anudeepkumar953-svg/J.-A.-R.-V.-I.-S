import type { CtaBlock as CtaBlockType } from '@/payload-types';
import { InitLink } from '../jarvis/Live';
import { Brackets, btnPrimary } from '../jarvis/ui';

// Closing call to action: a framed HUD slab over a soft backlight. The label and
// target come from the CMS; the link also boots the demo core.
export function Cta({ heading, body, ctaLabel, ctaHref }: CtaBlockType) {
  return (
    <section className="relative isolate overflow-clip px-5 py-20 sm:px-8 md:px-10 md:py-24">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-1/2 -z-10 h-[420px] w-[720px] max-w-full -translate-x-1/2 -translate-y-1/2 animate-orb rounded-full bg-holo/30 blur-[110px]"
      />
      <div className="relative mx-auto max-w-4xl rounded-[18px] border border-cyan/30 bg-[rgba(5,11,26,0.6)] px-6 py-14 text-center shadow-glow-soft backdrop-blur-xl sm:px-12">
        <Brackets />
        <h2 className="reveal whitespace-pre-line font-heading text-4xl font-bold leading-[1.02] tracking-[-0.04em] text-ice sm:text-5xl lg:text-6xl">
          {heading}
        </h2>
        {body ? (
          <p
            className="reveal mx-auto mt-5 max-w-[56ch] text-base leading-relaxed text-mist md:text-lg"
            style={{ transitionDelay: '80ms' }}
          >
            {body}
          </p>
        ) : null}
        {ctaLabel && ctaHref ? (
          <div className="reveal mt-8" style={{ transitionDelay: '160ms' }}>
            <InitLink href={ctaHref} className={btnPrimary}>
              {ctaLabel}
            </InitLink>
          </div>
        ) : null}
      </div>
    </section>
  );
}
