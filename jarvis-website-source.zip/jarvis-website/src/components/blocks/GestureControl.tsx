'use client';

import { useEffect, useRef } from 'react';
import {
  ArrowLeftRight,
  Camera,
  CameraOff,
  ChevronLeft,
  ChevronRight,
  Grab,
  Hand,
  Maximize2,
  Move3d,
  MousePointer2,
  Pointer,
  ShieldCheck,
} from 'lucide-react';
import type { GestureControlBlock as GestureControlBlockType } from '@/payload-types';
import { HolographicCore } from '../jarvis/HolographicCore';
import { CapabilityMiniList, StatusPill, ZoomControls } from '../jarvis/Live';
import { GESTURE_LABEL } from '../jarvis/status';
import { GlassPanel, Lockup, SectionShell, btnGhost, btnPrimary } from '../jarvis/ui';
import { PANEL_COUNT, startCamera, stopCamera } from '../jarvis/gestures';
import { STATE_LABEL, live, setState, useJarvis, type GestureName } from '../jarvis/store';

const PANEL_TITLES = ['Telemetry', 'Gesture map', 'Console log', 'Capabilities'];
const TELEMETRY_REFRESH_MS = 120;

const CAMERA_TITLE: Record<string, string> = {
  checking: 'Checking camera support',
  off: 'Camera off',
  loading: 'Starting camera',
  on: 'Tracking',
  denied: 'Permission denied',
  nocamera: 'No camera found',
  unsupported: 'Camera unsupported',
  modelfailed: 'Model failed to load',
};

function legendIcon(text: string) {
  const t = text.toLowerCase();
  if (t.includes('palm')) return Hand;
  if (t.includes('pinch')) return Grab;
  if (t.includes('fist')) return Grab;
  if (t.includes('point')) return Pointer;
  if (t.includes('two')) return Maximize2;
  if (t.includes('swipe')) return ArrowLeftRight;
  return Move3d;
}

function legendGesture(text: string): GestureName | null {
  const t = text.toLowerCase();
  if (t.includes('palm')) return 'open-palm';
  if (t.includes('pinch')) return 'pinch';
  if (t.includes('fist')) return 'fist';
  if (t.includes('point')) return 'point';
  if (t.includes('two')) return 'two-hands';
  return null;
}

/** Numeric readout refreshed from `live` without React renders. */
function Telemetry() {
  const refs = useRef<Record<string, HTMLElement | null>>({});
  useEffect(() => {
    const id = setInterval(() => {
      const set = (k: string, v: string) => {
        const el = refs.current[k];
        if (el) el.textContent = v;
      };
      set('rx', `${live.rx.toFixed(1)}°`);
      set('ry', `${live.ry.toFixed(1)}°`);
      set('zoom', `×${live.scale.toFixed(2)}`);
      set('pos', `${Math.round(live.ox)}, ${Math.round(live.oy)}`);
    }, TELEMETRY_REFRESH_MS);
    return () => clearInterval(id);
  }, []);
  const rows: [string, string, string][] = [
    ['rx', 'Tilt X', '0.0°'],
    ['ry', 'Rotation Y', '0.0°'],
    ['zoom', 'Zoom', '×1.00'],
    ['pos', 'Offset px', '0, 0'],
  ];
  return (
    <dl className="grid grid-cols-2 gap-x-4 gap-y-2 font-mono text-[12px]">
      {rows.map(([k, label, init]) => (
        <div key={k} className="flex justify-between gap-2 border-b border-cyan/10 pb-1.5">
          <dt className="text-mist">{label}</dt>
          <dd ref={(el) => { refs.current[k] = el; }} className="text-cyan-2">
            {init}
          </dd>
        </div>
      ))}
    </dl>
  );
}

function DeckPanel({ index }: { index: number }) {
  const s = useJarvis();
  if (index === 0) {
    return (
      <>
        <Telemetry />
        <p className="mt-3 font-mono text-[11px] uppercase tracking-[0.18em] text-mist">
          Core · <span className="text-cyan-2">{STATE_LABEL[s.core]}</span>
        </p>
      </>
    );
  }
  if (index === 1) {
    return (
      <dl className="space-y-2 font-mono text-[12px]">
        <div className="flex justify-between"><dt className="text-mist">Detected</dt><dd className="text-cyan-2">{s.camera === 'on' ? GESTURE_LABEL[s.gesture] : 'Camera off'}</dd></div>
        <div className="flex justify-between"><dt className="text-mist">Hands</dt><dd className="text-ice">{s.camera === 'on' ? s.handsCount : '—'}</dd></div>
        <div className="flex justify-between"><dt className="text-mist">Tracking rate</dt><dd className="text-ice">{s.camera === 'on' ? `${s.fps} FPS` : '—'}</dd></div>
        <div className="flex justify-between"><dt className="text-mist">Fist lock</dt><dd className="text-ice">{s.locked ? 'LOCKED' : 'FREE'}</dd></div>
      </dl>
    );
  }
  if (index === 2) {
    const last = s.messages.slice(-3);
    return last.length === 0 ? (
      <p className="text-sm text-mist">No console messages yet. Open the Voice &amp; Conversation console below and send a command.</p>
    ) : (
      <ul className="space-y-1.5 text-[13px] leading-snug">
        {last.map((m) => (
          <li key={m.id} className="line-clamp-2">
            <span className="font-mono text-[10.5px] uppercase tracking-[0.14em] text-cyan-2">
              {m.role === 'user' ? 'You' : m.role === 'jarvis' ? 'J.A.R.V.I.S.' : 'System'} ·{' '}
            </span>
            <span className="text-ice/90">{m.text}</span>
          </li>
        ))}
      </ul>
    );
  }
  return <CapabilityMiniList />;
}

function PanelDeck() {
  const s = useJarvis();
  const active = s.activePanel;
  const drag = useRef<number | null>(null);
  const go = (i: number) => setState({ activePanel: (i + PANEL_COUNT) % PANEL_COUNT });
  const pointing = s.camera === 'on' && s.gesture === 'point';

  return (
    <div>
      <div
        className="relative h-[290px] touch-pan-y select-none sm:h-[300px]"
        style={{ perspective: '1100px' }}
        onPointerDown={(e) => { drag.current = e.clientX; }}
        onPointerUp={(e) => {
          if (drag.current === null) return;
          const dx = e.clientX - drag.current;
          drag.current = null;
          if (dx > 55) go(active - 1);
          else if (dx < -55) go(active + 1);
        }}
        onPointerCancel={() => { drag.current = null; }}
      >
        {PANEL_TITLES.map((title, i) => {
          let off = i - active;
          if (off > 2) off -= PANEL_COUNT;
          if (off < -1) off += PANEL_COUNT;
          const abs = Math.abs(off);
          const isActive = off === 0;
          return (
            <div
              key={title}
              role="tabpanel"
              id={`deck-panel-${i}`}
              aria-labelledby={`deck-tab-${i}`}
              aria-hidden={!isActive}
              onClick={() => { if (!isActive) go(i); }}
              className={`absolute left-1/2 top-0 w-[74%] transition-[transform,opacity] duration-500 ease-out sm:w-[60%] ${isActive ? '' : 'cursor-pointer'}`}
              style={{
                transform: `translateX(calc(-50% + ${off * 52}%)) translateZ(${-abs * 110}px) rotateY(${off * -26}deg) scale(${1 - abs * 0.06})`,
                opacity: isActive ? 1 : abs === 1 ? 0.5 : 0.18,
                zIndex: 10 - abs,
                pointerEvents: abs > 1 ? 'none' : 'auto',
              }}
            >
              <GlassPanel
                className={`h-[250px] overflow-hidden p-4 transition-shadow duration-300 ${isActive ? 'shadow-[0_0_36px_-6px_rgba(0,229,255,0.55)]' : ''}`}
              >
                <div className="mb-3 flex items-center justify-between gap-2">
                  <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-cyan-2">{title}</p>
                  {isActive ? (
                    <span className="rounded-full border border-cyan-2/50 px-2 py-0.5 font-mono text-[9.5px] uppercase tracking-[0.16em] text-ice">
                      {pointing ? 'Highlighted · point' : 'Selected'}
                    </span>
                  ) : null}
                </div>
                <DeckPanel index={i} />
              </GlassPanel>
            </div>
          );
        })}
      </div>
      <div className="mt-3 flex items-center justify-center gap-2">
        <button type="button" aria-label="Previous panel" onClick={() => go(active - 1)} className="inline-flex h-9 w-9 items-center justify-center rounded-[9px] border border-cyan/30 text-ice transition-[transform,background-color,border-color] duration-200 hover:border-cyan-2 hover:bg-cyan/15 active:scale-[0.94]">
          <ChevronLeft size={16} aria-hidden="true" />
        </button>
        <div role="tablist" aria-label="Holographic panels" className="flex gap-1.5">
          {PANEL_TITLES.map((t, i) => (
            <button
              key={t}
              id={`deck-tab-${i}`}
              role="tab"
              type="button"
              aria-selected={i === active}
              aria-controls={`deck-panel-${i}`}
              onClick={() => go(i)}
              onKeyDown={(e) => {
                if (e.key === 'ArrowRight') { go(active + 1); e.preventDefault(); }
                if (e.key === 'ArrowLeft') { go(active - 1); e.preventDefault(); }
              }}
              className={`rounded-full border px-3 py-1.5 font-mono text-[10.5px] uppercase tracking-[0.12em] transition-[background-color,border-color,color] duration-200 ${
                i === active ? 'border-cyan-2 bg-cyan/15 text-ice' : 'border-cyan/20 text-mist hover:border-cyan-2/60 hover:text-ice'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        <button type="button" aria-label="Next panel" onClick={() => go(active + 1)} className="inline-flex h-9 w-9 items-center justify-center rounded-[9px] border border-cyan/30 text-ice transition-[transform,background-color,border-color] duration-200 hover:border-cyan-2 hover:bg-cyan/15 active:scale-[0.94]">
          <ChevronRight size={16} aria-hidden="true" />
        </button>
      </div>
    </div>
  );
}

export function GestureControl({
  kicker,
  heading,
  subheading,
  privacyNote,
  fallbackNote,
  gestures,
}: GestureControlBlockType) {
  const s = useJarvis();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => () => stopCamera(), []);

  const busy = s.camera === 'loading';
  const on = s.camera === 'on';
  const showFeed = on || busy;
  const blocked = ['denied', 'nocamera', 'unsupported', 'modelfailed'].includes(s.camera);
  const tone = on ? 'on' : blocked ? 'blocked' : 'idle';

  const enable = () => {
    if (videoRef.current && canvasRef.current) {
      void startCamera(videoRef.current, canvasRef.current);
    }
  };

  return (
    <SectionShell id="gesture" orb="c">
      <div className="grid gap-12 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] lg:gap-14">
        {/* sticky text column */}
        <div className="lg:sticky lg:top-24 lg:self-start">
          <Lockup kicker={kicker} heading={heading} subheading={subheading} />

          <div className="reveal mt-7 flex flex-wrap gap-3" style={{ transitionDelay: '200ms' }}>
            <button type="button" onClick={enable} disabled={busy || on} className={btnPrimary}>
              <Camera size={16} aria-hidden="true" />
              Enable camera
            </button>
            <button type="button" onClick={() => stopCamera()} disabled={!on && !busy} className={btnGhost}>
              <CameraOff size={16} aria-hidden="true" />
              Stop camera
            </button>
          </div>
          {privacyNote ? (
            <p className="mt-4 flex items-start gap-2.5 text-sm leading-relaxed text-ice/90">
              <ShieldCheck size={18} className="mt-0.5 shrink-0 text-cyan-2" aria-hidden="true" />
              {privacyNote}
            </p>
          ) : null}
          <p
            role="status"
            className="mt-4 rounded-[10px] border border-cyan/20 bg-white/[0.02] px-3.5 py-2.5 font-mono text-[12px] leading-relaxed text-mist"
          >
            <span className="text-cyan-2">{CAMERA_TITLE[s.camera]?.toUpperCase()}</span> — {s.cameraMessage}
          </p>
          {fallbackNote ? (
            <p className="mt-4 flex items-start gap-2.5 text-sm leading-relaxed text-mist">
              <MousePointer2 size={18} className="mt-0.5 shrink-0 text-cyan-2" aria-hidden="true" />
              {fallbackNote}
            </p>
          ) : null}
        </div>

        {/* scrolling column */}
        <div className="space-y-6">
          {/* camera HUD */}
          <GlassPanel as="section" label="Camera feed" className="reveal overflow-hidden p-3 sm:p-4">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-mist">
                Camera feed · mirrored · on-device
              </p>
              <div className="flex flex-wrap items-center gap-2">
                <StatusPill tone={tone}>{CAMERA_TITLE[s.camera]}</StatusPill>
                <span className="font-mono text-[11px] uppercase tracking-[0.12em] text-ice">
                  {on ? `${s.fps} FPS · ${s.handsCount} ${s.handsCount === 1 ? 'hand' : 'hands'}` : '— FPS'}
                </span>
              </div>
            </div>
            <div className="relative aspect-[4/3] w-full overflow-hidden rounded-[10px] border border-cyan/25 bg-[#02050B]">
              <div className={`absolute inset-0 [transform:scaleX(-1)] ${showFeed ? 'opacity-100' : 'opacity-0'}`}>
                <video ref={videoRef} muted playsInline autoPlay className="h-full w-full object-cover" aria-label="Your mirrored camera feed" />
                <canvas ref={canvasRef} aria-hidden="true" className="absolute inset-0 h-full w-full object-cover" />
              </div>
              {!showFeed ? (
                <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center">
                  <CameraOff size={34} className="text-mist" aria-hidden="true" />
                  <p className="font-display text-sm font-semibold uppercase tracking-[0.14em] text-ice">
                    {CAMERA_TITLE[s.camera]}
                  </p>
                  <p className="max-w-[44ch] text-sm leading-relaxed text-mist">{s.cameraMessage}</p>
                  <p className="font-mono text-[10.5px] uppercase tracking-[0.18em] text-mist/80">
                    No video is shown or stored until you enable the camera
                  </p>
                </div>
              ) : null}
              {busy ? (
                <div className="pointer-events-none absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/80 to-transparent p-3 text-center font-mono text-[11px] uppercase tracking-[0.18em] text-cyan-2">
                  {s.cameraMessage}
                </div>
              ) : null}
              {on ? (
                <div className="pointer-events-none absolute left-3 top-3 rounded-full border border-cyan-2/50 bg-black/55 px-3 py-1 font-mono text-[11px] uppercase tracking-[0.14em] text-cyan-2 backdrop-blur-md">
                  {s.handsCount === 0 ? 'Show your hand' : GESTURE_LABEL[s.gesture]}
                </div>
              ) : null}
            </div>
          </GlassPanel>

          {/* live response: mini core + readout */}
          <div className="grid items-center gap-5 sm:grid-cols-[200px_minmax(0,1fr)]">
            <div className="mx-auto w-full max-w-[220px]">
              <HolographicCore variant="compact" />
            </div>
            <GlassPanel as="section" label="Live hologram response" className="reveal p-4">
              <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.22em] text-mist">Live hologram response</p>
              <Telemetry />
              <div className="mt-3 flex items-center justify-between gap-3">
                <p className="font-mono text-[11px] uppercase tracking-[0.14em] text-mist">
                  Gesture ·{' '}
                  <span className="text-cyan-2">{on ? GESTURE_LABEL[s.gesture] : 'camera off'}</span>
                </p>
                <ZoomControls />
              </div>
            </GlassPanel>
          </div>

          {/* legend */}
          <GlassPanel as="section" label="Gesture legend" className="reveal p-4 sm:p-5">
            <p className="mb-4 font-mono text-[11px] uppercase tracking-[0.22em] text-mist">Gesture legend</p>
            <ul className="grid gap-2.5 sm:grid-cols-2">
              {(gestures ?? []).map((g) => {
                const Icon = legendIcon(g.gesture);
                const key = legendGesture(g.gesture);
                const live_ = on && key !== null && s.gesture === key;
                return (
                  <li
                    key={g.id ?? g.gesture}
                    className={`flex gap-3 rounded-[10px] border p-3 transition-[border-color,background-color,box-shadow] duration-200 ${
                      live_ ? 'border-cyan-2 bg-cyan/15 shadow-glow' : 'border-cyan/15 bg-white/[0.02]'
                    }`}
                  >
                    <span className="mt-0.5 inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-[8px] border border-cyan/30 bg-cyan/10 text-cyan-2">
                      <Icon size={16} aria-hidden="true" />
                    </span>
                    <div className="min-w-0">
                      <p className="font-display text-[12px] font-semibold uppercase tracking-[0.1em] text-ice">
                        {g.gesture}
                        {live_ ? <span className="ml-2 text-cyan-2">● detected</span> : null}
                      </p>
                      <p className="mt-0.5 text-[13px] leading-snug text-ice/85">{g.action}</p>
                      {g.fallback ? (
                        <p className="mt-1 font-mono text-[10.5px] leading-snug text-mist">No camera: {g.fallback}</p>
                      ) : null}
                    </div>
                  </li>
                );
              })}
            </ul>
          </GlassPanel>

          {/* holographic panel deck */}
          <div className="reveal">
            <p className="mb-3 font-mono text-[11px] uppercase tracking-[0.22em] text-mist">
              Holographic panels · swipe, point, drag or use the tabs
            </p>
            <PanelDeck />
          </div>
        </div>
      </div>
    </SectionShell>
  );
}
