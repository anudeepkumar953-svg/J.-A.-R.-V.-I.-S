'use client';

import Link from 'next/link';
import { Camera, Cpu, Mic, RefreshCw, Volume2, type LucideIcon } from 'lucide-react';
import type { CapabilitiesBlock as CapabilitiesBlockType } from '@/payload-types';
import { StatusPill } from '../jarvis/Live';
import { capabilityRows, type CapabilityKey } from '../jarvis/status';
import { GlassPanel, Lockup, SectionShell, Trace, btnGhost } from '../jarvis/ui';
import { recheckCapabilities, useJarvis } from '../jarvis/store';

const ICON: Record<CapabilityKey, LucideIcon> = {
  camera: Camera,
  microphone: Mic,
  synthesis: Volume2,
  provider: Cpu,
};

const LINK: Partial<Record<CapabilityKey, { href: string; label: string }>> = {
  camera: { href: '/#gesture', label: 'Open Gesture Control' },
  microphone: { href: '/#console', label: 'Open the console' },
  provider: { href: '/#provider', label: 'How a provider would connect' },
};

export function Capabilities({
  kicker,
  heading,
  subheading,
  note,
  items,
}: CapabilitiesBlockType) {
  const s = useJarvis();
  const rows = capabilityRows(s);
  const cards = (items ?? []).map((it) => ({
    it,
    row: rows.find((r) => r.key === it.capability) ?? rows[0],
  }));
  const left = cards.slice(0, Math.ceil(cards.length / 2));
  const right = cards.slice(Math.ceil(cards.length / 2));

  const renderCard = ({ it, row }: (typeof cards)[number], i: number) => {
    const Icon = ICON[row.key];
    const link = LINK[row.key];
    return (
      <div key={it.id ?? row.key} className="reveal relative z-10" style={{ transitionDelay: `${i * 80}ms` }}>
      <GlassPanel
        as="article"
        className="flex h-full flex-col p-5 transition-[transform,box-shadow] duration-200 hover:-translate-y-1 hover:shadow-glow"
      >
        <div className="flex items-start justify-between gap-3">
          <span className="inline-flex h-10 w-10 items-center justify-center rounded-[10px] border border-cyan/30 bg-cyan/10 text-cyan-2">
            <Icon size={19} aria-hidden="true" />
          </span>
          <StatusPill tone={row.tone}>{row.status}</StatusPill>
        </div>
        <h3 className="mt-4 font-heading text-xl font-semibold tracking-[-0.02em] text-ice">{it.label}</h3>
        {it.description ? <p className="mt-1.5 text-sm leading-relaxed text-mist">{it.description}</p> : null}
        <p className="mt-3 border-t border-cyan/15 pt-3 font-mono text-[11.5px] leading-relaxed text-ice/85" aria-live="polite">
          {row.detail}
        </p>
        {link ? (
          <Link
            href={link.href}
            className="mt-3 inline-flex w-fit items-center gap-1.5 font-mono text-[11px] uppercase tracking-[0.16em] text-cyan-2 underline-offset-4 transition-colors duration-200 hover:text-ice hover:underline"
          >
            {link.label} →
          </Link>
        ) : null}
      </GlassPanel>
      </div>
    );
  };

  return (
    <SectionShell id="capabilities" orb="b">
      <Lockup kicker={kicker} heading={heading} subheading={subheading} align="center" />

      <div className="relative mt-14 grid items-center gap-5 lg:grid-cols-[minmax(0,1fr)_260px_minmax(0,1fr)] lg:gap-12">
        <div aria-hidden="true" className="pointer-events-none absolute inset-0 hidden lg:block">
          <Trace viewBox="0 0 100 100" className="inset-0 h-full w-full" d="M 36 24 H 38.6 V 43 H 41.6" />
          <Trace viewBox="0 0 100 100" className="inset-0 h-full w-full" d="M 36 76 H 38.6 V 57 H 41.6" />
          <Trace viewBox="0 0 100 100" className="inset-0 h-full w-full" d="M 64 24 H 61.4 V 43 H 58.4" />
          <Trace viewBox="0 0 100 100" className="inset-0 h-full w-full" d="M 64 76 H 61.4 V 57 H 58.4" />
        </div>

        {/* orb: second in DOM order visually on mobile (first), centred on lg */}
        <div className="order-first mx-auto w-full max-w-[220px] lg:order-none lg:col-start-2 lg:row-start-1 lg:max-w-none">
          <div className="relative aspect-square w-full">
            <div aria-hidden="true" className="absolute inset-0 animate-pulse-dot rounded-full bg-cyan/10 blur-2xl" />
            <div aria-hidden="true" className="absolute inset-0 rounded-full border border-cyan/30" />
            <div
              aria-hidden="true"
              className="absolute inset-[9%] rounded-full border border-dashed border-holo-2/50"
              style={{ animation: 'hud-spin 24s linear infinite' }}
            />
            <div
              aria-hidden="true"
              className="absolute inset-[20%] rounded-full border-2 border-cyan-2/60 border-r-transparent"
              style={{ animation: 'hud-spin 9s linear infinite reverse' }}
            />
            <div
              aria-hidden="true"
              className="absolute inset-[30%] rounded-full bg-[radial-gradient(closest-side,rgba(25,240,255,0.35),rgba(30,107,255,0.12)_70%,transparent)]"
            />
            <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
              <span className="font-display text-[15px] font-bold tracking-[0.06em] text-ice text-glow">J.A.R.V.I.S.</span>
              <span className="mt-1 font-mono text-[9.5px] uppercase tracking-[0.24em] text-mist">Live in this browser</span>
            </div>
          </div>
        </div>

        <div className="grid gap-5 lg:col-start-1 lg:row-start-1 lg:gap-8">{left.map(renderCard)}</div>
        <div className="grid gap-5 lg:col-start-3 lg:row-start-1 lg:gap-8">
          {right.map((c, i) => renderCard(c, i + left.length))}
        </div>
      </div>

      <div className="mt-10 flex flex-col items-center gap-4 text-center">
        <button type="button" onClick={() => recheckCapabilities()} className={btnGhost}>
          <RefreshCw size={15} aria-hidden="true" />
          Re-check capabilities
        </button>
        {note ? <p className="max-w-[62ch] font-mono text-[11.5px] leading-relaxed text-mist">{note}</p> : null}
      </div>
    </SectionShell>
  );
}
