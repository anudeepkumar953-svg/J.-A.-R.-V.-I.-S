import type { HeroBlock as HeroBlockType } from '@/payload-types';
import { GridFloor, HeroConsole } from '../jarvis/HeroConsole';
import { InitLink } from '../jarvis/Live';
import { Kicker, btnGhost, btnPrimary } from '../jarvis/ui';

// J.A.R.V.I.S. hero: a full-bleed command centre. The copy comes from the CMS
// (eyebrow / heading / subheading / CTAs); the holographic core and its HUD
// panels are live code (see ../jarvis). No raster imagery is used.
export function Hero({
  eyebrow,
  heading,
  subheading,
  primaryCtaLabel,
  primaryCtaHref,
  secondaryCtaLabel,
  secondaryCtaHref,
}: HeroBlockType) {
  return (
    <section
      id="core"
      className="relative isolate scroll-mt-0 overflow-clip px-5 pb-16 pt-24 sm:px-8 lg:px-10"
    >
      <GridFloor />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-[38%] -z-10 h-[620px] w-[620px] -translate-x-1/2 -translate-y-1/2 animate-orb rounded-full bg-holo/25 blur-[120px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-32 top-24 -z-10 h-[340px] w-[340px] animate-orb rounded-full bg-cyan/12 blur-[110px]"
        style={{ animationDelay: '-11s' }}
      />
      <div className="hud-scan pointer-events-none absolute inset-0 -z-10" aria-hidden="true" />

      <div className="relative mx-auto w-full max-w-[1320px]">
        <div className="mx-auto flex max-w-4xl flex-col items-center text-center">
          {eyebrow ? (
            <div className="reveal">
              <Kicker>{eyebrow}</Kicker>
            </div>
          ) : null}
          <h1
            className="reveal mt-5 font-heading text-[2.15rem] font-bold leading-[1.02] tracking-[-0.04em] text-ice sm:text-5xl lg:text-[3.6rem]"
            style={{ transitionDelay: '70ms' }}
          >
            {heading}
          </h1>
          {subheading ? (
            <p
              className="reveal mt-4 max-w-[60ch] text-base leading-relaxed text-mist md:text-lg"
              style={{ transitionDelay: '140ms' }}
            >
              {subheading}
            </p>
          ) : null}
          {(primaryCtaLabel && primaryCtaHref) || (secondaryCtaLabel && secondaryCtaHref) ? (
            <div
              className="reveal mt-6 flex flex-wrap items-center justify-center gap-3"
              style={{ transitionDelay: '210ms' }}
            >
              {primaryCtaLabel && primaryCtaHref ? (
                <InitLink href={primaryCtaHref} className={btnPrimary}>
                  {primaryCtaLabel}
                </InitLink>
              ) : null}
              {secondaryCtaLabel && secondaryCtaHref ? (
                <InitLink href={secondaryCtaHref} boot={false} className={btnGhost}>
                  {secondaryCtaLabel}
                </InitLink>
              ) : null}
            </div>
          ) : null}
        </div>

        <HeroConsole />
      </div>
    </section>
  );
}
