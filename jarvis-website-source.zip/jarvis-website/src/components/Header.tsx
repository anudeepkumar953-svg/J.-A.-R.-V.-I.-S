import Link from 'next/link';
import type { SiteSetting } from '@/payload-types';
import { AmbientBackdrop } from './jarvis/AmbientBackdrop';
import { HeaderBar } from './jarvis/HeaderBar';
import { CapabilityProbe } from './jarvis/Live';

// Baked site header, fed by the SiteSettings global (brand name + nav items).
// Also mounts the page-wide ambient backdrop and the one-time capability probe
// (local feature detection only — it never prompts for camera or microphone).
export function Header({ settings }: { settings: SiteSetting }) {
  const navItems = (settings.navItems ?? []).map((item) => ({
    label: item.label,
    href: item.href,
  }));
  return (
    <>
      <AmbientBackdrop />
      <CapabilityProbe />
      <Link
        href="/#core"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-md focus:bg-navy focus:px-4 focus:py-2 focus:text-ice"
      >
        Skip to content
      </Link>
      <HeaderBar brandName={settings.brandName} navItems={navItems} />
    </>
  );
}
