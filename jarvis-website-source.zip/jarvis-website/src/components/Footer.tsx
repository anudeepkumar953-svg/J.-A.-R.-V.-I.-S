import Link from 'next/link';
import type { SiteSetting } from '@/payload-types';

const PROVISIONAL = 'Provisional — to be confirmed';

// Baked site footer, fed by the SiteSettings global (tagline, copyright/legal
// line, links, socials, contact). Contact fields that are not set are shown as a
// clearly labelled provisional placeholder — never as an invented detail.
export function Footer({ settings }: { settings: SiteSetting }) {
  const links = settings.footer?.links ?? [];
  const socials = settings.socialLinks ?? [];
  const { email, phone, address } = settings.contact ?? {};
  const hasContact = Boolean(email || phone || address);
  const linkCls =
    'text-sm text-mist underline-offset-4 transition-colors duration-200 hover:text-cyan-2 hover:underline';
  return (
    <footer className="relative isolate overflow-clip border-t border-cyan/20 bg-black">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 left-1/2 -z-10 h-[300px] w-[640px] max-w-full -translate-x-1/2 rounded-full bg-holo/20 blur-[110px]"
      />
      <div className="mx-auto max-w-7xl px-5 pb-6 pt-16 sm:px-8 lg:px-10">
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-[1.3fr_1fr_1.1fr]">
          <div>
            <div className="font-display text-xl font-bold tracking-[0.08em] text-ice text-glow">
              {settings.brandName}
            </div>
            {settings.footer?.tagline ? (
              <p className="mt-3 max-w-sm text-sm leading-relaxed text-mist">
                {settings.footer.tagline}
              </p>
            ) : null}
            {socials.length > 0 ? (
              <ul className="mt-4 flex flex-wrap gap-x-5 gap-y-2">
                {socials.map((social) => (
                  <li key={social.id}>
                    <a href={social.href} className={linkCls}>
                      {social.platform}
                    </a>
                  </li>
                ))}
              </ul>
            ) : null}
          </div>

          <nav aria-label="Footer">
            <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-cyan-2">Sections</p>
            <ul className="mt-4 grid grid-cols-2 gap-x-6 gap-y-2.5 md:grid-cols-1">
              {links.map((link) => (
                <li key={link.id}>
                  <Link href={link.href} className={linkCls}>
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.22em] text-cyan-2">Contact</p>
            {hasContact ? (
              <address className="mt-4 space-y-1.5 text-sm text-ice not-italic">
                {email ? (
                  <div>
                    <a href={`mailto:${email}`} className={linkCls}>{email}</a>
                  </div>
                ) : null}
                {phone ? (
                  <div>
                    <a href={`tel:${phone}`} className={linkCls}>{phone}</a>
                  </div>
                ) : null}
                {address ? <div className="whitespace-pre-line text-mist">{address}</div> : null}
              </address>
            ) : (
              <div className="mt-4 rounded-[10px] border border-dashed border-mist/45 p-3.5 text-sm leading-relaxed text-mist">
                <p className="font-mono text-[11px] uppercase tracking-[0.16em] text-cyan-2">{PROVISIONAL}</p>
                <p className="mt-1.5">
                  Contact details and company information are provisional and will be confirmed.
                </p>
              </div>
            )}
          </div>
        </div>

        {settings.footer?.copyright ? (
          <p className="mt-12 max-w-3xl border-t border-cyan/15 pt-6 text-[13px] leading-relaxed text-mist">
            {settings.footer.copyright}
          </p>
        ) : null}
      </div>

      {/* structural watermark */}
      <div
        aria-hidden="true"
        className="pointer-events-none select-none overflow-clip pb-2 text-center font-display text-[10.4vw] font-black leading-[0.9] tracking-[0.02em] text-ice/[0.07]"
      >
        {settings.brandName}
      </div>
    </footer>
  );
}
