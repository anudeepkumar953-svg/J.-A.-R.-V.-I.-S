// Camera + MediaPipe HandLandmarker controller.
//
// - The camera never starts on its own: `startCamera` is only called from the
//   "Enable camera" button.
// - MediaPipe Tasks Vision is loaded in the browser from a CDN, on demand; the
//   model runs on-device, and no frame is ever sent anywhere.
// - Recognised gestures drive the shared store/`live` values that the holographic
//   core and the panel deck read.
import {
  getState,
  live,
  logEvent,
  setCore,
  setState,
  triggerError,
  type GestureName,
} from './store';

/* eslint-disable @typescript-eslint/no-explicit-any */

const VISION_VERSION = '0.10.21';
const VISION_BASE = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${VISION_VERSION}`;
const MODEL_URL =
  'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';

const CONNECTIONS: [number, number][] = [
  [0, 1], [1, 2], [2, 3], [3, 4],
  [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12],
  [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20],
  [0, 17],
];

type Pt = { x: number; y: number; z?: number };

const dist = (a: Pt, b: Pt) => Math.hypot(a.x - b.x, a.y - b.y);

/** Classify one hand from its 21 landmarks (image-space, unmirrored). */
export function classifyHand(lm: Pt[]): Exclude<GestureName, 'two-hands' | 'none'> | 'unknown' {
  const wrist = lm[0];
  const size = dist(wrist, lm[9]) || 0.001;
  const ext = (tip: number, pip: number) =>
    dist(lm[tip], wrist) > dist(lm[pip], wrist) * 1.08;
  const index = ext(8, 6);
  const middle = ext(12, 10);
  const ring = ext(16, 14);
  const pinky = ext(20, 18);
  const thumb = dist(lm[4], lm[17]) > dist(lm[3], lm[17]) * 1.02;
  const pinchRatio = dist(lm[4], lm[8]) / size;

  if (pinchRatio < 0.3) return 'pinch';
  const count = [index, middle, ring, pinky].filter(Boolean).length;
  if (count === 0) return 'fist';
  if (index && !middle && !ring && !pinky) return 'point';
  if (count >= 4 && thumb) return 'open-palm';
  if (count >= 3) return 'open-palm';
  return 'unknown';
}

const center = (lm: Pt[]): Pt => {
  // palm centre: average of wrist and the four finger MCPs
  const ids = [0, 5, 9, 13, 17];
  let x = 0;
  let y = 0;
  for (const i of ids) {
    x += lm[i].x;
    y += lm[i].y;
  }
  return { x: x / ids.length, y: y / ids.length };
};

const clamp = (v: number, lo: number, hi: number) =>
  Math.min(hi, Math.max(lo, v));

let landmarker: any = null;
let stream: MediaStream | null = null;
let raf = 0;
let running = false;
let videoEl: HTMLVideoElement | null = null;
let canvasEl: HTMLCanvasElement | null = null;

// per-run tracking state
let stableGesture: GestureName = 'none';
let candidate: GestureName = 'none';
let candidateFrames = 0;
let lastHandSeen = 0;
let pinchAnchor: { px: number; py: number; ox: number; oy: number } | null = null;
let history: { t: number; x: number }[] = [];
let lastSwipe = 0;
let lastVideoTime = -1;
let frames = 0;
let fpsStamp = 0;
let panelHold = { idx: -1, at: 0 };

export const PANEL_COUNT = 4;

async function loadLandmarker(): Promise<any> {
  const mod: any = await import(
    /* webpackIgnore: true */ /* turbopackIgnore: true */ `${VISION_BASE}/vision_bundle.mjs`
  );
  const fileset = await mod.FilesetResolver.forVisionTasks(`${VISION_BASE}/wasm`);
  const make = (delegate: 'GPU' | 'CPU') =>
    mod.HandLandmarker.createFromOptions(fileset, {
      baseOptions: { modelAssetPath: MODEL_URL, delegate },
      runningMode: 'VIDEO',
      numHands: 2,
      minHandDetectionConfidence: 0.55,
      minTrackingConfidence: 0.5,
    });
  try {
    return await make('GPU');
  } catch {
    return await make('CPU');
  }
}

export function stopCamera(message = 'Camera stopped. Video was never uploaded.'): void {
  running = false;
  cancelAnimationFrame(raf);
  stream?.getTracks().forEach((t) => t.stop());
  stream = null;
  if (videoEl) {
    videoEl.pause();
    videoEl.srcObject = null;
  }
  if (canvasEl) {
    const ctx = canvasEl.getContext('2d');
    ctx?.clearRect(0, 0, canvasEl.width, canvasEl.height);
  }
  try {
    landmarker?.close?.();
  } catch {
    /* ignore */
  }
  landmarker = null;
  pinchAnchor = null;
  history = [];
  stableGesture = 'none';
  candidate = 'none';
  const wasOn = ['on', 'loading'].includes(getState().camera);
  setState({
    camera: wasOn ? 'off' : getState().camera,
    cameraMessage: wasOn ? message : getState().cameraMessage,
    gesture: 'none',
    handsCount: 0,
    fps: 0,
    locked: false,
  });
  if (wasOn) logEvent('camera stopped');
}

export async function startCamera(
  video: HTMLVideoElement,
  canvas: HTMLCanvasElement,
): Promise<void> {
  const s = getState();
  if (s.camera === 'loading' || s.camera === 'on') return;
  if (!navigator.mediaDevices?.getUserMedia) {
    setState({
      camera: 'unsupported',
      cameraMessage: window.isSecureContext
        ? 'This browser does not support camera access.'
        : 'Camera access needs a secure (HTTPS) connection.',
    });
    return;
  }
  videoEl = video;
  canvasEl = canvas;
  setState({
    camera: 'loading',
    cameraMessage: 'Waiting for camera permission…',
  });
  try {
    stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' },
      audio: false,
    });
  } catch (err: any) {
    const name: string = err?.name ?? '';
    if (name === 'NotAllowedError' || name === 'SecurityError') {
      setState({
        camera: 'denied',
        cameraMessage:
          'Camera permission was declined. Allow it in the browser’s site settings to use gesture control.',
      });
      triggerError('CAMERA PERMISSION DENIED');
    } else if (name === 'NotFoundError' || name === 'OverconstrainedError') {
      setState({
        camera: 'nocamera',
        cameraMessage: 'No camera was found on this device.',
      });
      triggerError('NO CAMERA FOUND');
    } else {
      setState({
        camera: 'nocamera',
        cameraMessage: 'The camera could not be opened (it may be in use by another app).',
      });
      triggerError('CAMERA UNAVAILABLE');
    }
    stream = null;
    return;
  }

  setState({ camera: 'loading', cameraMessage: 'Loading hand-tracking model…' });
  video.srcObject = stream;
  try {
    await video.play();
  } catch {
    /* autoplay with muted+playsinline normally succeeds */
  }

  try {
    landmarker = await loadLandmarker();
  } catch {
    stream?.getTracks().forEach((t) => t.stop());
    stream = null;
    video.srcObject = null;
    setState({
      camera: 'modelfailed',
      cameraMessage:
        'The hand-tracking model failed to load (network blocked or offline). The camera was turned off.',
    });
    triggerError('MODEL FAILED TO LOAD');
    return;
  }

  // The visitor may have pressed Stop while the model was loading.
  if (!stream) {
    try {
      landmarker?.close?.();
    } catch {
      /* ignore */
    }
    landmarker = null;
    return;
  }

  running = true;
  lastVideoTime = -1;
  frames = 0;
  fpsStamp = performance.now();
  setState({
    camera: 'on',
    cameraMessage: 'Tracking on-device. Show your hand to the camera.',
  });
  logEvent('camera enabled · tracking');
  loop();
}

function draw(hands: Pt[][]): void {
  const canvas = canvasEl;
  const video = videoEl;
  if (!canvas || !video) return;
  const w = video.videoWidth || 640;
  const h = video.videoHeight || 480;
  if (canvas.width !== w) canvas.width = w;
  if (canvas.height !== h) canvas.height = h;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.clearRect(0, 0, w, h);
  ctx.lineCap = 'round';
  for (const lm of hands) {
    ctx.strokeStyle = 'rgba(25,240,255,0.95)';
    ctx.shadowColor = 'rgba(0,229,255,0.9)';
    ctx.shadowBlur = 12;
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    for (const [a, b] of CONNECTIONS) {
      ctx.moveTo(lm[a].x * w, lm[a].y * h);
      ctx.lineTo(lm[b].x * w, lm[b].y * h);
    }
    ctx.stroke();
    ctx.shadowBlur = 8;
    for (let i = 0; i < lm.length; i++) {
      const tip = i === 4 || i === 8 || i === 12 || i === 16 || i === 20;
      ctx.fillStyle = tip ? '#E8F6FF' : '#19F0FF';
      ctx.beginPath();
      ctx.arc(lm[i].x * w, lm[i].y * h, tip ? 4.5 : 3, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  ctx.shadowBlur = 0;
}

function loop(): void {
  if (!running) return;
  raf = requestAnimationFrame(loop);
  const video = videoEl;
  if (!video || !landmarker || video.readyState < 2) return;
  if (video.currentTime === lastVideoTime) return;
  lastVideoTime = video.currentTime;
  const now = performance.now();

  let result: any;
  try {
    result = landmarker.detectForVideo(video, now);
  } catch {
    return;
  }
  const hands: Pt[][] = result?.landmarks ?? [];
  draw(hands);

  frames += 1;
  if (now - fpsStamp >= 500) {
    setState({ fps: Math.round((frames * 1000) / (now - fpsStamp)) });
    frames = 0;
    fpsStamp = now;
  }
  setState({ handsCount: hands.length });
  interpret(hands, now);
}

function commit(g: GestureName, lm?: Pt[]): void {
  const prev = stableGesture;
  stableGesture = g;
  setState({ gesture: g });
  if (g === prev) return;
  logEvent(`gesture · ${g}`);
  if (g === 'open-palm') {
    setState({ locked: false });
    setCore('idle', 'AWAKE · OPEN PALM');
  } else if (g === 'fist') {
    setState({ locked: true });
    setCore('processing', 'LOCKED · FIST');
  } else if (g === 'pinch' && lm) {
    const p = { x: 1 - (lm[4].x + lm[8].x) / 2, y: (lm[4].y + lm[8].y) / 2 };
    pinchAnchor = { px: p.x, py: p.y, ox: live.ox, oy: live.oy };
  }
  if (g !== 'pinch') pinchAnchor = null;
}

function interpret(hands: Pt[][], now: number): void {
  if (hands.length === 0) {
    if (now - lastHandSeen > 700 && stableGesture !== 'none') {
      stableGesture = 'none';
      candidate = 'none';
      pinchAnchor = null;
      setState({ gesture: 'none' });
    }
    return;
  }
  lastHandSeen = now;

  // Two hands: spread distance zooms the core.
  if (hands.length >= 2) {
    const a = center(hands[0]);
    const b = center(hands[1]);
    const d = Math.hypot(a.x - b.x, a.y - b.y);
    const target = clamp(0.6 + ((d - 0.15) / 0.55) * 1.1, 0.6, 1.8);
    live.scale += (target - live.scale) * 0.25;
    if (stableGesture !== 'two-hands') commit('two-hands');
    return;
  }

  const lm = hands[0];
  const raw = classifyHand(lm);
  const g: GestureName = raw === 'unknown' ? stableGesture === 'none' ? 'none' : stableGesture : raw;

  // Debounce: a gesture must hold for 3 frames before it commits.
  if (g === candidate) candidateFrames += 1;
  else {
    candidate = g;
    candidateFrames = 1;
  }
  if (candidateFrames >= 3 && g !== stableGesture && g !== 'none') commit(g, lm);

  const c = center(lm);
  const mx = 1 - c.x; // mirrored: matches what the visitor sees
  const my = c.y;

  const active = stableGesture;
  if (active === 'open-palm' || active === 'point') {
    // hand position tilts the hologram
    const ty = clamp((mx - 0.5) * 80, -60, 60);
    const tx = clamp(-(my - 0.5) * 60, -45, 45);
    live.ry += (ty - live.ry) * 0.2;
    live.rx += (tx - live.rx) * 0.2;
  }

  if (active === 'pinch') {
    if (!pinchAnchor) {
      pinchAnchor = {
        px: 1 - (lm[4].x + lm[8].x) / 2,
        py: (lm[4].y + lm[8].y) / 2,
        ox: live.ox,
        oy: live.oy,
      };
    }
    const px = 1 - (lm[4].x + lm[8].x) / 2;
    const py = (lm[4].y + lm[8].y) / 2;
    live.ox = clamp(pinchAnchor.ox + (px - pinchAnchor.px) * 700, -180, 180);
    live.oy = clamp(pinchAnchor.oy + (py - pinchAnchor.py) * 500, -110, 110);
  }

  if (active === 'point') {
    // index fingertip x selects the panel under it
    const tipX = 1 - lm[8].x;
    const idx = clamp(Math.floor(tipX * PANEL_COUNT), 0, PANEL_COUNT - 1);
    if (idx !== panelHold.idx) panelHold = { idx, at: now };
    else if (now - panelHold.at > 350 && getState().activePanel !== idx) {
      setState({ activePanel: idx });
      logEvent(`panel ${idx + 1} selected`);
    }
  }

  // Swipe: fast horizontal travel of the palm with the hand open.
  if (active === 'open-palm') {
    history.push({ t: now, x: mx });
    history = history.filter((h) => now - h.t < 450);
    if (history.length > 4 && now - lastSwipe > 900) {
      const dx = history[history.length - 1].x - history[0].x;
      if (Math.abs(dx) > 0.32) {
        lastSwipe = now;
        const dir = dx > 0 ? 1 : -1;
        const next = (getState().activePanel + dir + PANEL_COUNT) % PANEL_COUNT;
        setState({ activePanel: next });
        logEvent(`swipe ${dir > 0 ? 'right' : 'left'} → panel ${next + 1}`);
        history = [];
      }
    }
  } else {
    history = [];
  }
}
