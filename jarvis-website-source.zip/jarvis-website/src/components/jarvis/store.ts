// Shared, framework-free store for the J.A.R.V.I.S. console.
//
// The hero core, the state selector, the gesture module, the voice console and
// the capabilities panel are sibling CMS blocks, so they cannot share React
// context. They share this module instead: a tiny external store consumed with
// useSyncExternalStore, plus a mutable `live` object for per-frame values
// (tilt, zoom, audio level) that must never trigger React renders.
import { useSyncExternalStore } from 'react';

export type CoreState =
  'idle' | 'listening' | 'processing' | 'speaking' | 'error';

export const CORE_STATES: CoreState[] = [
  'idle',
  'listening',
  'processing',
  'speaking',
  'error',
];

export const STATE_LABEL: Record<CoreState, string> = {
  idle: 'Idle',
  listening: 'Listening',
  processing: 'Processing',
  speaking: 'Speaking',
  error: 'Error',
};

export const STATE_READOUT: Record<CoreState, string> = {
  idle: 'IDLE · STANDING BY',
  listening: 'LISTENING · AWAITING INPUT',
  processing: 'PROCESSING · WORKING',
  speaking: 'SPEAKING · OUTPUT ACTIVE',
  error: 'WARNING · FAULT DETECTED',
};

export type CameraStatus =
  'checking' | 'off' | 'loading' | 'on' | 'denied' | 'nocamera' |
  'unsupported' | 'modelfailed';
export type MicStatus =
  'checking' | 'ready' | 'listening' | 'denied' | 'unsupported' | 'nomic';
export type SynthStatus = 'checking' | 'available' | 'unsupported';
export type GestureName =
  'none' | 'open-palm' | 'pinch' | 'fist' | 'point' | 'two-hands';

export interface LogEntry {
  id: number;
  role: 'user' | 'jarvis' | 'system';
  text: string;
}

export interface JarvisState {
  core: CoreState;
  coreNote: string;
  booted: boolean;
  gridOn: boolean;
  voiceReplies: boolean;
  camera: CameraStatus;
  cameraMessage: string;
  mic: MicStatus;
  micMessage: string;
  micLevelReal: boolean;
  synth: SynthStatus;
  speechReal: boolean;
  gesture: GestureName;
  handsCount: number;
  fps: number;
  activePanel: number;
  locked: boolean;
  messages: LogEntry[];
  events: string[];
}

const INITIAL: JarvisState = {
  core: 'idle',
  coreNote: '',
  booted: false,
  gridOn: true,
  voiceReplies: true,
  camera: 'checking',
  cameraMessage: 'Checking camera support…',
  mic: 'checking',
  micMessage: 'Checking speech recognition…',
  micLevelReal: false,
  synth: 'checking',
  speechReal: false,
  gesture: 'none',
  handsCount: 0,
  fps: 0,
  activePanel: 0,
  locked: false,
  messages: [],
  events: [],
};

let state: JarvisState = INITIAL;
const listeners = new Set<() => void>();

export function getState(): JarvisState {
  return state;
}

export function subscribe(fn: () => void): () => void {
  listeners.add(fn);
  return () => {
    listeners.delete(fn);
  };
}

export function setState(patch: Partial<JarvisState>): void {
  let changed = false;
  for (const key of Object.keys(patch) as (keyof JarvisState)[]) {
    if (state[key] !== patch[key]) {
      changed = true;
      break;
    }
  }
  if (!changed) return;
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

export function useJarvis(): JarvisState {
  return useSyncExternalStore(subscribe, getState, () => INITIAL);
}

/** Mutable per-frame values. Read in rAF loops; never rendered directly. */
export const live = {
  rx: 0,
  ry: 0,
  scale: 1,
  ox: 0,
  oy: 0,
  level: 0, // 0..1 real microphone level
  pulseAt: 0, // performance.now() of last speech-boundary event
};

export function resetTransform(): void {
  live.rx = 0;
  live.ry = 0;
  live.scale = 1;
  live.ox = 0;
  live.oy = 0;
}

const clamp = (v: number, lo: number, hi: number) =>
  Math.min(hi, Math.max(lo, v));

export function nudgeTransform(d: {
  rx?: number;
  ry?: number;
  scale?: number;
}): void {
  if (d.rx) live.rx = clamp(live.rx + d.rx, -60, 60);
  if (d.ry) live.ry = clamp(live.ry + d.ry, -85, 85);
  if (d.scale) live.scale = clamp(live.scale * d.scale, 0.55, 1.8);
}

function stamp(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

export function logEvent(text: string): void {
  const next = [`${stamp()}  ${text}`, ...state.events].slice(0, 4);
  setState({ events: next });
}

let msgId = 0;
export function addMessage(role: LogEntry['role'], text: string): void {
  msgId += 1;
  setState({
    messages: [...state.messages, { id: msgId, role, text }].slice(-40),
  });
}

let recoverTimer: ReturnType<typeof setTimeout> | null = null;
export const ERROR_RECOVER_MS = 4500;

export function setCore(core: CoreState, note = ''): void {
  if (recoverTimer) {
    clearTimeout(recoverTimer);
    recoverTimer = null;
  }
  const changed = state.core !== core;
  setState({ core, coreNote: note });
  if (changed) logEvent(`core → ${core.toUpperCase()}`);
  if (core === 'error') {
    recoverTimer = setTimeout(() => {
      recoverTimer = null;
      if (state.core === 'error') {
        setCore('idle', 'RECOVERED');
      }
    }, ERROR_RECOVER_MS);
  }
}

export function triggerError(message: string): void {
  setCore('error', message);
}

let bootTimer: ReturnType<typeof setTimeout> | null = null;
export function initializeSystem(): void {
  if (bootTimer) clearTimeout(bootTimer);
  setState({ booted: false });
  setCore('processing', 'INITIALIZING');
  logEvent('boot sequence started');
  bootTimer = setTimeout(() => {
    bootTimer = null;
    setState({ booted: true });
    if (state.core === 'processing') setCore('idle', 'SYSTEM ONLINE');
    logEvent('system initialized');
    addMessage(
      'system',
      'System initialized. Type or say “help” to list the commands this demo understands.',
    );
  }, 1800);
}

export function toggleGrid(): boolean {
  setState({ gridOn: !state.gridOn });
  logEvent(`grid ${state.gridOn ? 'on' : 'off'}`);
  return state.gridOn;
}

/* ------------------------------------------------------------------ */
/* Capability detection — honest, local, never prompts the visitor.    */
/* ------------------------------------------------------------------ */

type AnyWin = Window & Record<string, unknown>;

export function speechRecognitionSupported(): boolean {
  if (typeof window === 'undefined') return false;
  const w = window as unknown as AnyWin;
  return Boolean(w.SpeechRecognition || w.webkitSpeechRecognition);
}

export async function detectCapabilities(): Promise<void> {
  if (typeof window === 'undefined') return;

  // Camera
  const md = navigator.mediaDevices;
  if (!md || typeof md.getUserMedia !== 'function') {
    setState({
      camera: 'unsupported',
      cameraMessage: window.isSecureContext
        ? 'This browser does not expose a camera API.'
        : 'Camera access needs a secure (HTTPS) connection.',
    });
  } else if (getState().camera === 'checking') {
    let next: CameraStatus = 'off';
    let msg = 'Camera not enabled. Nothing starts until you press Enable camera.';
    try {
      const devices = await md.enumerateDevices();
      if (!devices.some((d) => d.kind === 'videoinput')) {
        next = 'nocamera';
        msg = 'No camera was found on this device.';
      }
    } catch {
      /* keep default */
    }
    try {
      const perm = await navigator.permissions?.query({
        name: 'camera' as PermissionName,
      });
      if (perm?.state === 'denied') {
        next = 'denied';
        msg = 'Camera permission is blocked for this site in the browser.';
      }
    } catch {
      /* permissions API unavailable for camera — fine */
    }
    if (getState().camera === 'checking') {
      setState({ camera: next, cameraMessage: msg });
    }
  }

  // Microphone / speech recognition
  if (!speechRecognitionSupported()) {
    setState({
      mic: 'unsupported',
      micMessage:
        'Speech recognition is not available in this browser (Firefox, for one). Typed input works fully.',
    });
  } else if (getState().mic === 'checking') {
    let next: MicStatus = 'ready';
    let msg = 'Speech recognition available. Nothing listens until you press the mic.';
    try {
      const perm = await navigator.permissions?.query({
        name: 'microphone' as PermissionName,
      });
      if (perm?.state === 'denied') {
        next = 'denied';
        msg = 'Microphone permission is blocked for this site in the browser.';
      }
    } catch {
      /* ignore */
    }
    if (getState().mic === 'checking') setState({ mic: next, micMessage: msg });
  }

  // Speech synthesis
  const synthOk = 'speechSynthesis' in window;
  setState({ synth: synthOk ? 'available' : 'unsupported' });
  if (!synthOk) setState({ voiceReplies: false });
}

export function recheckCapabilities(): void {
  const s = getState();
  setState({
    camera: s.camera === 'on' || s.camera === 'loading' ? s.camera : 'checking',
    mic: s.mic === 'listening' ? s.mic : 'checking',
  });
  void detectCapabilities();
  logEvent('capabilities re-checked');
}

/* ------------------------------------------------------------------ */
/* Shared audio-level model used by every core canvas.                 */
/* ------------------------------------------------------------------ */

/** 0..1 amplitude for the current state at time t (seconds). */
export function audioLevel(core: CoreState, t: number, now: number): number {
  if (core === 'listening') {
    if (state.micLevelReal) return clamp(live.level, 0, 1);
    return 0.25 + 0.2 * Math.sin(t * 2.3) * Math.sin(t * 0.7 + 1);
  }
  if (core === 'speaking') {
    if (state.speechReal) {
      const env = Math.exp(-(now - live.pulseAt) / 140);
      return clamp(0.22 + 0.78 * env, 0, 1);
    }
    return clamp(
      0.55 +
        0.3 * Math.sin(t * 7.3) * Math.sin(t * 2.1) +
        0.15 * Math.sin(t * 13),
      0.1,
      1,
    );
  }
  return 0;
}
