import type { JarvisState } from './store';

export type Tone = 'on' | 'idle' | 'blocked';
export type CapabilityKey = 'camera' | 'microphone' | 'synthesis' | 'provider';

export interface CapabilityRow {
  key: CapabilityKey;
  short: string;
  status: string;
  tone: Tone;
  detail: string;
}

const CAMERA: Record<JarvisState['camera'], [string, Tone]> = {
  checking: ['CHECKING', 'idle'],
  off: ['NOT ENABLED', 'idle'],
  loading: ['LOADING', 'on'],
  on: ['ENABLED', 'on'],
  denied: ['DENIED', 'blocked'],
  nocamera: ['NO CAMERA', 'blocked'],
  unsupported: ['UNSUPPORTED', 'blocked'],
  modelfailed: ['MODEL FAILED', 'blocked'],
};

const MIC: Record<JarvisState['mic'], [string, Tone]> = {
  checking: ['CHECKING', 'idle'],
  ready: ['AVAILABLE', 'idle'],
  listening: ['LISTENING', 'on'],
  denied: ['DENIED', 'blocked'],
  unsupported: ['UNSUPPORTED', 'blocked'],
  nomic: ['NO MICROPHONE', 'blocked'],
};

export function capabilityRows(s: JarvisState): CapabilityRow[] {
  const [camS, camT] = CAMERA[s.camera];
  const [micS, micT] = MIC[s.mic];
  const synthS =
    s.synth === 'checking'
      ? 'CHECKING'
      : s.synth === 'unsupported'
        ? 'UNSUPPORTED'
        : s.voiceReplies
          ? 'ON'
          : 'AVAILABLE · MUTED';
  const synthT: Tone =
    s.synth === 'unsupported' ? 'blocked' : s.synth === 'available' && s.voiceReplies ? 'on' : 'idle';
  return [
    { key: 'camera', short: 'Camera', status: camS, tone: camT, detail: s.cameraMessage },
    { key: 'microphone', short: 'Microphone', status: micS, tone: micT, detail: s.micMessage },
    {
      key: 'synthesis',
      short: 'Speech synthesis',
      status: synthS,
      tone: synthT,
      detail:
        s.synth === 'unsupported'
          ? 'This browser has no speechSynthesis. Replies stay as text with a simulated waveform.'
          : 'Replies can be spoken with a browser voice. Toggle in the console.',
    },
    {
      key: 'provider',
      short: 'AI provider',
      status: 'NOT CONNECTED · DEMO',
      tone: 'idle',
      detail: 'No language model is connected. Commands are handled locally in the browser.',
    },
  ];
}

export const GESTURE_LABEL: Record<JarvisState['gesture'], string> = {
  none: 'No hand detected',
  'open-palm': 'Open palm',
  pinch: 'Pinch',
  fist: 'Fist',
  point: 'Pointing',
  'two-hands': 'Two hands',
};

export function formatMark(tone: Tone): string {
  return tone === 'on' ? '●' : tone === 'idle' ? '○' : '✕';
}
