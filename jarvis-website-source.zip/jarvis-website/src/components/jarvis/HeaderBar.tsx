'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import { Menu, X } from 'lucide-react';
import { InitLink } from './Live';
import { STATE_LABEL, useJarvis } from './store';
import { btnPrimary } from './ui';

interface NavItem {
  label: string;
  href: string;
}

// The last nav item is rendered as the primary call to action; the rest are
// section anchors.
export function HeaderBar({
  brandName,
  navItems,
}: {
  brandName: string;
  navItems: NavItem[];
}) {
  const [open, setOpen] = useState(false);
  const btnRef = useRef<HTMLButtonElement>(null);
  const s = useJarvis();
  const err = s.core === 'error';
  const links = navItems.slice(0, -1);
  const cta = navItems[navItems.length - 1];

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
        btnRef.current?.focus();
      }
    };
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1280px)');
    const onChange = () => {
      if (mq.matches) setOpen(false);
    };
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  const linkCls =
    'rounded-md px-3 py-2 font-mono text-[11.5px] uppercase tracking-[0.14em] text-mist transition-colors duration-200 hover:text-ice';

  return (
    <header className="fixed inset-x-0 top-0 z-50">
      <nav
        aria-label="Primary"
        className="relative z-50 border-b border-cyan/20 bg-[rgba(2,5,11,0.62)] backdrop-blur-xl"
      >
        <div className="mx-auto flex h-16 max-w-[1400px] items-center justify-between gap-4 px-5 sm:px-8 xl:px-10">
          <Link
            href="/#core"
            className="flex items-center gap-3 rounded-md"
            aria-label={`${brandName} — back to the core`}
          >
            <span
              className={`font-display text-[17px] font-bold tracking-[0.08em] text-glow ${err ? 'text-alert' : 'text-ice'}`}
            >
              {brandName}
            </span>
          </Link>

          <ul className="hidden items-center gap-1 xl:flex">
            {links.map((item) => (
              <li key={item.href + item.label}>
                <Link href={item.href} className={linkCls}>
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-3">
            <span
              role="status"
              aria-label={`Core state: ${STATE_LABEL[s.core]}`}
              className={`hidden items-center gap-2 rounded-full border px-3 py-1.5 font-mono text-[11px] uppercase tracking-[0.14em] sm:inline-flex ${
                err ? 'border-alert/70 text-alert' : 'border-cyan/30 text-cyan-2'
              }`}
            >
              <span
                aria-hidden="true"
                className={`h-2 w-2 animate-pulse-dot rounded-full ${err ? 'bg-alert' : 'bg-cyan-2 shadow-[0_0_8px_#19F0FF]'}`}
              />
              {STATE_LABEL[s.core]}
            </span>
            {cta ? (
              <InitLink href={cta.href} className={`${btnPrimary} hidden !px-4 !py-2.5 md:inline-flex`}>
                {cta.label}
              </InitLink>
            ) : null}
            <button
              ref={btnRef}
              type="button"
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? 'Close menu' : 'Open menu'}
              onClick={() => setOpen((v) => !v)}
              className="inline-flex h-10 w-10 items-center justify-center rounded-[10px] border border-cyan/35 text-ice transition-[transform,background-color,border-color] duration-200 hover:border-cyan-2 hover:bg-cyan/15 active:scale-[0.94] xl:hidden"
            >
              {open ? <X size={20} aria-hidden="true" /> : <Menu size={20} aria-hidden="true" />}
            </button>
          </div>
        </div>
      </nav>

      {/* mobile drawer: shares one duration/easing between backdrop and panel */}
      <div
        aria-hidden="true"
        onClick={() => setOpen(false)}
        className={`fixed inset-0 z-40 bg-black/65 backdrop-blur-sm transition-opacity duration-300 ease-out xl:hidden ${
          open ? 'opacity-100' : 'pointer-events-none opacity-0'
        }`}
      />
      <div
        id="mobile-menu"
        inert={!open}
        className={`fixed right-0 top-0 z-40 h-full w-[min(86vw,360px)] overflow-y-auto border-l border-cyan/25 bg-[rgba(5,11,26,0.96)] px-6 pb-8 pt-24 transition-transform duration-300 ease-out xl:hidden ${
          open ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <ul className="space-y-1">
          {links.map((item) => (
            <li key={item.href + item.label}>
              <Link
                href={item.href}
                onClick={() => setOpen(false)}
                className="block rounded-[10px] border border-transparent px-3 py-3 font-display text-[14px] font-semibold uppercase tracking-[0.14em] text-ice transition-[background-color,border-color] duration-200 hover:border-cyan/30 hover:bg-cyan/10"
              >
                {item.label}
              </Link>
            </li>
          ))}
        </ul>
        {cta ? (
          <div className="mt-6">
            <InitLink href={cta.href} className={`${btnPrimary} w-full`}>
              {cta.label}
            </InitLink>
          </div>
        ) : null}
        <p className="mt-6 font-mono text-[11px] uppercase tracking-[0.16em] text-mist">
          Core · {STATE_LABEL[s.core]}
        </p>
      </div>
    </header>
  );
}
