'use client';

// Small live widgets bound to the shared J.A.R.V.I.S. store.
import Link from 'next/link';
import { useEffect, type ReactNode } from 'react';
import { Minus, Plus, RotateCcw } from 'lucide-react';
import {
  CORE_STATES,
  STATE_LABEL,
  detectCapabilities,
  initializeSystem,
  nudgeTransform,
  resetTransform,
  setCore,
  useJarvis,
  type CoreState,
} from './store';
import { capabilityRows, formatMark, type Tone } from './status';

const TONE_CLS: Record<Tone, string> = {
  on: 'border-cyan-2/60 bg-cyan/10 text-cyan-2',
  idle: 'border-mist/35 bg-white/[0.03] text-mist',
  blocked: 'border-mist/35 bg-white/[0.03] text-ice/70',
};

export function StatusPill({
  tone,
  children,
}: {
  tone: Tone;
  children: ReactNode;
}) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 whitespace-nowrap rounded-full border px-2.5 py-0.5 font-mono text-[10.5px] font-medium uppercase tracking-[0.12em] ${TONE_CLS[tone]}`}
    >
      <span aria-hidden="true">{formatMark(tone)}</span>
      <span>{children}</span>
    </span>
  );
}

/** Runs capability detection once for the page (never prompts the visitor). */
export function CapabilityProbe() {
  useEffect(() => {
    void detectCapabilities();
  }, []);
  return null;
}

/** Link that also boots the system when clicked. */
export function InitLink({
  href,
  className,
  children,
  boot = true,
}: {
  href: string;
  className?: string;
  children: ReactNode;
  boot?: boolean;
}) {
  return (
    <Link
      href={href}
      className={className}
      onClick={() => {
        if (boot) initializeSystem();
      }}
    >
      {children}
    </Link>
  );
}

export function CapabilityMiniList() {
  const s = useJarvis();
  return (
    <ul className="space-y-2.5">
      {capabilityRows(s).map((row) => (
        <li key={row.key} className="flex items-center justify-between gap-3">
          <span className="text-sm text-ice/90">{row.short}</span>
          <StatusPill tone={row.tone}>{row.status}</StatusPill>
        </li>
      ))}
    </ul>
  );
}

const STATE_KEYS: Record<CoreState, string> = {
  idle: '1',
  listening: '2',
  processing: '3',
  speaking: '4',
  error: '5',
};

export function CoreStateSelector({ compact = false }: { compact?: boolean }) {
  const s = useJarvis();
  return (
    <div
      role="group"
      aria-label="Core state selector"
      className={compact ? 'flex flex-wrap gap-2' : 'grid gap-2'}
    >
      {CORE_STATES.map((c) => {
        const active = s.core === c;
        const isErr = c === 'error';
        return (
          <button
            key={c}
            type="button"
            aria-pressed={active}
            onClick={() => setCore(c, isErr ? 'SIMULATED FAULT' : 'MANUAL SELECT')}
            className={`group flex items-center justify-between gap-3 rounded-[10px] border px-3.5 py-2.5 text-left font-display text-[12px] font-semibold uppercase tracking-[0.14em] transition-[transform,background-color,border-color,box-shadow] duration-200 active:scale-[0.97] ${
              active
                ? isErr
                  ? 'border-alert bg-alert/15 text-alert shadow-[0_0_24px_-6px_rgba(255,45,85,0.7)]'
                  : 'border-cyan-2 bg-cyan/15 text-ice shadow-glow'
                : 'border-cyan/20 bg-white/[0.02] text-mist hover:border-cyan-2/60 hover:bg-cyan/10 hover:text-ice'
            }`}
          >
            <span className="flex items-center gap-2.5">
              <span
                aria-hidden="true"
                className={`h-2 w-2 rounded-full ${
                  active ? (isErr ? 'bg-alert' : 'bg-cyan-2') : 'border border-mist/60'
                }`}
              />
              {STATE_LABEL[c]}
            </span>
            {!compact ? (
              <kbd className="rounded border border-mist/30 px-1.5 font-mono text-[10px] font-normal text-mist">
                {STATE_KEYS[c]}
              </kbd>
            ) : null}
          </button>
        );
      })}
    </div>
  );
}

export function ZoomControls() {
  const btn =
    'inline-flex h-9 w-9 items-center justify-center rounded-[9px] border border-cyan/30 bg-white/[0.03] text-ice transition-[transform,background-color,border-color] duration-200 hover:border-cyan-2 hover:bg-cyan/15 active:scale-[0.94]';
  return (
    <div className="flex items-center gap-2" role="group" aria-label="Hologram zoom controls">
      <button type="button" className={btn} aria-label="Zoom out" onClick={() => nudgeTransform({ scale: 1 / 1.12 })}>
        <Minus size={16} aria-hidden="true" />
      </button>
      <button type="button" className={btn} aria-label="Zoom in" onClick={() => nudgeTransform({ scale: 1.12 })}>
        <Plus size={16} aria-hidden="true" />
      </button>
      <button type="button" className={btn} aria-label="Reset hologram position, tilt and zoom" onClick={() => resetTransform()}>
        <RotateCcw size={15} aria-hidden="true" />
      </button>
    </div>
  );
}

/** Keys 1–5 switch core state anywhere on the page (not while typing). */
export function StateKeyShortcuts() {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      const el = e.target as HTMLElement | null;
      if (el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.isContentEditable)) return;
      const idx = '12345'.indexOf(e.key);
      if (idx < 0 || e.key.length !== 1) return;
      const c = CORE_STATES[idx];
      setCore(c, c === 'error' ? 'SIMULATED FAULT' : 'KEYBOARD');
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  return null;
}
