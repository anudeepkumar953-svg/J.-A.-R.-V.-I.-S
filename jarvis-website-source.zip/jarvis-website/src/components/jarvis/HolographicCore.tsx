'use client';

// The J.A.R.V.I.S. holographic core — drawn entirely in code (Canvas 2D for the
// rings / sweeps / particles / waveforms, CSS 3D for tilt and zoom, real DOM text
// for the wordmark and live status). It is a view over the shared state machine
// in ./store: five states, each with its own motion profile.
import { useEffect, useRef } from 'react';
import {
  STATE_LABEL,
  audioLevel,
  getState,
  live,
  nudgeTransform,
  resetTransform,
  useJarvis,
} from './store';

type RGB = [number, number, number];
const CYAN: RGB = [0, 229, 255];
const BLUE: RGB = [47, 140, 255];
const RED: RGB = [255, 45, 85];

const PROFILE = {
  idle: { spin: 1, sweep: 0.55, glow: 0.62, pulse: 1.2 },
  listening: { spin: 1.4, sweep: 0.5, glow: 0.8, pulse: 2.6 },
  processing: { spin: 5.5, sweep: 3.4, glow: 1, pulse: 7 },
  speaking: { spin: 2, sweep: 0.9, glow: 0.95, pulse: 4.5 },
  error: { spin: 0.25, sweep: 0.15, glow: 0.9, pulse: 12 },
} as const;

interface Ring {
  r: number;
  w: number;
  speed: number;
  alpha: number;
  dash?: number[];
  arcs?: [number, number][];
  alt?: boolean;
}

const RINGS: Ring[] = [
  { r: 0.92, w: 1.2, speed: 0.12, alpha: 0.5, dash: [2, 10] },
  { r: 0.84, w: 2.4, speed: -0.25, alpha: 0.85, arcs: [[0, 1.2], [2.1, 3.4], [4.2, 5.4]], alt: true },
  { r: 0.74, w: 1, speed: 0.4, alpha: 0.6, dash: [40, 6, 4, 6] },
  { r: 0.66, w: 3.2, speed: 0.55, alpha: 0.9, arcs: [[0.3, 2.2], [3.5, 5.0]] },
  { r: 0.52, w: 1.2, speed: -0.7, alpha: 0.7, dash: [1, 6], alt: true },
  { r: 0.42, w: 2.2, speed: 1.1, alpha: 0.9, arcs: [[0, 4.2]] },
];

interface Particle {
  a: number;
  r: number;
  speed: number;
  tilt: number;
  squash: number;
  size: number;
  phase: number;
}

const TAU = Math.PI * 2;
const lerp = (a: number, b: number, k: number) => a + (b - a) * k;
const rgba = (c: RGB, a: number) =>
  `rgba(${Math.round(c[0])},${Math.round(c[1])},${Math.round(c[2])},${a.toFixed(3)})`;

export function HolographicCore({
  variant = 'hero',
  className = '',
}: {
  variant?: 'hero' | 'compact';
  className?: string;
}) {
  const hero = variant === 'hero';
  const wrapRef = useRef<HTMLDivElement>(null);
  const stageRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const visibleRef = useRef(true);
  const hoverRef = useRef({ x: 0, y: 0 });
  const pointers = useRef(new Map<number, { x: number; y: number }>());
  const pinchDist = useRef(0);
  const s = useJarvis();

  /* ---------------------------- render loop --------------------------- */
  useEffect(() => {
    const canvas = canvasRef.current;
    const wrap = wrapRef.current;
    const stage = stageRef.current;
    if (!canvas || !wrap || !stage) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    let reduced = mq.matches;
    const onMq = () => {
      reduced = mq.matches;
    };
    mq.addEventListener('change', onMq);

    let W = 400;
    let dpr = 1;
    const resize = () => {
      const rect = wrap.getBoundingClientRect();
      W = Math.max(120, Math.round(rect.width));
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      canvas.width = Math.round(W * dpr);
      canvas.height = Math.round(W * dpr);
      canvas.style.width = `${W}px`;
      canvas.style.height = `${W}px`;
    };
    resize();
    const ro = new ResizeObserver(resize);
    ro.observe(wrap);

    const io = new IntersectionObserver(
      (entries) => {
        visibleRef.current = entries[0]?.isIntersecting ?? true;
      },
      { rootMargin: '120px' },
    );
    io.observe(wrap);

    const count = hero ? 78 : 36;
    const particles: Particle[] = Array.from({ length: count }, () => ({
      a: Math.random() * TAU,
      r: 0.5 + Math.random() * 0.62,
      speed: (0.08 + Math.random() * 0.28) * (Math.random() < 0.5 ? -1 : 1),
      tilt: Math.random() * Math.PI,
      squash: 0.25 + Math.random() * 0.75,
      size: 0.8 + Math.random() * 1.8,
      phase: Math.random() * TAU,
    }));
    const ringAngles = RINGS.map(() => Math.random() * TAU);
    let ripples: number[] = [];
    let lastRipple = -10;
    let sweepAngle = 0;
    let t = 0;
    let last = performance.now();
    let lastDraw = 0;
    let raf = 0;
    const color: RGB = [...CYAN];
    const color2: RGB = [...BLUE];
    let spinMul = 1;
    let sweepMul = 0.5;
    let glow = 0.6;
    let lvlS = 0;
    const cur = { rx: 0, ry: 0, scale: 1, ox: 0, oy: 0 };

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      if (!visibleRef.current || document.hidden) {
        last = now;
        return;
      }
      if (reduced && now - lastDraw < 100) return;
      lastDraw = now;
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const st = getState();
      const core = st.core;
      const prof = PROFILE[core];
      const motion = reduced ? 0 : 1;
      t += dt * motion;

      const kc = Math.min(1, dt * 6);
      const tc = core === 'error' ? RED : CYAN;
      const tc2 = core === 'error' ? RED : BLUE;
      for (let i = 0; i < 3; i++) {
        color[i] = lerp(color[i], tc[i], kc);
        color2[i] = lerp(color2[i], tc2[i], kc);
      }
      const ks = Math.min(1, dt * 3);
      spinMul = lerp(spinMul, prof.spin * motion, ks);
      sweepMul = lerp(sweepMul, prof.sweep * motion, ks);
      glow = lerp(glow, prof.glow, ks);
      lvlS = lerp(lvlS, audioLevel(core, t, now), Math.min(1, dt * 12));

      /* 3D transform (tilt / zoom / grab) */
      const kt = 1 - Math.exp(-dt * 9);
      const drift = reduced ? 0 : Math.sin(t * 0.45) * 3;
      cur.rx = lerp(cur.rx, live.rx + drift * 0.6, kt);
      cur.ry = lerp(cur.ry, live.ry + drift, kt);
      cur.scale = lerp(cur.scale, live.scale, kt);
      cur.ox = lerp(cur.ox, live.ox, kt);
      cur.oy = lerp(cur.oy, live.oy, kt);
      const kx = W / 620;
      const h = hoverRef.current;
      stage.style.transform = `translate3d(${(cur.ox * kx).toFixed(1)}px,${(cur.oy * kx).toFixed(1)}px,0) perspective(1100px) rotateX(${(cur.rx - h.y * 6).toFixed(2)}deg) rotateY(${(cur.ry + h.x * 8).toFixed(2)}deg) scale(${cur.scale.toFixed(3)})`;

      /* ---------------------------- canvas ---------------------------- */
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, W, W);
      ctx.save();
      const k = Math.max(0.55, W / 600);
      const cx = W / 2;
      const cy = W / 2;
      const R = (W / 2) * 0.97;

      let alpha = 1;
      if (core === 'error' && !reduced) {
        const f = Math.sin(t * 38) * Math.sin(t * 17 + 1);
        alpha = f > -0.35 ? 1 : 0.35;
        ctx.translate((Math.random() - 0.5) * 2.5, (Math.random() - 0.5) * 2.5);
      }
      ctx.globalAlpha = alpha;
      const pulse = 0.5 + 0.5 * Math.sin(t * prof.pulse);

      // ambient glow
      let g = ctx.createRadialGradient(cx, cy, 0, cx, cy, R);
      g.addColorStop(0, rgba(color, 0.2 * glow * (0.8 + 0.2 * pulse)));
      g.addColorStop(0.55, rgba(color2, 0.07 * glow));
      g.addColorStop(1, rgba(color2, 0));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, TAU);
      ctx.fill();

      // outer tick ring
      ctx.strokeStyle = rgba(color, 0.55);
      ctx.lineWidth = 1 * k;
      ctx.beginPath();
      const tickRot = ringAngles[0] * 0.2;
      for (let i = 0; i < 120; i++) {
        const a = (i / 120) * TAU + tickRot;
        const long = i % 10 === 0;
        const r0 = R * (long ? 0.93 : 0.955);
        ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
        ctx.lineTo(cx + Math.cos(a) * R, cy + Math.sin(a) * R);
      }
      ctx.stroke();

      // gyroscope orbit ellipses
      ctx.lineWidth = 1 * k;
      ctx.strokeStyle = rgba(color2, 0.3);
      for (let i = 0; i < 2; i++) {
        const rot = (i === 0 ? 0.5 : -0.75) + Math.sin(t * 0.2 + i) * 0.15;
        ctx.beginPath();
        ctx.ellipse(cx, cy, R * 0.98, R * 0.32, rot, 0, TAU);
        ctx.stroke();
      }

      // sweeps
      sweepAngle += dt * sweepMul * 1.4;
      const sweeps = core === 'processing' ? 3 : 1;
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, R * 0.88, 0, TAU);
      ctx.clip();
      for (let i = 0; i < sweeps; i++) {
        const lead = sweepAngle + (i * TAU) / sweeps;
        if (typeof ctx.createConicGradient === 'function') {
          const cg = ctx.createConicGradient(lead - 0.16 * TAU, cx, cy);
          cg.addColorStop(0, rgba(color, 0));
          cg.addColorStop(0.159, rgba(color, 0.3 * glow));
          cg.addColorStop(0.1595, rgba(color, 0));
          cg.addColorStop(1, rgba(color, 0));
          ctx.fillStyle = cg;
          ctx.fillRect(0, 0, W, W);
        }
        ctx.strokeStyle = rgba(color, 0.85 * glow);
        ctx.lineWidth = 1.5 * k;
        ctx.beginPath();
        ctx.moveTo(cx, cy);
        ctx.lineTo(cx + Math.cos(lead) * R * 0.88, cy + Math.sin(lead) * R * 0.88);
        ctx.stroke();
      }
      ctx.restore();

      // concentric rings
      ctx.lineCap = 'round';
      RINGS.forEach((ring, i) => {
        ringAngles[i] += dt * ring.speed * spinMul;
        const ang = ringAngles[i];
        const col = ring.alt ? color2 : color;
        const passes: [number, number][] = [
          [ring.w * 3.4, ring.alpha * 0.1],
          [ring.w, ring.alpha],
        ];
        for (const [lw, a] of passes) {
          ctx.lineWidth = lw * k;
          ctx.strokeStyle = rgba(col, a * (0.7 + 0.3 * glow));
          if (ring.arcs) {
            ctx.setLineDash([]);
            for (const [a0, a1] of ring.arcs) {
              ctx.beginPath();
              ctx.arc(cx, cy, R * ring.r, ang + a0, ang + a1);
              ctx.stroke();
            }
          } else {
            ctx.setLineDash((ring.dash ?? []).map((d) => d * k));
            ctx.beginPath();
            ctx.arc(cx, cy, R * ring.r, ang, ang + TAU);
            ctx.stroke();
          }
        }
        ctx.setLineDash([]);
      });

      // listening / error ripples
      if (core === 'listening' || core === 'error') {
        const gap =
          core === 'error' ? 0.45 : Math.min(0.95, Math.max(0.35, 0.95 - lvlS * 0.6));
        if (!reduced && t - lastRipple > gap) {
          ripples.push(t);
          lastRipple = t;
        }
      }
      const life = 2.4;
      ripples = ripples.filter((b) => t - b < life);
      for (const b of ripples) {
        const age = (t - b) / life;
        ctx.lineWidth = (1.4 + lvlS * 2.4) * k;
        ctx.strokeStyle = rgba(color, (1 - age) * (0.3 + 0.45 * lvlS + 0.1));
        ctx.beginPath();
        ctx.arc(cx, cy, R * (0.3 + 0.66 * age), 0, TAU);
        ctx.stroke();
      }
      if (core === 'listening') {
        ctx.lineWidth = 2 * k;
        ctx.strokeStyle = rgba(color, 0.6 + lvlS * 0.4);
        ctx.beginPath();
        ctx.arc(cx, cy, R * 0.36 * (1 + lvlS * 0.3), 0, TAU);
        ctx.stroke();
      }

      // audio-reactive bars: speaking (outward ring) / listening (mic level)
      if (core === 'speaking' || core === 'listening') {
        const N = 84;
        const r0 = R * (core === 'speaking' ? 0.57 : 0.45);
        const maxLen = R * (core === 'speaking' ? 0.22 : 0.14);
        ctx.lineWidth = Math.max(1.6, 2.6 * k);
        ctx.strokeStyle = rgba(color, 0.95);
        ctx.beginPath();
        for (let i = 0; i < N; i++) {
          const a = (i / N) * TAU + ringAngles[0] * 0.5;
          const amp =
            (0.5 + 0.5 * Math.sin(i * 0.42 + t * 6.1)) * 0.55 +
            (0.5 + 0.5 * Math.sin(i * 1.17 - t * 8.3)) * 0.45;
          const len = R * 0.012 + maxLen * amp * Math.max(0.08, lvlS);
          ctx.moveTo(cx + Math.cos(a) * r0, cy + Math.sin(a) * r0);
          ctx.lineTo(cx + Math.cos(a) * (r0 + len), cy + Math.sin(a) * (r0 + len));
        }
        ctx.stroke();
      }

      // inner energy
      const er = R * (0.34 + 0.05 * pulse + 0.07 * lvlS);
      g = ctx.createRadialGradient(cx, cy, 0, cx, cy, er);
      g.addColorStop(0, rgba([232, 246, 255], 0.5 * glow));
      g.addColorStop(0.4, rgba(color, 0.42 * glow));
      g.addColorStop(1, rgba(color, 0));
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.arc(cx, cy, er, 0, TAU);
      ctx.fill();

      // orbiting particles
      const pm = core === 'processing' ? 3.2 : core === 'idle' ? 1 : 1.6;
      for (const p of particles) {
        p.a += dt * p.speed * pm * motion;
        const x0 = Math.cos(p.a) * R * p.r;
        const y0 = Math.sin(p.a) * R * p.r * p.squash;
        const ct = Math.cos(p.tilt);
        const sn = Math.sin(p.tilt);
        const x = cx + x0 * ct - y0 * sn;
        const y = cy + x0 * sn + y0 * ct;
        const depth = (Math.sin(p.a) + 1) / 2;
        const tw = 0.6 + 0.4 * Math.sin(t * 2 + p.phase);
        ctx.fillStyle = rgba(color, (0.25 + 0.6 * depth) * tw);
        ctx.beginPath();
        ctx.arc(x, y, p.size * k * (0.6 + 0.7 * depth), 0, TAU);
        ctx.fill();
      }
      ctx.restore();
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      ro.disconnect();
      io.disconnect();
      mq.removeEventListener('change', onMq);
    };
  }, [hero]);

  /* ------------------- mouse / touch / keyboard control ---------------- */
  const onPointerDown = (e: React.PointerEvent) => {
    pointers.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    try {
      (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
    } catch {
      /* ignore */
    }
    if (pointers.current.size === 2) {
      const [a, b] = [...pointers.current.values()];
      pinchDist.current = Math.hypot(a.x - b.x, a.y - b.y);
    }
  };
  const onPointerMove = (e: React.PointerEvent) => {
    const prev = pointers.current.get(e.pointerId);
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    if (!prev) {
      if (e.pointerType === 'mouse') {
        hoverRef.current = {
          x: ((e.clientX - rect.left) / rect.width - 0.5) * 2,
          y: ((e.clientY - rect.top) / rect.height - 0.5) * 2,
        };
      }
      return;
    }
    const next = { x: e.clientX, y: e.clientY };
    pointers.current.set(e.pointerId, next);
    if (pointers.current.size >= 2) {
      const [a, b] = [...pointers.current.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      if (pinchDist.current > 0) nudgeTransform({ scale: d / pinchDist.current });
      pinchDist.current = d;
    } else {
      nudgeTransform({ ry: (next.x - prev.x) * 0.4, rx: -(next.y - prev.y) * 0.4 });
    }
  };
  const onPointerEnd = (e: React.PointerEvent) => {
    pointers.current.delete(e.pointerId);
    pinchDist.current = 0;
  };
  const onKeyDown = (e: React.KeyboardEvent) => {
    const step = 6;
    switch (e.key) {
      case 'ArrowLeft': nudgeTransform({ ry: -step }); break;
      case 'ArrowRight': nudgeTransform({ ry: step }); break;
      case 'ArrowUp': nudgeTransform({ rx: step }); break;
      case 'ArrowDown': nudgeTransform({ rx: -step }); break;
      case '+':
      case '=': nudgeTransform({ scale: 1.08 }); break;
      case '-': nudgeTransform({ scale: 1 / 1.08 }); break;
      case '0': resetTransform(); break;
      default: return;
    }
    e.preventDefault();
  };

  const error = s.core === 'error';
  const word = STATE_LABEL[s.core].toUpperCase();

  return (
    <div
      ref={wrapRef}
      role="group"
      tabIndex={0}
      aria-label="Holographic core. Drag to rotate. Arrow keys rotate, plus and minus zoom, zero resets."
      onPointerDown={onPointerDown}
      onPointerMove={onPointerMove}
      onPointerUp={onPointerEnd}
      onPointerCancel={onPointerEnd}
      onPointerLeave={(e) => {
        hoverRef.current = { x: 0, y: 0 };
        if (e.pointerType === 'mouse') pointers.current.clear();
      }}
      onKeyDown={onKeyDown}
      className={`@container relative aspect-square w-full cursor-grab touch-pan-y select-none rounded-full outline-none active:cursor-grabbing focus-visible:ring-2 focus-visible:ring-cyan-2/70 ${className}`}
    >
      <div
        ref={stageRef}
        className="absolute inset-0 will-change-transform"
        style={{ transformOrigin: '50% 50%' }}
      >
        <canvas ref={canvasRef} aria-hidden="true" className="absolute left-0 top-0" />
        <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
          <div
            aria-hidden="true"
            className="absolute left-1/2 top-1/2 h-[46%] w-[46%] -translate-x-1/2 -translate-y-1/2 rounded-full"
            style={{
              background:
                'radial-gradient(closest-side, rgba(2,5,11,0.82), rgba(2,5,11,0.5) 60%, transparent)',
            }}
          />
          <span
            className={`relative font-display font-bold leading-none ${
              hero ? 'text-[5.2cqw]' : 'text-[7cqw]'
            } tracking-[0.04em] ${error ? 'text-alert' : 'text-ice'} text-glow`}
            style={error ? { textShadow: '0 0 18px rgba(255,45,85,0.7)' } : undefined}
          >
            J.A.R.V.I.S.
          </span>
          <span
            className={`relative mt-[1.6cqw] font-mono text-[clamp(8px,1.8cqw,12px)] uppercase tracking-[0.3em] ${
              error ? 'text-alert' : 'text-mist'
            }`}
          >
            System status
          </span>
          <span
            {...(hero ? { 'aria-live': 'polite' as const } : {})}
            className={`relative mt-[0.8cqw] font-mono text-[clamp(10px,2.7cqw,17px)] font-medium uppercase tracking-[0.16em] ${
              error ? 'text-alert' : 'text-cyan-2'
            }`}
          >
            {error ? '⚠ ' : ''}
            {word}
          </span>
          {hero && s.coreNote ? (
            <span
              className={`relative mt-[0.8cqw] hidden font-mono text-[clamp(9px,1.7cqw,11px)] uppercase tracking-[0.18em] @md:block ${
                error ? 'text-alert' : 'text-mist'
              }`}
            >
              {s.coreNote}
            </span>
          ) : null}
        </div>
      </div>
    </div>
  );
}
