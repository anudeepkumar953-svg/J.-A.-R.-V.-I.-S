import type { CSSProperties, ReactNode } from 'react';

// Shared HUD primitives: corner brackets, glass panel, section shell with
// blurred backlights, kicker pill + heading lockup.

export function Brackets({ tone = 'cyan' }: { tone?: 'cyan' | 'alert' }) {
  const c = tone === 'alert' ? 'border-alert' : 'border-cyan-2';
  const base = `pointer-events-none absolute h-3.5 w-3.5 ${c}`;
  return (
    <>
      <span aria-hidden="true" className={`${base} -left-px -top-px border-l-2 border-t-2`} />
      <span aria-hidden="true" className={`${base} -right-px -top-px border-r-2 border-t-2`} />
      <span aria-hidden="true" className={`${base} -bottom-px -left-px border-b-2 border-l-2`} />
      <span aria-hidden="true" className={`${base} -bottom-px -right-px border-b-2 border-r-2`} />
    </>
  );
}

export function GlassPanel({
  children,
  className = '',
  style,
  as: Tag = 'div',
  label,
}: {
  children: ReactNode;
  className?: string;
  style?: CSSProperties;
  as?: 'div' | 'section' | 'article' | 'aside';
  label?: string;
}) {
  return (
    <Tag
      style={style}
      aria-label={label}
      className={`relative rounded-[14px] border border-cyan/25 bg-[rgba(5,11,26,0.62)] shadow-glow-soft backdrop-blur-xl ${className}`}
    >
      <Brackets />
      {children}
    </Tag>
  );
}

export function Kicker({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full border border-cyan/35 bg-cyan/10 px-3.5 py-1.5 font-mono text-[11px] font-medium uppercase tracking-[0.22em] text-cyan-2">
      <span aria-hidden="true" className="h-1.5 w-1.5 rounded-full bg-cyan-2" />
      {children}
    </span>
  );
}

export function Lockup({
  kicker,
  heading,
  subheading,
  align = 'left',
  className = '',
}: {
  kicker?: string | null;
  heading: string;
  subheading?: string | null;
  align?: 'left' | 'center';
  className?: string;
}) {
  const center = align === 'center';
  return (
    <div
      className={`${center ? 'mx-auto text-center' : ''} ${className}`}
    >
      {kicker ? (
        <div className="reveal">
          <Kicker>{kicker}</Kicker>
        </div>
      ) : null}
      <h2
        className="reveal mt-5 whitespace-pre-line font-heading text-[2.25rem] font-bold leading-[1.02] tracking-[-0.035em] text-ice sm:text-5xl lg:text-[4rem]"
        style={{ transitionDelay: '70ms' }}
      >
        {heading}
      </h2>
      {subheading ? (
        <p
          className={`reveal mt-5 max-w-[62ch] text-base leading-relaxed text-mist md:text-lg ${center ? 'mx-auto' : ''}`}
          style={{ transitionDelay: '140ms' }}
        >
          {subheading}
        </p>
      ) : null}
    </div>
  );
}

type Orb = 'a' | 'b' | 'c';
const ORBS: Record<Orb, string[]> = {
  a: [
    '-left-40 top-10 h-[420px] w-[420px] bg-holo/25',
    '-right-32 bottom-0 h-[360px] w-[360px] bg-cyan/15',
  ],
  b: [
    '-right-40 top-0 h-[460px] w-[460px] bg-holo/20',
    '-left-24 bottom-10 h-[320px] w-[320px] bg-cyan/15',
  ],
  c: [
    'left-1/2 top-1/3 h-[520px] w-[520px] -translate-x-1/2 bg-holo/20',
    '-right-20 -top-10 h-[260px] w-[260px] bg-cyan/12',
  ],
};

export function SectionShell({
  id,
  children,
  className = '',
  orb = 'a',
  width = 'max-w-7xl',
  labelledBy,
}: {
  id?: string;
  children: ReactNode;
  className?: string;
  orb?: Orb;
  width?: string;
  labelledBy?: string;
}) {
  return (
    <section
      id={id}
      aria-labelledby={labelledBy}
      className={`relative isolate scroll-mt-16 overflow-clip px-5 py-20 sm:px-8 md:py-24 lg:px-10 ${className}`}
    >
      {ORBS[orb].map((cls, i) => (
        <div
          key={i}
          aria-hidden="true"
          className={`pointer-events-none absolute -z-10 animate-orb rounded-full blur-[110px] ${cls}`}
          style={{ animationDelay: `${i * -9}s` }}
        />
      ))}
      <div className={`relative mx-auto w-full ${width}`}>{children}</div>
    </section>
  );
}

/** Glowing circuit trace with 90° elbows. Pure SVG, scales with its box. */
export function Trace({
  d,
  viewBox,
  className = '',
}: {
  d: string;
  viewBox: string;
  className?: string;
}) {
  return (
    <svg
      aria-hidden="true"
      viewBox={viewBox}
      preserveAspectRatio="none"
      className={`pointer-events-none absolute ${className}`}
    >
      <path
        d={d}
        fill="none"
        stroke="rgba(0,229,255,0.28)"
        strokeWidth="1"
        vectorEffect="non-scaling-stroke"
      />
      <path
        d={d}
        fill="none"
        stroke="#19F0FF"
        strokeWidth="1.5"
        strokeLinecap="round"
        vectorEffect="non-scaling-stroke"
        className="trace-line"
        style={{ filter: 'drop-shadow(0 0 3px rgba(0,229,255,0.9))' }}
      />
    </svg>
  );
}

export const btnPrimary =
  'inline-flex items-center justify-center gap-2 rounded-[10px] border border-cyan-2 bg-cyan/15 px-6 py-3 font-display text-[13px] font-semibold uppercase tracking-[0.14em] text-ice shadow-glow transition-[transform,background-color,box-shadow] duration-200 hover:bg-cyan/30 hover:shadow-[0_0_34px_-2px_rgba(0,229,255,0.6)] active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-50';

export const btnGhost =
  'inline-flex items-center justify-center gap-2 rounded-[10px] border border-mist/40 bg-white/[0.03] px-5 py-3 font-display text-[12px] font-semibold uppercase tracking-[0.14em] text-ice transition-[transform,background-color,border-color] duration-200 hover:border-cyan-2/70 hover:bg-cyan/10 active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-40';
