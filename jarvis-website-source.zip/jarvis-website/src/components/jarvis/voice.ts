// Voice input (Web Speech API), spoken replies (speechSynthesis) and the local
// scripted command handler. There is NO language-model backend: anything the
// handler does not recognise gets an honest "not connected" reply.
import {
  CORE_STATES,
  STATE_LABEL,
  addMessage,
  getState,
  live,
  logEvent,
  resetTransform,
  setCore,
  setState,
  speechRecognitionSupported,
  toggleGrid,
  triggerError,
  type CoreState,
} from './store';

/* eslint-disable @typescript-eslint/no-explicit-any */
type AnyRecognition = any;

let recognition: AnyRecognition | null = null;
let micStream: MediaStream | null = null;
let micCtx: AudioContext | null = null;
let micRaf = 0;
let replyTimer: ReturnType<typeof setTimeout> | null = null;
let scanTimer: ReturnType<typeof setTimeout> | null = null;

/* ------------------------- microphone level ------------------------- */

async function startMicLevel(): Promise<void> {
  try {
    if (!navigator.mediaDevices?.getUserMedia) return;
    micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    const Ctx: typeof AudioContext | undefined =
      window.AudioContext || (window as any).webkitAudioContext;
    if (!Ctx) return;
    micCtx = new Ctx();
    const src = micCtx.createMediaStreamSource(micStream);
    const analyser = micCtx.createAnalyser();
    analyser.fftSize = 512;
    src.connect(analyser);
    const data = new Uint8Array(analyser.fftSize);
    setState({ micLevelReal: true });
    const tick = () => {
      analyser.getByteTimeDomainData(data);
      let sum = 0;
      for (let i = 0; i < data.length; i++) {
        const v = (data[i] - 128) / 128;
        sum += v * v;
      }
      const rms = Math.sqrt(sum / data.length);
      const target = Math.min(1, rms * 5);
      live.level += (target - live.level) * 0.35;
      micRaf = requestAnimationFrame(tick);
    };
    tick();
  } catch {
    // Level metering is an extra; recognition still works without it.
    setState({ micLevelReal: false });
  }
}

function stopMicLevel(): void {
  cancelAnimationFrame(micRaf);
  micStream?.getTracks().forEach((t) => t.stop());
  micStream = null;
  void micCtx?.close().catch(() => undefined);
  micCtx = null;
  live.level = 0;
  setState({ micLevelReal: false });
}

/* --------------------------- recognition ---------------------------- */

export function stopListening(): void {
  try {
    recognition?.stop();
  } catch {
    /* already stopped */
  }
  stopMicLevel();
  if (getState().mic === 'listening') {
    setState({ mic: 'ready', micMessage: 'Microphone off.' });
  }
}

export function startListening(handlers: {
  onInterim: (text: string) => void;
  onFinal: (text: string) => void;
}): void {
  if (!speechRecognitionSupported()) {
    setState({
      mic: 'unsupported',
      micMessage:
        'Speech recognition is not available in this browser. Use typed input.',
    });
    return;
  }
  const Ctor =
    (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
  cancelSpeech();
  const rec: AnyRecognition = new Ctor();
  recognition = rec;
  rec.lang = 'en-US';
  rec.continuous = false;
  rec.interimResults = true;

  let finalText = '';
  rec.onstart = () => {
    setState({ mic: 'listening', micMessage: 'Listening — speak a command.' });
    setCore('listening', getState().micLevelReal ? 'MIC LIVE' : 'MIC ACTIVE');
    void startMicLevel().then(() => {
      if (getState().mic === 'listening') {
        setCore('listening', getState().micLevelReal ? 'MIC LIVE' : 'MIC ACTIVE');
      }
    });
  };
  rec.onresult = (e: any) => {
    let interim = '';
    for (let i = e.resultIndex; i < e.results.length; i++) {
      const r = e.results[i];
      if (r.isFinal) finalText += r[0].transcript;
      else interim += r[0].transcript;
    }
    handlers.onInterim((finalText + interim).trim());
  };
  rec.onerror = (e: any) => {
    const code: string = e?.error ?? 'unknown';
    if (code === 'not-allowed' || code === 'service-not-allowed') {
      setState({
        mic: 'denied',
        micMessage:
          'Microphone permission was denied. Typed input still works.',
      });
      triggerError('MICROPHONE DENIED');
    } else if (code === 'audio-capture') {
      setState({ mic: 'nomic', micMessage: 'No microphone was found.' });
      triggerError('NO MICROPHONE');
    } else if (code === 'no-speech') {
      setState({ micMessage: 'No speech detected. Try again.' });
    } else if (code !== 'aborted') {
      setState({ micMessage: `Speech recognition stopped (${code}).` });
      triggerError('SPEECH RECOGNITION ERROR');
    }
  };
  rec.onend = () => {
    stopMicLevel();
    const s = getState();
    if (s.mic === 'listening') setState({ mic: 'ready', micMessage: 'Microphone off.' });
    if (s.core === 'listening') setCore('idle');
    recognition = null;
    const text = finalText.trim();
    if (text) handlers.onFinal(text);
  };
  try {
    rec.start();
  } catch {
    setState({ micMessage: 'Could not start speech recognition.' });
  }
}

/* --------------------------- speech output -------------------------- */

export function cancelSpeech(): void {
  if (replyTimer) {
    clearTimeout(replyTimer);
    replyTimer = null;
  }
  if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
    window.speechSynthesis.cancel();
  }
}

/** Speak a reply: real speechSynthesis when on and available, else simulated. */
function speak(text: string, onDone?: () => void): void {
  const done = () => {
    if (getState().core === 'speaking') setCore('idle');
    setState({ speechReal: false });
    onDone?.();
  };
  const s = getState();
  if (s.voiceReplies && s.synth === 'available') {
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.02;
    u.pitch = 0.95;
    let started = false;
    u.onstart = () => {
      started = true;
      setState({ speechReal: true });
      setCore('speaking', 'SPEECH SYNTHESIS LIVE');
    };
    u.onboundary = () => {
      live.pulseAt = performance.now();
    };
    u.onend = done;
    u.onerror = done;
    setCore('speaking', 'SPEECH SYNTHESIS LIVE');
    window.speechSynthesis.speak(u);
    // Some browsers never fire start/end without a user-activated voice.
    replyTimer = setTimeout(() => {
      if (!started) {
        window.speechSynthesis.cancel();
        setCore('speaking', 'SIMULATED WAVEFORM');
        replyTimer = setTimeout(done, simulatedMs(text));
      }
    }, 1500);
    return;
  }
  setState({ speechReal: false });
  setCore('speaking', 'SIMULATED WAVEFORM');
  replyTimer = setTimeout(done, simulatedMs(text));
}

function simulatedMs(text: string): number {
  return Math.min(4200, 900 + text.length * 28);
}

/* ------------------------- command handler -------------------------- */

interface Result {
  reply: string;
  scrollTo?: string;
  action?: () => void;
}

const has = (t: string, ...words: string[]) => words.some((w) => t.includes(w));

function statusReport(): string {
  const s = getState();
  const cam: Record<string, string> = {
    off: 'not enabled',
    on: 'enabled',
    loading: 'loading model',
    denied: 'denied',
    nocamera: 'no camera found',
    unsupported: 'unsupported',
    modelfailed: 'model failed to load',
    checking: 'checking',
  };
  const mic: Record<string, string> = {
    ready: 'available',
    listening: 'listening',
    denied: 'denied',
    unsupported: 'unsupported',
    nomic: 'no microphone',
    checking: 'checking',
  };
  return [
    `Core: ${STATE_LABEL[s.core]}.`,
    `Camera: ${cam[s.camera]}.`,
    `Speech recognition: ${mic[s.mic]}.`,
    `Speech synthesis: ${s.synth === 'available' ? (s.voiceReplies ? 'on' : 'available, muted') : s.synth}.`,
    'AI provider: not connected (demo).',
  ].join(' ');
}

function parse(raw: string): Result {
  const t = raw.toLowerCase().replace(/[.!?,]/g, '').trim();

  const stateMatch = CORE_STATES.find(
    (c) =>
      (has(t, 'state', 'mode', 'switch to', 'go to', 'set core') && t.includes(c)) ||
      t === c,
  );
  if (stateMatch) {
    return {
      reply: `Core state set to ${STATE_LABEL[stateMatch]}.${
        stateMatch === 'error'
          ? ' Simulated fault — the core recovers on its own.'
          : ''
      }`,
      action: () =>
        setCore(
          stateMatch,
          stateMatch === 'error' ? 'SIMULATED FAULT' : 'COMMAND',
        ),
    };
  }

  if (has(t, 'toggle grid', 'grid')) {
    return {
      reply: '__GRID__',
      action: () => undefined,
    };
  }
  if (has(t, 'voice on', 'unmute', 'enable voice', 'speak to me')) {
    return {
      reply: 'Spoken replies enabled.',
      action: () => setState({ voiceReplies: getState().synth === 'available' }),
    };
  }
  if (has(t, 'voice off', 'mute', 'be quiet', 'silence')) {
    return {
      reply: 'Spoken replies muted. Text replies continue.',
      action: () => setState({ voiceReplies: false }),
    };
  }
  if (has(t, 'reset')) {
    return {
      reply: 'Hologram transform reset to centre.',
      action: () => resetTransform(),
    };
  }
  if (has(t, 'scan')) {
    return {
      reply: '__SCAN__',
    };
  }
  if (has(t, 'show gesture', 'gesture')) {
    return {
      reply:
        'Gesture Control: open palm wakes the core, pinch grabs it, a fist locks it into processing, pointing selects a panel, two hands zoom, and a swipe changes panel. All of it needs the camera enabled — mouse, touch and keyboard work without it.',
      scrollTo: 'gesture',
    };
  }
  if (has(t, 'capabilit', 'what is available', 'what\u2019s available')) {
    return { reply: statusReport(), scrollTo: 'capabilities' };
  }
  if (has(t, 'status', 'system report', 'how are you')) {
    return { reply: statusReport() };
  }
  if (has(t, 'what can you do', 'help', 'commands', 'what do you do')) {
    return {
      reply:
        'I can run these local commands: status, scan, show gestures, show capabilities, change state to listening / processing / speaking / error / idle, toggle grid, voice on / voice off, reset, connect a provider. Anything else needs a language model, which is not connected in this demo.',
    };
  }
  if (has(t, 'provider', 'connect', 'language model', 'llm', 'brain')) {
    return {
      reply:
        'No AI provider is connected. A provider adapter slot is planned, to be wired up after a design is chosen.',
      scrollTo: 'provider',
    };
  }
  if (has(t, 'how it works', 'how does this work')) {
    return {
      reply: 'Three steps: initialize, interact, connect a provider.',
      scrollTo: 'how-it-works',
    };
  }
  if (/^(hi|hello|hey|good (morning|evening|afternoon))\b/.test(t)) {
    return {
      reply:
        'Hello. This is a demo console — try “status”, “scan” or “help”.',
    };
  }
  return {
    reply:
      'The AI language-model connection is not connected in this demo, so I can only run local commands. Say or type “help” to see them.',
  };
}

export function runCommand(raw: string): void {
  const text = raw.trim();
  if (!text) return;
  addMessage('user', text);
  logEvent(`command: ${text.slice(0, 28)}`);
  cancelSpeech();
  if (scanTimer) {
    clearTimeout(scanTimer);
    scanTimer = null;
  }
  const result = parse(text);

  const respond = (reply: string) => {
    addMessage('jarvis', reply);
    if (result.scrollTo) {
      document
        .getElementById(result.scrollTo)
        ?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
    if (result.action) result.action();
    speak(reply);
  };

  if (result.reply === '__SCAN__') {
    setCore('processing', 'SCANNING');
    scanTimer = setTimeout(() => {
      scanTimer = null;
      respond(`Scan complete. ${statusReport()}`);
    }, 2600);
    return;
  }
  if (result.reply === '__GRID__') {
    const on = toggleGrid();
    setCore('processing', 'EXECUTING');
    scanTimer = setTimeout(() => {
      scanTimer = null;
      respond(`Perspective grid ${on ? 'enabled' : 'disabled'}.`);
    }, 450);
    return;
  }
  const isStateCmd = result.action && !result.scrollTo && getStateCommand(result);
  if (isStateCmd) {
    // The command itself set the state; show the reply without overriding it.
    addMessage('jarvis', result.reply);
    result.action?.();
    return;
  }
  setCore('processing', 'PARSING COMMAND');
  scanTimer = setTimeout(() => {
    scanTimer = null;
    respond(result.reply);
  }, 550);
}

function getStateCommand(r: Result): boolean {
  return /^Core state set to/.test(r.reply);
}

export type { CoreState };
