'use client';

// The hero "command centre": the holographic core flanked by four floating glass
// HUD panels (system status, capabilities, core-state selector, interaction).
import { Hand, Keyboard, Mouse } from 'lucide-react';
import { HolographicCore } from './HolographicCore';
import {
  CapabilityMiniList,
  CoreStateSelector,
  StateKeyShortcuts,
  ZoomControls,
} from './Live';
import { GlassPanel, Trace } from './ui';
import { GESTURE_LABEL } from './status';
import { STATE_READOUT, useJarvis } from './store';

const LABEL =
  'font-mono text-[11px] font-medium uppercase tracking-[0.24em] text-mist';

function PanelTitle({ children, live = false }: { children: string; live?: boolean }) {
  return (
    <div className="mb-3 flex items-center justify-between gap-3">
      <p className={LABEL}>{children}</p>
      {live ? (
        <span
          aria-hidden="true"
          className="h-2 w-2 animate-pulse-dot rounded-full bg-cyan-2 shadow-[0_0_10px_#19F0FF]"
        />
      ) : null}
    </div>
  );
}

export function GridFloor() {
  const s = useJarvis();
  return (
    <div
      aria-hidden="true"
      className={`pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-[62%] overflow-hidden transition-opacity duration-700 ${
        s.gridOn ? 'opacity-100' : 'opacity-0'
      }`}
      style={{
        perspective: '520px',
        perspectiveOrigin: '50% 0%',
        maskImage: 'linear-gradient(to bottom, transparent 0%, #000 38%, #000 70%, transparent 100%)',
        WebkitMaskImage:
          'linear-gradient(to bottom, transparent 0%, #000 38%, #000 70%, transparent 100%)',
      }}
    >
      <div
        className="absolute left-[-50%] top-0 h-[260%] w-[200%] origin-top opacity-[0.32]"
        style={{ transform: 'rotateX(64deg)' }}
      >
        <div className="hud-grid-plane h-full w-full animate-grid" />
      </div>
    </div>
  );
}

export function HeroConsole() {
  const s = useJarvis();
  const err = s.core === 'error';
  const modeLine =
    s.core === 'listening'
      ? s.micLevelReal
        ? 'MIC LEVEL · LIVE'
        : 'MIC · SIMULATED RIPPLES'
      : s.core === 'speaking'
        ? s.speechReal
          ? 'AUDIO · SPEECH TIMING'
          : 'WAVEFORM · SIMULATED'
        : 'RENDER · LOCAL CANVAS';

  return (
    <div className="relative mt-8 grid gap-4 sm:grid-cols-2 lg:mt-6 lg:grid-cols-[minmax(0,300px)_minmax(0,1fr)_minmax(0,300px)] lg:gap-x-8 lg:gap-y-5">
      <StateKeyShortcuts />
      {/* circuit traces linking the panels to the core (desktop only) */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 hidden lg:block">
        <Trace viewBox="0 0 100 100" className="inset-0 h-full w-full" d="M 24 24 H 29 V 38 H 33" />
        <Trace viewBox="0 0 100 100" className="inset-0 h-full w-full" d="M 24 76 H 29 V 62 H 33" />
        <Trace viewBox="0 0 100 100" className="inset-0 h-full w-full" d="M 76 24 H 71 V 38 H 67" />
        <Trace viewBox="0 0 100 100" className="inset-0 h-full w-full" d="M 76 76 H 71 V 62 H 67" />
      </div>

      {/* CORE */}
      <div className="relative z-10 mx-auto w-full max-w-[min(92vw,540px)] sm:col-span-2 lg:col-span-1 lg:col-start-2 lg:row-span-2 lg:row-start-1 lg:self-center">
        <HolographicCore variant="hero" />
        <p className="mt-2 text-center font-mono text-[10.5px] uppercase tracking-[0.2em] text-mist">
          {modeLine}
        </p>
      </div>

      {/* RIGHT TOP — state selector */}
      <GlassPanel
        as="section"
        label="Core state selector"
        className="z-10 p-4 lg:col-start-3 lg:row-start-1 lg:self-center"
        style={{ animation: 'float 6.2s ease-in-out infinite', animationDelay: '-1.4s' }}
      >
        <PanelTitle>Core state</PanelTitle>
        <CoreStateSelector />
      </GlassPanel>

      {/* LEFT TOP — system status */}
      <GlassPanel
        as="section"
        label="System status"
        className="z-10 p-4 lg:col-start-1 lg:row-start-1 lg:self-center"
        style={{ animation: 'float 5.4s ease-in-out infinite' }}
      >
        <PanelTitle live>System status</PanelTitle>
        <p
          className={`font-display text-[15px] font-semibold leading-snug tracking-[0.08em] ${
            err ? 'text-alert' : 'text-cyan-2'
          }`}
        >
          {err ? '⚠ ' : ''}
          {STATE_READOUT[s.core]}
        </p>
        <dl className="mt-3 space-y-1.5 font-mono text-[11.5px] leading-relaxed">
          <div className="flex justify-between gap-3">
            <dt className="text-mist">SESSION</dt>
            <dd className="text-ice">{s.booted ? 'INITIALIZED' : 'NOT INITIALIZED'}</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-mist">GRID</dt>
            <dd className="text-ice">{s.gridOn ? 'ON' : 'OFF'}</dd>
          </div>
          <div className="flex justify-between gap-3">
            <dt className="text-mist">LOCK</dt>
            <dd className="text-ice">{s.locked ? 'FIST LOCK' : 'FREE'}</dd>
          </div>
        </dl>
        <div className="mt-3 border-t border-cyan/15 pt-3">
          <p className="mb-1.5 font-mono text-[10px] uppercase tracking-[0.22em] text-mist">
            Event log
          </p>
          <ul className="min-h-[3.6rem] space-y-0.5 font-mono text-[10.5px] text-ice/80" aria-live="off">
            {s.events.length === 0 ? (
              <li className="text-mist">— no events yet —</li>
            ) : (
              s.events.slice(0, 3).map((e, i) => <li key={`${e}-${i}`}>› {e}</li>)
            )}
          </ul>
        </div>
      </GlassPanel>

      {/* LEFT BOTTOM — capabilities */}
      <GlassPanel
        as="section"
        label="Capabilities"
        className="z-10 p-4 lg:col-start-1 lg:row-start-2 lg:self-center"
        style={{ animation: 'float 7s ease-in-out infinite', animationDelay: '-3s' }}
      >
        <PanelTitle>Capabilities</PanelTitle>
        <CapabilityMiniList />
      </GlassPanel>

      {/* RIGHT BOTTOM — interaction */}
      <GlassPanel
        as="section"
        label="Interaction"
        className="z-10 p-4 lg:col-start-3 lg:row-start-2 lg:self-center"
        style={{ animation: 'float 6.6s ease-in-out infinite', animationDelay: '-2.2s' }}
      >
        <PanelTitle>Interaction</PanelTitle>
        <div className="flex items-center justify-between gap-3">
          <span className="text-sm text-ice/90">Gesture</span>
          <span className="font-mono text-[11.5px] uppercase tracking-[0.1em] text-cyan-2">
            {s.camera === 'on' ? GESTURE_LABEL[s.gesture] : 'Camera off'}
          </span>
        </div>
        <ul className="mt-3 space-y-2 text-[13px] leading-snug text-mist">
          <li className="flex gap-2.5">
            <Mouse size={15} className="mt-0.5 shrink-0 text-cyan-2" aria-hidden="true" />
            Drag the core to rotate. Two fingers pinch to zoom.
          </li>
          <li className="flex gap-2.5">
            <Keyboard size={15} className="mt-0.5 shrink-0 text-cyan-2" aria-hidden="true" />
            Focus it: arrows rotate, + / − zoom. Keys 1–5 set the state.
          </li>
          <li className="flex gap-2.5">
            <Hand size={15} className="mt-0.5 shrink-0 text-cyan-2" aria-hidden="true" />
            Hand tracking is opt-in, further down.
          </li>
        </ul>
        <div className="mt-3.5 border-t border-cyan/15 pt-3.5">
          <ZoomControls />
        </div>
      </GlassPanel>
    </div>
  );
}
