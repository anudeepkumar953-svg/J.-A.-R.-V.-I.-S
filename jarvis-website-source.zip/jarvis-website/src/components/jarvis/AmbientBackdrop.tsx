'use client';

// Persistent page-wide atmosphere: three slow blurred backlights plus a
// canvas of drifting particles. Fixed behind everything, never intercepts input.
import { useEffect, useRef } from 'react';
import { useJarvis } from './store';

const PARTICLES = 70;

export function AmbientBackdrop() {
  const ref = useRef<HTMLCanvasElement>(null);
  const s = useJarvis();
  const err = s.core === 'error';

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    let reduced = mq.matches;
    const onMq = () => {
      reduced = mq.matches;
      drawStatic();
    };
    mq.addEventListener('change', onMq);

    let w = 0;
    let h = 0;
    let dpr = 1;
    const pts = Array.from({ length: PARTICLES }, () => ({
      x: Math.random(),
      y: Math.random(),
      r: 0.4 + Math.random() * 1.4,
      v: 0.004 + Math.random() * 0.012,
      dx: (Math.random() - 0.5) * 0.004,
      p: Math.random() * Math.PI * 2,
    }));

    const draw = (t: number) => {
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      ctx.clearRect(0, 0, w, h);
      for (const p of pts) {
        const tw = 0.35 + 0.65 * (0.5 + 0.5 * Math.sin(t * 0.0013 + p.p));
        ctx.fillStyle = `rgba(127,215,255,${(0.12 + 0.4 * tw * (p.r / 1.8)).toFixed(3)})`;
        ctx.beginPath();
        ctx.arc(p.x * w, p.y * h, p.r, 0, Math.PI * 2);
        ctx.fill();
      }
    };
    const drawStatic = () => draw(0);

    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      drawStatic();
    };
    resize();
    window.addEventListener('resize', resize);

    let raf = 0;
    let last = performance.now();
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop);
      if (reduced || document.hidden) {
        last = now;
        return;
      }
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      for (const p of pts) {
        p.y -= p.v * dt * 4;
        p.x += p.dx * dt * 4;
        if (p.y < -0.02) {
          p.y = 1.02;
          p.x = Math.random();
        }
        if (p.x < -0.02) p.x = 1.02;
        if (p.x > 1.02) p.x = -0.02;
      }
      draw(now);
    };
    raf = requestAnimationFrame(loop);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      mq.removeEventListener('change', onMq);
    };
  }, []);

  return (
    <div aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10 overflow-hidden bg-ink">
      <div className="absolute -left-[12%] top-[8%] h-[560px] w-[560px] animate-orb rounded-full bg-holo/20 blur-[130px]" />
      <div
        className={`absolute -right-[10%] top-[38%] h-[520px] w-[520px] animate-orb rounded-full blur-[130px] transition-colors duration-700 ${
          err ? 'bg-alert/15' : 'bg-cyan/12'
        }`}
        style={{ animationDelay: '-10s' }}
      />
      <div
        className="absolute bottom-[-10%] left-[30%] h-[480px] w-[480px] animate-orb rounded-full bg-navy-2/80 blur-[120px]"
        style={{ animationDelay: '-18s' }}
      />
      <canvas ref={ref} className="absolute inset-0" />
    </div>
  );
}
