// Pure derivation behind SaveControls: what the badge says and whether Save is
// enabled, given the form signals the control can observe. Kept free of React
// and Payload so the contract test can drive every state directly.

export type SaveState = 'saving' | 'error' | 'unsaved' | 'saved';

export type SaveSignals = {
  // Payload's form is mid-submit.
  processing: boolean;
  // The last submit threw (network failure); cleared when the editor retries.
  saveFailed: boolean;
  // Some field's value differs from the value it initialised with — the real
  // dirty check (Payload's `modified` is a set-once latch, see SaveControls).
  dirty: boolean;
  // Some array/blocks field's rows sit in a different order than in the saved
  // document (`rowOrderChanged`). Separate from `dirty` because the value diff
  // cannot see a reorder — see the helper for why.
  reordered: boolean;
  // Payload's `modified` latch: true from the first edit until a save resets it.
  modified: boolean;
  // This control's own submit resolved with a success status since it was last
  // clicked. The only signal that survives a create: Payload never refreshes a
  // create form's field state (so `dirty` stays stuck true) and instead relies on
  // a redirect to the edit view that this control does not own.
  justSaved: boolean;
  // A freshly added block is still generating its content (SectionAutofill);
  // saving now would trip validation on its still-empty required fields.
  fillPending: boolean;
  // Payload's `operation`: an existing document (or a global), not a create form.
  isUpdate: boolean;
  // A document id or global slug exists — false only on a create form.
  hasDocument: boolean;
};

export type SaveControlsView = {
  state: SaveState;
  saveDisabled: boolean;
  // Hidden on a pristine create form: nothing typed and nothing saved yet, so
  // there is no save state to report.
  showBadge: boolean;
};

export function deriveSaveControls(s: SaveSignals): SaveControlsView {
  // Anything to save: a changed value, or the same values in a new order.
  const dirty = s.dirty || s.reordered;

  // The submit this control fired succeeded and nothing has been edited since.
  // Reported from the control's own state rather than inherited from a form
  // refresh, so a create — where the refresh never comes — still reads Saved
  // and disables Save instead of inviting a second, duplicate submit.
  const settled = s.justSaved && !s.modified;

  const state: SaveState = s.processing
    ? 'saving'
    : s.saveFailed
      ? 'error'
      : settled || !dirty
        ? 'saved'
        : 'unsaved';

  // A create form that has already created its document but not yet been
  // redirected to it: another submit here can only POST a duplicate (rejected
  // by the unique slug) and would drop the pending edit when the redirect
  // rehydrates the form — so the edit reads Unsaved changes, but Save waits.
  const awaitingRedirect = s.justSaved && !s.hasDocument;

  // An existing document with no real changes has nothing to save (Payload's
  // native SaveButton disables on the `modified` latch here, but that leaves
  // Save enabled after a manual revert — hence `dirty`); a create form stays
  // enabled until its submit succeeds. `processing` is load-bearing: Payload's
  // own FormSubmit used to force a disabled state while a submit was in flight
  // and this button does not, so it is the only thing stopping a fast
  // double-click from firing a second concurrent submit.
  const saveDisabled =
    (s.isUpdate && !dirty) ||
    settled ||
    awaitingRedirect ||
    s.processing ||
    s.fillPending;

  // `processing` keeps "Saving" on screen through the submit: Payload resets
  // its `modified` latch as soon as the response lands, a frame before it
  // clears `processing`, and a create form has no `id` to hold the badge up.
  const showBadge = s.hasDocument || s.modified || s.justSaved || s.processing;

  return { state, saveDisabled, showBadge };
}

// The slice of Payload's flat `FormState` this needs: every array/blocks field
// carries its ordered row metadata under `rows`.
export type RowOrderFields = Record<
  string,
  { rows?: { id: string }[] } | undefined
>;

// The saved document's value at a form path such as `layout` or
// `layout.1.items` (a numeric segment indexes the saved array). After a parent
// reorder the form's index 1 and the saved index 1 are different blocks, but
// then the parent field already reports the change, so the nested lookup only
// has to be right when the parent order holds — and then the indexes agree.
function savedValueAt(savedDocument: unknown, path: string): unknown {
  return path
    .split('.')
    .reduce<unknown>(
      (node, segment) =>
        node && typeof node === 'object'
          ? (node as Record<string, unknown>)[segment]
          : undefined,
      savedDocument,
    );
}

// Whether any array/blocks field's rows sit in a different order than in the
// saved document. Per-field `value`/`initialValue` diffing cannot see this:
// Payload's `MOVE_ROW` moves each row's field entries wholesale, initial value
// included, and the parent field's `value` is only the row count — so a page
// whose sections were dragged into a new order diffs clean. The saved document
// (`useDocumentInfo().savedDocumentData`) is the authoritative order: it is the
// document as loaded, replaced only when a save SUCCEEDS, so a reorder whose
// submit the server rejected stays dirty and retryable. A saved array whose
// rows carry no ids gives nothing to compare against and is left alone.
export function rowOrderChanged(
  fields: RowOrderFields,
  savedDocument: unknown,
): boolean {
  return Object.entries(fields).some(([path, field]) => {
    if (!Array.isArray(field?.rows)) return false;
    const saved = savedValueAt(savedDocument, path);
    if (!Array.isArray(saved)) return false;
    const savedIds = saved.map((row) => (row as { id?: unknown } | null)?.id);
    if (!savedIds.every((id) => typeof id === 'string')) return false;
    return (
      field.rows.length !== savedIds.length ||
      field.rows.some((row, i) => row.id !== savedIds[i])
    );
  });
}
