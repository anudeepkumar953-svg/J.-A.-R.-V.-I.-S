// Single source of truth (template side) for the postMessage protocol between the
// embedded Payload admin and the platform content tab. The two halves can't share
// a build — the platform declares the SAME strings in
// frontend/src/pages/WebsiteDetails/pages/ContentPage/cmsBridgeProtocol.ts — so renaming
// either side silently breaks the bridge at runtime (stuck splash / never-resolving
// autofill). Keep the values byte-identical across both files.

// Section-content bridge: the admin asks the parent to generate on-brand content for
// a newly added layout block; the parent replies with the field values.
export const SECTION_CONTENT_REQUEST = 'kite:request-section-content';
export const SECTION_CONTENT_RESPONSE = 'kite:section-content';

// Session-keepalive bridge: the admin asks the parent for a fresh auto-login token to
// slide the session cookie before it expires; the parent replies with the token.
export const CMS_TOKEN_REQUEST = 'kite:request-cms-token';
export const CMS_TOKEN_RESPONSE = 'kite:cms-token';

// Theme bridge: the admin asks the parent for its resolved appearance on mount; the
// parent replies with `{ theme: 'light' | 'dark' }` and posts the same message
// unsolicited whenever the appearance changes while the admin is open.
export const THEME_REQUEST = 'kite:request-theme';
export const THEME_RESPONSE = 'kite:theme';

// Location bridge: the admin reports its current view to the parent whenever it
// navigates, as `{ path }` relative to the admin route (`''` on the dashboard,
// `/collections/pages/<id>` on a page). The parent records it in its own URL and
// hands it back as `?redirect=` on the next `/admin-login`, so a reload of the
// content tab reopens the view the editor was on. The reply is a bare ack.
export const ADMIN_LOCATION = 'kite:admin-location';
export const ADMIN_LOCATION_ACK = 'kite:admin-location-ack';

// Page-ideas context bridge: the create-page panel asks what it is allowed to do
// here — whether the feature is on for this team, whether this admin is a draft's
// or Main's, and the idea carried over from an open-draft hop. Answered with
// `{ enabled, isDraft, idea }`; `enabled: false` means the panel renders nothing.
export const PAGE_IDEAS_CONTEXT_REQUEST = 'kite:request-page-ideas-context';
export const PAGE_IDEAS_CONTEXT_RESPONSE = 'kite:page-ideas-context';

// Page-ideas bridge: one request per operation on this website's saved ideas —
// `list`, `create`, `dismiss`, `use` and `suggest` — answered with the ideas that
// remain, or `{ error }`.
export const PAGE_IDEAS_REQUEST = 'kite:request-page-ideas';
export const PAGE_IDEAS_RESPONSE = 'kite:page-ideas';

// Page-plan bridge: the panel sends the chosen idea, the page type and what the
// site already looks like; the platform replies with `{ plan }` — the title,
// slug, SEO and the ordered sections the panel then adds to the form.
export const PAGE_PLAN_REQUEST = 'kite:request-page-plan';
export const PAGE_PLAN_RESPONSE = 'kite:page-plan';

// Open-draft bridge: pages are generated in a draft, so on Main the panel asks
// the platform to make one and reopen this create screen inside it with the same
// idea. The reply is a bare ack; the platform owns the navigation.
export const OPEN_DRAFT_REQUEST = 'kite:request-open-draft';
export const OPEN_DRAFT_RESPONSE = 'kite:open-draft';

// The theme domain the bridge carries. One owner for every stage of the handoff
// (the `/admin-login?theme=` cookie seed and the live `ThemeSync` updates) so the
// two can never accept different values. Anything else is not a theme and is
// dropped, never coerced.
export type BridgeTheme = 'dark' | 'light';

export function parseBridgeTheme(value: unknown): BridgeTheme | null {
  return value === 'dark' || value === 'light' ? value : null;
}
