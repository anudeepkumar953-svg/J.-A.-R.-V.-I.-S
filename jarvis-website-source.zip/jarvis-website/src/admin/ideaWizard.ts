import { PREVIEW_ROUTE } from '../payload/proposals';

// Decisions behind the Content tab's AI create-page flow (IdeaPanel).
//
// Each idea row writes its own page on a worker straight into the open draft,
// and its state comes from that run; the editor can switch to the Manual form
// at any point. All of it is plain data here so it can be checked without a
// form.

export type WizardMode = 'ai' | 'manual';

export const WIZARD_MODE_KEY = 'kite:page-create-mode';

type KeyValueStore = Pick<Storage, 'getItem' | 'setItem'>;

/**
 * Storage can be missing or throw (a sandboxed iframe, blocked site data), and
 * the flow must still work, so every access goes through here.
 */
function safely<T>(run: () => T, fallback: T): T {
  try {
    return run();
  } catch {
    return fallback;
  }
}

/** The editor's last choice between the AI flow and the manual form. */
export function readWizardMode(store: KeyValueStore | undefined): WizardMode {
  const saved = safely(() => store?.getItem(WIZARD_MODE_KEY) ?? null, null);
  return saved === 'manual' ? 'manual' : 'ai';
}

export function writeWizardMode(
  store: KeyValueStore | undefined,
  mode: WizardMode,
): void {
  safely(() => store?.setItem(WIZARD_MODE_KEY, mode), undefined);
}

/** The site path a page renders at — the same rule as the live-preview url. */
export function previewPath(slug: string): string {
  return !slug || slug === 'home' ? '/' : `/${slug}`;
}

/**
 * Where the AI tab's preview loads a written page: the preview route, which
 * shows a signed-in editor the page whether or not it is added yet (see
 * `PREVIEW_ROUTE`).
 */
export function previewFrameSrc(slug: string): string {
  return `${PREVIEW_ROUTE}/${slug || 'home'}`;
}

/**
 * Whether to ask Kite for ideas as soon as the AI tab opens. Suggesting runs
 * paid research, so it starts on its own only when the site has no suggested
 * ideas yet — once it has some, the editor regenerates on purpose — and only
 * once per screen, after the saved list has loaded and nothing else is running.
 */
export function shouldAutoSuggest(state: {
  mode: WizardMode;
  ideasLoaded: boolean;
  ideas: { source?: string }[];
  alreadyTried: boolean;
  busy: boolean;
}): boolean {
  return (
    state.mode === 'ai' &&
    state.ideasLoaded &&
    !state.alreadyTried &&
    !state.busy &&
    !state.ideas.some((idea) => idea.source === 'suggested')
  );
}

/**
 * What the AI tab does about ideas when it opens on a spot.
 *
 * Opening the Content tab may already have started the top-level suggestion
 * round on the platform. While that round runs, the panel waits for it rather
 * than paying for a second one — unless Kite's own suggestions are already
 * there to pick from. A wait that ended without ideas (the round failed, or
 * outlived the wait) is not followed by a paid round of the panel's own: the
 * panel says so and the editor retries. Otherwise it does what it always did:
 * suggest only when `shouldAutoSuggest` says so.
 */
export function ideasActionOnOpen(state: {
  mode: WizardMode;
  ideasLoaded: boolean;
  ideas: { source?: string; status?: string }[];
  alreadyTried: boolean;
  busy: boolean;
  /** The spot is the top level, where the platform's round puts its ideas. */
  topLevel: boolean;
  /** The platform reports a suggestion round still adding ideas. */
  roundRunning: boolean;
  /** This screen's wait on that round ended without ideas. */
  waitedOut: boolean;
}): 'wait' | 'suggest' | 'none' {
  if (state.mode !== 'ai' || !state.ideasLoaded || state.busy) return 'none';
  if (state.topLevel && state.waitedOut) return 'none';
  if (
    state.roundRunning &&
    state.topLevel &&
    !state.ideas.some(
      (idea) => idea.source === 'suggested' && idea.status === 'new',
    )
  )
    return 'wait';
  return shouldAutoSuggest(state) ? 'suggest' : 'none';
}

/** The platform's answer about the round a panel is waiting on. */
export type RoundReply = {
  suggesting?: boolean;
  round?: { id?: string; status?: string; error?: string | null } | null;
} | null;

/**
 * One poll of the round the panel is waiting on — `roundId`, the round it
 * joined or was told about: keep waiting, show the ideas, or show the failure
 * with a retry. Only that round's outcome settles the wait; an answer about
 * any other round (an agent's, say) is not this one's. A round still running
 * past the panel's cap is a failure too — the platform stops counting a dead
 * round well before it, so this only bounds a platform that cannot say.
 */
export function roundPollStep(
  reply: RoundReply,
  roundId: string | null,
  waitedMs: number,
  capMs: number,
):
  | { kind: 'wait' }
  | { kind: 'done' }
  | { kind: 'failed'; error: string | null } {
  if (!reply) return { kind: 'failed', error: null };
  const keepWaiting = () =>
    waitedMs >= capMs
      ? ({ kind: 'failed', error: null } as const)
      : ({ kind: 'wait' } as const);
  const round = reply.round;
  if (round) {
    if (roundId && round.id !== roundId) return keepWaiting();
    if (round.status === 'running') return keepWaiting();
    if (round.status === 'failed')
      return { kind: 'failed', error: round.error ?? null };
    return { kind: 'done' };
  }
  // An older platform reports no round: its `suggesting` flag is all there is.
  return reply.suggesting === true ? keepWaiting() : { kind: 'done' };
}

/** One page run, as the platform reports it for the open draft. */
export type PageJob = {
  id: string;
  idea_id: string | null;
  status: string;
  stalled: boolean;
  write_attempted: boolean;
  slug: string | null;
  page_id: string | null;
  // The written page's title, once there is one.
  title?: string | null;
  error: string | null;
  // Set on a run that moves a page written on Main into a draft; that run's
  // `slug` and `page_id` are the draft's page, in `draft_id`.
  source_proposal_id?: string | null;
  // Set on a run that moves a page back out of a draft to wait on Main again;
  // that run's `page_id` is the proposal it became.
  source_draft_page_id?: string | null;
  draft_id?: string | null;
  // That draft's status now: `applied` once it merged.
  draft_status?: string | null;
  // Where the check that the page's text renders styled stands: `pending`,
  // `styled`, `applied`, `failed` (measured flat after the draft's pass) or
  // `unchecked` (not measured; nothing is shown); absent when no check follows.
  style_fix?: string | null;
  // What the run left out of the page or changed in it, a sentence each.
  withheld?: string[] | null;
  updated_at?: string;
};

// A draft closed this way never reached the site.
const UNMERGED_DRAFT_STATUSES = new Set(['reverted', 'abandoned']);

export type IdeaRowState =
  | { kind: 'idle' }
  | { kind: 'writing' }
  | {
      kind: 'created';
      slug: string;
      pageId: string | null;
      title?: string | null;
      // Written but not added to the draft yet: the site serves it to nobody.
      proposed?: boolean;
      // Moved back out of a draft: `pageId` is a `page-proposals` id on Main,
      // which a draft's own pages may reuse for another page.
      onMainOnly?: boolean;
      // Moving it into a draft failed; the page is still here to try again.
      moveError?: string | null;
      // The check that the page's text renders styled (PageJob.style_fix).
      styleFix?: string | null;
      // What the run left out of the page or changed in it (PageJob.withheld).
      notes?: string[];
    }
  // A real page on Main: added there, or to a draft that has since merged.
  | { kind: 'live'; slug: string; pageId: string | null }
  // Written on Main and being added, or already in a draft.
  | { kind: 'adding' }
  | {
      kind: 'added';
      slug: string;
      draftId: string | null;
      // The page's id in that draft.
      pageId: string | null;
      // The draft's status, when the platform said.
      draftStatus?: string | null;
      // Moving it back out failed; it is still in the draft.
      moveError?: string | null;
    }
  // Being moved back out of the draft to wait on Main.
  | { kind: 'removing' }
  // `uncertain`: the run sent the page and stopped before it could say whether
  // it landed, so the editor looks in the draft before asking again.
  | { kind: 'failed'; message: string | null; uncertain: boolean };

const WRITING_STATUSES = new Set(['claimed', 'generating']);

/**
 * What an idea's row shows: its newest page run in this draft decides, and an
 * idea that already produced a page without one (the guided form, an earlier
 * visit) reads as created.
 */
export function ideaRowState(
  idea: { id: string; status?: string; generated_slug?: string | null },
  jobs: PageJob[],
): IdeaRowState {
  const ideaJobs = jobs.filter((candidate) => candidate.idea_id === idea.id);
  const newest = ideaJobs[0];
  const running = (job: PageJob) =>
    WRITING_STATUSES.has(job.status) && !job.stalled;
  if (newest?.source_draft_page_id) {
    if (running(newest)) return { kind: 'removing' };
    if (newest.status === 'created' && newest.slug)
      return {
        kind: 'created',
        slug: newest.slug,
        pageId: newest.page_id,
        title: newest.title ?? null,
        proposed: true,
        onMainOnly: true,
      };
    // The move back failed: the page is still in the draft.
    const before = ideaRowState(idea, ideaJobs.slice(1));
    return before.kind === 'added'
      ? { ...before, moveError: newest.error }
      : before;
  }
  if (newest?.source_proposal_id) {
    if (running(newest)) return { kind: 'adding' };
    if (newest.status === 'created' && newest.slug) {
      // Added on Main itself: no draft took it, so it is on the site.
      if (!newest.draft_id)
        return { kind: 'live', slug: newest.slug, pageId: newest.page_id };
      // Added to a draft that was then thrown away: the page went with it.
      if (UNMERGED_DRAFT_STATUSES.has(newest.draft_status ?? ''))
        return { kind: 'idle' };
      return {
        kind: 'added',
        slug: newest.slug,
        draftId: newest.draft_id ?? null,
        pageId: newest.page_id,
        draftStatus: newest.draft_status ?? null,
      };
    }
    // The move failed: the page is still waiting where it was written.
    const before = ideaRowState(idea, ideaJobs.slice(1));
    return before.kind === 'created'
      ? { ...before, proposed: true, moveError: newest.error }
      : before;
  }
  const job = newest;
  if (job) {
    if (WRITING_STATUSES.has(job.status) && !job.stalled)
      return { kind: 'writing' };
    if (job.status === 'created' && job.slug) {
      return {
        kind: 'created',
        slug: job.slug,
        pageId: job.page_id,
        title: job.title ?? null,
        // A check whose worker is gone says nothing rather than spin forever.
        styleFix:
          job.style_fix === 'pending' && !styleCheckRunning(job)
            ? null
            : (job.style_fix ?? null),
        notes: job.withheld ?? [],
      };
    }
    return {
      kind: 'failed',
      message: job.error,
      uncertain: job.status === 'failed' && job.write_attempted,
    };
  }
  if (idea.status === 'used' && idea.generated_slug) {
    return { kind: 'created', slug: idea.generated_slug, pageId: null };
  }
  return { kind: 'idle' };
}

// How long a pending style check keeps the panel polling: the worker's own
// 45-minute limit (page_style_fix_service.STYLE_FIX_TIME_LIMIT_S) plus room for
// the task to wait in the queue, so a check still pending past it lost its
// worker. test_page_style_fix_service pins the relationship.
const STYLE_CHECK_WINDOW_MS = 60 * 60 * 1000;

/** Whether a written page's style check may still change its preview. */
export function styleCheckRunning(
  job: PageJob,
  now: number = Date.now(),
): boolean {
  if (job.style_fix !== 'pending') return false;
  const since = job.updated_at ? Date.parse(job.updated_at) : NaN;
  return Number.isNaN(since) || now - since < STYLE_CHECK_WINDOW_MS;
}

/**
 * Whether any page is still being written, or still having its text styled to
 * match the site, which is what keeps polling on.
 */
export function anyPageBeingWritten(
  jobs: PageJob[],
  now: number = Date.now(),
): boolean {
  return jobs.some(
    (job) =>
      (WRITING_STATUSES.has(job.status) && !job.stalled) ||
      styleCheckRunning(job, now),
  );
}

/**
 * Put a regenerated idea where the one it replaces was. The platform lists
 * newest first, which would move the fresh idea to the top of the list.
 */
export function replaceIdeaInPlace<T extends { id: string }>(
  before: T[],
  replacedId: string,
  after: T[],
): T[] {
  const known = new Set(before.map((idea) => idea.id));
  const fresh = after.filter((idea) => !known.has(idea.id));
  const byId = new Map(after.map((idea) => [idea.id, idea]));
  if (!known.has(replacedId)) return [...fresh, ...before];
  return before.flatMap((idea) => {
    if (idea.id === replacedId) return fresh;
    const current = byId.get(idea.id);
    return current ? [current] : [];
  });
}

/** The tones the editor can pick for a page; "custom" asks for their words. */
export const TONES = [
  'Friendly',
  'Professional',
  'Casual',
  'Enthusiastic',
  'Concise',
] as const;

/** The longest brief the platform takes, and so the box's counter. */
export const PURPOSE_MAX_LENGTH = 500;
const SLUG_MAX_LENGTH = 60;

/**
 * A URL segment for `title`, the way the platform normalises one: letters and
 * digits in any script, everything else a single dash.
 */
export function slugFromTitle(title: string): string {
  const slug = title
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, '-')
    .replace(/^-+|-+$/g, '');
  return slug.slice(0, SLUG_MAX_LENGTH).replace(/-+$/, '');
}

/** What a picked idea puts in the "Page purpose" box: its subject and the
 * questions it answers, for the editor to adjust. */
export function briefFromIdea(idea: {
  title: string;
  target_questions?: string[];
}): string {
  const questions = (idea.target_questions ?? []).filter(Boolean).slice(0, 4);
  const brief = questions.length
    ? `${idea.title}. Answer: ${questions.join(' ')}`
    : idea.title;
  return brief.slice(0, PURPOSE_MAX_LENGTH);
}

/**
 * The placement the platform is sent for a page written into `spot`: under
 * that page, or top-level for `''`. The editor's own address, brief and tone
 * go with it when given. Kite does not add the page to the menu.
 */
export function placementFor(
  spot: string,
  choices: { slug?: string; purpose?: string; tone?: string } = {},
): {
  parentSlug: string | null;
  purpose: string | null;
  slug: string | null;
  tone: string | null;
  addToMenu: false;
  submenuOf: null;
} {
  return {
    parentSlug: spot || null,
    purpose: choices.purpose?.trim() || null,
    slug: choices.slug?.trim() ? slugFromTitle(choices.slug) || null : null,
    tone: choices.tone?.trim() || null,
    addToMenu: false,
    submenuOf: null,
  };
}

/** The widths the preview can be seen at. */
export const PREVIEW_WIDTHS = {
  desktop: null,
  mobile: 390,
} as const;
export type PreviewDevice = keyof typeof PREVIEW_WIDTHS;

/** Marks an editor opened from the AI tab, so its back arrow returns there. */
export const FROM_IDEAS_PARAM = 'from';
export const FROM_IDEAS_VALUE = 'ideas';
export const IDEA_PARAM = 'idea';

/** The editor of a page written from `ideaId`, remembering where it came from. */
export function editorPathFromIdeas(
  pagesListPath: string,
  pageId: string | null,
  ideaId: string,
): string {
  const query = new URLSearchParams({
    [FROM_IDEAS_PARAM]: FROM_IDEAS_VALUE,
    [IDEA_PARAM]: ideaId,
  });
  return pageId
    ? `${pagesListPath}/${pageId}?${query}`
    : `${pagesListPath}?${query}`;
}

/**
 * Where the editor's back arrow goes when it was opened from the AI tab: the
 * create screen with that idea picked. `null` for an editor reached any other
 * way, which keeps going back to its list.
 */
export function backToIdeas(
  search: URLSearchParams,
  pagesListPath: string,
): string | null {
  if (search.get(FROM_IDEAS_PARAM) !== FROM_IDEAS_VALUE) return null;
  const idea = search.get(IDEA_PARAM);
  return idea
    ? `${pagesListPath}/create?${new URLSearchParams({ [IDEA_PARAM]: idea })}`
    : `${pagesListPath}/create`;
}

/** A page as the panel reads it from this draft. */
export type SitePageRecord = {
  id: string;
  slug: string;
  title: string;
  proposed: boolean;
};

/**
 * A written idea's state checked against the pages the draft actually has:
 * the page's current address and whether it is still a proposal. A page that
 * is gone (discarded, or deleted from the Pages list) leaves the idea
 * unwritten, so it can be written again. Until the pages have loaded the
 * state is left as the run reported it.
 */
/**
 * Whether an idea's page has already gone where pages live: into a draft or
 * onto the site. The idea list keeps only what is still to be decided. A
 * written page counts once the site has said it is not a proposal.
 */
export function isPlaced(state: IdeaRowState): boolean {
  return (
    state.kind === 'added' ||
    state.kind === 'live' ||
    (state.kind === 'created' && state.proposed === false)
  );
}

/**
 * A page added to a draft is only ever in that draft until the draft is
 * merged: it is live once that draft is, and not because Main happens to
 * have another page at the same address. The job still names the merged
 * draft, whose sandbox can no longer show it.
 */
export function withMergedPage(
  state: IdeaRowState,
  mainPages: SitePageRecord[] | null,
): IdeaRowState {
  if (state.kind !== 'added' || state.draftStatus !== 'applied') return state;
  const page = mainPages?.find(
    (candidate) => candidate.slug === state.slug && !candidate.proposed,
  );
  return { kind: 'live', slug: state.slug, pageId: page?.id ?? null };
}

/**
 * A page added on Main is on the site only while Main still has it: deleted
 * there, its idea is free to be written again.
 */
export function withAddedPageOnMain(
  state: IdeaRowState,
  mainPages: SitePageRecord[] | null,
): IdeaRowState {
  if (state.kind !== 'live' || mainPages === null) return state;
  const page = mainPages.find(
    (candidate) =>
      !candidate.proposed &&
      (candidate.id === state.pageId || candidate.slug === state.slug),
  );
  return page ? { ...state, pageId: page.id } : { kind: 'idle' };
}

/**
 * The pages nested under *slug*: a child's address is its parent's plus its
 * own segment, so its slug starts with the parent's and a slash.
 */
export function pagesUnder<T extends { slug: string }>(
  slug: string,
  pages: T[],
): T[] {
  return pages.filter((page) => page.slug.startsWith(`${slug}/`));
}

/**
 * On Main nothing written is in a draft: a written page waits there as a
 * proposal until it is added, whatever the pages read says or before it has
 * loaded. Its id is a `page-proposals` id, never a live page's.
 */
export function asMainProposal(state: IdeaRowState): IdeaRowState {
  return state.kind === 'created' && state.proposed !== true
    ? { ...state, proposed: true }
    : state;
}

/**
 * In a draft, a page moved back to Main is found by its address alone: its id
 * is a proposal's on Main and could name an unrelated page in this draft.
 */
export function inDraftView(state: IdeaRowState): IdeaRowState {
  return state.kind === 'created' && state.onMainOnly
    ? { ...state, pageId: null }
    : state;
}

export function withPageOnSite(
  state: IdeaRowState,
  pages: SitePageRecord[] | null,
): IdeaRowState {
  if (state.kind !== 'created' || pages === null) return state;
  const page =
    (state.pageId &&
      pages.find((candidate) => candidate.id === state.pageId)) ||
    pages.find((candidate) => candidate.slug === state.slug);
  if (!page) return { kind: 'idle' };
  return {
    ...state,
    pageId: page.id,
    slug: page.slug,
    proposed: page.proposed,
  };
}
