'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import type { Block } from 'payload';
import { toast, useForm, useFormFields } from '@payloadcms/ui';
import {
  BLOCKS_BY_SLUG,
  RowShimmer,
  SECTION_FILL_TIMEOUT_MS,
  fetchBrandContext,
  isObject,
  serializeFields,
  writeFields,
} from './blockFill';
import {
  SECTION_CONTENT_REQUEST,
  SECTION_CONTENT_RESPONSE,
} from './bridgeProtocol';
import { claimSectionBrief, type SectionBrief } from './pageFill';
import { requestFromParent } from './parentRpc';

// Auto-fills a layout block with AI content right after it's added via the CMS's
// native "Add Layout", and shows Payload's native shimmer over that block's
// fields while it generates. Generation runs platform-side (the sandbox admin
// can't reach it directly), so this bridges a request up to the parent window
// (the platform content tab), which calls the platform and posts the generated
// field values back. The values are then written into the live block here.
//
// This is the ONLY filler. A page generated from an idea (see IdeaPanel) plans
// the sections and appends the rows; each one then arrives here like any other
// newly added block, carrying a brief the panel left in the shared store. A row
// with no brief — every section an editor adds by hand — fills exactly as it
// always has.

// Dispatched on window (detail = whether a fill is in flight) so SaveControls
// can disable Save while a freshly added block is still generating. A newly
// added block's required fields (e.g. Hero -> Heading) start empty, and
// Payload validates the whole form on submit — saving mid-fill would surface a
// spurious "field is invalid" toast for a block the editor never touched.
export const SECTION_FILL_PENDING_EVENT = 'kite:section-fill-pending';

export const SectionAutofill = () => {
  const { addFieldRow, dispatchFields, getDataByPath, setModified } = useForm();
  const rows = useFormFields(([fields]) => fields?.layout?.rows);
  // Block-row ids accounted for (present on load + ones we've filled).
  const seen = useRef<Set<string> | null>(null);
  // In-flight fills, in state so the shimmer renders/clears reactively. `key` is
  // a per-fill id, distinct from the bridge requestId owned by requestFromParent.
  const [pending, setPending] = useState<{ key: string; index: number }[]>([]);

  // Ask the parent for on-brand content for one block, show its shimmer until the
  // reply lands (or the request times out), then write the values in.
  const fillBlock = useCallback(
    async (
      index: number,
      blockType: string,
      def: Block,
      // A planned section's job on the page, claimed by the watcher below. A
      // hand-added one has none, and the keys are then LEFT OUT rather than
      // sent empty — the platform renders the same prompt it always has when
      // they are absent.
      brief: SectionBrief | undefined,
    ) => {
      const key =
        typeof crypto !== 'undefined' && 'randomUUID' in crypto
          ? crypto.randomUUID()
          : `${blockType}-${index}`;
      setPending((p) => [...p, { key, index }]);
      try {
        const brandContext = await fetchBrandContext();

        // The plan chose this section's surface across the whole page, and it
        // is already written into the row, so the field is withheld — offered,
        // the writing model picks its own and the rhythm the plan chose is
        // gone. Only when a background was actually written: a planned `hero`
        // has no such field, and a planned section the plan left unset should
        // still get the same choice a hand-added one gets.
        const withholdBackground = Boolean(brief?.designContext?.background);
        const fieldSchema = serializeFields(
          withholdBackground
            ? def.fields.filter(
                (f) => !('name' in f && f.name === 'background'),
              )
            : def.fields,
        );

        const reply = await requestFromParent(
          SECTION_CONTENT_REQUEST,
          SECTION_CONTENT_RESPONSE,
          {
            blockType,
            fieldSchema,
            brandContext,
            ...(brief
              ? {
                  pageContext: brief.pageContext,
                  designContext: brief.designContext,
                }
              : {}),
          },
          SECTION_FILL_TIMEOUT_MS,
        );

        // `null` = the parent never answered within the window; error/no-values =
        // it failed. Both leave the block empty, so tell the editor rather than
        // just clearing the shimmer — a silent empty fill is indistinguishable
        // from a real one and looks like the generation worked.
        if (!reply || reply.error || !isObject(reply.values)) {
          toast.error(
            'Could not generate section content — edit the fields manually or try again.',
          );
          return;
        }

        for (const [field, value] of Object.entries(reply.values)) {
          writeFields(
            { addFieldRow, dispatchFields },
            value,
            `layout.${index}.${field}`,
            `layout.${blockType}.${field}`,
          );
        }
        // Mark the form dirty so the save-state badge flips to "Unsaved changes"
        // and the editor knows to Save the generated content.
        setModified(true);
      } finally {
        setPending((p) => p.filter((x) => x.key !== key));
      }
    },
    [addFieldRow, dispatchFields, setModified],
  );

  // Detect newly-added blocks and fill them.
  useEffect(() => {
    const ids = (rows ?? [])
      .map((r) => r.id)
      .filter((id): id is string => typeof id === 'string');
    if (seen.current === null) {
      seen.current = new Set(ids);
      return;
    }
    ids.forEach((id) => {
      if (seen.current!.has(id)) return;
      seen.current!.add(id);
      const layout =
        (getDataByPath('layout') as { id?: string; blockType?: string }[]) ??
        [];
      // Resolve the row's true position in the layout array by id. The index in
      // the filtered id list is NOT authoritative — it diverges if any row lacks
      // a string id — and this index is the write target (`layout.<index>`), so a
      // mismatch would fill the wrong block. Bail if the row can't be located.
      const layoutIndex = layout.findIndex((b) => b?.id === id);
      if (layoutIndex < 0) return;
      const blockType = layout[layoutIndex]?.blockType;
      const def = blockType ? BLOCKS_BY_SLUG.get(blockType) : undefined;
      if (!def || !blockType) return;
      // Claimed HERE, synchronously, while the rows are still being walked in
      // page order. Claiming inside the fill would order the briefs by whatever
      // each row's brand lookup returned first, so a page with two sections of
      // the same type could hand one row the other's purpose and outline.
      void fillBlock(
        layoutIndex,
        blockType,
        def,
        claimSectionBrief(id, blockType),
      );
    });
  }, [rows, getDataByPath, fillBlock]);

  // Let SaveControls know whether it's safe to save right now.
  useEffect(() => {
    window.dispatchEvent(
      new CustomEvent(SECTION_FILL_PENDING_EVENT, {
        detail: pending.length > 0,
      }),
    );
  }, [pending.length]);

  if (pending.length === 0) return null;
  return (
    <>
      {pending.map((p) => (
        <RowShimmer key={p.key} index={p.index} />
      ))}
    </>
  );
};
