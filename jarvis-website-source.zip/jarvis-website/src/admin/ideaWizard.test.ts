// Contract for the AI create-page flow:
//   - the editor's choice of the AI flow vs the manual form sticks, and a
//     broken or missing storage falls back to the AI flow instead of throwing;
//   - ideas are suggested on their own only when the site has none yet;
//   - each idea row shows its own page run in the open draft, and the list
//     keeps checking only while a page is being written;
//   - a regenerated idea takes the place of the one it replaces.
//
// Run locally: pnpm exec tsx src/admin/ideaWizard.test.ts

import {
  anyPageBeingWritten,
  styleCheckRunning,
  ideaRowState,
  backToIdeas,
  briefFromIdea,
  withPageOnSite,
  withAddedPageOnMain,
  withMergedPage,
  isPlaced,
  asMainProposal,
  pagesUnder,
  inDraftView,
  editorPathFromIdeas,
  placementFor,
  previewFrameSrc,
  slugFromTitle,
  replaceIdeaInPlace,
  previewPath,
  readWizardMode,
  ideasActionOnOpen,
  roundPollStep,
  shouldAutoSuggest,
  writeWizardMode,
  type PageJob,
} from './ideaWizard';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

function memoryStore() {
  const data = new Map<string, string>();
  return {
    getItem: (key: string) => data.get(key) ?? null,
    setItem: (key: string, value: string) => void data.set(key, value),
  };
}

const brokenStore = {
  getItem: () => {
    throw new Error('blocked');
  },
  setItem: () => {
    throw new Error('blocked');
  },
};

{
  console.log('the AI flow is the default and the choice sticks');
  const store = memoryStore();
  check('nothing saved means the AI flow', readWizardMode(store) === 'ai');
  writeWizardMode(store, 'manual');
  check(
    'switching to the manual form is remembered',
    readWizardMode(store) === 'manual',
  );
  writeWizardMode(store, 'ai');
  check('switching back is remembered', readWizardMode(store) === 'ai');
  check(
    'no storage at all means the AI flow',
    readWizardMode(undefined) === 'ai',
  );
  let threw = false;
  try {
    writeWizardMode(brokenStore, 'manual');
    check(
      'blocked storage reads as the AI flow',
      readWizardMode(brokenStore) === 'ai',
    );
  } catch {
    threw = true;
  }
  check('blocked storage never throws', !threw);
}

{
  console.log('ideas are suggested on open only when the site has none yet');
  const base = {
    mode: 'ai' as const,
    ideasLoaded: true,
    ideas: [] as { source?: string }[],
    alreadyTried: false,
    busy: false,
  };
  check(
    'a site with no ideas gets suggestions on open',
    shouldAutoSuggest(base),
  );
  check(
    'ideas the editor typed do not count as suggestions',
    shouldAutoSuggest({ ...base, ideas: [{ source: 'user' }] }),
  );
  check(
    'a site that already has suggestions shows them instead of paying again',
    !shouldAutoSuggest({ ...base, ideas: [{ source: 'suggested' }] }),
  );
  check(
    'waits for the saved list',
    !shouldAutoSuggest({ ...base, ideasLoaded: false }),
  );
  check(
    'runs once per screen',
    !shouldAutoSuggest({ ...base, alreadyTried: true }),
  );
  check(
    'never on top of another run',
    !shouldAutoSuggest({ ...base, busy: true }),
  );
  check(
    'never on the Manual tab',
    !shouldAutoSuggest({ ...base, mode: 'manual' }),
  );
}

{
  console.log('the AI tab waits for a round the editor already started');
  const opening = {
    mode: 'ai' as const,
    ideasLoaded: true,
    ideas: [] as { source?: string; status?: string }[],
    alreadyTried: false,
    busy: false,
    topLevel: true,
    roundRunning: false,
    waitedOut: false,
  };
  check(
    'no round running and no ideas: suggests, as before',
    ideasActionOnOpen(opening) === 'suggest',
  );
  check(
    'a round running: waits instead of paying for a second one',
    ideasActionOnOpen({ ...opening, roundRunning: true }) === 'wait',
  );
  check(
    'waits even when only written ideas are listed, so the new ones appear',
    ideasActionOnOpen({
      ...opening,
      roundRunning: true,
      ideas: [{ source: 'suggested', status: 'used' }],
    }) === 'wait',
  );
  check(
    'unwritten ideas to pick from: shows them rather than a spinner',
    ideasActionOnOpen({
      ...opening,
      roundRunning: true,
      ideas: [{ source: 'suggested', status: 'new' }],
    }) === 'none',
  );
  check(
    'the round finished with ideas: shows them, no second run',
    ideasActionOnOpen({
      ...opening,
      ideas: [{ source: 'suggested', status: 'new' }],
    }) === 'none',
  );
  check(
    'a wait that ended without ideas: no paid round of its own, the retry is the editor’s',
    ideasActionOnOpen({ ...opening, roundRunning: true, waitedOut: true }) ===
      'none' && ideasActionOnOpen({ ...opening, waitedOut: true }) === 'none',
  );
  check(
    'an idea the editor typed does not stop the wait',
    ideasActionOnOpen({
      ...opening,
      roundRunning: true,
      ideas: [{ source: 'user', status: 'new' }],
    }) === 'wait',
  );
  check(
    'under another page: the top-level round is not this spot’s ideas',
    ideasActionOnOpen({ ...opening, roundRunning: true, topLevel: false }) ===
      'suggest',
  );
  check(
    'nothing before the saved list loads',
    ideasActionOnOpen({
      ...opening,
      roundRunning: true,
      ideasLoaded: false,
    }) === 'none',
  );
  check(
    'nothing while the panel is already waiting or suggesting',
    ideasActionOnOpen({ ...opening, roundRunning: true, busy: true }) ===
      'none',
  );
  check(
    'nothing on the Manual tab',
    ideasActionOnOpen({ ...opening, roundRunning: true, mode: 'manual' }) ===
      'none',
  );
}

{
  console.log('a wait on a round ends in its ideas or a visible retry');
  const cap = 12 * 60_000;
  const ours = 'round-ours';
  const running = {
    suggesting: true,
    round: { id: ours, status: 'running', error: null },
  };
  // Drives the panel's poll through the platform's answers, as it sees them.
  function drive(
    replies: Parameters<typeof roundPollStep>[0][],
    stepMs: number,
    roundId: string | null = ours,
  ) {
    let waited = 0;
    for (const reply of replies) {
      waited += stepMs;
      const step = roundPollStep(reply, roundId, waited, cap);
      if (step.kind !== 'wait') return step;
    }
    return { kind: 'wait' as const };
  }
  check(
    'a round that finishes: its ideas, and no second round',
    drive(
      [
        running,
        running,
        {
          suggesting: false,
          round: { id: ours, status: 'succeeded', error: null },
        },
      ],
      2_500,
    ).kind === 'done',
  );
  const failed = drive(
    [
      running,
      {
        suggesting: false,
        round: { id: ours, status: 'failed', error: 'model down' },
      },
    ],
    2_500,
  );
  check(
    'a round that failed: the failure, with its reason, not an empty list',
    failed.kind === 'failed' && failed.error === 'model down',
  );
  check(
    'another round succeeding does not end the wait on ours',
    drive(
      [
        {
          suggesting: false,
          round: { id: 'round-agent', status: 'succeeded', error: null },
        },
      ],
      2_500,
    ).kind === 'wait',
  );
  check(
    'another round failing does not turn ours into a failure',
    drive(
      [
        {
          suggesting: false,
          round: { id: 'round-agent', status: 'failed', error: 'agent down' },
        },
        {
          suggesting: false,
          round: { id: ours, status: 'succeeded', error: null },
        },
      ],
      2_500,
    ).kind === 'done',
  );
  const stopped = drive(
    [
      running,
      {
        suggesting: false,
        round: {
          id: ours,
          status: 'failed',
          error: 'This round of ideas stopped without finishing.',
        },
      },
    ],
    5 * 60_000,
  );
  check(
    'a round whose worker died: reported failed once the platform lets it go',
    stopped.kind === 'failed',
  );
  check(
    'still running past the cap: a retry, not a spinner without end',
    drive([running, running, running], cap / 2).kind === 'failed',
  );
  check(
    'no answer from the platform: a retry, not "still running"',
    roundPollStep(null, ours, 2_500, cap).kind === 'failed',
  );
  check(
    'an older platform that reports no round: its flag is the answer',
    roundPollStep({ suggesting: true }, null, 2_500, cap).kind === 'wait' &&
      roundPollStep({ suggesting: false }, null, 2_500, cap).kind === 'done',
  );
}

{
  console.log('the preview frame loads the route the page renders at');
  check('home is the site root', previewPath('home') === '/');
  check('any other page is its slug', previewPath('catering') === '/catering');
}

function job(overrides: Partial<PageJob>): PageJob {
  return {
    id: 'job-1',
    idea_id: 'idea-1',
    status: 'generating',
    stalled: false,
    write_attempted: false,
    slug: null,
    page_id: null,
    error: null,
    ...overrides,
  };
}

{
  console.log('each idea row shows its own page run in this draft');
  const idea = { id: 'idea-1', status: 'new' };
  check(
    'an idea nobody started is idle',
    ideaRowState(idea, []).kind === 'idle',
  );
  check(
    "another idea's run does not move this row",
    ideaRowState(idea, [job({ idea_id: 'idea-2' })]).kind === 'idle',
  );
  check(
    'a running page is being written',
    ideaRowState(idea, [job({})]).kind === 'writing',
  );
  const created = ideaRowState(idea, [
    job({ status: 'created', slug: 'catering', page_id: 'p-7' }),
  ]);
  check(
    'a written page can be previewed at its slug',
    created.kind === 'created' &&
      created.slug === 'catering' &&
      created.pageId === 'p-7',
  );
  check(
    'the newest run decides when an idea was started twice',
    ideaRowState(idea, [
      job({ id: 'new', status: 'generating' }),
      job({ id: 'old', status: 'failed' }),
    ]).kind === 'writing',
  );
  const stalled = ideaRowState(idea, [job({ stalled: true })]);
  check(
    'a run whose worker is gone offers to try again',
    stalled.kind === 'failed',
  );
  const uncertain = ideaRowState(idea, [
    job({ status: 'failed', write_attempted: true, error: 'stopped' }),
  ]);
  check(
    'a run that stopped after sending the page says it may have landed',
    uncertain.kind === 'failed' && uncertain.uncertain,
  );
  const refused = ideaRowState(idea, [job({ status: 'failed', error: 'no' })]);
  check(
    'a run that stopped before the write says nothing landed',
    refused.kind === 'failed' && !refused.uncertain && refused.message === 'no',
  );
  check(
    'a page the guided form already made reads as created',
    ideaRowState({ id: 'idea-1', status: 'used', generated_slug: 'menu' }, [])
      .kind === 'created',
  );
}

{
  console.log('a page written on Main shows its move into a draft');
  const idea = { id: 'idea-1', status: 'new' };
  const written = job({
    id: 'gen',
    status: 'created',
    slug: 'catering',
    page_id: 'proposal-1',
  });
  const moving = job({ id: 'add', source_proposal_id: 'proposal-1' });
  check(
    'while it is being moved the row says so',
    ideaRowState(idea, [moving, written]).kind === 'adding',
  );
  const added = ideaRowState(idea, [
    {
      ...moving,
      status: 'created',
      slug: 'catering',
      page_id: 'p-9',
      draft_id: 'draft-2',
    },
    written,
  ]);
  check(
    'once moved, the row names the draft it is in',
    added.kind === 'added' &&
      added.draftId === 'draft-2' &&
      added.pageId === 'p-9' &&
      added.slug === 'catering',
  );
  const onSite = ideaRowState(idea, [
    { ...moving, status: 'created', slug: 'catering', page_id: 'p-9' },
    written,
  ]);
  check(
    'added with no draft, it is a page on the site',
    onSite.kind === 'live' &&
      onSite.pageId === 'p-9' &&
      onSite.slug === 'catering',
  );
  const onMain = [
    { id: 'p-9', title: 'Catering', slug: 'catering', proposed: false },
  ];
  check(
    'while Main still has that page it stays on the site',
    withAddedPageOnMain(onSite, onMain).kind === 'live' &&
      withAddedPageOnMain(onSite, null).kind === 'live',
  );
  check(
    'deleted from Main, its idea can be written again',
    withAddedPageOnMain(onSite, []).kind === 'idle' &&
      withAddedPageOnMain(onSite, [{ ...onMain[0], proposed: true }]).kind ===
        'idle',
  );
  const refused = ideaRowState(idea, [
    { ...moving, status: 'failed', error: 'That draft is closed.' },
    written,
  ]);
  check(
    'a failed move leaves the written page to add again, with the reason',
    refused.kind === 'created' &&
      refused.proposed === true &&
      refused.pageId === 'proposal-1' &&
      refused.moveError === 'That draft is closed.',
  );
}

{
  console.log('a page taken back out of its draft waits on Main again');
  const idea = { id: 'idea-1', status: 'new' };
  const written = job({
    id: 'gen',
    status: 'created',
    slug: 'catering',
    page_id: 'proposal-1',
  });
  const added = job({
    id: 'add',
    status: 'created',
    slug: 'catering',
    page_id: 'p-9',
    draft_id: 'draft-2',
    source_proposal_id: 'proposal-1',
  });
  const back = job({ id: 'back', source_draft_page_id: 'p-9' });
  check(
    'while it is being moved back the row says so',
    ideaRowState(idea, [back, added, written]).kind === 'removing',
  );
  const returned = ideaRowState(idea, [
    { ...back, status: 'created', slug: 'catering', page_id: 'proposal-7' },
    added,
    written,
  ]);
  check(
    'once back, it is a page not added yet, under its new proposal id',
    returned.kind === 'created' &&
      returned.proposed === true &&
      returned.pageId === 'proposal-7',
  );
  const stuck = ideaRowState(idea, [
    { ...back, status: 'failed', error: 'Slug taken.' },
    added,
    written,
  ]);
  check(
    'a failed move back leaves it in the draft, with the reason',
    stuck.kind === 'added' && stuck.moveError === 'Slug taken.',
  );
}

{
  console.log('the list keeps checking only while a page is being written');
  check(
    'nothing running, nothing to poll',
    !anyPageBeingWritten([job({ status: 'created' })]),
  );
  check('a running page keeps polling', anyPageBeingWritten([job({})]));
  check(
    'a stalled run does not poll forever',
    !anyPageBeingWritten([job({ stalled: true })]),
  );
}

{
  console.log("a written page's style check keeps the preview current");
  const now = Date.parse('2026-10-09T12:00:00Z');
  const written = (
    styleFix: string | null,
    updatedAt = '2026-10-09T11:50:00Z',
  ) =>
    job({
      status: 'created',
      slug: 'blog/how-to-measure',
      style_fix: styleFix,
      updated_at: updatedAt,
    });
  check(
    'a page whose text is still being styled keeps polling',
    anyPageBeingWritten([written('pending')], now) &&
      styleCheckRunning(written('pending'), now),
  );
  check(
    'a settled check stops polling',
    !anyPageBeingWritten([written('applied')], now) &&
      !anyPageBeingWritten([written('styled')], now) &&
      !anyPageBeingWritten([written('failed')], now) &&
      !anyPageBeingWritten([written('unchecked')], now),
  );
  check(
    'a check whose worker died does not poll forever',
    !styleCheckRunning(written('pending', '2026-10-09T11:00:00Z'), now),
  );
  const stale = ideaRowState({ id: 'idea-1', status: 'used' }, [
    written('pending', '2020-01-01T00:00:00Z'),
  ]);
  check(
    'and its row shows no endless progress note',
    stale.kind === 'created' && stale.styleFix === null,
    JSON.stringify(stale),
  );
  const row = ideaRowState({ id: 'idea-1', status: 'used' }, [
    written('applied'),
  ]);
  check(
    "the row carries the check's outcome for the preview to show",
    row.kind === 'created' && row.styleFix === 'applied',
    JSON.stringify(row),
  );
  const noted = ideaRowState({ id: 'idea-1', status: 'used' }, [
    {
      ...written('styled'),
      withheld: [
        'Kite left out a claim your site does not back up: "A service costs £49" (hero section).',
      ],
    },
  ]);
  check(
    'the row carries what the run left out or changed, for the preview to list',
    noted.kind === 'created' &&
      noted.notes?.length === 1 &&
      noted.notes[0].includes('£49'),
    JSON.stringify(noted),
  );
  check(
    'and a run that reported nothing carries no notes',
    row.kind === 'created' && row.notes?.length === 0,
    JSON.stringify(row),
  );
}

{
  console.log('a regenerated idea takes the place of the one it replaces');
  const a = { id: 'a' };
  const b = { id: 'b' };
  const c = { id: 'c' };
  const fresh = { id: 'z' };
  const after = replaceIdeaInPlace([a, b, c], 'b', [fresh, a, c]);
  check(
    'the new idea sits where the old one was',
    after.map((idea) => idea.id).join(',') === 'a,z,c',
  );
  const nothingNew = replaceIdeaInPlace([a, b, c], 'b', [a, c]);
  check(
    'with no new idea the old one just goes',
    nothingNew.map((idea) => idea.id).join(',') === 'a,c',
  );
}

{
  console.log('a page is written into the spot chosen above');
  const child = placementFor('menu-visit');
  check(
    'a page under another page goes there and stays out of the menu',
    child.parentSlug === 'menu-visit' &&
      !child.addToMenu &&
      child.submenuOf === null,
  );
  check(
    'the empty spot is the top level',
    placementFor('').parentSlug === null,
  );
  const chosen = placementFor('', {
    slug: ' Office Catering! ',
    purpose: '  Sell office lunches ',
    tone: 'Friendly',
  });
  check(
    "the editor's address, brief and tone go with it, tidied",
    chosen.slug === 'office-catering' &&
      chosen.purpose === 'Sell office lunches' &&
      chosen.tone === 'Friendly',
  );
  check(
    'blank choices are left to Kite',
    placementFor('', { slug: '  ', purpose: '', tone: '' }).slug === null &&
      placementFor('', { purpose: ' ' }).purpose === null,
  );
}

{
  console.log('what the editor types becomes an idea and an address');
  check(
    'a title becomes its address',
    slugFromTitle('Catering & Events') === 'catering-events',
  );
  check(
    'any script keeps its letters',
    slugFromTitle('Кейтеринг') === 'кейтеринг',
  );
  check(
    'a picked idea fills the brief with its questions',
    briefFromIdea({
      title: 'Catering',
      target_questions: ['What can you cater?'],
    }) === 'Catering. Answer: What can you cater?',
  );
  check(
    'an idea with no questions is just its title',
    briefFromIdea({ title: 'Our Story' }) === 'Our Story',
  );
}

{
  console.log('an editor opened from the AI tab goes back to it');
  const list = '/admin/collections/pages';
  const editor = editorPathFromIdeas(list, '7', 'idea-1');
  check(
    'the editor carries where it came from',
    editor === '/admin/collections/pages/7?from=ideas&idea=idea-1',
  );
  const search = new URLSearchParams(editor.split('?')[1]);
  check(
    'its back arrow returns to that idea',
    backToIdeas(search, list) === '/admin/collections/pages/create?idea=idea-1',
  );
  check(
    'an editor reached any other way keeps its list',
    backToIdeas(new URLSearchParams(''), list) === null,
  );
}

{
  console.log('a page added to a draft that was since merged reads as live');
  const added = {
    kind: 'added' as const,
    slug: 'your-first-class',
    draftId: 'merged-draft',
    pageId: '5',
    draftStatus: 'applied',
  };
  const mainPages = [
    {
      id: '9',
      slug: 'your-first-class',
      title: 'Your first class',
      proposed: false,
    },
  ];
  const now = withMergedPage(added, mainPages);
  check(
    'it is live on Main, with the page Main has',
    now.kind === 'live' &&
      now.slug === 'your-first-class' &&
      now.pageId === '9',
  );
  check(
    'it is live before Main\u2019s pages have loaded too',
    withMergedPage(added, null).kind === 'live',
  );
  const open = { ...added, draftStatus: 'created' };
  check(
    'a page in a draft still open stays added, even with a Main page at its address',
    withMergedPage(open, mainPages) === open,
  );
  check(
    'with no status from the platform it stays added',
    withMergedPage({ ...added, draftStatus: null }, mainPages).kind === 'added',
  );
  for (const status of ['reverted', 'abandoned']) {
    check(
      `a draft ${status} without merging leaves the idea unwritten`,
      ideaRowState({ id: 'i9' }, [
        job({
          id: 'add',
          idea_id: 'i9',
          status: 'created',
          slug: 'your-first-class',
          page_id: '5',
          draft_id: 'gone',
          source_proposal_id: 'p1',
          draft_status: status,
        }),
      ]).kind === 'idle',
    );
  }
}

{
  console.log('only ideas whose page is not placed yet stay in the list');
  check(
    'a page in a draft or live on the site is placed',
    isPlaced({ kind: 'added', slug: 'a', draftId: 'd', pageId: '1' }) &&
      isPlaced({ kind: 'live', slug: 'a', pageId: '1' }) &&
      isPlaced({ kind: 'created', slug: 'a', pageId: '1', proposed: false }),
  );
  check(
    'a new, written-but-not-added, moving or failed idea is not',
    !isPlaced({ kind: 'idle' }) &&
      !isPlaced({ kind: 'writing' }) &&
      !isPlaced({ kind: 'adding' }) &&
      !isPlaced({ kind: 'removing' }) &&
      !isPlaced({ kind: 'created', slug: 'a', pageId: '1', proposed: true }) &&
      !isPlaced({ kind: 'failed', message: null, uncertain: false }),
  );
  check(
    'a written page stays until the site says where it is',
    !isPlaced({ kind: 'created', slug: 'a', pageId: '1' }),
  );
}

{
  console.log('a written idea follows the page the draft really has');
  const written = { kind: 'created' as const, slug: 'catering', pageId: '7' };
  const pages = [
    { id: '7', slug: 'menu-visit/catering', title: 'Catering', proposed: true },
  ];
  const now = withPageOnSite(written, pages);
  check(
    "it reads the page's current address and that it is still proposed",
    now.kind === 'created' &&
      now.slug === 'menu-visit/catering' &&
      now.proposed === true,
  );
  check(
    'a discarded page leaves the idea unwritten',
    withPageOnSite(written, []).kind === 'idle',
  );
  check(
    'before the pages load nothing changes',
    withPageOnSite(written, null) === written,
  );
  check(
    'an idea known only by its address still finds its page',
    withPageOnSite(
      { kind: 'created', slug: 'menu-visit/catering', pageId: null },
      pages,
    ).kind === 'created',
  );
}

{
  console.log('the preview loads the page through the preview route');
  check(
    'a written page loads under the preview route',
    previewFrameSrc('menu-visit/catering') ===
      '/admin/kite-proposal/menu-visit/catering',
  );
  check(
    'the home page keeps its slug there',
    previewFrameSrc('home') === '/admin/kite-proposal/home' &&
      previewFrameSrc('') === '/admin/kite-proposal/home',
  );
}

{
  console.log(
    '\non Main a written page is a proposal, so it offers Add, never Remove',
  );
  // Before the pages read loads, a fresh run on Main reports a plain written
  // page whose id is a `page-proposals` id. Read as "in the draft", the row
  // offered Remove, which PATCHed the live page with that same number.
  const fresh = { kind: 'created' as const, slug: 'catering', pageId: '7' };
  const main = asMainProposal(fresh);
  check(
    'a written row with no pages read yet is a proposal',
    main.kind === 'created' && main.proposed === true,
  );
  check('so it is not counted as placed', !isPlaced(main));
  check(
    'a page the pages read called live still waits on Main',
    (() => {
      const read = asMainProposal({ ...fresh, proposed: false });
      return read.kind === 'created' && read.proposed === true;
    })(),
  );
  const added = {
    kind: 'added' as const,
    slug: 'catering',
    draftId: 'd1',
    pageId: '3',
  };
  check(
    'a page moved into a draft is left as added',
    asMainProposal(added) === added,
  );
}

{
  console.log(
    '\nin a draft, a page moved back to Main is not matched by its proposal id',
  );
  // The return run's page id is a `page-proposals` id on Main. Draft pages
  // are numbered on their own, so the same number can name another page.
  const idea = { id: 'i1' };
  const returned = ideaRowState(idea, [
    job({
      id: 'back',
      idea_id: 'i1',
      status: 'created',
      slug: 'catering',
      page_id: '4',
      source_draft_page_id: '9',
    }),
  ]);
  const unrelated = {
    id: '4',
    slug: 'gift-cards',
    title: 'Gift cards',
    proposed: false,
  };
  const inDraft = withPageOnSite(inDraftView(returned), [unrelated]);
  check(
    'the unrelated draft page with that number is not taken for it',
    inDraft.kind === 'idle',
  );
  check(
    'so no action on the row can name that page',
    !(inDraft.kind === 'created' && inDraft.pageId === '4'),
  );
  check(
    'on Main the same row still names its proposal',
    returned.kind === 'created' && returned.pageId === '4',
  );
}

{
  console.log('\na page with pages under it is found by their addresses');
  const pages = [
    { id: '1', slug: 'catering' },
    { id: '2', slug: 'catering/office-lunches' },
    { id: '3', slug: 'catering-menu' },
    { id: '4', slug: 'catering/office-lunches/vegan' },
  ];
  check(
    'its children and their children, not a sibling sharing the prefix',
    pagesUnder('catering', pages)
      .map((page) => page.id)
      .join(',') === '2,4',
  );
  check(
    'a page with none has none',
    pagesUnder('catering-menu', pages).length === 0,
  );
}

if (failures > 0) {
  console.error(`\n${failures} failure(s)`);
  process.exit(1);
}
console.log('\nall checks passed');
