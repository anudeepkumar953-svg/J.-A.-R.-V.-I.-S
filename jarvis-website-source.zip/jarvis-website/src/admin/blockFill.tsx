'use client';

import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import type { Block, Field } from 'payload';
import { Skeleton } from '@appsmithorg/kite-ui/components/skeleton';
import { layoutBlocks } from '@/payload/blocks';

// Everything two fillers need to put generated content into the Pages form:
// SectionAutofill (one block, added by hand) and IdeaPanel (a whole page, from
// a plan). One copy, so a change to how a block's schema is described or how a
// value is written into the form cannot apply to only one of them.
//
// Deliberately free of `@payloadcms/ui`: `writeFields` takes the two form
// dispatchers as an argument instead of calling `useForm()` itself. That keeps
// the module importable from a plain node script and keeps the form plumbing
// where the components already own it.

// Clear a block's generating shimmer if the parent never replies within this
// window (platform error, content tab navigated away, dropped message).
// Generous because the parent round-trip includes LLM + image generation.
export const SECTION_FILL_TIMEOUT_MS = 60_000;

export type SerializedField = {
  name: string;
  type: string;
  required?: boolean;
  options?: unknown[];
  isImage?: boolean;
  fields?: SerializedField[];
};

export const isObject = (v: unknown): v is Record<string, unknown> =>
  typeof v === 'object' && v !== null && !Array.isArray(v);

function isImageField(field: Field): boolean {
  if (!('name' in field) || field.type !== 'text') return false;
  // `imageUrlField()` tags image fields with `admin.custom.isImage` — the
  // authoritative signal. The `Url`-suffix check is a fallback for any image
  // text field authored without the helper.
  if (field.admin?.custom?.isImage === true) return true;
  return /url$/i.test(field.name);
}

export function serializeFields(fields: Field[]): SerializedField[] {
  const out: SerializedField[] = [];
  for (const field of fields) {
    if (field.type === 'ui' || !('name' in field)) continue;
    const s: SerializedField = { name: field.name, type: field.type };
    if ('required' in field && field.required) s.required = true;
    if ('options' in field && Array.isArray(field.options))
      s.options = field.options;
    if (isImageField(field)) s.isImage = true;
    if (
      (field.type === 'group' || field.type === 'array') &&
      'fields' in field
    ) {
      s.fields = serializeFields(field.fields);
    }
    out.push(s);
  }
  return out;
}

export const BLOCKS_BY_SLUG = new Map(
  (layoutBlocks as Block[]).map((b) => [b.slug, b]),
);

/** Whether this block actually has the named field — `hero` has no background. */
export function blockHasField(def: Block, name: string): boolean {
  return def.fields.some((f) => 'name' in f && f.name === name);
}

// The two form dispatchers `writeFields` needs, as `useForm()` hands them out.
export type FormWriter = {
  addFieldRow: (args: {
    path: string;
    schemaPath: string;
    rowIndex?: number;
    blockType?: string;
  }) => void;
  dispatchFields: (action: {
    type: 'UPDATE';
    path: string;
    value: unknown;
  }) => void;
};

// Write one generated value into the live form, recursing into groups and
// arrays (each array row has to exist before its fields can be addressed).
export function writeFields(
  form: FormWriter,
  value: unknown,
  dataPath: string,
  schemaPath: string,
): void {
  if (Array.isArray(value)) {
    value.forEach((_, i) =>
      form.addFieldRow({ path: dataPath, schemaPath, rowIndex: i }),
    );
    value.forEach((row, i) => {
      if (isObject(row)) {
        for (const [k, v] of Object.entries(row)) {
          writeFields(form, v, `${dataPath}.${i}.${k}`, `${schemaPath}.${k}`);
        }
      }
    });
    return;
  }
  if (isObject(value) && !('root' in value)) {
    for (const [k, v] of Object.entries(value)) {
      writeFields(form, v, `${dataPath}.${k}`, `${schemaPath}.${k}`);
    }
    return;
  }
  form.dispatchFields({ type: 'UPDATE', path: dataPath, value });
}

// The site's own brand settings, which steer every generated word. Its absence
// is non-fatal: generation falls back to whatever the platform knows.
export async function fetchBrandContext(): Promise<Record<string, unknown>> {
  try {
    const res = await fetch('/cms-api/globals/site-settings?depth=0');
    const data = res.ok ? await res.json() : null;
    return isObject(data) ? data : {};
  } catch {
    return {};
  }
}

// Overlays the design system's loading skeleton over the generating block's
// fields, so a section being written by the agent looks the same as any other
// pending surface in the product. Each block row is `#layout-row-${index}`
// (Payload BlockRow); we cover its `.collapsible__content` so the row's header
// stays visible.
export function RowShimmer({ index }: { index: number }) {
  const [host, setHost] = useState<HTMLElement | null>(null);
  useEffect(() => {
    const row = document.getElementById(`layout-row-${index}`);
    if (!row) return;
    const content =
      row.querySelector<HTMLElement>('.collapsible__content') ?? row;
    setHost(content);
    const prevPosition = content.style.position;
    const prevMinHeight = content.style.minHeight;
    if (!prevPosition || prevPosition === 'static')
      content.style.position = 'relative';
    content.style.minHeight = '220px';
    return () => {
      content.style.position = prevPosition;
      content.style.minHeight = prevMinHeight;
    };
  }, [index]);

  if (!host) return null;
  return createPortal(
    <div className="bg-bg absolute inset-0 z-5 flex flex-col gap-3.5 py-1">
      <Skeleton className="h-9 w-2/5" />
      <Skeleton className="h-9" />
      <Skeleton className="h-9 w-3/4" />
      <Skeleton className="h-[150px]" />
    </div>,
    host,
  );
}
