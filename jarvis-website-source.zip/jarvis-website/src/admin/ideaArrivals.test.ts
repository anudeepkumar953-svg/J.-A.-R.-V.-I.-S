// Contract for ideas arriving while a suggestion run is still going:
//   - each read adds only the ideas the panel has not shown this run, so a
//     card the editor removed mid-run never comes back from a read that was
//     already on its way;
//   - the list keeps the platform's newest-first order, which puts a run's
//     ideas in the model's own order above everything stored before it, even
//     when they land one read at a time;
//   - while a run goes, the first idea it produces is the one picked, never
//     an older one; once it is over, the first fresh idea of the spot is.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml). Exits non-zero on
// any failure.
//
// Run locally: pnpm exec tsx src/admin/ideaArrivals.test.ts

import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  SUGGESTING_COPY,
  firstFreshIdea,
  mergeArrivals,
  newArrivals,
  newRunId,
  producedByRun,
  dismissalSaved,
  emptyIdeaList,
  ideaListStep,
  recheckDelay,
  RECHECK_DELAYS_MS,
  type IdeaListEvent,
  type IdeaListState,
  autoPick,
  endOfPass,
  suggestingLabel,
  type ArrivingIdea,
} from './ideaArrivals';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

type Idea = ArrivingIdea & { title: string; source?: 'user' | 'suggested' };

// A run that started at 12:00:10.500 stamps its ideas one millisecond apart,
// the model's first choice newest.
const RUN = Date.parse('2026-10-07T12:00:10.500Z');
function runIdea(rank: number, title: string): Idea {
  return {
    id: `run-${rank}`,
    title,
    created_at: new Date(RUN - rank).toISOString(),
  };
}
const older: Idea = {
  id: 'old-1',
  title: 'Typed last week',
  created_at: '2026-09-30T09:00:00.000Z',
};

const titles = (ideas: readonly Idea[]) => ideas.map((idea) => idea.title);

// --- One idea per read, in the model's order -------------------------------
{
  console.log('ideas landing one read at a time keep the model order');
  const first = runIdea(0, 'Pricing FAQ');
  const second = runIdea(1, 'Setup guide');
  const third = runIdea(2, 'Security overview');
  const seen = new Set<string>([older.id]);

  let shown: Idea[] = [older];
  for (const listed of [
    [first, older],
    [first, second, older],
    [first, second, third, older],
  ]) {
    const arrived = newArrivals(listed, seen);
    arrived.forEach((idea) => seen.add(idea.id));
    shown = mergeArrivals(shown, arrived);
  }

  check(
    'the run sits above older ideas, best idea first',
    JSON.stringify(titles(shown)) ===
      JSON.stringify([
        'Pricing FAQ',
        'Setup guide',
        'Security overview',
        'Typed last week',
      ]),
    titles(shown).join(', '),
  );
}

// --- A removed card stays removed ------------------------------------------
{
  console.log('a card removed mid-run is not brought back by a late read');
  const first = runIdea(0, 'Pricing FAQ');
  const seen = new Set<string>([older.id]);
  let shown: Idea[] = [older];

  const arrived = newArrivals([first, older], seen);
  arrived.forEach((idea) => seen.add(idea.id));
  shown = mergeArrivals(shown, arrived);
  // The editor removes it; a read sent before that answers afterwards.
  shown = shown.filter((idea) => idea.id !== first.id);
  const late = newArrivals([first, older], seen);
  shown = mergeArrivals(shown, late);

  check('the late read brings nothing new', late.length === 0);
  check(
    'the removed card is still gone',
    !shown.some((idea) => idea.id === first.id),
    titles(shown).join(', '),
  );
}

// --- Merging twice changes nothing -----------------------------------------
{
  console.log('merging is idempotent');
  const first = runIdea(0, 'Pricing FAQ');
  const once = mergeArrivals([older], [first]);
  const twice = mergeArrivals(once, [first]);
  check('no duplicate card', twice.length === 2, titles(twice).join(', '));
  check(
    'nothing to add returns the same list',
    mergeArrivals(once, []) === once,
  );
}

// --- Cards on screen stay where they are ---------------------------------
{
  console.log('an arrival never moves a card already on screen');
  // A replacement keeps the replaced card's slot although it is newer.
  const replacement: Idea = {
    id: 'replacement',
    title: 'Replacement',
    created_at: '2026-10-07T12:30:00.000Z',
  };
  const shown: Idea[] = [runIdea(0, 'Pricing FAQ'), replacement, older];
  const merged = mergeArrivals(shown, [runIdea(1, 'Setup guide')]);
  check(
    'the existing cards keep their order',
    JSON.stringify(
      titles(merged).filter((title) => title !== 'Setup guide'),
    ) === JSON.stringify(titles(shown)),
    titles(merged).join(', '),
  );
  check(
    'the new idea goes before the first older card',
    titles(merged).indexOf('Setup guide') <
      titles(merged).indexOf('Typed last week'),
    titles(merged).join(', '),
  );
}

// --- Only this pass's own ideas count as its arrivals ---------------------
{
  console.log("ideas from another run or typed mid-run are not this run's");
  const mine: Idea = { ...runIdea(1, 'Setup guide'), run_id: 'run-a' };
  const otherRun: Idea = {
    ...runIdea(0, 'Their idea'),
    id: 'theirs',
    run_id: 'run-b',
  };
  const typed: Idea = { ...runIdea(0, 'Typed now'), id: 'typed', run_id: null };
  check(
    'only the idea stamped with this run counts',
    JSON.stringify(titles(producedByRun([otherRun, typed, mine], 'run-a'))) ===
      JSON.stringify(['Setup guide']),
  );
  // Stored by this run, then typed by an editor before the panel read it.
  const takenOver: Idea = {
    ...runIdea(2, 'Pricing FAQ'),
    id: 'taken-over',
    run_id: 'run-a',
    source: 'user',
  };
  check(
    "an idea an editor typed over is no longer the run's",
    producedByRun([takenOver, mine], 'run-a').every(
      (idea) => idea.id !== takenOver.id,
    ),
  );
  check(
    "with another run first in the list, the pick is still this run's",
    firstFreshIdea(
      [otherRun, mine],
      '',
      new Set(producedByRun([otherRun, mine], 'run-a').map((idea) => idea.id)),
    )?.id === mine.id,
  );
}

// --- Run ids ---------------------------------------------------------------
{
  console.log('a run id is a UUID the platform accepts');
  const pattern =
    /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/;
  check('looks like a v4 UUID', pattern.test(newRunId()));
  check('two passes get two ids', newRunId() !== newRunId());
}

// --- What is picked --------------------------------------------------------
{
  console.log('the first idea of the run is picked, not an older one');
  const first = runIdea(0, 'Pricing FAQ');
  const freshOld: Idea = { ...older, id: 'old-fresh', title: 'Older idea' };

  check(
    'before the run has produced anything, nothing is picked',
    firstFreshIdea([freshOld], '', new Set()) === undefined,
  );
  check(
    'once the first idea lands, it is the pick',
    firstFreshIdea([first, freshOld], '', new Set([first.id]))?.id === first.id,
  );
  check(
    'with no run going, the first fresh idea of the spot is picked',
    firstFreshIdea([freshOld], '')?.id === freshOld.id,
  );
  const usedFirst: Idea = { ...first, status: 'used' };
  const second = runIdea(1, 'Setup guide');
  check(
    'an idea that already produced a page is skipped',
    firstFreshIdea([usedFirst, second], '', new Set([first.id, second.id]))
      ?.id === second.id,
  );
  const elsewhere: Idea = { ...runIdea(3, 'Catering'), parent_slug: 'menu' };
  check(
    'an idea for another spot is not picked',
    firstFreshIdea([elsewhere], '', new Set([elsewhere.id])) === undefined,
  );
}

// --- Joining a running round picks that round's first idea ----------------
{
  console.log('joining a running round picks its first idea, not an older one');
  const typedEarlier: Idea = {
    id: 'typed-earlier',
    title: 'Typed earlier',
    source: 'user',
    created_at: '2026-10-01T09:00:00.000Z',
  };
  const roundFirst = {
    ...runIdea(0, 'Pricing FAQ'),
    run_id: 'round-1',
    source: 'suggested',
  } as Idea;

  // The suggest pass is answered "joined": it goes straight into the wait.
  const end = endOfPass(true);
  check('a joined pass keeps looking for ideas', end.stopLooking === false);
  check('a joined pass waits on the round', end.waitOnRound === true);

  // Before the round's first idea lands, only the older typed idea is listed.
  const before = autoPick({
    pending: true,
    lookingForIdeas: !end.stopLooking,
    selectedId: null,
    ideas: [typedEarlier],
    spot: '',
    arrivals: new Set(),
  });
  check('nothing is picked before the round produces', before.pick === null);
  check('a pick is still owed', before.pending === true);

  // The round's first idea lands.
  const landed = autoPick({
    pending: before.pending,
    lookingForIdeas: true,
    selectedId: null,
    ideas: [roundFirst, typedEarlier],
    spot: '',
    arrivals: new Set(
      producedByRun([roundFirst, typedEarlier], 'round-1').map((i) => i.id),
    ),
  });
  check("the round's first idea is picked", landed.pick?.id === roundFirst.id);

  // Had the pass ended first, that moment would have picked the older idea.
  const gap = autoPick({
    pending: true,
    lookingForIdeas: false,
    selectedId: null,
    ideas: [typedEarlier],
    spot: '',
    arrivals: null,
  });
  check(
    'a moment with nothing looking would pick the older idea',
    gap.pick?.id === typedEarlier.id,
  );
  check(
    'a pass that was not joined stops looking',
    endOfPass(false).stopLooking,
  );
}

// --- The panel's ideas: one rule for removals and reads -------------------
{
  console.log("a dismissal's own answer decides it; reads only add or update");
  type S = IdeaListState<Idea>;
  const step = (state: S, ...events: IdeaListEvent<Idea>[]) =>
    events.reduce(ideaListStep, state);
  const ids = (state: S) => state.shown.map((idea) => idea.id);
  const card: Idea = { ...runIdea(0, 'Pricing FAQ'), status: 'new' };
  const other = runIdea(1, 'Setup guide');
  const start = step(emptyIdeaList<Idea>(), {
    type: 'listReadOk',
    ideas: [card, other, older],
    full: true,
    readFrom: 0,
  });
  // A read sent after everything here: newer than any card on screen.
  const NOW = Number.MAX_SAFE_INTEGER;
  // What a read of new arrivals can say about the card afterwards.
  const reads: [string, IdeaListEvent<Idea>][] = [
    [
      'a read still listing it',
      { type: 'listReadOk', ideas: [card, other, older], full: false },
    ],
    [
      'a read without it',
      { type: 'listReadOk', ideas: [other, older], full: false },
    ],
    ['an empty read', { type: 'listReadOk', ideas: [], full: false }],
    [
      'a whole list still listing it',
      {
        type: 'listReadOk',
        ideas: [card, other, older],
        full: true,
        readFrom: NOW,
      },
    ],
    ['a failed read', { type: 'listReadFailed' }],
  ];

  check(
    'a first read shows the list',
    ids(start).join() === [card, other, older].map((i) => i.id).join(),
  );

  for (const hidden of [true, false]) {
    const path = hidden ? 'dismiss' : 'replace';
    const requested = step(start, {
      type: 'removalRequested',
      idea: card,
      hidden,
    });
    check(
      `${path}: requested, the card is ${hidden ? 'off screen' : 'still on screen'}`,
      ids(requested).includes(card.id) === !hidden,
    );
    // Reads while the platform decides.
    for (const [label, read] of reads) {
      const during = step(requested, read);
      check(
        `${path}: ${label} while deciding does not bring a hidden card back`,
        !hidden
          ? ids(during).includes(card.id)
          : !ids(during).includes(card.id),
      );
    }

    // Saved, then any read: out for good.
    for (const [label, read] of [['no read', null], ...reads] as const) {
      let after = step(requested, { type: 'removalConfirmed', id: card.id });
      if (read) after = step(after, read);
      if (!hidden)
        after = step(after, { type: 'replacementFailed', id: card.id });
      check(
        `${path}: saved, then ${label}: the card is gone`,
        !ids(after).includes(card.id),
        ids(after).join(),
      );
      check(
        `${path}: saved, then ${label}: the others stay`,
        ids(after).includes(other.id),
      );
    }

    // Saved, and a replacement takes its slot: the new idea, never the old.
    {
      const fresh: Idea = { ...runIdea(5, 'Fresh idea'), id: 'fresh' };
      const after = step(
        requested,
        { type: 'removalConfirmed', id: card.id },
        {
          type: 'replaced',
          id: card.id,
          ideas: [fresh, card, other, older],
          readFrom: requested.version,
        },
      );
      check(
        `${path}: replaced, the new idea takes the slot and the old never returns`,
        !ids(after).includes(card.id) && ids(after).includes('fresh'),
        ids(after).join(),
      );
    }

    // Not saved (no answer, an error, a throw): back at once, from the
    // panel's own copy, whatever any read after says.
    for (const [label, read] of [['no read', null], ...reads] as const) {
      let after = step(requested, { type: 'removalFailed', id: card.id });
      check(
        `${path}: not saved: the card is back at once`,
        ids(after).includes(card.id),
      );
      if (read) after = step(after, read);
      check(
        `${path}: not saved, then ${label}: the card is still shown`,
        ids(after).includes(card.id),
        ids(after).join(),
      );
    }
  }

  // A failed read changes nothing; a read of new arrivals never removes.
  check(
    'a failed read leaves the state as it was',
    ideaListStep(start, { type: 'listReadFailed' }) === start,
  );
  check(
    'a read of new arrivals without an idea does not remove it',
    ids(step(start, { type: 'listReadOk', ideas: [], full: false })).join() ===
      ids(start).join(),
  );
  const renamed: Idea = { ...other, title: 'Setup guide, renamed' };
  check(
    'a read updates an idea in place',
    step(start, { type: 'listReadOk', ideas: [renamed], full: false }).shown[1]
      .title === renamed.title,
  );

  // The whole list holds every idea not dismissed: one it leaves out is gone.
  check(
    'a whole list without a card drops it (dismissed in another session)',
    ids(
      step(start, {
        type: 'listReadOk',
        ideas: [other, older],
        full: true,
        readFrom: NOW,
      }),
    ).join() === [other, older].map((i) => i.id).join(),
  );
  {
    const replacing = step(start, {
      type: 'removalRequested',
      idea: card,
      hidden: false,
    });
    const whole: IdeaListEvent<Idea> = {
      type: 'listReadOk',
      ideas: [other, older],
      full: true,
      readFrom: NOW,
    };
    check(
      'a whole list keeps a card whose replacement is still deciding',
      ids(step(replacing, whole)).includes(card.id),
    );
    const saved = step(replacing, { type: 'removalConfirmed', id: card.id });
    check(
      'a whole list keeps a saved card until its replacement settles',
      ids(step(saved, whole)).includes(card.id),
    );
    // A replace's answer is the whole list: an unrelated card it leaves out
    // was dismissed in another session.
    {
      const mark = replacing.version;
      const after = step(
        replacing,
        { type: 'removalConfirmed', id: card.id },
        {
          type: 'replaced',
          id: card.id,
          ideas: [{ ...runIdea(6, 'New one'), id: 'new' }, older],
          readFrom: mark,
        },
      );
      check(
        'a replace answer drops an unrelated card it no longer lists',
        ids(after).join() === ['new', older.id].join(),
        ids(after).join(),
      );
    }
    // A round poll that read the list before the replacement was stored, and
    // answers after it: the newer card stays.
    {
      const pollSent = replacing.version;
      const replaced = step(
        replacing,
        { type: 'removalConfirmed', id: card.id },
        {
          type: 'replaced',
          id: card.id,
          ideas: [{ ...runIdea(7, 'Saved later'), id: 'later' }, other, older],
          readFrom: replacing.version,
        },
      );
      const afterPoll = step(replaced, {
        type: 'listReadOk',
        ideas: [other, older],
        full: true,
        readFrom: pollSent,
      });
      check(
        'an older whole list does not remove a replacement saved after it',
        ids(afterPoll).includes('later'),
        ids(afterPoll).join(),
      );
      const freshPoll = step(afterPoll, {
        type: 'listReadOk',
        ideas: [other, older],
        full: true,
        readFrom: NOW,
      });
      check(
        'a whole list sent after the replacement still drops it when absent',
        !ids(freshPoll).includes('later'),
      );
    }
    // A final round poll sent before a dismissal reply added a card, and
    // answering after another editor dismissed that card: it cannot vouch for
    // the card, so the state asks for a fresh read, which then drops it.
    {
      const pollSent = start.version;
      const b: Idea = { ...runIdea(8, 'Added by a reply'), id: 'b' };
      const withB = step(start, {
        type: 'listReadOk',
        ideas: [card, other, older, b],
        full: true,
        readFrom: start.version,
      });
      const afterPoll = step(withB, {
        type: 'listReadOk',
        ideas: [card, other, older],
        full: true,
        readFrom: pollSent,
      });
      check(
        'an older whole list keeps a newer card but marks it unconfirmed',
        ids(afterPoll).includes('b') && afterPoll.unconfirmed,
      );
      const rechecked = step(afterPoll, {
        type: 'listReadOk',
        ideas: [card, other, older],
        full: true,
        readFrom: afterPoll.version,
      });
      check(
        'the fresh read drops the card and clears the mark',
        !ids(rechecked).includes('b') && !rechecked.unconfirmed,
      );
    }
    // Follow-up reads for an unconfirmed list: retried, but a bounded number.
    check(
      'the first follow-up read goes at once, later ones back off',
      recheckDelay(0) === 0 &&
        (recheckDelay(1) ?? 0) > 0 &&
        (recheckDelay(2) ?? 0) > (recheckDelay(1) ?? 0),
    );
    check(
      'follow-up reads stop after the last try',
      recheckDelay(RECHECK_DELAYS_MS.length) === null,
    );
    check(
      'a replace that ends with no replacement takes the saved card off',
      !ids(
        step(saved, whole, { type: 'replacementFailed', id: card.id }),
      ).includes(card.id),
    );
  }

  // The dismissal's own answer.
  check(
    'a saved write with a failed list read is saved',
    dismissalSaved({ dismissed: true }),
  );
  check(
    'a saved write with its list is saved',
    dismissalSaved({ dismissed: true, ideas: [] }),
  );
  check(
    'an older platform answering with the list is saved',
    dismissalSaved({ ideas: [] }),
  );
  check('an error is not saved', !dismissalSaved({ error: true }));
  check('no answer is not saved', !dismissalSaved(null));
}

// --- Every panel path goes through that rule ------------------------------
{
  console.log('every panel path changes ideas through the rule');
  const source = readFileSync(
    join(dirname(fileURLToPath(import.meta.url)), 'IdeaPanel.tsx'),
    'utf8',
  );
  check('nothing sets the ideas directly', !/\bsetIdeas\(/.test(source));
  check(
    'the state is only changed by ideaListStep',
    (source.match(/setIdeaState\(/g) ?? []).length === 1 &&
      /setIdeaState\(\(state\) => \{\s*const next = ideaListStep\(state, event\);/.test(
        source,
      ),
  );
  check(
    'a settled follow-up read always runs the recheck effect again',
    /finally\(\(\) => \{[\s\S]{0,300}setRecheckAttempt\(\(n\) => n \+ 1\)/.test(
      source,
    ) &&
      /\[ideaState\.unconfirmed, ideaState\.version, recheckAttempt/.test(
        source,
      ),
  );
  const wholeLists = source.match(/full: true,?\s*readFrom/g) ?? [];
  check(
    'every whole list the panel applies says when it was asked for',
    wholeLists.length === (source.match(/full: true/g) ?? []).length &&
      wholeLists.length > 0,
  );
  const sends = [...source.matchAll(/op: 'dismiss'/g)].map((m) => m.index ?? 0);
  check('the panel sends dismissals', sends.length === 2, String(sends.length));
  for (const at of sends) {
    const after = source.slice(at, at + 700);
    check(
      `the dismissal at offset ${at} is settled in a finally by its own answer`,
      /finally\s*\{[\s\S]*dismissalSaved\([\s\S]*'removalConfirmed'[\s\S]*'removalFailed'/.test(
        after,
      ),
    );
  }
}

// --- The indicator ---------------------------------------------------------
{
  console.log('the indicator says whether ideas have landed');
  check('none yet', suggestingLabel(0) === SUGGESTING_COPY.first);
  check('some on screen', suggestingLabel(2) === SUGGESTING_COPY.more);
}

if (failures > 0) {
  console.error(`\n${failures} failure(s)`);
  process.exit(1);
}
console.log('\nall checks passed');
