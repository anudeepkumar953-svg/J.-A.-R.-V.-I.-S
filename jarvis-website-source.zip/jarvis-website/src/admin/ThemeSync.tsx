'use client';

import { useEffect } from 'react';
import type { ReactNode } from 'react';
import { useTheme } from '@payloadcms/ui';
import {
  THEME_REQUEST,
  THEME_RESPONSE,
  parseBridgeTheme,
  type BridgeTheme,
} from './bridgeProtocol';
import { isEmbedded, requestFromParent } from './parentRpc';

// Keeps the embedded admin on the platform's appearance (light / dark / system,
// resolved by the platform). The admin is a separate cross-origin document, so
// the platform's own theme attribute never reaches it; this is the client half
// of the handoff, applied through Payload's `setTheme` (which stamps
// `data-theme` on `<html>` — the attribute Payload's stylesheet, kite-ui's
// `light-dark()` tokens and the `dark:` variant in admin-ds.css all key off).
//
// Two arms, both over the bridge in bridgeProtocol.ts:
//   - on mount, ask the parent for its current theme. `/admin-login?theme=`
//     already seeded Payload's cookie so the first paint matches, but a full
//     reload after a switch (stranded-session recovery) would repaint from that
//     stale cookie — the request corrects it.
//   - thereafter, apply any `THEME_RESPONSE` the parent pushes unsolicited: the
//     user switching appearance while the Content tab is open.
const REQUEST_TIMEOUT_MS = 10_000;

export const ThemeSync = ({ children }: { children?: ReactNode }) => {
  const { setTheme } = useTheme();

  useEffect(() => {
    if (typeof window === 'undefined' || !isEmbedded()) return;

    let cancelled = false;
    const apply = (next: BridgeTheme) => {
      if (!cancelled) setTheme(next);
    };

    // Pushed updates. Only the parent may steer the theme; `requestId` is
    // absent on pushes and present on the reply to the request below, which
    // `requestFromParent` consumes itself.
    const onMessage = (event: MessageEvent) => {
      const d = event.data;
      if (
        event.source !== window.parent ||
        !d ||
        typeof d !== 'object' ||
        d.type !== THEME_RESPONSE ||
        'requestId' in d
      )
        return;
      const next = parseBridgeTheme(d.theme);
      if (next) apply(next);
    };
    window.addEventListener('message', onMessage);

    void requestFromParent(
      THEME_REQUEST,
      THEME_RESPONSE,
      {},
      REQUEST_TIMEOUT_MS,
    ).then((reply) => {
      const next = parseBridgeTheme(reply?.theme);
      if (next) apply(next);
    });

    return () => {
      cancelled = true;
      window.removeEventListener('message', onMessage);
    };
  }, [setTheme]);

  return <>{children}</>;
};
