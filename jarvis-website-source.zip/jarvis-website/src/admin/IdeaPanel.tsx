'use client';

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Button } from '@appsmithorg/kite-ui/components/button';
import { Card } from '@appsmithorg/kite-ui/components/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@appsmithorg/kite-ui/components/dialog';
import { Icon } from '@appsmithorg/kite-ui/components/icon';
import { Skeleton } from '@appsmithorg/kite-ui/components/skeleton';
import { Spinner } from '@appsmithorg/kite-ui/components/spinner';
import {
  Tabs,
  TabsList,
  TabsTrigger,
} from '@appsmithorg/kite-ui/components/tabs';
import { Input } from '@appsmithorg/kite-ui/components/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@appsmithorg/kite-ui/components/select';
import { Textarea } from '@appsmithorg/kite-ui/components/textarea';
import { Tooltip } from '@appsmithorg/kite-ui/components/tooltip';
import { useConfig, useDocumentInfo, useDocumentTitle } from '@payloadcms/ui';
import {
  CircleHelpIcon,
  FileTextIcon,
  PlusIcon,
  SparklesIcon,
  SquarePenIcon,
  FolderTreeIcon,
  HouseIcon,
  LockIcon,
  XIcon,
} from 'lucide-react';
import { useRouter, useSearchParams } from 'next/navigation';
import type { Block } from 'payload';
import { layoutBlocks } from '@/payload/blocks';
import { SECTION_FILL_TIMEOUT_MS, fetchBrandContext } from './blockFill';
import {
  OPEN_DRAFT_REQUEST,
  OPEN_DRAFT_RESPONSE,
  PAGE_IDEAS_CONTEXT_REQUEST,
  PAGE_IDEAS_CONTEXT_RESPONSE,
  PAGE_IDEAS_REQUEST,
  PAGE_IDEAS_RESPONSE,
} from './bridgeProtocol';
import { isCreateMode, type PageType } from './pageFill';
import {
  collectExistingPages,
  contentCollectionSlugs,
  designSamplePages,
  pageSummaries,
  refusedForCredits,
} from './ideaPanelFlow';
import {
  IDEA_POLL_INTERVAL_MS,
  IDEA_POLL_TIMEOUT_MS,
  autoPick,
  endOfPass,
  newArrivals,
  newRunId,
  producedByRun,
  dismissalSaved,
  emptyIdeaList,
  ideaListStep,
  recheckDelay,
  type IdeaListEvent,
  type IdeaListState,
  suggestingLabel,
} from './ideaArrivals';
import { requestFromParent } from './parentRpc';
import {
  anyPageBeingWritten,
  briefFromIdea,
  editorPathFromIdeas,
  IDEA_PARAM,
  ideaRowState,
  placementFor,
  previewFrameSrc,
  previewPath,
  PURPOSE_MAX_LENGTH,
  readWizardMode,
  ideasActionOnOpen,
  roundPollStep,
  type RoundReply,
  slugFromTitle,
  TONES,
  writeWizardMode,
  type IdeaRowState,
  type PageJob,
  type PreviewDevice,
  type SitePageRecord,
  type WizardMode,
  isPlaced,
  pagesUnder,
  asMainProposal,
  inDraftView,
  withAddedPageOnMain,
  withMergedPage,
  withPageOnSite,
} from './ideaWizard';
import {
  DeviceToggle,
  IconButton,
  IdeaCard,
  OptionCard,
  IdeaSuggestion,
  PreviewPane,
  StepCard,
  ToneChips,
} from './IdeaWizardParts';

// The create-page screen, split into two tabs the editor can switch between at
// any point.
//
// AI (the default) hides the form and lists page ideas: ones Kite suggested
// for this site and ones the editor typed. Each row's Preview icon has the
// platform write that whole page on a worker, straight into the open draft —
// several can be under way at once — and opens the rendered page once it
// exists. The live site does not change until the draft is merged.
//
// Manual is Payload's own form with nothing from Kite above it; the editor's
// Save creates the page.
//
// The AI tab renders only on the create screen and only when the parent says
// the feature is on for this team. Pages are written only inside a draft — on
// Main a row first opens one and reopens this screen there with that idea.

// Suggesting runs live web research plus two model calls, so it gets a window
// of its own rather than the fill timeout.
const SUGGEST_TIMEOUT_MS = 120_000;
// How often the AI tab reads the list while it waits on a suggestion round,
// and the most it waits. A round takes about 25 s. The platform stops counting
// a dead round after ten minutes and reports it failed, so the cap sits past
// that and only bounds a platform that cannot say.
const ROUND_POLL_MS = 2_500;
const ROUND_WAIT_CAP_MS = 12 * 60_000;
// A sleeping draft sandbox takes about a minute to wake; ask again this often.
const DRAFT_PREVIEW_RETRY_MS = 5_000;
// A draft sandbox that is not up within about five minutes is not coming.
const DRAFT_PREVIEW_MAX_TRIES = 60;
// The idea list scrolls inside itself so Add more under it stays on screen:
// room kept below the list for that button and the card's padding.
const IDEA_LIST_ROOM_BELOW = 104;
const IDEA_LIST_MIN_HEIGHT = 200;

const COPY = {
  suggestMore: 'Add more ideas',
  addMore: 'Add more',
  suggestMoreBlurb:
    'Kite looks for more pages your site could have. Say what they should be about, or leave it empty.',
  suggestMoreLabel: 'What should the new ideas be about? (optional)',
  suggestMorePlaceholder: 'For example: pages for beginners',
  suggestMoreSubmit: 'Suggest ideas',
  ideasEmpty: 'No ideas yet. Type one above.',
  ideasAllPlaced:
    'Every idea here is already in a draft or on your site. Suggest more ideas to get new ones.',
  dismiss: (title: string) => `Remove "${title}"`,
  // Removing the idea never deletes the page it produced.
  dismissWritten: (title: string) =>
    `Remove "${title}" from the list. Its page stays in your draft.`,
  ideasFailed: 'Could not load your saved ideas.',
  suggestFailed: 'Kite could not think of any ideas right now. Try again.',
  retrySuggest: 'Try again',
  draftFailed: 'Could not open a draft. Try again.',
  pageStartFailed: 'Could not start this page. Try again.',
  outOfCredits: 'Your team is out of Kite credits. Add credits to keep going.',
  replaceFailed: 'Kite could not find a new idea right now. Try again.',
  dismissFailed: 'Could not remove that idea. Try again.',
  addPageFailed: 'Could not add the page to your draft. Try again.',
  addPageToSiteFailed: 'Could not add the page to your site. Try again.',
  removePageFailed: 'Could not take the page out of your draft. Try again.',
  removeParentFirst: (count: number) =>
    `${count === 1 ? 'A page sits' : `${count} pages sit`} under this one. Move or remove ${count === 1 ? 'it' : 'them'} first: a draft cannot publish a page whose parent is gone.`,
  discardPageFailed: 'Could not discard the page. Try again.',
} as const;

const WIZARD_COPY = {
  heading: 'Create a new page',
  newPage: 'New page',
  locationTitle: 'Page location',
  addressLabel: 'Page address',
  addressHelp: 'Only the last part can be changed',
  addressClear: 'Clear the address',
  clear: 'Clear',
  addressPlaceholder: 'page-address',
  addressSaved: 'Address changed.',
  addressTaken: 'Another page already uses this address.',
  addressFailed: 'Could not change the address. Try again.',
  detailsTitle: 'Page details',
  ideaDetails: (title: string) => `Details for "${title}"`,
  saveDetails: 'Save',
  purposeLabel: 'Page purpose',
  toneLabel: 'Tone',
  optional: '(optional)',
  customTone: 'Custom',
  customToneLabel: 'Your own tone',
  customTonePlaceholder: 'For example: warm, plain, no jargon',
  ideasTitle: 'Start with an idea',
  rewriteTitle: 'Rewrite this page?',
  generateIdea: (title: string) => `Generate the "${title}" page`,
  retryIdea: (title: string) => `Try the "${title}" page again`,
  rewriteIdea: (title: string) => `Rewrite the "${title}" page`,
  previewNothingPicked: 'Pick an idea, then generate it to see the page here.',
  suggestionType: {
    solution: 'Solution page',
    guide: 'Guide',
    howto: 'How-to',
    comparison: 'Comparison',
    faq: 'Questions and answers',
    custom: 'Page',
  } as Record<string, string>,
  suggestionWhy: 'Why this page',
  suggestionQuestions: 'Questions it answers',
  suggestionRelated: 'Related pages',
  suggestionEvidence: 'Based on',
  suggestionGenerate: 'Generate page',
  writingBlurb:
    'This takes about a minute. You can start another idea meanwhile.',
  devices: { desktop: 'Desktop', mobile: 'Mobile' },
  mainBlurb:
    'Kite creates new pages inside a draft, so your live site stays as it is until you merge.',
  ideaPlaceholder:
    'For example: a page answering pricing questions before people book',
  writingFromIdea: (title: string) => `Writing the "${title}" page`,
  replaceIdea: (title: string) => `Replace "${title}" with a new idea`,
  rowWriting: 'Writing the page…',
  rowAdding: 'Adding to your draft…',
  rowAddingToSite: 'Adding to your site…',
  rowAdded: (slug: string) => `In your draft at /${slug}`,
  removePage: (title: string) => `Take the "${title}" page out of your draft`,
  rowRemoving: 'Taking it out of your draft…',
  removingFromIdea: (title: string) => `Taking "${title}" out of your draft`,
  addingFromIdea: (title: string) => `Adding "${title}" to your draft`,
  addingBlurb:
    'If your draft has to start up first, this takes about a minute.',
  addingToSiteFromIdea: (title: string) => `Adding "${title}" to your site`,
  addingToSiteBlurb: 'The page is added to your site without a draft.',
  addedPreviewStarting: 'Starting your draft to show this page…',
  addedPreviewUnavailable:
    'Your draft is not showing this page right now. Open the draft to see it.',
  rowCreated: (slug: string) => `In your draft at /${slug}`,
  rowLive: (slug: string) => `On your site at /${slug}`,
  rowProposed: (slug: string) => `Not added yet · /${slug}`,
  addPage: (title: string) => `Add the "${title}" page to your draft`,
  addPageToSite: (title: string) => `Add the "${title}" page to your site`,
  addTip: 'Add to draft',
  addToSiteTip: 'Add to site',
  discardPage: (title: string) => `Discard the "${title}" page`,
  rowFailed: 'Kite could not write this page.',
  rowUncertain:
    'This page may already be in your draft. Look there before trying again.',
  topLevel: 'Top-level page',
  underPage: 'Under another page',
  choosePage: 'Choose a page',
  choosePagePlaceholder: 'Choose a page…',
  chooseParentFirst: 'Choose the page it goes under to see ideas for it.',
  rewriteConfirm: (path: string) =>
    `Kite writes it again at ${path} and replaces its current text in your draft. Its address and menu entry stay the same.`,
  rewrite: 'Rewrite',
  cancel: 'Cancel',
  modeLabel: 'How to create the page',
  aiTab: 'AI',
  manualTab: 'Manual',
  previewFrameTitle: (title: string) => `Preview of ${title || 'the new page'}`,
  styleFixPending: "Matching this page's text to your site's styles…",
  styleFixApplied:
    "Kite styled this page's text to match your site. The change is in this draft.",
  styleFixFailed:
    "This page's text may look plainer than the rest of your site. Ask Kite in chat to match your site's text styles.",
  pageNotes: (count: number) =>
    count === 1
      ? '1 note from Kite about this page'
      : `${count} notes from Kite about this page`,
  editPage: 'Edit page',
} as const;

// How often the rows check on the pages being written. Each page takes
// minutes, so this only needs to be quick enough that a finished one shows.
const PAGE_JOBS_POLL_MS = 5_000;

// Marks the panel while the wizard owns the screen; admin-overrides.css hides
// the form and its Save strip around it. The form stays mounted underneath:
// the section fills write into its rows.
const WIZARD_ACTIVE_ATTR = { 'data-kite-page-wizard': 'active' } as const;

function browserStore(): Storage | undefined {
  try {
    return window.localStorage;
  } catch {
    return undefined;
  }
}

// The platform's saved idea, exactly as the page-ideas API stores it.
type PageIdea = {
  id: string;
  title: string;
  page_type: PageType;
  target_questions?: string[];
  rationale?: string | null;
  // The site pages and other ideas this one's page links with.
  related?: { kind?: string; slug?: string; title?: string }[];
  evidence?: { url: string; title?: string; excerpt?: string }[];
  source?: 'user' | 'suggested';
  status?: 'new' | 'used' | 'dismissed';
  generated_slug?: string | null;
  parent_slug?: string | null;
  run_id?: string | null;
  created_at?: string;
};

// What the editor said about one idea's page: the brief and how it should
// sound. An idea nobody opened is written from its own title and questions.
type IdeaDetails = { purpose: string; tone: string | null; customTone: string };
const EMPTY_DETAILS: IdeaDetails = { purpose: '', tone: null, customTone: '' };

type PanelContext = {
  enabled: boolean;
  isDraft: boolean;
  idea: PageIdea | null;
  // The published site's address, when it has one.
  siteUrl: string | null;
  // The platform's preview of the open draft, ending in `path=/`: where an
  // unpublished page can be seen.
  previewBaseUrl: string | null;
  // The editor pressed Generate on a site that could only write in a draft:
  // the carried idea starts writing as soon as the draft's admin opens.
  autoStart: boolean;
};

type SitePatterns = {
  pages: {
    title: string;
    slug: string;
    sections: { blockType: string; background: string | null }[];
  }[];
  blockTypes: string[];
  collections: string[];
};

type CmsPage = {
  id?: string | number;
  title?: string;
  slug?: string;
  proposed?: boolean | null;
  layout?: { blockType?: string; background?: string | null }[];
};

function isIdeaArray(value: unknown): value is PageIdea[] {
  return (
    Array.isArray(value) &&
    value.every(
      (v) =>
        typeof v === 'object' &&
        v !== null &&
        typeof (v as PageIdea).id === 'string' &&
        typeof (v as PageIdea).title === 'string',
    )
  );
}

function isJobArray(value: unknown): value is PageJob[] {
  return (
    Array.isArray(value) &&
    value.every(
      (v) =>
        typeof v === 'object' &&
        v !== null &&
        typeof (v as PageJob).id === 'string' &&
        typeof (v as PageJob).status === 'string',
    )
  );
}

// What the site already publishes: the pages, the sections each one is built
// from, and the surfaces they sit on. This is the empirical design of the site,
// and the planner copies it rather than inventing a shape of its own.
async function fetchSitePages(): Promise<CmsPage[] | null> {
  // The duplicate and slug guarantees are only as good as this list. One
  // response page is not the site: walk every page up to the backend cap.
  // A failed request is not an empty site — the caller must not plan or
  // suggest from the pages that happened to load first.
  const collected = await collectExistingPages(async (page, limit) => {
    try {
      const res = await fetch(
        `/cms-api/pages?depth=0&limit=${limit}&page=${page}&sort=-updatedAt`,
      );
      if (!res.ok) return null;
      const data = (await res.json()) as {
        docs?: CmsPage[];
        hasNextPage?: boolean;
      };
      // A body with no page list is a failed request, not an empty site.
      if (!Array.isArray(data?.docs)) return null;
      return { docs: data.docs, hasNextPage: data?.hasNextPage };
    } catch {
      return null;
    }
  });
  return collected.ok ? collected.pages : null;
}

// Pages written on Main that nobody added to a draft yet. A site whose
// template predates them answers 404, which is simply none.
async function fetchMainProposals(): Promise<CmsPage[] | null> {
  try {
    const res = await fetch('/cms-api/page-proposals?depth=0&limit=200');
    if (res.status === 404) return [];
    if (!res.ok) return null;
    const data = (await res.json()) as { docs?: CmsPage[] };
    return Array.isArray(data?.docs) ? data.docs : null;
  } catch {
    return null;
  }
}

type SitePage = SitePageRecord;

function toSitePages(pages: CmsPage[]): SitePage[] {
  return pages
    .filter(
      (page): page is CmsPage & { slug: string } =>
        typeof page.slug === 'string',
    )
    .map((page) => ({
      id: String(page.id ?? ''),
      slug: page.slug,
      title: page.title ?? '',
      proposed: page.proposed === true,
    }));
}

export const IdeaPanel = () => {
  const { id } = useDocumentInfo();
  const { config } = useConfig();
  const { title: documentTitle, setDocumentTitle } = useDocumentTitle();
  const router = useRouter();
  const pagesListPath = `${config.routes.admin}/collections/pages`;

  // Create mode only. On an existing page the form already has its content, and
  // generating over it would replace what the editor came here to edit.
  const isCreate = isCreateMode(id);

  const [context, setContext] = useState<PanelContext | null>(null);
  const [contextSettled, setContextSettled] = useState(false);
  // The ideas on screen and the editor's removals, changed only through
  // `ideaListStep`: a dismissal's own answer decides it, and list reads only
  // add or update.
  const [ideaState, setIdeaState] =
    useState<IdeaListState<PageIdea>>(emptyIdeaList);
  const ideas = ideaState.shown;
  // The list's `version` as last computed, for a whole-list request to note
  // when it was sent. It can lag the latest state, never lead it, so a read
  // marked with it only ever keeps more cards.
  const ideaVersion = useRef(0);
  const applyIdeas = useCallback(
    (event: IdeaListEvent<PageIdea>) =>
      setIdeaState((state) => {
        const next = ideaListStep(state, event);
        ideaVersion.current = next.version;
        return next;
      }),
    [],
  );
  // The editor's own last URL segment; until they type one it follows the
  // picked idea's title.
  // A written page's address as edited, and the addresses pages were moved
  // to here — the run that wrote them still names the old one.
  const [addressDraft, setAddressDraft] = useState<string | null>(null);
  const [addressStatus, setAddressStatus] = useState<{
    kind: 'saving' | 'saved' | 'error';
    message?: string;
  } | null>(null);
  const [movedSlugs, setMovedSlugs] = useState<Record<string, string>>({});
  // The last segment a page not yet written will get; empty lets Kite choose.
  const [newSlug, setNewSlug] = useState('');
  const [details, setDetails] = useState<Record<string, IdeaDetails>>({});
  // The idea whose details dialog is open, and the answers being edited.
  const [detailsFor, setDetailsFor] = useState<{ ideaId: string } | null>(null);
  const [detailsDraft, setDetailsDraft] = useState<IdeaDetails>(EMPTY_DETAILS);
  const [device, setDevice] = useState<PreviewDevice>('desktop');
  const [selectedIdeaId, setSelectedIdeaId] = useState<string | null>(null);
  const [busy, setBusy] = useState<'ideas' | 'draft' | null>(null);
  // Suggesting is tracked apart from `busy`: it starts on its own when the
  // screen opens and can take two minutes, and the editor should be able to
  // type an idea and create the page meanwhile.
  const [suggesting, setSuggesting] = useState(false);
  // A request for more ideas keeps the current ones on screen while it runs.
  const [suggestingMore, setSuggestingMore] = useState(false);
  const [moreDirection, setMoreDirection] = useState('');
  const [moreOpen, setMoreOpen] = useState(false);
  // The first fresh idea is picked when a list arrives (on opening, on a new
  // spot, as a suggestion pass produces its first idea), so the preview shows
  // something at once. Only then: an editor who clears the choice keeps it
  // cleared.
  const pickFirstPending = useRef(true);
  // The ideas the running suggestion pass has produced so far; null when no
  // pass is running.
  const runArrivals = useRef<Set<string> | null>(null);
  // The joined-round wait, for the suggest pass that hands over to it.
  const waitForRoundRef = useRef<() => Promise<void>>(async () => {});
  const [ideaList, setIdeaList] = useState<HTMLDivElement | null>(null);
  const [ideaListMaxHeight, setIdeaListMaxHeight] = useState<number | null>(
    null,
  );
  useEffect(
    function fitIdeaListToScreen() {
      if (!ideaList) return;
      const fit = () => {
        // Measured from the top of the page, so scrolling does not move it.
        const top = ideaList.getBoundingClientRect().top + window.scrollY;
        setIdeaListMaxHeight(
          Math.max(
            IDEA_LIST_MIN_HEIGHT,
            Math.floor(window.innerHeight - top - IDEA_LIST_ROOM_BELOW),
          ),
        );
      };
      fit();
      window.addEventListener('resize', fit);
      // The steps above it grow and shrink (choosing a parent page).
      const observer = new ResizeObserver(fit);
      observer.observe(document.body);
      return () => {
        window.removeEventListener('resize', fit);
        observer.disconnect();
      };
    },
    [ideaList],
  );
  const [ideasLoaded, setIdeasLoaded] = useState(false);
  // The pages being written from ideas into this draft, one run per idea.
  const [jobs, setJobs] = useState<PageJob[]>([]);
  // Asked for, but the platform has not answered with the run yet.
  const [startingIdeaIds, setStartingIdeaIds] = useState<ReadonlySet<string>>(
    new Set(),
  );
  // Pages written on Main whose move into a draft is being started.
  const [addingIdeaIds, setAddingIdeaIds] = useState<ReadonlySet<string>>(
    new Set(),
  );
  const [removingIdeaIds, setRemovingIdeaIds] = useState<ReadonlySet<string>>(
    new Set(),
  );
  const [replacingIdeaId, setReplacingIdeaId] = useState<string | null>(null);
  // The idea whose placement is being asked, and what the editor has chosen.
  const [sitePages, setSitePages] = useState<SitePage[] | null>(null);
  // Pages written on Main and not yet added to a draft.
  const [mainProposals, setMainProposals] = useState<SitePage[] | null>(null);
  // How many runs had finished when `sitePages` was read. A list read before
  // the latest run finished cannot say that run's page is gone.
  const [pagesReadForRuns, setPagesReadForRuns] = useState(0);
  const finishedRunsRef = useRef(0);
  // The written page waiting for the editor to confirm its rewrite.
  const [confirmingRewrite, setConfirmingRewrite] = useState<{
    ideaId: string;
    slug: string;
    pageId: string | null;
  } | null>(null);
  // The spots ideas were already asked for on this screen, '' for top level.
  const autoSuggestTried = useRef<Set<string>>(new Set());
  // A suggestion round the platform is running for this site — started when
  // the editor opened — and whether this screen already waited it out.
  const [roundRunning, setRoundRunning] = useState(false);
  // That round's job id, which every poll reads back by.
  const roundIdRef = useRef<string | null>(null);
  const [roundWaitedOut, setRoundWaitedOut] = useState(false);
  // The last suggestion failed, and the error above the list offers a retry.
  const [suggestRetry, setSuggestRetry] = useState(false);
  // Where the new page goes: a page's slug, or '' for the top level.
  const [spot, setSpot] = useState('');
  // "Under another page" picked, maybe before the page itself is chosen.
  const [underPage, setUnderPage] = useState(false);
  // Under a page that is not chosen yet: nothing to suggest for.
  const spotPending = underPage && !spot;
  const [error, setError] = useState<string | null>(null);
  // AI until storage says otherwise. Read after mount: the server render
  // has no storage, and the two renders must agree.
  const [mode, setMode] = useState<WizardMode>('ai');
  const mounted = useRef(true);
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  // Back from a page opened here: the AI tab, with that idea picked once the
  // list has loaded (see `pickTheIdeaWeCameBackTo`).
  const returningIdeaId = useSearchParams().get(IDEA_PARAM);
  useEffect(
    function restoreWizardMode() {
      setMode(returningIdeaId ? 'ai' : readWizardMode(browserStore()));
    },
    [returningIdeaId],
  );

  const chooseMode = useCallback((next: WizardMode) => {
    setMode(next);
    writeWizardMode(browserStore(), next);
  }, []);

  // Content types this site actually has. A block that lists a collection
  // cannot be planned onto a site without one, so the planner is told which
  // exist — and told nothing where there are none, which is the gate it reads.
  const collections = useMemo(
    () => contentCollectionSlugs(config.collections),
    [config.collections],
  );

  const loadIdeas = useCallback(async () => {
    const readFrom = ideaVersion.current;
    const reply = await requestFromParent(
      PAGE_IDEAS_REQUEST,
      PAGE_IDEAS_RESPONSE,
      { op: 'list' },
      SECTION_FILL_TIMEOUT_MS,
    );
    if (!mounted.current) return;
    if (!reply || reply.error || !isIdeaArray(reply.ideas)) {
      applyIdeas({ type: 'listReadFailed' });
      setError(COPY.ideasFailed);
      return;
    }
    applyIdeas({
      type: 'listReadOk',
      ideas: reply.ideas,
      full: true,
      readFrom,
    });
    setIdeasLoaded(true);
    // The site's top-level round, by id, so the wait hears only that one. A
    // platform without the field never reports a round, so the panel behaves
    // as it did before.
    const round = reply.round as { id?: string; status?: string } | null;
    roundIdRef.current =
      round?.status === 'running' ? (round.id ?? null) : null;
    setRoundRunning(reply.suggesting === true);
  }, [applyIdeas]);

  // A whole list that could not vouch for a newer card (another session may
  // have dismissed it meanwhile) is followed by fresh reads until one settles
  // it: a read that fails, or that a newer reply overtakes, is tried again,
  // a bounded number of times.
  const recheckRunning = useRef(false);
  const [recheckAttempt, setRecheckAttempt] = useState(0);
  useEffect(() => {
    if (!ideaState.unconfirmed) {
      if (recheckAttempt !== 0) setRecheckAttempt(0);
      return;
    }
    if (recheckRunning.current) return;
    const delay = recheckDelay(recheckAttempt);
    if (delay === null) return;
    recheckRunning.current = true;
    let sent = false;
    const timer = window.setTimeout(() => {
      sent = true;
      const readFrom = ideaVersion.current;
      void requestFromParent(
        PAGE_IDEAS_REQUEST,
        PAGE_IDEAS_RESPONSE,
        { op: 'list' },
        SECTION_FILL_TIMEOUT_MS,
      )
        .then((reply) => {
          if (!mounted.current) return;
          if (reply && !reply.error && isIdeaArray(reply.ideas))
            applyIdeas({
              type: 'listReadOk',
              ideas: reply.ideas,
              full: true,
              readFrom,
            });
        })
        .catch(() => {})
        .finally(() => {
          recheckRunning.current = false;
          // Runs the effect again: a settled list resets the count, one
          // still unconfirmed gets the next try.
          if (mounted.current) setRecheckAttempt((n) => n + 1);
        });
    }, delay);
    return () => {
      // Only a read not yet sent is called off; one in flight settles itself.
      if (!sent) {
        window.clearTimeout(timer);
        recheckRunning.current = false;
      }
    };
  }, [ideaState.unconfirmed, ideaState.version, recheckAttempt, applyIdeas]);

  // One context request on mount: the flag, Main vs draft, and the idea a
  // draft hop carried over.
  useEffect(
    function loadPanelContext() {
      if (!isCreate) return;
      let cancelled = false;
      void (async () => {
        const reply = await requestFromParent(
          PAGE_IDEAS_CONTEXT_REQUEST,
          PAGE_IDEAS_CONTEXT_RESPONSE,
          {},
          SECTION_FILL_TIMEOUT_MS,
        );
        if (cancelled || !mounted.current) return;
        setContextSettled(true);
        // No answer at all (a standalone admin tab, a content tab that went
        // away): there is no platform to generate through, so the panel stays
        // out of the way rather than offering a button that cannot work.
        if (!reply || reply.error || reply.enabled !== true) return;
        const carried = (reply.idea ?? null) as PageIdea | null;
        setContext({
          enabled: true,
          isDraft: reply.isDraft === true,
          idea: carried,
          siteUrl: typeof reply.siteUrl === 'string' ? reply.siteUrl : null,
          previewBaseUrl:
            typeof reply.previewBaseUrl === 'string'
              ? reply.previewBaseUrl
              : null,
          autoStart: reply.autoStart === true,
        });
        if (carried) {
          // Its spot too, or the list would show another spot's ideas.
          setSpot(carried.parent_slug ?? '');
          setUnderPage(Boolean(carried.parent_slug));
          pickFirstPending.current = false;
          setSelectedIdeaId(carried.id);
        }
        setBusy('ideas');
        await loadIdeas();
        if (mounted.current) setBusy(null);
      })();
      return () => {
        cancelled = true;
      };
    },
    [isCreate, loadIdeas],
  );

  const collectSiteContext = useCallback(async () => {
    const [brandContext, pages] = await Promise.all([
      fetchBrandContext(),
      fetchSitePages(),
    ]);
    // A hole in the list is not a short site. Suggest and plan both refuse
    // to go out without every page the cap allows.
    if (!pages) return null;
    // Titles and slugs for every page. Section shape is a design sample of
    // the newest pages — the prompt trims that itself, and it is not what
    // duplicate detection compares against.
    const existingPages = pageSummaries(pages);
    const sampled = designSamplePages(pages);
    const sitePatterns: SitePatterns = {
      pages: sampled
        .filter((page) => typeof page.slug === 'string')
        .map((page) => ({
          title: page.title ?? '',
          slug: page.slug as string,
          sections: (page.layout ?? [])
            .filter((section) => typeof section.blockType === 'string')
            .map((section) => ({
              blockType: section.blockType as string,
              background: section.background ?? null,
            })),
        })),
      blockTypes: (layoutBlocks as Block[]).map((block) => block.slug),
      collections,
    };
    return { brandContext, existingPages, sitePatterns };
  }, [collections]);

  // The list is not the only place the chosen idea can come from: after a draft
  // hop the context reply carried it, and if the list then failed to load the
  // plan would go out with no `idea_id` and no evidence, and nothing would ever
  // be marked used.
  const chosenIdea =
    ideas.find((idea) => idea.id === selectedIdeaId) ??
    (context?.idea && context.idea.id === selectedIdeaId ? context.idea : null);

  // The ideas on screen and the pick, for a pass that starts from them.
  const ideasRef = useRef(ideas);
  ideasRef.current = ideas;
  const selectedRef = useRef(selectedIdeaId);
  selectedRef.current = selectedIdeaId;

  const handleSuggest = useCallback(
    async (more?: { direction: string }) => {
      setError(null);
      setSuggestRetry(false);
      const setLoading = more ? setSuggestingMore : setSuggesting;
      setLoading(true);
      // The platform stores each idea as it is written; until the pass
      // answers, read the stored list now and then and show what landed.
      const seen = new Set(ideasRef.current.map((idea) => idea.id));
      const arrivals = new Set<string>();
      runArrivals.current = arrivals;
      // Stamped on every idea this pass stores: the list is the website's, and
      // another editor's run may be storing ideas for this spot too.
      const runId = newRunId();
      // Its first idea is picked only for an editor with nothing picked; one
      // who has a pick and clears it mid-run keeps it cleared.
      pickFirstPending.current = selectedRef.current === null;
      let running = true;
      let handedOff = false;
      const showArrivals = async () => {
        while (running) {
          await new Promise((resolve) =>
            window.setTimeout(resolve, IDEA_POLL_INTERVAL_MS),
          );
          if (!running) return;
          const reply = await requestFromParent(
            PAGE_IDEAS_REQUEST,
            PAGE_IDEAS_RESPONSE,
            { op: 'list' },
            IDEA_POLL_TIMEOUT_MS,
          );
          // The pass's own answer is the whole list; a read after it is older.
          if (!running || !mounted.current) return;
          if (!reply || reply.error || !isIdeaArray(reply.ideas)) {
            applyIdeas({ type: 'listReadFailed' });
            continue;
          }
          const arrived = newArrivals(reply.ideas, seen);
          if (arrived.length === 0) continue;
          for (const idea of arrived) seen.add(idea.id);
          for (const idea of producedByRun(arrived, runId))
            arrivals.add(idea.id);
          applyIdeas({ type: 'listReadOk', ideas: arrived, full: false });
        }
      };
      // A plain ask can be answered by a round already running; one that
      // failed offers its retry, a steered one has its own dialog to retry from.
      const failed = () => {
        setError(COPY.suggestFailed);
        if (!more) setSuggestRetry(true);
      };
      try {
        const site = await collectSiteContext();
        if (!mounted.current) return;
        if (!site) {
          failed();
          return;
        }
        const { brandContext, existingPages, sitePatterns } = site;
        void showArrivals();
        const readFrom = ideaVersion.current;
        const reply = await requestFromParent(
          PAGE_IDEAS_REQUEST,
          PAGE_IDEAS_RESPONSE,
          {
            op: 'suggest',
            existingPages,
            brandContext,
            sitePatterns,
            parentSlug: spot,
            runId,
            // This panel can wait on a round already running, so a plain
            // top-level ask may join it instead of paying for a second one.
            joinRunningRound: true,
            ...(more?.direction.trim()
              ? { direction: more.direction.trim() }
              : {}),
          },
          SUGGEST_TIMEOUT_MS,
        );
        running = false;
        if (!mounted.current) return;
        if (refusedForCredits(reply)) {
          setError(COPY.outOfCredits);
          return;
        }
        if (!reply || reply.error || !isIdeaArray(reply.ideas)) {
          // The answer was lost, not necessarily the ideas: each one was
          // stored as it was written. Show whatever made it, and report a
          // failure only when nothing did.
          const listed = await requestFromParent(
            PAGE_IDEAS_REQUEST,
            PAGE_IDEAS_RESPONSE,
            { op: 'list' },
            IDEA_POLL_TIMEOUT_MS,
          );
          if (!mounted.current) return;
          if (listed && !listed.error && isIdeaArray(listed.ideas)) {
            const arrived = newArrivals(listed.ideas, seen);
            producedByRun(arrived, runId).forEach((idea) =>
              arrivals.add(idea.id),
            );
            applyIdeas({ type: 'listReadOk', ideas: arrived, full: false });
          } else applyIdeas({ type: 'listReadFailed' });
          if (arrivals.size === 0) failed();
          return;
        }
        applyIdeas({
          type: 'listReadOk',
          ideas: reply.ideas,
          full: true,
          readFrom,
        });
        // Nothing landed while it ran: pick from the answer, as before.
        if (arrivals.size === 0) pickFirstPending.current = true;
        // The site's top-level round was already running (the Content tab
        // started it): nothing was paid twice, and the panel tracks it again,
        // even after an earlier wait on it ended. That wait shows the round's
        // ideas as they land; this pass's own reads stop here.
        if (reply.suggesting === true) {
          const joined = reply.round as { id?: string } | null;
          roundIdRef.current = joined?.id ?? null;
          setRoundWaitedOut(false);
          setRoundRunning(true);
          handedOff = true;
        }
        if (more) setMoreDirection('');
      } finally {
        running = false;
        runArrivals.current = null;
        const end = endOfPass(handedOff);
        if (mounted.current && end.waitOnRound) {
          // In this same update, so no render shows nothing looking.
          void waitForRoundRef.current();
          if (more) setSuggestingMore(false);
        }
        if (mounted.current && end.stopLooking) setLoading(false);
      }
    },
    [applyIdeas, collectSiteContext, spot],
  );

  // The ideas for the chosen spot; older ideas with no spot are top-level.
  const spotIdeas = useMemo(
    () => ideas.filter((idea) => (idea.parent_slug ?? '') === spot),
    [ideas, spot],
  );

  // The spot as it is now, for a wait that outlives the render it began in.
  const spotRef = useRef(spot);
  spotRef.current = spot;

  // Shows "Looking for ideas…" while the platform's round finishes, reading
  // the stored list until the round ends: its ideas, or its failure with a
  // retry — never an empty list that reads as "no ideas".
  const waitForRound = useCallback(async () => {
    setSuggesting(true);
    // The round stores each idea as it is written and stamps it with its own
    // id; picking from those, the editor sees the round's first idea as soon
    // as it lands, as with a pass the panel runs itself.
    const arrivals = new Set<string>();
    runArrivals.current = arrivals;
    pickFirstPending.current = selectedRef.current === null;
    try {
      const started = Date.now();
      for (;;) {
        await new Promise((resolve) => setTimeout(resolve, ROUND_POLL_MS));
        if (!mounted.current) return;
        // The editor moved to another spot: that round is not its ideas, and
        // holding the panel busy would block that spot's own suggestions.
        if (spotRef.current !== '') return;
        const roundId = roundIdRef.current;
        const readFrom = ideaVersion.current;
        const reply = await requestFromParent(
          PAGE_IDEAS_REQUEST,
          PAGE_IDEAS_RESPONSE,
          roundId ? { op: 'list', roundId } : { op: 'list' },
          SECTION_FILL_TIMEOUT_MS,
        );
        if (!mounted.current) return;
        const answered =
          reply && !reply.error && isIdeaArray(reply.ideas) ? reply : null;
        if (answered) {
          const listed = answered.ideas as PageIdea[];
          if (roundId)
            producedByRun(listed, roundId).forEach((idea) =>
              arrivals.add(idea.id),
            );
          applyIdeas({
            type: 'listReadOk',
            ideas: listed,
            full: true,
            readFrom,
          });
        } else applyIdeas({ type: 'listReadFailed' });
        const step = roundPollStep(
          answered as RoundReply,
          roundId,
          Date.now() - started,
          ROUND_WAIT_CAP_MS,
        );
        if (step.kind === 'wait') continue;
        setRoundRunning(false);
        if (step.kind === 'done') {
          // A round that succeeded was this screen's suggestion, even one
          // that found nothing new: the editor can still ask for more.
          autoSuggestTried.current.add('');
          // Nothing landed while it ran: pick from the final list, as before.
          if (arrivals.size === 0) pickFirstPending.current = true;
          return;
        }
        setRoundWaitedOut(true);
        setError(COPY.suggestFailed);
        setSuggestRetry(true);
        return;
      }
    } finally {
      runArrivals.current = null;
      if (mounted.current) setSuggesting(false);
    }
  }, [applyIdeas]);
  waitForRoundRef.current = waitForRound;

  useEffect(
    function suggestIdeasOnOpen() {
      if (!isCreate || !context || spotPending) return;
      const action = ideasActionOnOpen({
        mode,
        ideasLoaded,
        ideas: spotIdeas,
        alreadyTried: autoSuggestTried.current.has(spot),
        busy: suggesting || busy !== null,
        topLevel: spot === '',
        roundRunning,
        waitedOut: roundWaitedOut,
      });
      if (action === 'wait') {
        void waitForRound();
        return;
      }
      if (action !== 'suggest') return;
      autoSuggestTried.current.add(spot);
      void handleSuggest();
    },
    [
      busy,
      context,
      handleSuggest,
      spotIdeas,
      spot,
      spotPending,
      ideasLoaded,
      isCreate,
      mode,
      roundRunning,
      roundWaitedOut,
      suggesting,
      waitForRound,
    ],
  );

  const handleDismiss = useCallback(
    async (ideaId: string) => {
      const idea = ideasRef.current.find((row) => row.id === ideaId);
      if (!idea) return;
      // Off the screen at once; the dismissal's own answer decides the rest.
      applyIdeas({ type: 'removalRequested', idea, hidden: true });
      setSelectedIdeaId((current) => (current === ideaId ? null : current));
      let reply: Awaited<ReturnType<typeof requestFromParent>> = null;
      const readFrom = ideaVersion.current;
      try {
        reply = await requestFromParent(
          PAGE_IDEAS_REQUEST,
          PAGE_IDEAS_RESPONSE,
          { op: 'dismiss', ideaId },
          SECTION_FILL_TIMEOUT_MS,
        );
      } finally {
        applyIdeas({
          type: dismissalSaved(reply) ? 'removalConfirmed' : 'removalFailed',
          id: ideaId,
        });
      }
      if (!mounted.current) return;
      if (!dismissalSaved(reply)) {
        setError(COPY.dismissFailed);
        return;
      }
      // The list that came with it, when it came: the whole list.
      if (reply && isIdeaArray(reply.ideas))
        applyIdeas({
          type: 'listReadOk',
          ideas: reply.ideas,
          full: true,
          readFrom,
        });
    },
    [applyIdeas],
  );

  /**
   * Only for a site whose template cannot hold pages written on Main: reopen
   * this screen in the editor's draft (a new one only when they have none)
   * with *idea* carried, and write it there straight away.
   */
  const openDraftFor = useCallback(async (idea: PageIdea) => {
    const reply = await requestFromParent(
      OPEN_DRAFT_REQUEST,
      OPEN_DRAFT_RESPONSE,
      { title: idea.title, ideaId: idea.id, reuse: true, autoStart: true },
      SECTION_FILL_TIMEOUT_MS,
    );
    if (!mounted.current) return;
    // The platform navigates on success, which tears this admin down. Only a
    // failure is ever seen here.
    if (!reply || reply.error) setError(COPY.draftFailed);
  }, []);

  const loadJobs = useCallback(async () => {
    const reply = await requestFromParent(
      PAGE_IDEAS_REQUEST,
      PAGE_IDEAS_RESPONSE,
      { op: 'jobs' },
      SECTION_FILL_TIMEOUT_MS,
    );
    if (!mounted.current) return;
    // A missed poll leaves the rows as they were; the next one catches up.
    if (reply && !reply.error && isJobArray(reply.jobs)) setJobs(reply.jobs);
  }, []);

  const isDraftContext = context?.isDraft === true;
  // Pages are written here on Main too: as hidden proposals in their own
  // collection, which no public page reads, until the editor adds one to a
  // draft. In a draft they are `pages` rows marked `proposed`.
  const writesHere = context?.enabled === true;
  const onMain = writesHere && !isDraftContext;
  const writtenCollection = onMain ? 'page-proposals' : 'pages';
  const keepCheckingPages =
    anyPageBeingWritten(jobs) ||
    startingIdeaIds.size > 0 ||
    addingIdeaIds.size > 0 ||
    removingIdeaIds.size > 0;
  useEffect(
    function followThePagesBeingWritten() {
      if (!isCreate || !writesHere) return;
      // Once on open, so a page started on an earlier visit shows its state.
      void loadJobs();
    },
    [isCreate, writesHere, loadJobs],
  );
  useEffect(
    function pollWhilePagesAreBeingWritten() {
      if (!isCreate || !writesHere || !keepCheckingPages) return;
      const timer = window.setInterval(
        () => void loadJobs(),
        PAGE_JOBS_POLL_MS,
      );
      return () => window.clearInterval(timer);
    },
    [isCreate, writesHere, keepCheckingPages, loadJobs],
  );

  // A whole page per idea, written on a worker straight into this draft, so
  // several can be under way at once while the editor carries on here.
  const handleCreateFromIdea = useCallback(
    async (
      idea: PageIdea,
      placement?:
        | ReturnType<typeof placementFor>
        | { rewriteSlug: string; purpose: string | null; tone: string | null },
    ) => {
      setError(null);
      setStartingIdeaIds((current) => new Set(current).add(idea.id));
      try {
        const reply = await requestFromParent(
          PAGE_IDEAS_REQUEST,
          PAGE_IDEAS_RESPONSE,
          {
            op: 'generate',
            ideaId: idea.id,
            pageType: idea.page_type,
            ...(placement ? { placement } : {}),
          },
          SECTION_FILL_TIMEOUT_MS,
        );
        if (!mounted.current) return;
        if (reply?.needsDraft === true) {
          setBusy('draft');
          try {
            await openDraftFor(idea);
          } finally {
            if (mounted.current) setBusy(null);
          }
          return;
        }
        if (!reply || reply.error || !isJobArray(reply.jobs)) {
          setError(
            refusedForCredits(reply) ? COPY.outOfCredits : COPY.pageStartFailed,
          );
          return;
        }
        setJobs(reply.jobs);
      } finally {
        if (mounted.current) {
          setStartingIdeaIds((current) => {
            const next = new Set(current);
            next.delete(idea.id);
            return next;
          });
        }
      }
    },
    [openDraftFor],
  );

  // A typed idea joins the list like any suggestion and starts writing at
  // once, the same as pressing its Preview icon.
  // The pages a new one can go under.
  const loadSiteShape = useCallback(async () => {
    const runsAtRead = finishedRunsRef.current;
    const [pages, mainProposals] = await Promise.all([
      fetchSitePages(),
      onMain ? fetchMainProposals() : Promise.resolve([]),
    ]);
    if (!mounted.current) return;
    // A failed read is not an empty site: keep what was last read, or every
    // written card would look unwritten and offer to write it again.
    if (pages === null || mainProposals === null) return;
    setPagesReadForRuns(runsAtRead);
    setSitePages(toSitePages(pages));
    // Kept apart from the pages: the two collections number their documents
    // independently, so a proposal can share an id with a live page.
    setMainProposals(
      toSitePages(mainProposals.map((page) => ({ ...page, proposed: true }))),
    );
  }, [onMain]);

  // A page added to a draft from Main is served by that draft's sandbox, not
  // this one: its preview comes from there, once that sandbox is up.
  // Read as the row reads it: a merged or thrown-away draft has nothing to
  // show any more.
  const addedTarget = useMemo(() => {
    if (!onMain || !chosenIdea) return null;
    const state = withMergedPage(ideaRowState(chosenIdea, jobs), null);
    return state.kind === 'added' && state.draftId
      ? { draftId: state.draftId, slug: state.slug }
      : null;
  }, [chosenIdea, jobs, onMain]);
  const [addedPreview, setAddedPreview] = useState<{
    key: string;
    url: string | null;
  } | null>(null);
  const addedKey = addedTarget
    ? `${addedTarget.draftId}/${addedTarget.slug}`
    : null;
  useEffect(
    function previewThePageInItsDraft() {
      if (!addedKey) return;
      // The key is `<draft id>/<slug>`; a draft id has no slash in it.
      const cut = addedKey.indexOf('/');
      const target = {
        draftId: addedKey.slice(0, cut),
        slug: addedKey.slice(cut + 1),
      };
      let stopped = false;
      let timer: number | undefined;
      let tries = 0;
      const ask = async () => {
        tries += 1;
        const reply = await requestFromParent(
          PAGE_IDEAS_REQUEST,
          PAGE_IDEAS_RESPONSE,
          { op: 'draftPreview', ...target },
          SECTION_FILL_TIMEOUT_MS,
        );
        if (stopped || !mounted.current) return;
        if (reply && typeof reply.url === 'string') {
          setAddedPreview({ key: addedKey, url: reply.url });
          return;
        }
        setAddedPreview({ key: addedKey, url: null });
        if (tries < DRAFT_PREVIEW_MAX_TRIES)
          timer = window.setTimeout(() => void ask(), DRAFT_PREVIEW_RETRY_MS);
        else setAddedPreview({ key: addedKey, url: '' });
      };
      void ask();
      return () => {
        stopped = true;
        if (timer) window.clearTimeout(timer);
      };
    },
    [addedKey],
  );

  // A finished run means a new page in the draft: read the pages again so its
  // card knows it is there and still a proposal.
  const finishedRuns = jobs.filter((job) => job.status === 'created').length;
  finishedRunsRef.current = finishedRuns;
  useEffect(
    function rereadPagesWhenARunFinishes() {
      if (isCreate && writesHere && finishedRuns > 0) void loadSiteShape();
    },
    [finishedRuns, isCreate, writesHere, loadSiteShape],
  );

  useEffect(
    function loadThePagesTheSpotCanBe() {
      if (isCreate && writesHere) void loadSiteShape();
    },
    [isCreate, writesHere, loadSiteShape],
  );

  // The address belongs to the picked idea: a new pick replaces it, and
  // letting go of a pick clears it, so one page's address never goes out with
  // the next.
  const selectIdea = useCallback((idea: PageIdea) => {
    setSelectedIdeaId(idea.id);
    setNewSlug(slugFromTitle(idea.title));
    setAddressDraft(null);
    setAddressStatus(null);
    setConfirmingRewrite(null);
  }, []);

  const returnHandled = useRef(false);
  useEffect(
    function pickTheIdeaWeCameBackTo() {
      if (!returningIdeaId || returnHandled.current || !ideasLoaded) return;
      returnHandled.current = true;
      const idea = ideas.find((candidate) => candidate.id === returningIdeaId);
      if (!idea) return;
      // Its spot first: the list shows only the chosen spot's ideas.
      const parent = idea.parent_slug ?? '';
      setSpot(parent);
      setUnderPage(parent !== '');
      // The first fresh idea must not take its place in this same pass.
      pickFirstPending.current = false;
      selectIdea(idea);
    },
    [ideas, ideasLoaded, returningIdeaId, selectIdea],
  );

  useEffect(
    function pickFirstOnNewSpot() {
      pickFirstPending.current = true;
    },
    [spot],
  );
  useEffect(
    function pickTheFirstFreshIdea() {
      if (!pickFirstPending.current || !ideasLoaded) return;
      // An idea the editor came back to is picked by its own effect.
      if (returningIdeaId && !returnHandled.current) return;
      // Mid-pass, only the pass's own first idea, the moment it lands; the
      // pass ending picks as before if none did.
      const { pick, pending } = autoPick({
        pending: true,
        lookingForIdeas: suggesting || suggestingMore,
        selectedId: selectedIdeaId,
        ideas,
        spot,
        arrivals: runArrivals.current,
      });
      pickFirstPending.current = pending;
      if (pick) selectIdea(pick);
    },
    [
      ideas,
      ideasLoaded,
      returningIdeaId,
      selectIdea,
      selectedIdeaId,
      spot,
      suggesting,
      suggestingMore,
    ],
  );

  const clearSelection = useCallback(() => {
    setSelectedIdeaId(null);
    setNewSlug('');
    setAddressDraft(null);
    setAddressStatus(null);
    setConfirmingRewrite(null);
  }, []);

  const detailsOf = useCallback(
    (idea: PageIdea): IdeaDetails =>
      details[idea.id] ?? { ...EMPTY_DETAILS, purpose: briefFromIdea(idea) },
    [details],
  );

  // The brief and tone an idea's page goes out with. A brief left as the idea
  // filled it says nothing the idea does not.
  const choicesFor = useCallback(
    (idea: PageIdea) => {
      const own = detailsOf(idea);
      const brief = own.purpose.trim();
      return {
        purpose:
          brief === briefFromIdea(idea) || brief === idea.title ? '' : brief,
        tone: own.tone === 'custom' ? own.customTone : (own.tone ?? ''),
      };
    },
    [detailsOf],
  );

  const openDetails = useCallback(
    (idea: PageIdea) => {
      setDetailsDraft(detailsOf(idea));
      setDetailsFor({ ideaId: idea.id });
    },
    [detailsOf],
  );

  const saveDetails = useCallback(() => {
    if (!detailsFor) return;
    const { ideaId } = detailsFor;
    const answers = detailsDraft;
    setDetails((current) => ({ ...current, [ideaId]: answers }));
    setDetailsFor(null);
  }, [detailsDraft, detailsFor]);

  // The one button: write the picked idea's page. On Main the hop to a draft
  // comes first. Several pages can be under way at once.
  // Each card writes its own idea's page, and picks it so the address and
  // preview follow. The address typed for the picked idea goes with it; any
  // other idea gets its title's. On Main the hop to a draft comes first.
  const handleGenerate = useCallback(
    (idea: PageIdea) => {
      setError(null);
      setConfirmingRewrite(null);
      const slug =
        idea.id === selectedIdeaId ? newSlug : slugFromTitle(idea.title);
      if (idea.id !== selectedIdeaId) selectIdea(idea);
      // Under the idea's own parent: a carried or returned idea can be
      // generated while another spot is showing.
      void handleCreateFromIdea(
        idea,
        placementFor(idea.parent_slug ?? '', { slug, ...choicesFor(idea) }),
      );
    },
    [choicesFor, handleCreateFromIdea, newSlug, selectIdea, selectedIdeaId],
  );

  // After the fallback hop into a draft, the page the editor asked for on
  // Main starts writing here without a second press.
  const autoStarted = useRef(false);
  useEffect(
    function writeTheCarriedIdea() {
      if (autoStarted.current || !context?.autoStart || !isDraftContext) return;
      const carried = context.idea;
      if (!carried || !ideasLoaded) return;
      const idea = ideas.find((candidate) => candidate.id === carried.id);
      if (!idea) return;
      autoStarted.current = true;
      handleGenerate(idea);
    },
    [context, handleGenerate, ideas, ideasLoaded, isDraftContext],
  );

  // Moves a written page to a new last segment. Payload keeps it under its
  // parent and refuses an address another page has.
  const handleRenamePage = useCallback(
    async (pageId: string, leaf: string, parentPath: string) => {
      const next = slugFromTitle(leaf);
      if (!next) return;
      setAddressStatus({ kind: 'saving' });
      try {
        // A page nests its own slug under its parent; a page written on Main
        // keeps the whole path, so it is sent whole.
        const res = await fetch(
          `/cms-api/${writtenCollection}/${pageId}?depth=0`,
          {
            method: 'PATCH',
            headers: { 'content-type': 'application/json' },
            body: JSON.stringify({
              slug: onMain ? `${parentPath}${next}` : next,
            }),
          },
        );
        const body = (await res.json().catch(() => null)) as {
          doc?: { slug?: string };
          errors?: { data?: { errors?: { path?: string }[] } }[];
        } | null;
        if (!mounted.current) return;
        const moved = body?.doc?.slug;
        if (res.ok && typeof moved === 'string') {
          setMovedSlugs((current) => ({ ...current, [pageId]: moved }));
          setAddressDraft(null);
          setAddressStatus({ kind: 'saved' });
          void loadSiteShape();
          return;
        }
        const taken = body?.errors?.some((error) =>
          error.data?.errors?.some((field) => field.path === 'slug'),
        );
        setAddressStatus({
          kind: 'error',
          message: taken ? WIZARD_COPY.addressTaken : WIZARD_COPY.addressFailed,
        });
      } catch {
        if (mounted.current)
          setAddressStatus({
            kind: 'error',
            message: WIZARD_COPY.addressFailed,
          });
      }
    },
    [loadSiteShape, onMain, writtenCollection],
  );

  // A proposal becomes a real page where it was written. In a draft the site
  // starts serving it, and merging the draft publishes it. On Main it is made
  // a page of Main on a worker, with no draft, and its row follows that run
  // like a page being written.
  const handleAddPage = useCallback(
    async (idea: PageIdea, pageId: string) => {
      setError(null);
      if (onMain) {
        setAddingIdeaIds((current) => new Set(current).add(idea.id));
        try {
          const reply = await requestFromParent(
            PAGE_IDEAS_REQUEST,
            PAGE_IDEAS_RESPONSE,
            { op: 'add', proposalId: pageId, ideaId: idea.id, target: 'main' },
            SECTION_FILL_TIMEOUT_MS,
          );
          if (!mounted.current) return;
          if (!reply || reply.error || !isJobArray(reply.jobs)) {
            setError(COPY.addPageToSiteFailed);
            return;
          }
          setJobs(reply.jobs);
        } finally {
          if (mounted.current)
            setAddingIdeaIds((current) => {
              const next = new Set(current);
              next.delete(idea.id);
              return next;
            });
        }
        return;
      }
      try {
        const res = await fetch(`/cms-api/pages/${pageId}?depth=0`, {
          method: 'PATCH',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ proposed: false }),
        });
        if (!res.ok) throw new Error(String(res.status));
      } catch {
        if (mounted.current) setError(COPY.addPageFailed);
      }
      await loadSiteShape();
    },
    [loadSiteShape, onMain],
  );

  // The add, undone: the page goes back to waiting, content kept, so the same
  // button adds it again. In a draft that is the flag; a page moved into a
  // draft from Main is moved back out on a worker.
  const handleRemovePage = useCallback(
    async (idea: PageIdea, state: IdeaRowState) => {
      setError(null);
      // Taking a parent out would leave its children under an address the
      // merged site does not have.
      if (!onMain && (state.kind === 'added' || state.kind === 'created')) {
        // Without the page list there is no telling: refuse rather than risk
        // it. The CMS refuses too.
        if (!sitePages) {
          setError(COPY.removePageFailed);
          return;
        }
        const children = pagesUnder(state.slug, sitePages);
        if (children.length > 0) {
          setError(COPY.removeParentFirst(children.length));
          return;
        }
      }
      if (state.kind === 'added') {
        if (!state.draftId || !state.pageId) return;
        setRemovingIdeaIds((current) => new Set(current).add(idea.id));
        try {
          const reply = await requestFromParent(
            PAGE_IDEAS_REQUEST,
            PAGE_IDEAS_RESPONSE,
            {
              op: 'return',
              draftId: state.draftId,
              pageId: state.pageId,
              ideaId: idea.id,
            },
            SECTION_FILL_TIMEOUT_MS,
          );
          if (!mounted.current) return;
          if (!reply || reply.error || !isJobArray(reply.jobs)) {
            setError(COPY.removePageFailed);
            return;
          }
          setJobs(reply.jobs);
        } finally {
          if (mounted.current)
            setRemovingIdeaIds((current) => {
              const next = new Set(current);
              next.delete(idea.id);
              return next;
            });
        }
        return;
      }
      // On Main a written row's id is a proposal's, never a page's: there is
      // nothing in a draft to take out.
      if (onMain || state.kind !== 'created' || !state.pageId) return;
      try {
        const res = await fetch(`/cms-api/pages/${state.pageId}?depth=0`, {
          method: 'PATCH',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ proposed: true }),
        });
        if (!res.ok) throw new Error(String(res.status));
      } catch {
        if (mounted.current) setError(COPY.removePageFailed);
      }
      await loadSiteShape();
    },
    [loadSiteShape, onMain, sitePages],
  );

  // A proposal nobody wants is deleted from the draft; its idea goes back to
  // unwritten, so it can be written again.
  const handleDiscardPage = useCallback(
    async (pageId: string) => {
      setError(null);
      try {
        const res = await fetch(`/cms-api/${writtenCollection}/${pageId}`, {
          method: 'DELETE',
        });
        if (!res.ok) throw new Error(String(res.status));
      } catch {
        if (mounted.current) setError(COPY.discardPageFailed);
      }
      await loadSiteShape();
    },
    [loadSiteShape, writtenCollection],
  );

  // A completely new idea in this one's place: the old one is dismissed, so
  // it is never suggested again, and Kite is asked for exactly one more.
  const handleReplaceIdea = useCallback(
    async (idea: PageIdea) => {
      setError(null);
      setReplacingIdeaId(idea.id);
      // Left on screen while its dismissal is decided: the card shows it is
      // being replaced until a new one takes its place.
      applyIdeas({ type: 'removalRequested', idea, hidden: false });
      let dismissed: Awaited<ReturnType<typeof requestFromParent>> = null;
      // Every way out that brings no replacement must still settle the slot,
      // or a saved dismissal would stay on screen as a selectable card.
      let settled = false;
      try {
        try {
          dismissed = await requestFromParent(
            PAGE_IDEAS_REQUEST,
            PAGE_IDEAS_RESPONSE,
            { op: 'dismiss', ideaId: idea.id },
            SECTION_FILL_TIMEOUT_MS,
          );
        } finally {
          applyIdeas({
            type: dismissalSaved(dismissed)
              ? 'removalConfirmed'
              : 'removalFailed',
            id: idea.id,
          });
        }
        const site = await collectSiteContext();
        if (!mounted.current) return;
        if (!dismissalSaved(dismissed) || !site) {
          setError(COPY.replaceFailed);
          return;
        }
        const { brandContext, existingPages, sitePatterns } = site;
        const readFrom = ideaVersion.current;
        const reply = await requestFromParent(
          PAGE_IDEAS_REQUEST,
          PAGE_IDEAS_RESPONSE,
          {
            op: 'suggest',
            existingPages,
            brandContext,
            sitePatterns,
            limit: 1,
            parentSlug: spot,
          },
          SUGGEST_TIMEOUT_MS,
        );
        if (!mounted.current) return;
        if (!reply || reply.error || !isIdeaArray(reply.ideas)) {
          setError(
            refusedForCredits(reply) ? COPY.outOfCredits : COPY.replaceFailed,
          );
          return;
        }
        const after = reply.ideas;
        settled = true;
        applyIdeas({ type: 'replaced', id: idea.id, ideas: after, readFrom });
        setSelectedIdeaId((current) => (current === idea.id ? null : current));
      } finally {
        if (!settled) applyIdeas({ type: 'replacementFailed', id: idea.id });
        if (mounted.current) setReplacingIdeaId(null);
      }
    },
    [applyIdeas, collectSiteContext, spot],
  );

  // In the AI tab the heading above the panel says "New page", then names the
  // page once Kite has written it; the Manual tab gets Payload's own back. Payload recomputes the
  // title whenever the form's data changes, so it is set again if it drifts.
  const selectedForTitle =
    chosenIdea && !startingIdeaIds.has(chosenIdea.id)
      ? ideaRowState(chosenIdea, jobs)
      : null;
  const writtenTitle =
    mode !== 'ai' || !context
      ? ''
      : selectedForTitle?.kind === 'created'
        ? selectedForTitle.title || chosenIdea?.title || WIZARD_COPY.newPage
        : WIZARD_COPY.newPage;
  // Payload's own title while the panel has replaced it, to put back after.
  const replacedTitle = useRef<string | null>(null);
  useEffect(
    function nameTheWrittenPage() {
      if (writtenTitle) {
        if (replacedTitle.current === null)
          replacedTitle.current = documentTitle;
        if (documentTitle !== writtenTitle) setDocumentTitle(writtenTitle);
      } else if (replacedTitle.current !== null) {
        setDocumentTitle(replacedTitle.current);
        replacedTitle.current = null;
      }
    },
    [documentTitle, setDocumentTitle, writtenTitle],
  );

  if (!isCreate) return null;
  // Nothing at all until the parent has answered — and nothing ever if it said
  // the feature is off here.
  if (!contextSettled) return null;
  if (!context) return null;

  // Loading the saved ideas or hopping to a draft: the idea box waits.
  const isWorking = busy !== null;

  // Only the tab list: the panel each tab selects is this card's own body
  // (and, for Manual, the form under it), not a TabsContent.
  const modeTabs = (
    <Tabs
      value={mode}
      onValueChange={(value) => chooseMode(value as WizardMode)}
    >
      <TabsList aria-label={WIZARD_COPY.modeLabel}>
        <TabsTrigger value="ai">{WIZARD_COPY.aiTab}</TabsTrigger>
        <TabsTrigger value="manual">{WIZARD_COPY.manualTab}</TabsTrigger>
      </TabsList>
    </Tabs>
  );

  if (mode === 'ai') {
    // Proposals can be discarded, which would strand a page nested under one.
    const parentChoices = (sitePages ?? []).filter(
      (page) => page.slug !== 'home' && !page.proposed,
    );
    const stateOf = (idea: PageIdea): IdeaRowState => {
      if (startingIdeaIds.has(idea.id)) return { kind: 'writing' };
      if (addingIdeaIds.has(idea.id)) return { kind: 'adding' };
      if (removingIdeaIds.has(idea.id)) return { kind: 'removing' };
      const reported = ideaRowState(idea, jobs);
      const state = onMain ? reported : inDraftView(reported);
      const moved =
        state.kind === 'created' && state.pageId
          ? movedSlugs[state.pageId]
          : undefined;
      const pagesRead = pagesReadForRuns === finishedRuns;
      const onSite = withPageOnSite(
        moved && state.kind === 'created' ? { ...state, slug: moved } : state,
        !pagesRead ? null : onMain ? mainProposals : sitePages,
      );
      return onMain
        ? withMergedPage(
            asMainProposal(
              withAddedPageOnMain(onSite, pagesRead ? sitePages : null),
            ),
            pagesRead ? sitePages : null,
          )
        : onSite;
    };
    const selectedState = chosenIdea ? stateOf(chosenIdea) : null;
    // Ideas already placed in a draft or on the site leave the list: it holds
    // only what is still to be decided.
    const openIdeas = spotIdeas.filter((idea) => !isPlaced(stateOf(idea)));
    // A suggestion pass shows each idea as it lands; the skeletons stand in
    // only until the first one does.
    const listLoading =
      busy === 'ideas' || (suggesting && openIdeas.length === 0);
    const lookingForMore = suggesting || suggestingMore;
    // What a page's path is appended to: the published site, or before it is
    // published the platform's preview of this draft. Never this admin's own
    // sandbox host, which nobody else can open.
    const addressBase = context.siteUrl
      ? `${context.siteUrl.replace(/\/+$/, '')}/`
      : (context.previewBaseUrl ?? `${window.location.origin}/`);
    const chooseSpot = (next: { spot: string; underPage: boolean }) => {
      setSpot(next.spot);
      setUnderPage(next.underPage);
      if (chosenIdea) clearSelection();
      setConfirmingRewrite(null);
    };
    const rewriting = confirmingRewrite
      ? (ideas.find((idea) => idea.id === confirmingRewrite.ideaId) ?? null)
      : null;
    // A rewrite keeps the page's address; the brief and tone as now edited
    // go with it.
    const rewriteChoices = (() => {
      const placed = placementFor(spot, rewriting ? choicesFor(rewriting) : {});
      return { purpose: placed.purpose, tone: placed.tone };
    })();
    const statusLabel = (state: IdeaRowState): string | null => {
      if (state.kind === 'writing') return WIZARD_COPY.rowWriting;
      if (state.kind === 'adding')
        return onMain ? WIZARD_COPY.rowAddingToSite : WIZARD_COPY.rowAdding;
      if (state.kind === 'removing') return WIZARD_COPY.rowRemoving;
      if (state.kind === 'added')
        return state.moveError ?? WIZARD_COPY.rowAdded(state.slug);
      if (state.kind === 'live') return WIZARD_COPY.rowLive(state.slug);
      if (state.kind === 'created' && state.moveError) return state.moveError;
      if (state.kind === 'created')
        return state.proposed
          ? WIZARD_COPY.rowProposed(state.slug)
          : WIZARD_COPY.rowCreated(state.slug);
      if (state.kind === 'failed')
        return state.uncertain
          ? WIZARD_COPY.rowUncertain
          : (state.message ?? WIZARD_COPY.rowFailed);
      return null;
    };
    // One address field over the preview: the site and parent are fixed, the
    // last segment is the editor's. Before the page exists it is the address
    // Kite writes it at; once written, changing it moves the page.
    // Width toggles, and for a written page the way into its full editor.
    const writtenPage =
      context.isDraft && selectedState?.kind === 'created'
        ? selectedState
        : null;
    const deviceToggle = (
      <div className="flex shrink-0 items-center gap-1">
        {writtenPage && (
          <IconButton
            label={WIZARD_COPY.editPage}
            icon={SquarePenIcon}
            size="icon"
            variant="outline"
            onClick={() =>
              router.push(
                chosenIdea
                  ? editorPathFromIdeas(
                      pagesListPath,
                      writtenPage.pageId,
                      chosenIdea.id,
                    )
                  : pagesListPath,
              )
            }
          />
        )}
        <DeviceToggle
          device={device}
          labels={WIZARD_COPY.devices}
          onDevice={setDevice}
        />
      </div>
    );
    const addressBar = (() => {
      if (!writesHere || spotPending) return null;
      const written = selectedState?.kind === 'created' ? selectedState : null;
      const writing = selectedState?.kind === 'writing';
      const slug = written ? written.slug : spot ? `${spot}/` : '';
      const cut = slug.lastIndexOf('/');
      const fixed = `${addressBase}${cut >= 0 ? slug.slice(0, cut + 1) : ''}`;
      const leaf = written ? slug.slice(cut + 1) : newSlug;
      const value = written ? (addressDraft ?? leaf) : newSlug;
      const save = () => {
        if (written?.pageId && value.trim() && slugFromTitle(value) !== leaf)
          void handleRenamePage(
            written.pageId,
            value,
            cut >= 0 ? slug.slice(0, cut + 1) : '',
          );
      };
      const editable = !writing && (written ? Boolean(written.pageId) : true);
      return (
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center gap-1.5">
            <label
              htmlFor="kite-page-address"
              className="text-fg-normal text-sm font-medium"
            >
              {WIZARD_COPY.addressLabel}
            </label>
            <Tooltip content={WIZARD_COPY.addressHelp}>
              <span
                className="text-fg-subtle inline-flex"
                tabIndex={0}
                aria-label={WIZARD_COPY.addressHelp}
              >
                <Icon icon={CircleHelpIcon} size="sm" aria-hidden />
              </span>
            </Tooltip>
          </div>
          <div className="flex min-w-0 items-center gap-2">
            <div className="flex h-10 min-w-0 flex-1 items-stretch text-sm">
              <span
                className="border-bd-neutral-subtle bg-bg-neutral-subtle text-fg-subtle flex max-w-[60%] min-w-0 shrink items-center gap-2 rounded-l-md border border-r-0 px-3"
                title={fixed}
              >
                <Icon
                  icon={LockIcon}
                  size="sm"
                  className="shrink-0"
                  aria-hidden
                />
                <span className="truncate">{fixed}</span>
              </span>
              <span className="border-bd-neutral-subtle bg-bg-card focus-within:border-bd-focus focus-within:ring-bd-focus/30 flex min-w-[12rem] flex-1 items-center rounded-r-md border focus-within:ring-2">
                <input
                  id="kite-page-address"
                  aria-label={WIZARD_COPY.addressLabel}
                  className="text-fg-normal placeholder:text-fg-subtle h-full min-w-0 flex-1 border-0 bg-transparent px-3 outline-none disabled:opacity-60"
                  value={value}
                  placeholder={WIZARD_COPY.addressPlaceholder}
                  readOnly={!editable}
                  disabled={writing || addressStatus?.kind === 'saving'}
                  onChange={(event) => {
                    if (written) setAddressDraft(event.target.value);
                    else setNewSlug(event.target.value);
                    setAddressStatus(null);
                  }}
                  onBlur={() => {
                    if (!written)
                      setNewSlug((current) => slugFromTitle(current));
                    else if (addressDraft !== null && !addressDraft.trim())
                      setAddressDraft(null);
                  }}
                  onKeyDown={(event) => {
                    // The admin's own form wraps this panel; Enter here never
                    // saves the form.
                    if (event.key === 'Enter') {
                      event.preventDefault();
                      save();
                    } else if (event.key === 'Escape' && written) {
                      setAddressDraft(null);
                      setAddressStatus(null);
                    }
                  }}
                />
                {editable && value && (
                  <IconButton
                    label={WIZARD_COPY.addressClear}
                    tip={WIZARD_COPY.clear}
                    icon={XIcon}
                    className="mr-1.5"
                    onClick={() => {
                      if (written) setAddressDraft('');
                      else setNewSlug('');
                      setAddressStatus(null);
                      document.getElementById('kite-page-address')?.focus();
                    }}
                  />
                )}
              </span>
            </div>
            {deviceToggle}
          </div>
          {addressStatus && addressStatus.kind !== 'saving' && (
            <p
              className={`m-0 text-xs ${
                addressStatus.kind === 'error'
                  ? 'text-fg-negative'
                  : 'text-fg-subtle'
              }`}
              role="status"
            >
              {addressStatus.kind === 'error'
                ? addressStatus.message
                : WIZARD_COPY.addressSaved}
            </p>
          )}
        </div>
      );
    })();

    const preview = (() => {
      const common = { device };
      if (!writesHere) {
        return (
          <PreviewPane {...common}>
            <p className="text-fg-subtle m-0 max-w-sm text-sm">
              {WIZARD_COPY.mainBlurb}
            </p>
          </PreviewPane>
        );
      }
      if (
        chosenIdea &&
        (selectedState?.kind === 'created' || selectedState?.kind === 'live')
      ) {
        const styleFix =
          selectedState.kind === 'created' ? selectedState.styleFix : null;
        const notes =
          selectedState.kind === 'created' ? (selectedState.notes ?? []) : [];
        return (
          <PreviewPane
            {...common}
            frame={{
              src: previewFrameSrc(selectedState.slug),
              title: WIZARD_COPY.previewFrameTitle(chosenIdea.title),
              version: styleFix ?? undefined,
            }}
            changes={{ summary: WIZARD_COPY.pageNotes(notes.length), notes }}
            note={
              styleFix === 'pending' ? (
                <>
                  <Spinner className="size-4" aria-hidden />
                  {WIZARD_COPY.styleFixPending}
                </>
              ) : styleFix === 'applied' ? (
                WIZARD_COPY.styleFixApplied
              ) : styleFix === 'failed' ? (
                WIZARD_COPY.styleFixFailed
              ) : null
            }
          />
        );
      }
      if (chosenIdea && selectedState?.kind === 'writing') {
        return (
          <PreviewPane {...common}>
            <Spinner className="size-6" aria-hidden />
            <p className="text-fg-normal m-0 text-sm font-medium" role="status">
              {WIZARD_COPY.writingFromIdea(chosenIdea.title)}
            </p>
            <p className="text-fg-subtle m-0 max-w-sm text-sm">
              {WIZARD_COPY.writingBlurb}
            </p>
          </PreviewPane>
        );
      }
      if (chosenIdea && selectedState?.kind === 'adding') {
        return (
          <PreviewPane {...common}>
            <Spinner className="size-6" aria-hidden />
            <p className="text-fg-normal m-0 text-sm font-medium" role="status">
              {onMain
                ? WIZARD_COPY.addingToSiteFromIdea(chosenIdea.title)
                : WIZARD_COPY.addingFromIdea(chosenIdea.title)}
            </p>
            <p className="text-fg-subtle m-0 max-w-sm text-sm">
              {onMain ? WIZARD_COPY.addingToSiteBlurb : WIZARD_COPY.addingBlurb}
            </p>
          </PreviewPane>
        );
      }
      if (chosenIdea && selectedState?.kind === 'removing') {
        return (
          <PreviewPane {...common}>
            <Spinner className="size-6" aria-hidden />
            <p className="text-fg-normal m-0 text-sm font-medium" role="status">
              {WIZARD_COPY.removingFromIdea(chosenIdea.title)}
            </p>
          </PreviewPane>
        );
      }
      if (chosenIdea && selectedState?.kind === 'added') {
        // In a draft the page was added to this draft: this site serves it.
        if (!onMain)
          return (
            <PreviewPane
              {...common}
              frame={{
                src: previewFrameSrc(selectedState.slug),
                title: WIZARD_COPY.previewFrameTitle(chosenIdea.title),
              }}
            />
          );
        const url =
          addedPreview && addedPreview.key === addedKey
            ? addedPreview.url
            : null;
        if (url === '')
          return (
            <PreviewPane {...common}>
              <p className="text-fg-subtle m-0 max-w-sm text-sm" role="status">
                {WIZARD_COPY.addedPreviewUnavailable}
              </p>
            </PreviewPane>
          );
        if (url)
          return (
            <PreviewPane
              {...common}
              frame={{
                src: url,
                title: WIZARD_COPY.previewFrameTitle(chosenIdea.title),
              }}
            />
          );
        return (
          <PreviewPane {...common}>
            <Spinner className="size-6" aria-hidden />
            <p className="text-fg-normal m-0 text-sm font-medium" role="status">
              {WIZARD_COPY.addedPreviewStarting}
            </p>
          </PreviewPane>
        );
      }
      if (chosenIdea && selectedState?.kind === 'failed') {
        return (
          <PreviewPane {...common}>
            <p className="text-fg-negative m-0 max-w-sm text-sm" role="alert">
              {statusLabel(selectedState)}
            </p>
          </PreviewPane>
        );
      }
      // Nothing written for this choice yet. The preview shows only a page
      // that exists: another page here would read as the new one. A picked
      // idea shows what it would become instead.
      if (chosenIdea) {
        return (
          <PreviewPane {...common}>
            <IdeaSuggestion
              title={chosenIdea.title}
              pageType={chosenIdea.page_type}
              rationale={chosenIdea.rationale}
              questions={chosenIdea.target_questions}
              related={chosenIdea.related}
              evidence={chosenIdea.evidence}
              locked={busy !== null || replacingIdeaId !== null || spotPending}
              labels={{
                pageType:
                  WIZARD_COPY.suggestionType[chosenIdea.page_type] ??
                  WIZARD_COPY.suggestionType.custom,
                why: WIZARD_COPY.suggestionWhy,
                questions: WIZARD_COPY.suggestionQuestions,
                related: WIZARD_COPY.suggestionRelated,
                evidence: WIZARD_COPY.suggestionEvidence,
                generate: WIZARD_COPY.suggestionGenerate,
              }}
              onGenerate={() => handleGenerate(chosenIdea)}
            />
          </PreviewPane>
        );
      }
      return (
        <PreviewPane {...common}>
          <Icon
            icon={FileTextIcon}
            size="lg"
            className="text-fg-subtle"
            aria-hidden
          />
          <p className="text-fg-subtle m-0 max-w-sm text-sm">
            {WIZARD_COPY.previewNothingPicked}
          </p>
        </PreviewPane>
      );
    })();

    return (
      <Card className="mb-3 gap-4 py-5" {...WIZARD_ACTIVE_ATTR}>
        <div className="flex flex-col gap-5 px-5">
          <div className="grid items-start gap-5 min-[1100px]:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
            <div className="flex min-w-0 flex-col gap-4">
              {modeTabs}
              <h2 className="text-fg-normal m-0 text-xl font-semibold">
                {WIZARD_COPY.heading}
              </h2>

              {error && (
                <div className="flex flex-wrap items-center gap-3">
                  <p className="text-fg-negative m-0 text-sm" role="alert">
                    {error}
                  </p>
                  {suggestRetry && (
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      disabled={suggesting}
                      onClick={() => void handleSuggest()}
                    >
                      {COPY.retrySuggest}
                    </Button>
                  )}
                </div>
              )}

              {writesHere && (
                <StepCard step={1} title={WIZARD_COPY.locationTitle}>
                  <div
                    role="radiogroup"
                    aria-label={WIZARD_COPY.locationTitle}
                    className="flex flex-col gap-3 min-[560px]:flex-row"
                  >
                    <OptionCard
                      icon={HouseIcon}
                      title={WIZARD_COPY.topLevel}
                      selected={!underPage}
                      onSelect={() =>
                        chooseSpot({ spot: '', underPage: false })
                      }
                    />
                    <OptionCard
                      icon={FolderTreeIcon}
                      title={WIZARD_COPY.underPage}
                      selected={underPage}
                      disabled={parentChoices.length === 0}
                      onSelect={() => chooseSpot({ spot: '', underPage: true })}
                    />
                  </div>
                  {underPage && (
                    <div className="flex flex-col gap-1.5">
                      <span className="text-fg-normal text-sm font-medium">
                        {WIZARD_COPY.choosePage}
                      </span>
                      <Select
                        value={spot || undefined}
                        onValueChange={(value) =>
                          chooseSpot({ spot: value, underPage: true })
                        }
                      >
                        <SelectTrigger
                          className="w-full"
                          aria-label={WIZARD_COPY.choosePage}
                        >
                          <SelectValue
                            placeholder={WIZARD_COPY.choosePagePlaceholder}
                          />
                        </SelectTrigger>
                        <SelectContent className="border-bd-neutral-subtle shadow-lg">
                          {parentChoices.map((page) => (
                            <SelectItem key={page.slug} value={page.slug}>
                              {page.title || page.slug}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </StepCard>
              )}

              <StepCard
                step={writesHere ? 2 : 1}
                title={WIZARD_COPY.ideasTitle}
                description={
                  spotPending ? WIZARD_COPY.chooseParentFirst : undefined
                }
                action={
                  !spotPending && (
                    <div className="flex shrink-0 items-center gap-2">
                      {suggesting && (
                        <span className="text-fg-subtle text-xs" role="status">
                          {suggestingLabel(openIdeas.length)}
                        </span>
                      )}
                    </div>
                  )
                }
              >
                {spotPending ? null : listLoading ? (
                  <div className="grid gap-2 min-[560px]:grid-cols-2">
                    {[0, 1, 2, 3].map((key) => (
                      <Skeleton key={key} className="h-16" />
                    ))}
                  </div>
                ) : openIdeas.length === 0 ? (
                  <p className="text-fg-subtle m-0 text-sm">
                    {spotIdeas.length === 0
                      ? COPY.ideasEmpty
                      : COPY.ideasAllPlaced}
                  </p>
                ) : (
                  <div
                    ref={setIdeaList}
                    role="radiogroup"
                    aria-label={WIZARD_COPY.ideasTitle}
                    className="grid gap-2 overflow-y-auto p-px min-[560px]:grid-cols-2"
                    style={
                      ideaListMaxHeight
                        ? { maxHeight: `${ideaListMaxHeight}px` }
                        : undefined
                    }
                  >
                    {openIdeas.map((idea) => {
                      const state = stateOf(idea);
                      return (
                        <IdeaCard
                          key={idea.id}
                          title={idea.title}
                          rationale={idea.rationale}
                          pageType={idea.page_type}
                          state={state}
                          selected={idea.id === selectedIdeaId}
                          replacing={replacingIdeaId === idea.id}
                          locked={
                            busy !== null ||
                            replacingIdeaId !== null ||
                            spotPending
                          }
                          customized={idea.id in details}
                          onDetails={() => {
                            if (idea.id !== selectedIdeaId) selectIdea(idea);
                            openDetails(idea);
                          }}
                          labels={{
                            details: WIZARD_COPY.ideaDetails(idea.title),
                            replace: WIZARD_COPY.replaceIdea(idea.title),
                            generate: WIZARD_COPY.generateIdea(idea.title),
                            retry: WIZARD_COPY.retryIdea(idea.title),
                            rewrite: WIZARD_COPY.rewriteIdea(idea.title),
                            add: onMain
                              ? WIZARD_COPY.addPageToSite(idea.title)
                              : WIZARD_COPY.addPage(idea.title),
                            addTip: onMain
                              ? WIZARD_COPY.addToSiteTip
                              : WIZARD_COPY.addTip,
                            remove: WIZARD_COPY.removePage(idea.title),
                            discard: WIZARD_COPY.discardPage(idea.title),
                            dismiss:
                              state.kind === 'created'
                                ? COPY.dismissWritten(idea.title)
                                : COPY.dismiss(idea.title),
                            status: statusLabel(state),
                          }}
                          onSelect={() =>
                            idea.id === selectedIdeaId
                              ? clearSelection()
                              : selectIdea(idea)
                          }
                          onReplace={() => void handleReplaceIdea(idea)}
                          onGenerate={() => handleGenerate(idea)}
                          onAdd={() => {
                            if (state.kind === 'created' && state.pageId)
                              void handleAddPage(idea, state.pageId);
                          }}
                          onRemove={() => void handleRemovePage(idea, state)}
                          onDiscard={() => {
                            if (state.kind === 'created' && state.pageId)
                              void handleDiscardPage(state.pageId);
                          }}
                          onRewrite={() => {
                            if (state.kind === 'created')
                              setConfirmingRewrite({
                                ideaId: idea.id,
                                slug: state.slug,
                                pageId: state.pageId,
                              });
                          }}
                          onDismiss={() => {
                            if (idea.id === selectedIdeaId) clearSelection();
                            void handleDismiss(idea.id);
                          }}
                        />
                      );
                    })}
                    {lookingForMore &&
                      [0, 1].map((key) => (
                        <Skeleton key={`more-${key}`} className="h-16" />
                      ))}
                  </div>
                )}
                {!spotPending && !listLoading && (
                  <Button
                    type="button"
                    variant="outline"
                    className="mx-auto mt-3 flex"
                    disabled={lookingForMore || busy !== null}
                    onClick={() => setMoreOpen(true)}
                  >
                    {suggestingMore ? (
                      <Spinner className="size-4" aria-hidden />
                    ) : (
                      <Icon icon={PlusIcon} size="sm" aria-hidden />
                    )}
                    {suggestingMore
                      ? suggestingLabel(openIdeas.length)
                      : COPY.addMore}
                  </Button>
                )}
              </StepCard>
            </div>

            {/* Below Payload's own sticky bar, which stays on screen as the page
                scrolls. */}
            <div className="flex min-w-0 flex-col gap-3 min-[1100px]:sticky min-[1100px]:top-[calc(var(--doc-controls-height,56px)+16px)]">
              {addressBar ?? (
                <div className="flex justify-end">{deviceToggle}</div>
              )}
              {preview}
            </div>
          </div>
          {/* No form element: React's submit event bubbles through the portal
              into Payload's document form and its save. */}
          <Dialog open={moreOpen} onOpenChange={setMoreOpen}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{COPY.suggestMore}</DialogTitle>
                <DialogDescription>{COPY.suggestMoreBlurb}</DialogDescription>
              </DialogHeader>
              <Textarea
                value={moreDirection}
                maxLength={500}
                rows={3}
                aria-label={COPY.suggestMoreLabel}
                placeholder={COPY.suggestMorePlaceholder}
                onChange={(event) => setMoreDirection(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key !== 'Enter' || event.shiftKey) return;
                  event.preventDefault();
                  setMoreOpen(false);
                  void handleSuggest({ direction: moreDirection });
                }}
              />
              <DialogFooter>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setMoreOpen(false)}
                >
                  {WIZARD_COPY.cancel}
                </Button>
                <Button
                  type="button"
                  onClick={() => {
                    setMoreOpen(false);
                    void handleSuggest({ direction: moreDirection });
                  }}
                >
                  <Icon icon={SparklesIcon} size="sm" aria-hidden />
                  {COPY.suggestMoreSubmit}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          <Dialog
            open={rewriting !== null}
            onOpenChange={(open) => !open && setConfirmingRewrite(null)}
          >
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{WIZARD_COPY.rewriteTitle}</DialogTitle>
                <DialogDescription>
                  {confirmingRewrite &&
                    WIZARD_COPY.rewriteConfirm(
                      previewPath(confirmingRewrite.slug),
                    )}
                </DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setConfirmingRewrite(null)}
                >
                  {WIZARD_COPY.cancel}
                </Button>
                <Button
                  type="button"
                  onClick={() => {
                    if (!rewriting || !confirmingRewrite) return;
                    const { slug, pageId } = confirmingRewrite;
                    setConfirmingRewrite(null);
                    if (rewriting.id !== selectedIdeaId) selectIdea(rewriting);
                    if (onMain) {
                      // Nothing on Main is live yet: the old version goes and
                      // a new one is written at the same address.
                      const cut = slug.lastIndexOf('/');
                      void (async () => {
                        if (pageId) await handleDiscardPage(pageId);
                        await handleCreateFromIdea(
                          rewriting,
                          placementFor(cut >= 0 ? slug.slice(0, cut) : '', {
                            slug: slug.slice(cut + 1),
                            ...choicesFor(rewriting),
                          }),
                        );
                      })();
                      return;
                    }
                    void handleCreateFromIdea(rewriting, {
                      rewriteSlug: slug,
                      ...rewriteChoices,
                    });
                  }}
                >
                  {WIZARD_COPY.rewrite}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          <Dialog
            open={detailsFor !== null}
            onOpenChange={(open) => !open && setDetailsFor(null)}
          >
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{WIZARD_COPY.detailsTitle}</DialogTitle>
                <DialogDescription>
                  {ideas.find((idea) => idea.id === detailsFor?.ideaId)
                    ?.title ?? ''}
                </DialogDescription>
              </DialogHeader>
              <label className="flex flex-col gap-1.5">
                <span className="text-fg-normal text-sm font-medium">
                  {WIZARD_COPY.purposeLabel}
                </span>
                <Textarea
                  autoFocus
                  rows={4}
                  maxLength={PURPOSE_MAX_LENGTH}
                  value={detailsDraft.purpose}
                  placeholder={WIZARD_COPY.ideaPlaceholder}
                  onChange={(event) =>
                    setDetailsDraft((current) => ({
                      ...current,
                      purpose: event.target.value,
                    }))
                  }
                  onKeyDown={(event) => {
                    // Enter saves; Shift+Enter keeps a new line. The admin's
                    // own form must never see it.
                    if (event.key === 'Enter' && !event.shiftKey) {
                      event.preventDefault();
                      saveDetails();
                    }
                  }}
                />
                <span className="text-fg-subtle self-end text-xs">
                  {detailsDraft.purpose.length}/{PURPOSE_MAX_LENGTH}
                </span>
              </label>
              {writesHere && (
                <div className="flex flex-col gap-2">
                  <span className="text-fg-normal text-sm font-medium">
                    {WIZARD_COPY.toneLabel}{' '}
                    <span className="text-fg-subtle font-normal">
                      {WIZARD_COPY.optional}
                    </span>
                  </span>
                  <ToneChips
                    tones={TONES}
                    value={detailsDraft.tone}
                    customLabel={WIZARD_COPY.customTone}
                    onChange={(next) =>
                      setDetailsDraft((current) => ({ ...current, tone: next }))
                    }
                  />
                  {detailsDraft.tone === 'custom' && (
                    <Input
                      aria-label={WIZARD_COPY.customToneLabel}
                      placeholder={WIZARD_COPY.customTonePlaceholder}
                      value={detailsDraft.customTone}
                      maxLength={80}
                      onChange={(event) =>
                        setDetailsDraft((current) => ({
                          ...current,
                          customTone: event.target.value,
                        }))
                      }
                      onKeyDown={(event) => {
                        if (event.key === 'Enter') event.preventDefault();
                      }}
                    />
                  )}
                </div>
              )}
              <DialogFooter>
                <Button
                  type="button"
                  variant="ghost"
                  onClick={() => setDetailsFor(null)}
                >
                  {WIZARD_COPY.cancel}
                </Button>
                <Button type="button" onClick={saveDetails}>
                  {WIZARD_COPY.saveDetails}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </Card>
    );
  }

  // Manual: just the tabs above Payload's own form, plus the reason when an AI
  // run fell back here because its save was refused.
  return (
    <Card className="mb-3 gap-4 py-5">
      <div className="flex flex-col gap-3 px-5">
        {modeTabs}
        {error && (
          <p className="text-fg-negative m-0 text-sm" role="alert">
            {error}
          </p>
        )}
      </div>
    </Card>
  );
};
