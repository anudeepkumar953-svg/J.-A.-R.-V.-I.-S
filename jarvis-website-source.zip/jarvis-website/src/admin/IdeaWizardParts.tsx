'use client';

import type { ReactNode } from 'react';
import { Button } from '@appsmithorg/kite-ui/components/button';
import { Icon } from '@appsmithorg/kite-ui/components/icon';
import { Spinner } from '@appsmithorg/kite-ui/components/spinner';
import { Tooltip } from '@appsmithorg/kite-ui/components/tooltip';
import {
  AlignLeftIcon,
  BookOpenIcon,
  BriefcaseIcon,
  CheckIcon,
  CircleAlertIcon,
  CircleHelpIcon,
  CoffeeIcon,
  FileTextIcon,
  ListOrderedIcon,
  MinusIcon,
  MonitorIcon,
  PlusIcon,
  RotateCwIcon,
  ScaleIcon,
  SlidersHorizontalIcon,
  SmartphoneIcon,
  SmileIcon,
  SparklesIcon,
  StarIcon,
  Trash2Icon,
} from 'lucide-react';
import {
  PREVIEW_WIDTHS,
  type IdeaRowState,
  type PreviewDevice,
} from './ideaWizard';

// The pieces of the AI tab's create-a-page layout: numbered step cards on the
// left, the live preview on the right.

type Glyph = Parameters<typeof Icon>[0]['icon'];

const SELECTED =
  'border-bd-focus bg-bg-primary/5 ring-1 ring-[var(--color-bd-focus)]';
const UNSELECTED = 'border-bd-neutral-subtle hover:bg-bg-neutral-subtle-hover';

/** One numbered step of the form. */
export function StepCard({
  step,
  title,
  description,
  action,
  children,
}: {
  step: number;
  title: string;
  description?: string;
  action?: ReactNode;
  children: ReactNode;
}) {
  return (
    <section className="flex flex-col gap-4">
      <header className="flex items-start gap-3">
        <span
          className="bg-bg-primary/15 text-fg-primary-emphasis flex size-7 shrink-0 items-center justify-center rounded-full text-sm font-semibold"
          aria-hidden
        >
          {step}
        </span>
        <div className="flex min-w-0 flex-1 flex-col gap-0.5">
          <h3 className="text-fg-normal m-0 text-base leading-7 font-semibold">
            {title}
          </h3>
          {description && (
            <p className="text-fg-subtle m-0 text-sm">{description}</p>
          )}
        </div>
        {action}
      </header>
      {children}
    </section>
  );
}

/** A large radio choice with an icon, title and line of explanation. */
export function OptionCard({
  icon,
  title,
  selected,
  disabled,
  onSelect,
}: {
  icon: Glyph;
  title: string;
  selected: boolean;
  disabled?: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={selected}
      disabled={disabled}
      onClick={onSelect}
      className={`flex flex-1 cursor-pointer items-center gap-3 rounded-lg border bg-transparent p-3 text-left transition-colors disabled:cursor-not-allowed disabled:opacity-50 ${
        selected ? SELECTED : UNSELECTED
      }`}
    >
      <span className="bg-bg-neutral-subtle text-fg-neutral flex size-9 shrink-0 items-center justify-center rounded-md">
        <Icon icon={icon} size="sm" aria-hidden />
      </span>
      <span className="flex min-w-0 flex-1 flex-col gap-0.5">
        <span
          className={`text-sm font-semibold ${
            selected ? 'text-fg-primary-emphasis' : 'text-fg-normal'
          }`}
        >
          {title}
        </span>
      </span>
      <RadioMark selected={selected} />
    </button>
  );
}

function RadioMark({ selected }: { selected: boolean }) {
  return selected ? (
    <span className="bg-bg-primary text-fg-on-primary flex size-4 shrink-0 items-center justify-center rounded-full">
      <Icon icon={CheckIcon} size="xs" aria-hidden />
    </span>
  ) : (
    <span
      className="border-bd-neutral size-4 shrink-0 rounded-full border"
      aria-hidden
    />
  );
}

const TONE_ICONS: Record<string, Glyph> = {
  Friendly: SmileIcon,
  Professional: BriefcaseIcon,
  Casual: CoffeeIcon,
  Enthusiastic: StarIcon,
  Concise: AlignLeftIcon,
  custom: SlidersHorizontalIcon,
};

/** Optional tone: one chip at a time, clicked again to clear. */
export function ToneChips({
  tones,
  value,
  customLabel,
  onChange,
}: {
  tones: readonly string[];
  value: string | null;
  customLabel: string;
  onChange: (next: string | null) => void;
}) {
  return (
    <div className="flex flex-wrap gap-2">
      {[...tones, 'custom'].map((tone) => {
        const selected = value === tone;
        return (
          <button
            key={tone}
            type="button"
            aria-pressed={selected}
            onClick={() => onChange(selected ? null : tone)}
            className={`text-fg-normal flex cursor-pointer items-center gap-1.5 rounded-md border bg-transparent px-3 py-1.5 text-sm transition-colors ${
              selected ? `${SELECTED} text-fg-primary-emphasis` : UNSELECTED
            }`}
          >
            <Icon icon={TONE_ICONS[tone] ?? SmileIcon} size="sm" aria-hidden />
            {tone === 'custom' ? customLabel : tone}
          </button>
        );
      })}
    </div>
  );
}

/**
 * An icon-only button with the platform's tooltip. The tooltip is a short
 * verb ("Add to draft"); `label`, its accessible name, can say which idea it
 * acts on, since a screen reader hears every card's buttons in a row.
 */
export function IconButton({
  label,
  tip,
  icon,
  iconClassName,
  size = 'icon-xs',
  variant = 'ghost',
  disabled,
  onClick,
  pressed,
  className,
}: {
  label: string;
  tip?: string;
  icon: Glyph;
  iconClassName?: string;
  size?: 'icon-xs' | 'icon-sm' | 'icon';
  variant?: 'ghost' | 'default' | 'outline';
  disabled?: boolean;
  onClick: () => void;
  pressed?: boolean;
  className?: string;
}) {
  return (
    <Tooltip content={tip ?? label}>
      <Button
        type="button"
        size={size}
        variant={variant}
        aria-label={label}
        aria-pressed={pressed}
        className={className}
        disabled={disabled}
        onClick={onClick}
      >
        <Icon
          icon={icon}
          size={size === 'icon-xs' ? 'xs' : 'sm'}
          className={iconClassName}
          aria-hidden
        />
      </Button>
    </Tooltip>
  );
}

// What each card button's tooltip says: the verb alone, the card shows which
// idea it is.
const TIPS = {
  details: 'Details',
  replace: 'New idea',
  rewrite: 'Rewrite',
  dismiss: 'Remove',
  discard: 'Discard',
  generate: 'Generate',
  retry: 'Try again',
  remove: 'Remove from draft',
} as const;

const PAGE_TYPE_ICONS: Record<string, Glyph> = {
  solution: BriefcaseIcon,
  guide: BookOpenIcon,
  howto: ListOrderedIcon,
  comparison: ScaleIcon,
  faq: CircleHelpIcon,
  custom: FileTextIcon,
};

/**
 * One idea in the grid. Selecting it picks the page to write; its corner shows
 * how that page is doing. Details opens its brief and tone; replace and remove
 * appear on hover.
 */
export function IdeaCard({
  title,
  rationale,
  pageType,
  state,
  selected,
  replacing,
  locked,
  customized,
  labels,
  onSelect,
  onDetails,
  onReplace,
  onGenerate,
  onRewrite,
  onAdd,
  onRemove,
  onDiscard,
  onDismiss,
}: {
  title: string;
  rationale?: string | null;
  pageType?: string;
  state: IdeaRowState;
  selected: boolean;
  replacing: boolean;
  locked: boolean;
  /** The editor gave this idea a brief or tone of their own. */
  customized: boolean;
  labels: {
    details: string;
    replace: string;
    generate: string;
    add: string;
    /** Where the add puts the page: the open draft, or the site on Main. */
    addTip: string;
    discard: string;
    retry: string;
    rewrite: string;
    dismiss: string;
    remove: string;
    status: string | null;
  };
  onSelect: () => void;
  onDetails: () => void;
  onGenerate: () => void;
  onAdd: () => void;
  onRemove: () => void;
  onDiscard: () => void;
  onRewrite: () => void;
  onReplace: () => void;
  onDismiss: () => void;
}) {
  // Moving a page into or out of a draft runs like writing it.
  const writing =
    state.kind === 'writing' ||
    state.kind === 'adding' ||
    state.kind === 'removing';
  const created = state.kind === 'created';
  // Merged into Main: edited there like any page, so no draft actions.
  const live = state.kind === 'live';
  // Written but not in the draft yet: added with the card's action, or
  // discarded with its bin.
  const proposed = state.kind === 'created' && state.proposed === true;
  // In the draft: moved into one from Main, or added inside this draft.
  const added = state.kind === 'added' || (created && !proposed);
  const failed = state.kind === 'failed';
  return (
    <div
      className={`group relative flex items-start gap-3 rounded-lg border p-3 transition-colors ${
        selected ? SELECTED : UNSELECTED
      }`}
    >
      <button
        type="button"
        role="radio"
        aria-checked={selected}
        aria-label={title}
        onClick={onSelect}
        title={rationale ?? undefined}
        className="absolute inset-0 cursor-pointer rounded-lg border-0 bg-transparent"
      />
      <span className="text-fg-neutral pointer-events-none mt-0.5 shrink-0">
        <Icon
          icon={PAGE_TYPE_ICONS[pageType ?? ''] ?? FileTextIcon}
          size="sm"
          aria-hidden
        />
      </span>
      <span className="pointer-events-none flex min-w-0 flex-1 flex-col gap-0.5">
        <span className="text-fg-normal truncate text-sm font-semibold">
          {title}
        </span>
        {labels.status ? (
          <span
            className={`truncate text-xs ${failed ? 'text-fg-negative' : 'text-fg-subtle'}`}
            role={writing ? 'status' : undefined}
          >
            {labels.status}
          </span>
        ) : (
          rationale && (
            <span className="text-fg-subtle line-clamp-1 text-xs">
              {rationale}
            </span>
          )
        )}
      </span>
      <span className="relative flex shrink-0 items-center gap-0.5">
        <IconButton
          label={labels.details}
          tip={TIPS.details}
          icon={SlidersHorizontalIcon}
          iconClassName={customized ? 'text-fg-primary-emphasis' : undefined}
          onClick={onDetails}
        />
        <span className="flex items-center gap-0.5 opacity-0 transition-opacity group-focus-within:opacity-100 group-hover:opacity-100">
          {/* One fixed slot, so the icons line up on every card: a written
              page is rewritten in place, any other idea is replaced. */}
          {writing || state.kind === 'added' || live ? (
            // A page moved into a draft from Main is edited in that draft;
            // the slot keeps the icons aligned.
            <span className="size-7 shrink-0" aria-hidden />
          ) : created ? (
            <IconButton
              label={labels.rewrite}
              tip={TIPS.rewrite}
              icon={RotateCwIcon}
              disabled={locked}
              onClick={onRewrite}
            />
          ) : (
            <IconButton
              label={labels.replace}
              tip={TIPS.replace}
              icon={RotateCwIcon}
              iconClassName={replacing ? 'animate-spin' : undefined}
              disabled={locked}
              onClick={onReplace}
            />
          )}
          <IconButton
            label={proposed ? labels.discard : labels.dismiss}
            tip={proposed ? TIPS.discard : TIPS.dismiss}
            icon={Trash2Icon}
            disabled={writing || added || replacing || locked}
            onClick={proposed ? onDiscard : onDismiss}
          />
        </span>
        {/* Where the radio was: the card's own action, one fixed width on
            every card so the icons before it line up down the column. */}
        <span className="flex w-8 shrink-0 justify-end">
          {writing ? (
            <span className="flex size-8 items-center justify-center">
              <Spinner className="size-4" aria-hidden />
            </span>
          ) : live ? (
            <span className="flex size-8 items-center justify-center">
              <Icon
                icon={CheckIcon}
                size="sm"
                className="text-fg-subtle"
                aria-hidden
              />
            </span>
          ) : added ? (
            <IconButton
              label={labels.remove}
              tip={TIPS.remove}
              icon={MinusIcon}
              size="icon-sm"
              variant="outline"
              disabled={locked}
              onClick={onRemove}
            />
          ) : proposed ? (
            <IconButton
              label={labels.add}
              tip={labels.addTip}
              icon={PlusIcon}
              size="icon-sm"
              variant="default"
              disabled={locked}
              onClick={onAdd}
            />
          ) : (
            <IconButton
              label={failed ? labels.retry : labels.generate}
              tip={failed ? TIPS.retry : TIPS.generate}
              icon={failed ? CircleAlertIcon : SparklesIcon}
              size="icon-sm"
              iconClassName={
                failed ? 'text-fg-negative' : 'text-fg-primary-emphasis'
              }
              disabled={locked || replacing}
              onClick={onGenerate}
            />
          )}
        </span>
      </span>
    </div>
  );
}

function isWebLink(url: string): boolean {
  try {
    const { protocol } = new URL(url);
    return protocol === 'https:' || protocol === 'http:';
  } catch {
    return false;
  }
}

/**
 * What a not-yet-written idea would become: the suggestion itself, with the
 * same Generate the card offers, so the editor can judge it before writing.
 */
export function IdeaSuggestion({
  title,
  pageType,
  rationale,
  questions,
  related,
  evidence,
  locked,
  labels,
  onGenerate,
}: {
  title: string;
  pageType?: string | null;
  rationale?: string | null;
  questions?: string[];
  // The pages and ideas this page links with once both are on the site.
  related?: { title?: string }[];
  evidence?: { url: string; title?: string }[];
  locked: boolean;
  labels: {
    pageType: string;
    why: string;
    questions: string;
    related: string;
    evidence: string;
    generate: string;
  };
  onGenerate: () => void;
}) {
  const asked = (questions ?? []).filter((q) => q.trim());
  const sources = (evidence ?? []).filter((item) => isWebLink(item.url));
  const linked = (related ?? [])
    .map((item) => item.title?.trim() ?? '')
    .filter(Boolean);
  return (
    <div className="flex max-h-full w-full max-w-md flex-col gap-4 overflow-y-auto text-left">
      <div className="flex items-start gap-3">
        <span className="bg-bg-card flex size-9 shrink-0 items-center justify-center rounded-md">
          <Icon
            icon={PAGE_TYPE_ICONS[pageType ?? ''] ?? FileTextIcon}
            size="sm"
            className="text-fg-subtle"
            aria-hidden
          />
        </span>
        <div className="flex min-w-0 flex-col gap-0.5">
          <span className="text-fg-subtle text-xs">{labels.pageType}</span>
          <h3 className="text-fg-normal m-0 text-base font-semibold">
            {title}
          </h3>
        </div>
      </div>
      {rationale?.trim() && (
        <section className="flex flex-col gap-1">
          <h4 className="text-fg-subtle m-0 text-xs font-medium">
            {labels.why}
          </h4>
          <p className="text-fg-normal m-0 text-sm">{rationale}</p>
        </section>
      )}
      {asked.length > 0 && (
        <section className="flex flex-col gap-1">
          <h4 className="text-fg-subtle m-0 text-xs font-medium">
            {labels.questions}
          </h4>
          <ul className="text-fg-normal m-0 flex list-disc flex-col gap-1 pl-5 text-sm">
            {asked.map((question) => (
              <li key={question}>{question}</li>
            ))}
          </ul>
        </section>
      )}
      {linked.length > 0 && (
        <section className="flex flex-col gap-1">
          <h4 className="text-fg-subtle m-0 text-xs font-medium">
            {labels.related}
          </h4>
          <ul className="text-fg-normal m-0 flex list-disc flex-col gap-1 pl-5 text-sm">
            {linked.map((name) => (
              <li key={name}>{name}</li>
            ))}
          </ul>
        </section>
      )}
      {sources.length > 0 && (
        <section className="flex flex-col gap-1">
          <h4 className="text-fg-subtle m-0 text-xs font-medium">
            {labels.evidence}
          </h4>
          <ul className="m-0 flex list-none flex-col gap-1 p-0 text-sm">
            {sources.map((item) => (
              <li key={item.url} className="min-w-0 truncate">
                <a
                  href={item.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-fg-primary-emphasis underline-offset-2 hover:underline"
                >
                  {item.title?.trim() || new URL(item.url).hostname}
                </a>
              </li>
            ))}
          </ul>
        </section>
      )}
      <Button
        type="button"
        className="self-start"
        disabled={locked}
        onClick={onGenerate}
      >
        <Icon icon={SparklesIcon} size="sm" aria-hidden />
        {labels.generate}
      </Button>
    </div>
  );
}

// The pane sticks below Payload's own bar and must fit the screen there:
// a sticky box taller than the screen scrolls away regardless. The rest of
// the pane (the address above it, its footer and padding) takes about 200px.
const FRAME_HEIGHT =
  'h-[calc(100vh-var(--doc-controls-height,56px)-200px)] min-h-[360px]';

const DEVICE_ICONS: Record<PreviewDevice, Glyph> = {
  desktop: MonitorIcon,
  mobile: SmartphoneIcon,
};

/** The right-hand pane: a header with width toggles over whatever it shows. */
/** Desktop and mobile widths for the preview. */
export function DeviceToggle({
  device,
  labels,
  onDevice,
}: {
  device: PreviewDevice;
  labels: Record<PreviewDevice, string>;
  onDevice: (next: PreviewDevice) => void;
}) {
  return (
    <div className="flex shrink-0 items-center gap-1">
      {(Object.keys(DEVICE_ICONS) as PreviewDevice[]).map((key) => (
        <IconButton
          key={key}
          label={labels[key]}
          icon={DEVICE_ICONS[key]}
          size="icon"
          variant="outline"
          pressed={device === key}
          className={
            device === key
              ? 'border-bd-focus bg-bg-primary/10 text-fg-primary-emphasis'
              : undefined
          }
          onClick={() => onDevice(key)}
        />
      ))}
    </div>
  );
}

/** The right-hand pane: the page at the chosen width, or a message. */
export function PreviewPane({
  device,
  frame,
  note,
  changes,
  children,
}: {
  device: PreviewDevice;
  // `version` reloads the frame when it changes: the page at `src` was edited.
  frame?: { src: string; title: string; version?: string };
  // A line about the page shown above the frame.
  note?: ReactNode;
  // What the run left out of the page or changed in it, a sentence each.
  changes?: { summary: string; notes: string[] };
  children?: ReactNode;
}) {
  const width = PREVIEW_WIDTHS[device];
  return (
    <aside className="border-bd-neutral-subtle bg-bg-card flex flex-col gap-3 rounded-lg border p-3">
      {frame && note ? (
        <div
          className="text-fg-subtle flex items-center gap-2 text-sm"
          role="status"
        >
          {note}
        </div>
      ) : null}
      {frame && changes && changes.notes.length > 0 ? (
        <details className="text-fg-subtle text-sm">
          <summary className="text-fg-normal cursor-pointer font-medium">
            {changes.summary}
          </summary>
          <ul className="m-0 mt-2 flex list-disc flex-col gap-1 pl-5">
            {changes.notes.map((line, index) => (
              <li key={`${index}-${line}`}>{line}</li>
            ))}
          </ul>
        </details>
      ) : null}
      {frame ? (
        <div className="bg-bg-neutral-subtle flex justify-center overflow-auto rounded-md">
          <iframe
            key={frame.version ?? ''}
            src={frame.src}
            title={frame.title}
            style={{ width: width ? `${width}px` : '100%' }}
            className={`${FRAME_HEIGHT} max-w-full shrink-0 border-0 bg-white`}
          />
        </div>
      ) : (
        <div
          className={`${FRAME_HEIGHT} bg-bg-neutral-subtle flex flex-col items-center justify-center gap-3 rounded-md p-6 text-center`}
        >
          {children}
        </div>
      )}
    </aside>
  );
}
