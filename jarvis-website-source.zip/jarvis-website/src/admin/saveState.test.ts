// Contract for the SaveControls state derivation (KITE-7581). The pin that
// matters: on a CREATE form, a successful submit must read "Saved" and disable
// Save from the control's own state. Payload never refreshes a create form's
// field state (it redirects to the edit view instead), so `dirty` stays true
// and `id` stays unset until that redirect lands — deriving from those alone
// hid the badge and re-enabled Save right after the editor clicked it.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml). Exits non-zero on
// any failure.
//
// Run locally: pnpm exec tsx src/admin/saveState.test.ts

import {
  deriveSaveControls,
  rowOrderChanged,
  type RowOrderFields,
  type SaveSignals,
} from './saveState';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

function expectView(
  name: string,
  signals: SaveSignals,
  expected: ReturnType<typeof deriveSaveControls>,
): void {
  const actual = deriveSaveControls(signals);
  check(
    name,
    actual.state === expected.state &&
      actual.saveDisabled === expected.saveDisabled &&
      actual.showBadge === expected.showBadge,
    `expected ${JSON.stringify(expected)}\n        actual   ${JSON.stringify(actual)}`,
  );
}

const CREATE: SaveSignals = {
  processing: false,
  saveFailed: false,
  dirty: false,
  reordered: false,
  modified: false,
  justSaved: false,
  fillPending: false,
  isUpdate: false,
  hasDocument: false,
};
const UPDATE: SaveSignals = { ...CREATE, isUpdate: true, hasDocument: true };

function main(): void {
  console.log('SaveControls derivation contract');

  console.log('create form');
  expectView(
    'pristine: no badge, Save enabled (nothing to report yet)',
    CREATE,
    {
      state: 'saved',
      saveDisabled: false,
      showBadge: false,
    },
  );
  expectView(
    'edited: Unsaved changes, Save enabled',
    { ...CREATE, dirty: true, modified: true },
    { state: 'unsaved', saveDisabled: false, showBadge: true },
  );
  expectView(
    'submitting: Saving, Save disabled',
    { ...CREATE, dirty: true, modified: true, processing: true },
    { state: 'saving', saveDisabled: true, showBadge: true },
  );
  // Payload resets its `modified` latch the moment the response lands, one
  // frame before it clears `processing`; the badge must not blink out there.
  expectView(
    'response landed, still processing: Saving stays on screen',
    { ...CREATE, dirty: true, modified: false, processing: true },
    { state: 'saving', saveDisabled: true, showBadge: true },
  );
  // The KITE-7581 window: the POST succeeded (Payload reset `modified`), but the
  // redirect to the edit view has not landed — `dirty` is stale-true, no `id`.
  expectView(
    'created, redirect pending: Saved, Save disabled, badge shown',
    { ...CREATE, dirty: true, modified: false, justSaved: true },
    { state: 'saved', saveDisabled: true, showBadge: true },
  );
  // Another submit from the create form can only POST a duplicate (the slug is
  // unique) and would lose this edit when the redirect rehydrates the form.
  expectView(
    'created, then edited before the redirect: Unsaved changes, but Save waits',
    { ...CREATE, dirty: true, modified: true, justSaved: true },
    { state: 'unsaved', saveDisabled: true, showBadge: true },
  );
  expectView(
    'redirect landed, then edited: Unsaved changes, Save enabled',
    { ...UPDATE, dirty: true, modified: true, justSaved: true },
    { state: 'unsaved', saveDisabled: false, showBadge: true },
  );
  expectView(
    'redirect landed (now an update, state refreshed): Saved, Save disabled',
    { ...UPDATE, justSaved: true },
    { state: 'saved', saveDisabled: true, showBadge: true },
  );

  console.log('update form');
  expectView('opened, untouched: Saved, Save disabled', UPDATE, {
    state: 'saved',
    saveDisabled: true,
    showBadge: true,
  });
  expectView(
    'edited: Unsaved changes, Save enabled',
    { ...UPDATE, dirty: true, modified: true },
    { state: 'unsaved', saveDisabled: false, showBadge: true },
  );
  // V2-5802: every edit reverted by hand — Payload's latch stays true, the
  // real diff is clean.
  expectView(
    'edited then reverted by hand: Saved, Save disabled',
    { ...UPDATE, dirty: false, modified: true },
    { state: 'saved', saveDisabled: true, showBadge: true },
  );
  expectView(
    'saved (Payload refreshed state): Saved, Save disabled',
    { ...UPDATE, justSaved: true },
    { state: 'saved', saveDisabled: true, showBadge: true },
  );
  expectView(
    'save rejected by the server: still Unsaved changes, Save enabled',
    { ...UPDATE, dirty: true, modified: false, justSaved: false },
    { state: 'unsaved', saveDisabled: false, showBadge: true },
  );
  expectView(
    'save threw: Could not save, Save enabled for retry',
    { ...UPDATE, dirty: true, saveFailed: true },
    { state: 'error', saveDisabled: false, showBadge: true },
  );

  console.log('precedence');
  expectView(
    'processing wins over everything',
    {
      ...UPDATE,
      dirty: true,
      saveFailed: true,
      justSaved: true,
      processing: true,
    },
    { state: 'saving', saveDisabled: true, showBadge: true },
  );
  expectView(
    'a pending section fill disables Save without changing the badge',
    { ...UPDATE, dirty: true, modified: true, fillPending: true },
    { state: 'unsaved', saveDisabled: true, showBadge: true },
  );
  expectView(
    'a pending section fill disables Save on a create form too',
    { ...CREATE, dirty: true, modified: true, fillPending: true },
    { state: 'unsaved', saveDisabled: true, showBadge: true },
  );

  console.log('row order (KITE-7875)');
  // Dragging a section into a new place: values all still equal their initial
  // values (`dirty` false), only the order differs.
  expectView(
    'reordered: Unsaved changes, Save enabled',
    { ...UPDATE, reordered: true, modified: true },
    { state: 'unsaved', saveDisabled: false, showBadge: true },
  );
  // The order matches the saved document again (dragged back by hand, or the
  // save landed and Payload replaced the saved document): nothing to save.
  expectView(
    'reordered then dragged back: Saved, Save disabled',
    { ...UPDATE, reordered: false, modified: true },
    { state: 'saved', saveDisabled: true, showBadge: true },
  );
  expectView(
    'reorder saved (saved document refreshed): Saved, Save disabled',
    { ...UPDATE, reordered: false, justSaved: true },
    { state: 'saved', saveDisabled: true, showBadge: true },
  );
  // The server rejected the submit: Payload clears its `modified` latch on
  // any response, but the saved document is untouched, so the reorder must
  // still read as unsaved and Save must stay available for a retry.
  expectView(
    'reorder rejected by the server: still Unsaved changes, Save enabled',
    { ...UPDATE, reordered: true, modified: false, justSaved: false },
    { state: 'unsaved', saveDisabled: false, showBadge: true },
  );
  rowOrderChecks();

  if (failures > 0) {
    console.error(`\n${failures} check(s) failed`);
    process.exit(1);
  }
  console.log('\nall checks passed');
}

// A two-section page as Payload's flat form state holds it, the saved
// document it was loaded from, and the same form after `MOVE_ROW`
// (fieldReducer.js) dragged the second section above the first. The reducer
// moves each row's entries wholesale — `initialValue` rides along — and
// rewrites the parent's `rows`; the parent's `value` stays the row count.
// Reproduced here rather than imported because the reducer is not a public
// export of @payloadcms/ui.
type FieldEntry = {
  value?: unknown;
  initialValue?: unknown;
  rows?: { id: string; blockType?: string }[];
};
const SAVED_PAGE = {
  title: 'Home',
  layout: [
    { id: 'row-hero', blockType: 'hero', heading: 'Welcome' },
    { id: 'row-cta', blockType: 'cta', heading: 'Sign up' },
  ],
};
const PAGE: Record<string, FieldEntry> = {
  title: { value: 'Home', initialValue: 'Home' },
  layout: {
    value: 2,
    initialValue: 2,
    rows: [
      { id: 'row-hero', blockType: 'hero' },
      { id: 'row-cta', blockType: 'cta' },
    ],
  },
  'layout.0.id': { value: 'row-hero', initialValue: 'row-hero' },
  'layout.0.heading': { value: 'Welcome', initialValue: 'Welcome' },
  'layout.1.id': { value: 'row-cta', initialValue: 'row-cta' },
  'layout.1.heading': { value: 'Sign up', initialValue: 'Sign up' },
};
const PAGE_REORDERED: Record<string, FieldEntry> = {
  title: PAGE.title,
  'layout.0.id': PAGE['layout.1.id'],
  'layout.0.heading': PAGE['layout.1.heading'],
  'layout.1.id': PAGE['layout.0.id'],
  'layout.1.heading': PAGE['layout.0.heading'],
  layout: {
    ...PAGE.layout,
    rows: [PAGE.layout.rows![1], PAGE.layout.rows![0]],
  },
};

// The per-field predicate SaveControls diffs values with.
function valuesDiffer(fields: Record<string, FieldEntry>): boolean {
  return Object.values(fields).some(
    (field) =>
      JSON.stringify(field.value) !== JSON.stringify(field.initialValue),
  );
}

function rowOrderChecks(): void {
  // The defect: after a pure reorder every field still equals its initial
  // value, so the value diff alone reads the page as clean.
  check(
    'a pure reorder is invisible to the value diff',
    !valuesDiffer(PAGE_REORDERED),
  );
  check(
    'a reorder differs from the saved document',
    rowOrderChanged(PAGE_REORDERED, SAVED_PAGE),
  );
  check(
    'the loaded form matches the saved document',
    !rowOrderChanged(PAGE, SAVED_PAGE),
  );
  // Dragging the section back is a hand revert (V2-5802's rule): clean again.
  const restored: RowOrderFields = {
    ...PAGE_REORDERED,
    layout: { rows: [...PAGE.layout.rows!] },
  };
  check(
    'dragging back to the saved order is clean again',
    !rowOrderChanged(restored, SAVED_PAGE),
  );
  // A successful save replaces the saved document with the new order; a
  // rejected one leaves it alone (the D1-F1 case: the reorder stays unsaved).
  const savedReordered = {
    ...SAVED_PAGE,
    layout: [SAVED_PAGE.layout[1], SAVED_PAGE.layout[0]],
  };
  check(
    'after a successful save the new order is the saved order',
    !rowOrderChanged(PAGE_REORDERED, savedReordered),
  );
  check(
    'after a rejected save the reorder is still a change',
    rowOrderChanged(PAGE_REORDERED, SAVED_PAGE),
  );
  // An array nested inside a block is its own `rows` owner and is covered too.
  const savedNested = {
    ...SAVED_PAGE,
    layout: [
      { ...SAVED_PAGE.layout[0], items: [{ id: 'i-1' }, { id: 'i-2' }] },
      SAVED_PAGE.layout[1],
    ],
  };
  const nested: RowOrderFields = {
    ...PAGE,
    'layout.0.items': { rows: [{ id: 'i-1' }, { id: 'i-2' }] },
  };
  check(
    'a nested array in saved order is clean',
    !rowOrderChanged(nested, savedNested),
  );
  check(
    'a nested array reorder is a change',
    rowOrderChanged(
      { ...PAGE, 'layout.0.items': { rows: [{ id: 'i-2' }, { id: 'i-1' }] } },
      savedNested,
    ),
  );
  // Nothing to compare against: a create form, a saved array whose rows have
  // no ids, a saved field that is not an array.
  check(
    'a create form (no saved document) is clean',
    !rowOrderChanged(PAGE, undefined),
  );
  check(
    'saved rows without ids are left alone',
    !rowOrderChanged(PAGE_REORDERED, {
      layout: [{ blockType: 'hero' }, { blockType: 'cta' }],
    }),
  );
  check(
    'a saved field that is not an array is left alone',
    !rowOrderChanged(PAGE_REORDERED, { layout: 'not-rows' }),
  );
  check(
    'fields without rows are ignored',
    !rowOrderChanged({ title: PAGE.title }, SAVED_PAGE),
  );
}

main();
