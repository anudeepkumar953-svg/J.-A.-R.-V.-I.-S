'use client';

import { useEffect } from 'react';
import type { ReactNode } from 'react';
import { useConfig } from '@payloadcms/ui';
import { usePathname } from 'next/navigation';
import { ADMIN_LOCATION, ADMIN_LOCATION_ACK } from './bridgeProtocol';
import { isEmbedded, requestFromParent } from './parentRpc';

// Reports the admin's current view to the platform content tab. The admin is
// entered through `/admin-login`, which lands wherever the parent's
// `?redirect=` says — so the parent has to know where the editor is for a reload
// of the content tab to reopen the same page instead of the dashboard. Payload's
// client navigations never leave the iframe, so this is the only way that
// location reaches the parent's URL.
//
// Paths are sent relative to the admin route: the dashboard is `''`, which the
// parent treats as "nothing to restore". The parent's reply is a bare ack, so
// the request is fire-and-forget; a parent that never answers costs one timer.
const REQUEST_TIMEOUT_MS = 10_000;

export const LocationSync = ({ children }: { children?: ReactNode }) => {
  const pathname = usePathname();
  const adminRoute = useConfig().config.routes.admin;

  useEffect(() => {
    if (typeof window === 'undefined' || !isEmbedded()) return;
    if (!pathname.startsWith(adminRoute)) return;
    void requestFromParent(
      ADMIN_LOCATION,
      ADMIN_LOCATION_ACK,
      { path: pathname.slice(adminRoute.length) },
      REQUEST_TIMEOUT_MS,
    );
  }, [pathname, adminRoute]);

  return <>{children}</>;
};
