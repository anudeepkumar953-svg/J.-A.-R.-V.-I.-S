// Contract for what the panel sends about the site:
//   - the existing-page list the suggestion step compares against is the
//     whole site, up to the backend cap, not the first response page;
//   - the collections sent to the planner are the site's own content types.
//     Payload registers its bookkeeping collections on every site and the
//     client config strips the `admin.hidden` flag that marks them, so a
//     filter that only knows `users` and `pages` reports four content types
//     on a site that has none — and "has collections" is exactly the gate the
//     planner uses to decide a collection-backed block is buildable.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml). Exits non-zero on
// any failure.
//
// Run locally: pnpm exec tsx src/admin/ideaPanelFlow.test.ts

import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  DESIGN_SAMPLE_PAGE_LIMIT,
  EXISTING_PAGE_CAP,
  NON_CONTENT_COLLECTIONS,
  PAGE_FETCH_PAGE_SIZE,
  collectExistingPages,
  contentCollectionSlugs,
  designSamplePages,
  pageSummaries,
  refusedForCredits,
  type ExistingPagesResult,
  type PageBatch,
} from './ideaPanelFlow';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

type Page = { title: string; slug: string };

function listedPages<T>(result: ExistingPagesResult<T>): T[] | null {
  return result.ok ? result.pages : null;
}

function pages(from: number, count: number): Page[] {
  return Array.from({ length: count }, (_, index) => {
    const n = from + index;
    return { title: `Page ${n}`, slug: `page-${n}` };
  });
}

// --- A duplicate past the first response page ------------------------------
{
  console.log('pages past the first response page still count');
  const first = pages(0, PAGE_FETCH_PAGE_SIZE);
  const duplicate: Page = { title: 'Pricing FAQ', slug: 'pricing-faq' };
  const fetchPage = async (page: number): Promise<PageBatch<Page> | null> => {
    if (page === 1) return { docs: first, hasNextPage: true };
    if (page === 2) return { docs: [duplicate], hasNextPage: false };
    return { docs: [], hasNextPage: false };
  };

  const collected = listedPages(await collectExistingPages(fetchPage));
  const summaries = pageSummaries(collected ?? []);
  const sample = designSamplePages(collected ?? []);

  check(
    'the walk continues past the first page',
    collected !== null && collected.length === PAGE_FETCH_PAGE_SIZE + 1,
  );
  check(
    'a slug on the second page is in the list the plan compares against',
    summaries.some((page) => page.slug === 'pricing-faq'),
  );
  check(
    'the design sample stays the newest page of pages',
    sample.length === DESIGN_SAMPLE_PAGE_LIMIT &&
      !sample.some((page) => page.slug === 'pricing-faq'),
  );
}

// --- The backend cap, not an unbounded walk --------------------------------
{
  console.log('\nthe list stops at the backend cap');
  const fetchPage = async (page: number): Promise<PageBatch<Page>> => ({
    docs: pages((page - 1) * PAGE_FETCH_PAGE_SIZE, PAGE_FETCH_PAGE_SIZE),
    hasNextPage: true,
  });
  const collected = listedPages(await collectExistingPages(fetchPage));
  check(
    'the cap, and no more',
    collected !== null && collected.length === EXISTING_PAGE_CAP,
  );
  check(
    'the page just past the cap is not sent',
    collected !== null &&
      !pageSummaries(collected).some(
        (page) => page.slug === `page-${EXISTING_PAGE_CAP}`,
      ),
  );
}

// --- A failed page is not the end of the site ------------------------------
{
  console.log('\na failed later page is not sent as a complete list');
  const first = pages(0, PAGE_FETCH_PAGE_SIZE);
  const fetchPage = async (page: number): Promise<PageBatch<Page> | null> => {
    if (page === 1) return { docs: first, hasNextPage: true };
    return null;
  };
  const failed = await collectExistingPages(fetchPage);
  const sent = listedPages(failed);
  check(
    'page one succeeding and page two failing is a failure',
    failed.ok === false,
  );
  check(
    'the prefix loaded before the failure is not available to send',
    sent === null,
  );

  const exhausted = listedPages(
    await collectExistingPages(async () => ({ docs: [], hasNextPage: false })),
  );
  check(
    'an empty successful page is the whole site',
    exhausted !== null && exhausted.length === 0,
  );
}

// --- A typed idea in an open draft -----------------------------------------
{
  console.log('\nthe site\u2019s content types, out of everything registered');
  // What `useConfig().config.collections` holds on a Kite site that authored
  // two collections of its own: Payload's bookkeeping and the admin's
  // furniture come with the config, and carry no flag in the browser to tell
  // them apart (`admin.hidden` is server-only).
  const registered = [
    { slug: 'pages' },
    { slug: 'page-proposals' },
    { slug: 'users' },
    { slug: 'posts' },
    { slug: 'payload-kv' },
    { slug: 'payload-locked-documents' },
    { slug: 'payload-preferences' },
    { slug: 'payload-migrations' },
    { slug: 'case-studies' },
  ];
  check(
    'only the collections the site authored reach the planner',
    JSON.stringify(contentCollectionSlugs(registered)) ===
      JSON.stringify(['posts', 'case-studies']),
    JSON.stringify(contentCollectionSlugs(registered)),
  );
  check(
    'a site with no content collections reports none',
    contentCollectionSlugs(
      registered.filter((c) => NON_CONTENT_COLLECTIONS.includes(c.slug)),
    ).length === 0,
  );
  check(
    'and so does a config the admin has not handed over yet',
    contentCollectionSlugs(undefined).length === 0,
  );

  const panel = readFileSync(
    join(dirname(fileURLToPath(import.meta.url)), 'IdeaPanel.tsx'),
    'utf8',
  );
  check(
    'the panel builds its list here rather than filtering the config itself',
    panel.includes('contentCollectionSlugs(config.collections)') &&
      !panel.includes("slug !== 'users'"),
  );
}

{
  console.log('\nno panel button submits the page form around it');
  // The panel renders inside Payload's document form, where a button with no
  // type submits the empty page.
  const here = dirname(fileURLToPath(import.meta.url));
  for (const file of ['IdeaPanel.tsx', 'IdeaWizardParts.tsx']) {
    const source = readFileSync(join(here, file), 'utf8');
    const untyped = [
      ...source.matchAll(/<(Button|button)\b([^>]*?)>/gs),
    ].filter((match) => !/\btype=/.test(match[2]));
    check(
      `every button in ${file} says it is not a submit`,
      untyped.length === 0,
      untyped.map((match) => match[0].slice(0, 60)).join(' | '),
    );
  }
}

// --- A request refused because the team has no credits ---------------------
{
  console.log('a credit refusal is told apart from an ordinary failure');
  check(
    'the platform saying the team is out of credits is a credit refusal',
    refusedForCredits({ error: true, outOfCredits: true }),
  );
  check(
    'an ordinary failure is not, so it keeps its retry',
    !refusedForCredits({ error: true }),
  );
  check('nor is a lost reply', !refusedForCredits(null));
  check(
    'nor an answer that did not fail',
    !refusedForCredits({ outOfCredits: true, ideas: [] }),
  );

  const panel = readFileSync(
    join(dirname(fileURLToPath(import.meta.url)), 'IdeaPanel.tsx'),
    'utf8',
  );
  const suggestRefusal = panel.indexOf('if (refusedForCredits(reply)) {');
  const retryOffered = panel.indexOf('if (!more) setSuggestRetry(true);');
  check(
    'the suggestion that is refused for credits stops before the retry is offered',
    suggestRefusal > 0 &&
      panel.slice(suggestRefusal, suggestRefusal + 120).includes('return;') &&
      panel.indexOf('failed();', suggestRefusal) > suggestRefusal &&
      retryOffered > 0,
  );
  check(
    'a page start and a replacement refused for credits say so',
    (panel.match(/refusedForCredits\(reply\)\s*\?\s*COPY\.outOfCredits/g) ?? [])
      .length === 2,
  );
}

if (failures > 0) {
  console.error(`\n${failures} failure(s)`);
  process.exit(1);
}
console.log('\nall checks passed');
