// What the create-page panel sends about the site when it asks for ideas.
//
// Easy to get wrong in the component, and it only shows up on a large site:
// duplicate checks are only as good as the page list sent, and the backend
// refuses a list past its cap rather than shortening one.

/** Matches `page_ideas_schema.MAX_EXISTING_PAGES`. Past this the route refuses. */
export const EXISTING_PAGE_CAP = 2_000;
/** Newest pages, for how the site is built. Not the duplicate or slug set. */
export const DESIGN_SAMPLE_PAGE_LIMIT = 100;
export const PAGE_FETCH_PAGE_SIZE = 100;

export type PageBatch<T> = {
  docs: T[];
  hasNextPage?: boolean;
};

export type ExistingPagesResult<T> = { ok: true; pages: T[] } | { ok: false };

/**
 * Every page the site has, up to the backend's cap, one Payload page at a time.
 *
 * An empty page, `hasNextPage: false`, or a short page that omits the flag is
 * the end of the site. A failed request is not: the pages gathered so far are
 * a prefix, and returning them would let a slug collide with a page the walk
 * never saw. Callers abort instead of sending that prefix. A full page with
 * no `hasNextPage` is treated as "maybe more" so a response that omits the
 * flag cannot silently drop the rest of the site; the cap bounds that walk.
 */
export async function collectExistingPages<T>(
  fetchPage: (page: number, limit: number) => Promise<PageBatch<T> | null>,
  cap: number = EXISTING_PAGE_CAP,
): Promise<ExistingPagesResult<T>> {
  const collected: T[] = [];
  let page = 1;
  while (collected.length < cap && page <= cap) {
    const batch = await fetchPage(page, PAGE_FETCH_PAGE_SIZE);
    if (!batch || !Array.isArray(batch.docs)) return { ok: false };
    const docs = batch.docs;
    if (docs.length === 0) break;
    collected.push(...docs);
    if (collected.length >= cap) break;
    if (batch.hasNextPage === false) break;
    if (batch.hasNextPage !== true && docs.length < PAGE_FETCH_PAGE_SIZE) break;
    page += 1;
  }
  return { ok: true, pages: collected.slice(0, cap) };
}

/** The newest pages, which are what the design sample and the voice reference use. */
export function designSamplePages<T>(pages: T[]): T[] {
  return pages.slice(0, DESIGN_SAMPLE_PAGE_LIMIT);
}

/**
 * Registered collections that are never content a block can list.
 *
 * `users`, `pages` and `page-proposals` are the admin's own furniture: one
 * holds accounts, the others are where a generated page GOES (on Main it waits
 * in `page-proposals` until the editor adds it). The rest are Payload's
 * bookkeeping, which every site registers and no site authored; the list grows
 * with Payload releases (3.85 added `payload-kv`), so a new one shows up as a
 * collection offered to the planner until it is named here.
 *
 * Named rather than matched on the `payload-` prefix, which is the same call
 * the platform's CMS adapter makes for the same reason: a site is free to model
 * its own collection with that name, and it would be real content.
 */
export const NON_CONTENT_COLLECTIONS: readonly string[] = [
  'users',
  'pages',
  'page-proposals',
  'payload-jobs',
  'payload-kv',
  'payload-locked-documents',
  'payload-migrations',
  'payload-preferences',
];

/**
 * The content types this site actually has, out of the registered collections.
 *
 * This is a gate, not a list: a block that renders a collection cannot be
 * planned onto a site that has none, and the platform decides that by whether
 * this comes back empty. So an entry that is not content is not noise — it is
 * a site with no collections being planned a collection block, which reaches
 * the editor as a section that renders nothing.
 *
 * Read from the admin's own config rather than from the template's
 * `generatedCollections` (its stated single source of truth) because this runs
 * in the browser: on a site that has collections, that module builds them with
 * `makeCollection`, which reaches `next/cache` through the revalidate hooks and
 * cannot be imported into a client component. Payload's client config is the
 * browser's only view of them, and it strips `admin.hidden` — the flag that
 * separates the bookkeeping collections server-side — so the names are what is
 * left to go on.
 */
export function contentCollectionSlugs(
  collections: readonly { slug?: string }[] | undefined,
): string[] {
  return (collections ?? [])
    .map((collection) => collection.slug)
    .filter(
      (slug): slug is string =>
        typeof slug === 'string' &&
        slug.length > 0 &&
        !NON_CONTENT_COLLECTIONS.includes(slug),
    );
}

export function pageSummaries(
  pages: { title?: string; slug?: string }[],
): { title: string; slug: string }[] {
  return pages
    .filter(
      (page): page is { title?: string; slug: string } =>
        typeof page.slug === 'string' && page.slug.length > 0,
    )
    .map((page) => ({ title: page.title ?? '', slug: page.slug }));
}

/**
 * The platform refused a page-ideas request because the team has no Kite
 * credits. Its own recharge dialog is already open, so the panel names the
 * reason and offers no retry: asking again cannot succeed until credits are
 * added. A platform that never sends the field reads as an ordinary failure.
 */
export function refusedForCredits(
  reply: Record<string, unknown> | null,
): boolean {
  return reply?.error === true && reply.outOfCredits === true;
}
