// Turning one page plan into form writes and per-section briefs.
//
// Kept pure and import-free on purpose: this is the part of "generate a page"
// that has behavior worth pinning, and a plain module can be exercised by the
// template's tsx test scripts without booting Payload or a DOM.
//
// The division of labour with the filler: this module says WHAT to write and
// what each section's brief is; `blockFill.writeFields` and Payload's form
// dispatchers do the writing, and SectionAutofill's existing new-row watcher
// does the filling. There is one filler, not two.

export const PAGE_TYPES = [
  'solution',
  'guide',
  'howto',
  'comparison',
  'faq',
  'custom',
] as const;
export type PageType = (typeof PAGE_TYPES)[number];

// The plan crosses the bridge in the platform's own shape (snake_case), the way
// a saved idea does. Only the payloads the admin SENDS are camelCase.
export type PagePlanSection = {
  block_type: string;
  purpose: string;
  background?: string | null;
};

export type PagePlan = {
  title: string;
  slug: string;
  seo: { title: string; description: string };
  sections: PagePlanSection[];
};

// This section's job on the page, as the fill prompt reads it. Sent to the
// platform as `pageContext`; absent for any row the editor added by hand.
export type PageContext = {
  pageTitle: string;
  idea: string;
  purpose: string;
  /** The other sections, in page order, so a section knows what it follows. */
  outline: string[];
  evidence?: { url: string; excerpt: string }[];
};

// The visual half of the same brief. The site's own spec is read server-side
// (it lives outside the served app), so the admin contributes only the surface
// the plan chose for this section.
export type DesignContext = {
  background?: string | null;
};

export type SectionBrief = {
  blockType: string;
  pageContext: PageContext;
  designContext: DesignContext;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/**
 * Whether the open document is a new one.
 *
 * Payload's `useDocumentInfo().id` is unset until a document exists, which is
 * what separates the create screen from an edit screen — the panel renders on
 * the first and never on the second, where generating would overwrite the page
 * the editor opened.
 */
export function isCreateMode(documentId: unknown): boolean {
  return documentId === undefined || documentId === null;
}

export function isPageType(value: unknown): value is PageType {
  return PAGE_TYPES.includes(value as PageType);
}

/**
 * Whether this really is a plan this admin can build.
 *
 * The plan arrives over postMessage, so nothing about its shape is guaranteed.
 * A plan missing a title, a slug or a section list cannot fill a form, and
 * half-writing one would leave the editor with a page that looks generated and
 * is not.
 *
 * `knownBlockTypes` is required rather than optional because a block this build
 * does not register is the expensive failure: the row is appended, the filler
 * cannot resolve it and never starts, and the Save latch the panel raised has
 * nothing left to lower it. Rejecting the plan is what keeps that off the form
 * in the first place.
 */
export function isPagePlan(
  value: unknown,
  knownBlockTypes: ReadonlySet<string>,
): value is PagePlan {
  if (!isRecord(value)) return false;
  if (typeof value.title !== 'string' || !value.title) return false;
  if (typeof value.slug !== 'string' || !value.slug) return false;
  if (!Array.isArray(value.sections) || value.sections.length === 0)
    return false;
  return value.sections.every(
    (section) =>
      isRecord(section) &&
      typeof section.block_type === 'string' &&
      knownBlockTypes.has(section.block_type),
  );
}

/**
 * The scalar fields a plan fills before any section exists: title, slug and
 * SEO. Returned as data rather than dispatched here so the order is testable
 * and the caller owns the form.
 *
 * SEO is omitted rather than blanked when the plan carries none — an empty
 * string would overwrite whatever the editor had typed.
 */
export function planFieldWrites(
  plan: PagePlan,
): { path: string; value: string }[] {
  const writes = [
    { path: 'title', value: plan.title },
    { path: 'slug', value: plan.slug },
  ];
  if (plan.seo?.title)
    writes.push({ path: 'seo.title', value: plan.seo.title });
  if (plan.seo?.description)
    writes.push({ path: 'seo.description', value: plan.seo.description });
  return writes;
}

/**
 * One brief per planned section, in page order.
 *
 * `outline` is every OTHER section's purpose, in order, so the writing model
 * can place this section in the page instead of restating what the section
 * above it already said.
 */
export function buildSectionBriefs(
  plan: PagePlan,
  idea: string,
  options: {
    evidence?: { url: string; excerpt: string }[];
    /**
     * Whether a block actually has a `background` field. `hero` does not: its
     * surface is media-driven and the component never reads one. Telling the
     * image prompt about a surface the rendered section will not use steers it
     * for nothing, so the brief carries a background only where one exists.
     */
    supportsBackground?: (blockType: string) => boolean;
  } = {},
): SectionBrief[] {
  const { evidence, supportsBackground } = options;
  const outline = plan.sections.map(
    (section) => section.purpose || section.block_type,
  );
  return plan.sections.map((section, index) => {
    const background =
      supportsBackground && !supportsBackground(section.block_type)
        ? null
        : (section.background ?? null);
    return {
      blockType: section.block_type,
      pageContext: {
        pageTitle: plan.title,
        idea,
        purpose: section.purpose ?? '',
        outline: outline.filter((_, i) => i !== index),
        ...(evidence?.length ? { evidence } : {}),
      },
      designContext: { background },
    };
  });
}

// ---------------------------------------------------------------------------
// The shared per-row brief store.
//
// The panel appends the planned rows; the filler sees them arrive. Payload
// generates a block row's id inside its own reducer, so the panel cannot key a
// brief by row id at the moment it appends — it queues the briefs in page
// order instead, and the FILLER binds each to the row id it is looking at, the
// first time it sees it. From then on the store is keyed by row id, so a brief
// survives a re-read and can never be handed to a second row.
//
// `blockType` has to match for a claim to succeed, so a section the editor adds
// by hand mid-generation takes no brief and fills exactly as it does today.
// ---------------------------------------------------------------------------

const briefsByRowId = new Map<string, SectionBrief>();
let queuedBriefs: SectionBrief[] = [];

/** Start of a generation run: the planned briefs, in page order. */
export function queueSectionBriefs(briefs: SectionBrief[]): void {
  queuedBriefs = [...briefs];
}

/**
 * The brief for this row, or undefined when the row was not planned.
 *
 * The first call for a row id binds the next queued brief to it; later calls
 * return the same one.
 */
export function claimSectionBrief(
  rowId: string,
  blockType: string,
): SectionBrief | undefined {
  const bound = briefsByRowId.get(rowId);
  if (bound) return bound;
  const next = queuedBriefs[0];
  if (!next || next.blockType !== blockType) return undefined;
  queuedBriefs.shift();
  briefsByRowId.set(rowId, next);
  return next;
}

/** Drop every brief, queued or bound. Used between generation runs. */
export function resetSectionBriefs(): void {
  briefsByRowId.clear();
  queuedBriefs = [];
}
