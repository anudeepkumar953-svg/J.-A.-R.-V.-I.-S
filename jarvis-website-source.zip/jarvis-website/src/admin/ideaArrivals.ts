// Page ideas arriving while a suggestion run is still writing them.
//
// The platform stores each idea the moment the model finishes it, and the
// suggest request only answers once the whole run is done. While it runs, the
// panel reads the stored list on a timer and shows what has landed. These are
// the rules for folding those reads into the list on screen.

/** How often the panel reads the stored ideas while a run is going. */
export const IDEA_POLL_INTERVAL_MS = 2_000;
/** One read of the list; a slow one is skipped, the next tick asks again. */
export const IDEA_POLL_TIMEOUT_MS = 10_000;

export const SUGGESTING_COPY = {
  first: 'Looking for ideas…',
  more: 'Looking for more ideas…',
} as const;

export type ArrivingIdea = {
  id: string;
  // ISO timestamp. One run's ideas are stamped so that newest-first is the
  // model's own order, and the run sits above everything stored before it.
  created_at?: string;
  parent_slug?: string | null;
  status?: 'new' | 'used' | 'dismissed';
  generated_slug?: string | null;
  // The suggestion request that stored it; null for a typed idea.
  run_id?: string | null;
  source?: 'user' | 'suggested';
};

/**
 * The ideas in a fresh read that the panel has never shown during this run.
 *
 * *seen* holds every id that was on screen when the run started or arrived
 * since. An idea the editor removed mid-run is in it, so a read that was
 * already on its way when they removed it cannot bring the card back.
 */
export function newArrivals<T extends ArrivingIdea>(
  listed: readonly T[],
  seen: ReadonlySet<string>,
): T[] {
  return listed.filter((idea) => !seen.has(idea.id));
}

function stampOf(idea: ArrivingIdea): number {
  const parsed = idea.created_at ? Date.parse(idea.created_at) : NaN;
  return Number.isNaN(parsed) ? 0 : parsed;
}

/**
 * *shown* with *arrived* added where the platform's newest-first order puts
 * them.
 *
 * Only the new ideas are placed; everything already on screen keeps its
 * position, so nothing the editor is looking at moves. Pure and idempotent,
 * so it is safe inside a state updater: an idea already on screen is not
 * added twice.
 */
export function mergeArrivals<T extends ArrivingIdea>(
  shown: readonly T[],
  arrived: readonly T[],
): T[] {
  const onScreen = new Set(shown.map((idea) => idea.id));
  const added = arrived
    .filter((idea) => !onScreen.has(idea.id))
    .sort((a, b) => stampOf(b) - stampOf(a));
  if (added.length === 0) return shown as T[];
  const merged = [...shown];
  for (const idea of added) {
    // Before the first idea on screen that is older than this one.
    const at = merged.findIndex((other) => stampOf(other) < stampOf(idea));
    merged.splice(at === -1 ? merged.length : at, 0, idea);
  }
  return merged;
}

/**
 * Which of *arrived* the running pass produced: the ones stamped with its own
 * run id. The list is the whole website's, so an idea the editor typed, or one
 * another editor's run stored meanwhile, turns up in the same reads; neither
 * is this pass's, and neither may be picked as its first idea.
 */
export function producedByRun<T extends ArrivingIdea>(
  arrived: readonly T[],
  runId: string,
): T[] {
  // The source too: an idea typed under the same title takes the row over,
  // and a platform that predates clearing the run id would still carry it.
  return arrived.filter(
    (idea) => idea.run_id === runId && idea.source !== 'user',
  );
}

/** A fresh id for one suggestion pass; the platform stores it as a UUID. */
export function newRunId(): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function')
    return crypto.randomUUID();
  const hex = Array.from({ length: 32 }, () =>
    Math.floor(Math.random() * 16).toString(16),
  );
  hex[12] = '4';
  hex[16] = ((parseInt(hex[16], 16) & 0x3) | 0x8).toString(16);
  const h = hex.join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

/**
 * The idea to pick for the editor so the preview shows something at once:
 * the first one for this spot that has not produced a page yet.
 *
 * While a run is going, *onlyFrom* limits the pick to that run's own ideas:
 * the editor asked for new ones, and an older idea picked a second before the
 * first new one lands would be the wrong one.
 */
export function firstFreshIdea<T extends ArrivingIdea>(
  ideas: readonly T[],
  spot: string,
  onlyFrom?: ReadonlySet<string>,
): T | undefined {
  return ideas.find(
    (idea) =>
      (idea.parent_slug ?? '') === spot &&
      idea.status !== 'used' &&
      !idea.generated_slug &&
      (onlyFrom === undefined || onlyFrom.has(idea.id)),
  );
}

/** Fresh reads the panel tries while the list stays unconfirmed. */
export const RECHECK_DELAYS_MS = [0, 2_000, 6_000] as const;

/**
 * How long to wait before follow-up read number *attempt* (0-based) for an
 * unconfirmed list, or null once the tries are used up: a failed or
 * overtaken read is retried, but not forever.
 */
export function recheckDelay(attempt: number): number | null {
  return attempt < RECHECK_DELAYS_MS.length ? RECHECK_DELAYS_MS[attempt] : null;
}

/** What the list says while a run is going. */
export function suggestingLabel(ideasOnScreen: number): string {
  return ideasOnScreen > 0 ? SUGGESTING_COPY.more : SUGGESTING_COPY.first;
}

/**
 * What the auto-pick does on one update of the panel: the idea to select, if
 * any, and whether a pick is still owed.
 *
 * While ideas are being looked for, only the running pass's (or joined
 * round's) own ideas may be picked, the moment the first one lands; an older
 * idea in the list waits. Once nothing is running, the first fresh idea of
 * the spot is picked, as on opening.
 */
export function autoPick<T extends ArrivingIdea>(state: {
  pending: boolean;
  lookingForIdeas: boolean;
  selectedId: string | null;
  ideas: readonly T[];
  spot: string;
  arrivals: ReadonlySet<string> | null;
}): { pick: T | null; pending: boolean } {
  if (!state.pending) return { pick: null, pending: false };
  if (state.lookingForIdeas) {
    if (state.selectedId !== null) return { pick: null, pending: true };
    const first = firstFreshIdea(
      state.ideas,
      state.spot,
      state.arrivals ?? new Set(),
    );
    return first
      ? { pick: first, pending: false }
      : { pick: null, pending: true };
  }
  if (state.selectedId !== null) return { pick: null, pending: false };
  return {
    pick: firstFreshIdea(state.ideas, state.spot) ?? null,
    pending: false,
  };
}

/**
 * How a suggest pass ends once its answer is in. A pass the platform answered
 * by joining a round already running goes straight into the wait on that
 * round, still looking for ideas: ending the pass first would leave a moment
 * with nothing running, in which an older idea gets picked before the round's
 * first one lands.
 */
export function endOfPass(joined: boolean): {
  waitOnRound: boolean;
  stopLooking: boolean;
} {
  return joined
    ? { waitOnRound: true, stopLooking: false }
    : { waitOnRound: false, stopLooking: true };
}

/**
 * Whether the platform saved a dismissal. Its own answer decides: a platform
 * that reports the write (`dismissed`) is believed even when the list read it
 * does afterwards failed; an older one that cannot say is believed only when
 * it answered with the list.
 */
export function dismissalSaved(
  reply:
    | { error?: boolean; dismissed?: boolean; ideas?: unknown }
    | null
    | undefined,
): boolean {
  if (reply == null) return false;
  if (reply.dismissed === true) return true;
  return reply.error !== true && Array.isArray(reply.ideas);
}

/** The panel's ideas: what is on screen, and what the editor removed. */
export type IdeaListState<T extends ArrivingIdea> = {
  shown: T[];
  /** Saved dismissals: out for the rest of the screen, whatever a read says. */
  removed: ReadonlySet<string>;
  /** Dismissals not answered yet, with the panel's own copy of each idea. */
  pending: ReadonlyMap<string, { idea: T; hidden: boolean }>;
  /** Counts the cards put on screen; a whole-list read is ordered by it. */
  version: number;
  /** The `version` at which each card on screen was put there. */
  addedAt: ReadonlyMap<string, number>;
  /**
   * The last whole list left out a card that came on screen after it was
   * asked for, so it could not say whether that card is still offered. A
   * fresh read settles it.
   */
  unconfirmed: boolean;
};

export type IdeaListEvent<T extends ArrivingIdea> =
  /** The editor removed *idea*; `hidden` takes it off screen meanwhile. */
  | { type: 'removalRequested'; idea: T; hidden: boolean }
  /** The platform saved that dismissal. */
  | { type: 'removalConfirmed'; id: string }
  /** It did not: no answer, an error, or the request threw. */
  | { type: 'removalFailed'; id: string }
  /** New ideas a read found: they are only added or updated. */
  | { type: 'listReadOk'; ideas: readonly T[]; full: false }
  /**
   * The whole list, which holds every idea not dismissed. `readFrom` is the
   * state's `version` when the request was sent: a card put on screen after
   * that is newer than this answer, so its absence here says nothing.
   */
  | { type: 'listReadOk'; ideas: readonly T[]; full: true; readFrom: number }
  /** A list read that failed. */
  | { type: 'listReadFailed' }
  /**
   * A removed idea's slot goes to the new ideas of a replacement, whose answer
   * is the whole list as of `readFrom` (see `listReadOk`).
   */
  | { type: 'replaced'; id: string; ideas: readonly T[]; readFrom: number }
  /** No replacement came: the removed idea leaves its slot. */
  | { type: 'replacementFailed'; id: string };

export function emptyIdeaList<T extends ArrivingIdea>(): IdeaListState<T> {
  return {
    shown: [],
    removed: new Set(),
    pending: new Map(),
    version: 0,
    addedAt: new Map(),
    unconfirmed: false,
  };
}

/** *state* with its `addedAt` stamped for every card newly on screen. */
function stamped<T extends ArrivingIdea>(
  state: IdeaListState<T>,
): IdeaListState<T> {
  const fresh = state.shown.filter((idea) => !state.addedAt.has(idea.id));
  if (fresh.length === 0) return state;
  const version = state.version + 1;
  const addedAt = new Map(state.addedAt);
  for (const idea of fresh) addedAt.set(idea.id, version);
  return { ...state, version, addedAt };
}

/**
 * The cards a whole list as of *readFrom* no longer offers: absent from it,
 * on screen since before it was asked for, and not settling here.
 */
function goneFrom<T extends ArrivingIdea>(
  state: IdeaListState<T>,
  listed: readonly T[],
  readFrom: number,
): Set<string> {
  const ids = new Set(listed.map((idea) => idea.id));
  return new Set(
    state.shown
      .filter(
        (idea) =>
          !ids.has(idea.id) &&
          !state.removed.has(idea.id) &&
          !state.pending.has(idea.id) &&
          (state.addedAt.get(idea.id) ?? Infinity) <= readFrom,
      )
      .map((idea) => idea.id),
  );
}

/** Whether *listed* leaves out a card put on screen after *readFrom*. */
function newerThanRead<T extends ArrivingIdea>(
  state: IdeaListState<T>,
  listed: readonly T[],
  readFrom: number,
): boolean {
  const ids = new Set(listed.map((idea) => idea.id));
  return state.shown.some(
    (idea) =>
      !ids.has(idea.id) &&
      !state.removed.has(idea.id) &&
      !state.pending.has(idea.id) &&
      (state.addedAt.get(idea.id) ?? Infinity) > readFrom,
  );
}

/**
 * One change to the panel's ideas, under one rule: a dismissal's own answer
 * decides its outcome and nothing after it changes that. Saved, the idea is
 * out for good; not saved, it is back at once from the panel's own copy.
 * List reads never bring back a removed (or still-deciding, hidden) idea, and
 * a failed read changes nothing. A whole list (a read or a replacement's
 * answer) also drops every card it leaves out, since the platform no longer
 * offers it (another session may have dismissed it), except one whose own
 * dismissal or replacement is still running here, or one put on screen after
 * that list was asked for.
 */
export function ideaListStep<T extends ArrivingIdea>(
  state: IdeaListState<T>,
  event: IdeaListEvent<T>,
): IdeaListState<T> {
  const next = applyEvent(state, event);
  if (next === state) return state;
  // Forget stamps of cards no longer on screen; a card that comes back is new.
  const onScreen = new Set(next.shown.map((idea) => idea.id));
  const addedAt = new Map([...next.addedAt].filter(([id]) => onScreen.has(id)));
  return stamped({ ...next, addedAt });
}

function applyEvent<T extends ArrivingIdea>(
  state: IdeaListState<T>,
  event: IdeaListEvent<T>,
): IdeaListState<T> {
  const keptOut = (id: string) =>
    state.removed.has(id) || state.pending.get(id)?.hidden === true;
  switch (event.type) {
    case 'removalRequested': {
      const pending = new Map(state.pending);
      pending.set(event.idea.id, { idea: event.idea, hidden: event.hidden });
      return {
        ...state,
        pending,
        shown: event.hidden
          ? state.shown.filter((idea) => idea.id !== event.idea.id)
          : state.shown,
      };
    }
    case 'removalConfirmed': {
      const entry = state.pending.get(event.id);
      const pending = new Map(state.pending);
      pending.delete(event.id);
      const removed = new Set(state.removed);
      removed.add(event.id);
      // A card kept on screen for its replacement stays until that settles.
      const keep = entry !== undefined && !entry.hidden;
      return {
        ...state,
        shown: keep
          ? state.shown
          : state.shown.filter((idea) => idea.id !== event.id),
        removed,
        pending,
      };
    }
    case 'removalFailed': {
      const entry = state.pending.get(event.id);
      const pending = new Map(state.pending);
      pending.delete(event.id);
      if (!entry || state.removed.has(event.id)) return { ...state, pending };
      return {
        ...state,
        pending,
        shown: mergeArrivals(state.shown, [entry.idea]),
      };
    }
    case 'listReadOk': {
      const byId = new Map(
        event.ideas
          .filter((idea) => !keptOut(idea.id))
          .map((idea) => [idea.id, idea] as const),
      );
      const gone = event.full
        ? goneFrom(state, event.ideas, event.readFrom)
        : new Set<string>();
      const unconfirmed = event.full
        ? newerThanRead(state, event.ideas, event.readFrom)
        : state.unconfirmed;
      const updated = state.shown.flatMap((idea) => {
        if (gone.has(idea.id)) return [];
        if (state.removed.has(idea.id)) return [idea];
        return [byId.get(idea.id) ?? idea];
      });
      const onScreen = new Set(updated.map((idea) => idea.id));
      const added = [...byId.values()].filter((idea) => !onScreen.has(idea.id));
      return { ...state, shown: mergeArrivals(updated, added), unconfirmed };
    }
    case 'listReadFailed':
      return state;
    case 'replaced': {
      const onScreen = new Set(state.shown.map((idea) => idea.id));
      const fresh = event.ideas.filter(
        (idea) => !onScreen.has(idea.id) && !keptOut(idea.id),
      );
      const asRead: IdeaListEvent<T> = {
        type: 'listReadOk',
        ideas: event.ideas,
        full: true,
        readFrom: event.readFrom,
      };
      if (!onScreen.has(event.id)) return applyEvent(state, asRead);
      // The slot keeps its place: the new ideas go where the old card was,
      // then the answer is applied as the whole list it is.
      const slotted = {
        ...state,
        shown: state.shown.flatMap((idea) =>
          idea.id === event.id ? fresh : [idea],
        ),
      };
      return applyEvent(stamped(slotted), asRead);
    }
    case 'replacementFailed':
      return {
        ...state,
        shown: state.removed.has(event.id)
          ? state.shown.filter((idea) => idea.id !== event.id)
          : state.shown,
      };
  }
}
