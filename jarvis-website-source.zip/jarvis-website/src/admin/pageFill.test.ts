// Contract for turning one page plan into a filled form (KITE page ideas).
//
// Three things here can go wrong silently, and each one looks like a working
// generation until someone reads the page:
//   - the scalar writes: a plan that blanks SEO the editor already typed;
//   - the per-row briefs: a section told to write the whole page, or told
//     nothing, because `outline` included itself or the brief went to the
//     wrong row;
//   - the brief store: a hand-added section picking up a planned brief, which
//     is the one case where "a manually added section behaves exactly as
//     before" stops being true, whether the brief comes from this run or from
//     one the editor walked away from.
//
// Plus the one that fails loudly and then strands the form: a plan naming a
// block this build does not register. The row is appended, the filler cannot
// resolve it and never starts, and the Save latch the panel raised has nothing
// left to lower it.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml). Exits non-zero on
// any failure.
//
// Run locally: pnpm exec tsx src/admin/pageFill.test.ts

import {
  buildSectionBriefs,
  claimSectionBrief,
  isCreateMode,
  isPagePlan,
  isPageType,
  planFieldWrites,
  queueSectionBriefs,
  resetSectionBriefs,
  type PagePlan,
} from './pageFill';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

function equal(name: string, actual: unknown, expected: unknown): void {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  check(name, a === e, `expected ${e}\n        got      ${a}`);
}

// Exactly what a build of this template registers, as the panel reads it off
// `layoutBlocks` before asking for a plan.
const KNOWN = new Set(['hero', 'faq', 'cta', 'gallery', 'featureGrid']);
// `hero` has no background field: its surface is media-driven and the component
// never reads one.
const hasBackgroundField = (blockType: string) => blockType !== 'hero';

const PLAN: PagePlan = {
  title: 'Pricing questions',
  slug: 'pricing-questions',
  seo: {
    title: 'Pricing questions, answered',
    description: 'What a project costs and what changes the number.',
  },
  sections: [
    { block_type: 'hero', purpose: 'Name the question the page answers' },
    {
      block_type: 'faq',
      purpose: 'Answer the five asked most',
      background: 'muted',
    },
    { block_type: 'cta', purpose: 'Offer a call', background: 'dark' },
  ],
};

// --- A plan the platform did not produce ------------------------------------
{
  console.log('a reply that is not a plan');
  check('a plan is a plan', isPagePlan(PLAN, KNOWN));
  check('null is not', !isPagePlan(null, KNOWN));
  check('no title is not', !isPagePlan({ ...PLAN, title: '' }, KNOWN));
  check('no slug is not', !isPagePlan({ ...PLAN, slug: '' }, KNOWN));
  check('no sections is not', !isPagePlan({ ...PLAN, sections: [] }, KNOWN));
  check(
    'a section without a block type is not',
    !isPagePlan({ ...PLAN, sections: [{ purpose: 'something' }] }, KNOWN),
  );
  // The expensive one. Appended, this row can never be filled, and the Save
  // latch the panel raised for the planning window would never come down.
  check(
    'a block this build does not register is refused',
    !isPagePlan(
      {
        ...PLAN,
        sections: [
          ...PLAN.sections,
          { block_type: 'pricingMatrix', purpose: 'Compare the tiers' },
        ],
      },
      KNOWN,
    ),
  );
}

// --- The scalar writes ------------------------------------------------------
{
  console.log('\nwhat a plan writes before any section exists');
  equal('title, slug, then SEO', planFieldWrites(PLAN), [
    { path: 'title', value: 'Pricing questions' },
    { path: 'slug', value: 'pricing-questions' },
    { path: 'seo.title', value: 'Pricing questions, answered' },
    {
      path: 'seo.description',
      value: 'What a project costs and what changes the number.',
    },
  ]);
  // A plan with nothing to say about SEO must not clear what is in the form.
  equal(
    'an empty SEO field is left alone, not blanked',
    planFieldWrites({ ...PLAN, seo: { title: '', description: '' } }),
    [
      { path: 'title', value: 'Pricing questions' },
      { path: 'slug', value: 'pricing-questions' },
    ],
  );
}

// --- The per-section briefs -------------------------------------------------
{
  console.log('\nthe brief each section is written from');
  const briefs = buildSectionBriefs(PLAN, 'Pricing questions');
  check('one brief per planned section', briefs.length === 3);
  equal(
    'a brief names its own section, never in its own outline',
    briefs[1].pageContext,
    {
      pageTitle: 'Pricing questions',
      idea: 'Pricing questions',
      purpose: 'Answer the five asked most',
      outline: ['Name the question the page answers', 'Offer a call'],
    },
  );
  equal(
    'the surface the plan chose travels with the section',
    briefs.map((b) => b.designContext),
    [{ background: null }, { background: 'muted' }, { background: 'dark' }],
  );
  check(
    'evidence is absent unless the idea carried some',
    briefs[0].pageContext.evidence === undefined,
  );
  const cited = buildSectionBriefs(PLAN, 'Pricing questions', {
    evidence: [
      { url: 'https://example.com/a', excerpt: 'Most buyers want a range.' },
    ],
  });
  equal('evidence rides along when it exists', cited[0].pageContext.evidence, [
    { url: 'https://example.com/a', excerpt: 'Most buyers want a range.' },
  ]);
  // The brief steers image generation. A surface the rendered section will
  // never use is a prompt written against a page that does not exist.
  const surfaced = buildSectionBriefs(
    { ...PLAN, sections: [{ ...PLAN.sections[0], background: 'dark' }] },
    'Pricing questions',
    { supportsBackground: hasBackgroundField },
  );
  check(
    'a block with no background field is given none',
    surfaced[0].designContext.background === null,
  );
}

// --- The shared brief store -------------------------------------------------
{
  console.log('\nwhich row gets which brief');
  resetSectionBriefs();
  queueSectionBriefs(buildSectionBriefs(PLAN, 'Pricing questions'));

  const first = claimSectionBrief('row-a', 'hero');
  check(
    'the first planned section binds to the first row that arrives',
    first?.pageContext.purpose === 'Name the question the page answers',
  );
  check(
    'reading the same row again returns the same brief',
    claimSectionBrief('row-a', 'hero') === first,
  );
  check(
    'a row whose block type is not the next planned one takes nothing',
    claimSectionBrief('row-hand-added', 'gallery') === undefined,
  );
  const second = claimSectionBrief('row-b', 'faq');
  check(
    'the queue is not consumed by the row that took nothing',
    second?.pageContext.purpose === 'Answer the five asked most',
  );
  claimSectionBrief('row-c', 'cta');
  check(
    'a section added by hand after the plan is exhausted takes nothing',
    claimSectionBrief('row-d', 'hero') === undefined,
  );

  resetSectionBriefs();
  check(
    'a reset drops both the queue and what was already bound',
    claimSectionBrief('row-a', 'hero') === undefined,
  );

  // Two sections of the same type on one page. The block-type guard cannot tell
  // these apart, so the only thing keeping each row's purpose its own is that
  // the rows are claimed in page order — which is why the filler claims while
  // it walks the rows, not after each row's own network round-trip.
  resetSectionBriefs();
  queueSectionBriefs(
    buildSectionBriefs(
      {
        ...PLAN,
        sections: [
          { block_type: 'featureGrid', purpose: 'Show what is included' },
          { block_type: 'featureGrid', purpose: 'Show what is not' },
        ],
      },
      'Pricing questions',
    ),
  );
  const included = claimSectionBrief('row-1', 'featureGrid');
  const excluded = claimSectionBrief('row-2', 'featureGrid');
  check(
    'the first of two same-type sections keeps its own purpose',
    included?.pageContext.purpose === 'Show what is included',
  );
  check(
    'and the second keeps its own',
    excluded?.pageContext.purpose === 'Show what is not',
  );
  check(
    'each is written against the other, not against itself',
    JSON.stringify(included?.pageContext.outline) ===
      JSON.stringify(['Show what is not']),
  );
}

// --- A run nobody saved -----------------------------------------------------
{
  console.log('\na generation the editor walked away from');
  resetSectionBriefs();
  queueSectionBriefs(buildSectionBriefs(PLAN, 'Pricing questions'));
  claimSectionBrief('row-a', 'hero');
  // The editor leaves Create without saving. The briefs are module state, so
  // unless the form drops them on the way out, the next hand-added section
  // picks up a purpose from a page that was never created.
  resetSectionBriefs();
  check(
    'a half-consumed run leaves nothing for the next form',
    claimSectionBrief('row-fresh', 'faq') === undefined,
  );
  check(
    'not even for the type it was about to fill',
    claimSectionBrief('row-fresh-2', 'cta') === undefined,
  );
}

// --- Where the panel renders ------------------------------------------------
{
  console.log('\nthe create screen, and nowhere else');
  check('a create form has no document id', isCreateMode(undefined));
  check('nor does one whose id is null', isCreateMode(null));
  check('an existing page is not create mode', !isCreateMode('page-42'));
  check('nor is one identified by number', !isCreateMode(42));
}

// --- The page types the wizard knows ------------------------------------------
{
  console.log('\nthe page types');
  check(
    'every type the platform stores is one the wizard takes',
    ['solution', 'guide', 'howto', 'comparison', 'faq', 'custom'].every(
      isPageType,
    ),
  );
  check('a type it has never heard of is not', !isPageType('press'));
}

if (failures > 0) {
  console.error(`\n${failures} failure(s)`);
  process.exit(1);
}
console.log('\nall checks passed');
