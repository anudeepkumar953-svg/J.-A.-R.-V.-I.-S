# Visual Design Spec

## 1. Global Visual System
The website employs a highly polished, modern, premium SaaS aesthetic. The core visual language is "glass and glow"—relying on expansive white space, precise but extremely soft drop shadows, and vibrant, heavily blurred radial gradients (orbs) that sit behind content layers to create a sense of volumetric depth. The layout uses a strict grid foundation but intentionally breaks it using floating UI elements, intersecting layers, and robust scroll-linked motion. The interface acts as a continuous storytelling device, utilizing motion not just for entrances, but for structural transitions and pacing. 

## 2. Global Layout and Rhythm
- **Grid:** Built on a standard 12-column responsive layout with a constrained maximum width (approximately 1200px - 1440px). 
- **Pacing:** Vertical rhythm is exceptionally loose. Section padding is massive on desktop (roughly 120px - 160px), ensuring sections often occupy the entire viewport sequentially without crowding. Padding scales down proportionally on mobile.
- **Asymmetry & Splits:** Frequent use of 40/60 or 30/70 split layouts, often coupling a sticky, narrow text column with a wider, scrolling gallery or media column.
- **Mobile Degradation:** Complex horizontal or sticky desktop layouts consistently and gracefully collapse into center-aligned or left-aligned vertical single-column stacks with generous horizontal padding (16px - 24px).

## 3. Global Typography System
- **Family:** A clean, geometric, contemporary sans-serif.
- **Scale:** Extreme contrast between display typography and functional body copy. Primary headings operate in the 64px - 80px range (desktop), while body copy sits around 16px - 18px.
- **Headings:** Characterized by tight tracking (negative letter-spacing, approx `-0.02em` to `-0.04em`) and solid, heavy weights (Semi-Bold to Bold). Headings frequently utilize explicit line breaks (`<br>` or constrained max-widths) to force a specific, blocky, stacked typographic silhouette.
- **Body Copy:** High readability, utilizing regular weights, medium cool-gray tones, and generous line-heights (1.6 to 1.8).
- **Hierarchy Cues:** Strong reliance on small, pill-shaped kickers (caps or title case, distinct background color) placed directly above massive headings to establish section context.

## 4. Global Color, Surface, and Effects
- **Palette Logic:** The base is overwhelmingly pure white (`#FFFFFF`) or off-white pearl (`#FAFAFA`). 
- **The "Glow":** Vivid accent colors (cyan, sky blue, magenta, soft purple) are rarely used as flat blocks of color. Instead, they manifest as giant, absolute-positioned radial gradients with extreme blur radii (`filter: blur(100px+)`). These act as ambient backlights placed *behind* white cards or text elements.
- **Surfaces (Cards):** Standard structural cards feature pure white backgrounds, large border radii (16px - 24px), and massive, highly diffused drop shadows (e.g., `box-shadow: 0 20px 40px rgba(0,0,0,0.04)`). 
- **Edge Definition:** A critical component of the surface system is a 1px ultra-subtle inner border (`inset 0 0 0 1px rgba(0,0,0,0.05)`) on all white cards to prevent them from bleeding into the white background.
- **Glass Effects:** Floating widgets use translucent backgrounds (e.g., `rgba(255,255,255,0.7)`), backdrop blur (`backdrop-filter: blur(12px)`), and a slightly sharper shadow to elevate them above the base Z-index layer.

## 5. Global Motion Language
- **Ambient Motion:** Floating elements (like device mockups and glass UI widgets) exhibit continuous, looping, staggered sine-wave translations on the Y-axis (±10px to 15px over 3-5 second durations). They move independently to create multi-layer parallax depth.
- **Scroll-Scrubbed Motion:** Heavy reliance on scroll-linked property transformations (scale, opacity, Y-translation) pinned to viewport progress, rather than time-based animations. 
- **Viewport Reveals:** Elements crossing the threshold often ease in gracefully. Images frequently utilize a subtle scale-down from `1.05` to `1.0` coupled with a fade-in.
- **Easing:** Predominantly smooth, elegant `ease-out` or custom cubic-bezier curves that feel fluid, devoid of bouncy or elastic physics.

## 6. Motion Adaptation Rules
- **Sticky Column Dependencies:** Whenever a text column pins while a media column scrolls, the scrolling column *must* contain enough content (or forced minimum heights) to ensure the sticky behavior is sustained long enough to read the text.
- **Stacked Card Math:** 3D stacking effects must calculate their scroll-scrubbed progress dynamically based on the *number of children* and the *height of the wrapper*, not fixed integer heights, to prevent overlapping crashes if content length varies.
- **Aspect Ratio Safe Guards:** Circular or radial positioning logic must be anchored to containers that maintain their aspect ratio, preventing circular orbits from distorting into ovals if text expands vertically.

## 7. Global Imagery and Iconography
- **UI Mockups:** Highly stylized, edge-to-edge representations of application interfaces contained within rounded bento cards. They are often simplified, omitting fine UI text in favor of shapes and layout structures.
- **Avatars/People:** Cleanly masked into perfect circles or squircle shapes, often framed with subtle borders or shadows, used to humanize features or testimonials.
- **Iconography:** Minimalist, geometric, line-based icons, often contained within their own soft-tinted, rounded-rectangle background plates.

## 8. Persistent Interface Layers
- **Navigation:** A lightweight, un-boxed top navigation bar that integrates seamlessly into the page background. It avoids heavy, contrasting sticky wrapper backgrounds.
- **Background Orbs:** The blurred gradient backlights persist and subtly shift position across the entire page's Z-axis, creating continuity between distinct vertical sections.

## 9. Section Inventory
- **Primary Pages:** 
  - Hero Split Composition
  - Sticky Feature Detail Column
  - Circuit-Connected Bento Grid
  - Radial Avatar Orbit
  - Horizontal UI Integration Strip
  - 3D Testimonial Stacking Deck
  - Three-Column Pricing Grid
  - FAQ Accordion
  - Pre-Footer CTA Block
  - Dark Mode Typographic Footer
- **Secondary Pages:**
  - Standard Hero Media Header
  - 2x2 Feature Bento
  - Video Message Block
  - Team Member Grid
  - Sticky Timeline/Changelog Split
  - Top Card Contact Grid & Form Split

## 10. Section-by-Section Detailed Spec

### Hero Composition
- **Purpose:** Establish the brand aesthetic, core value proposition, and introduce the glass/glow UI language.
- **Layout (Desktop):** Asymmetrical 40/60 split. Left side handles text vertically centered. Right side features a massive vertical device mockup. Several "Glass UI" widgets overlap the device frame. An isolated card floats entirely on the far right.
- **Layout (Mobile):** Centralized stack. Text -> Device -> Isolated Card. Glass widgets intersect the device.
- **Background:** A massive, pulsing, blurred gradient orb sits directly behind the central device mockup.
- **Motion:** Ambient, asynchronous sine-wave floating for the device and all surrounding widgets. 

### Sticky Feature Detail Split
- **Purpose:** Deep dive into specific capabilities while pacing the user's scroll.
- **Layout:** 40/60 split. The left column (Heading + Text + CTA) is wrapped in a `position: sticky` container. The right column contains a vertical stack of three massive, tall UI Bento cards.
- **Mobile Behavior:** Sticky behavior is removed; elements stack naturally.

#### Motion pattern: Sticky Scroll Handoff
- **Role:** Control reading pace and anchor context while exploring detailed visuals.
- **Sequence structure:** 1 pinned text block (left), 3 tall scrolling visual cards (right).
- **Progression model:** Continuous vertical scroll.
- **Trigger:** Viewport top-edge intersection.
- **Scroll budget sufficiency:** High in source. The 3 right-hand cards are tall enough to afford a long dwell time for the sticky left column.
- **Portability note:** 
  - *Essential:* The left column must remain pinned until the *bottom* of the last right-hand card clears the sticky container's bottom edge.
  - *Constraint:* If reused with fewer or shorter cards, the scrolling column must be padded with a forced `min-height` to prevent the sticky column from instantly unpinning.

### Circuit-Connected Bento Grid
- **Purpose:** Show feature relationships to a core intelligence.
- **Layout:** A centered orb graphic sits in the middle of the section. Feature cards flank it on all sides. Thin, crisp, SVG-like lines with sharp 90-degree elbows (circuit board style) connect the outer cards to the central orb.
- **Implementation Clue:** The connection lines likely require absolute positioned SVG paths or border-based CSS routing that must aggressively adapt or hide on mobile breakpoints.

### Radial Avatar Orbit
- **Purpose:** Showcase community or user diversity in a visually dramatic format.
- **Layout:** Central text block with a glowing orb. User avatars are positioned in concentric radial orbits around the center.
- **Motion:** As the section enters the viewport, avatars scale from 0 and translate outward to their orbit positions. Once settled, they adopt a subtle ambient float.

#### Motion pattern: Viewport Radial Expansion
- **Role:** Dramatic, eye-catching entry sequence.
- **Progression model:** Discrete viewport trigger followed by continuous ambient loop.
- **Trigger:** Viewport intersection.
- **Easing feel:** Fluid spring-like pop-out.
- **Dependency variables:** The container must maintain a squarish aspect ratio. 
- **Portability note:** Do not hardcode standard grid CSS. This requires absolute positioning with trigonometric math (or nested rotational transforms) to ensure exact circular distribution.

### 3D Testimonial Stacking Deck
- **Purpose:** Present reviews in a compact, highly interactive, high-retention format.
- **Layout:** A centered stack of identical-width cards.

#### Motion pattern: Scroll-Scrubbed Depth Stack
- **Role:** Maximize content density while rewarding scroll interaction.
- **Sequence structure:** 1 pinned outer wrapper, 3-4 dynamic overlapping cards.
- **State count:** Equal to the number of cards.
- **Progression model:** Continuous scroll mapped precisely to card index.
- **Observed behavior:** As the user scrolls, the top active card pins. The next card translates upward over it. The pinned card scales down (simulating Z-axis depth), shifts slightly up, and drops opacity.
- **Trigger:** Scroll progress within the parent wrapper's bounding box.
- **Anchor element:** The section wrapper (which acts as the scroll track).
- **Grouped-unit behavior:** The cards act as a single, coordinated, shifting deck.
- **Scroll budget sufficiency:** Dependent on wrapper height calculation.
- **Portability note:**
  - *Essential:* The scaling and fading must be tethered to scroll progress, not a time-based transition.
  - *Adaptation constraints:* The outer wrapper's height must be dynamically calculated (e.g., `cardCount * 100vh`) to dictate the "scrub length". Hardcoding the wrapper height will cause the sequence to play too fast or overlap incorrectly.

### Dark Mode Typographic Footer
- **Purpose:** High-contrast conclusion and brand reinforcement.
- **Layout:** Standard grid of links at the top. The background is pure black.
- **Distinctive Cue:** The bottom 30% of the footer is dominated by massive, edge-to-edge brand typography with extremely low opacity (approx 5-10%), acting as a structural watermark.

### Changelog Sticky Timeline
- **Purpose:** Easy parsing of chronological updates.
- **Layout:** A two-column structure where the left column (containing the version number and date inside a small pill/card) acts as a sticky anchor, while the right column (rich text and large images) scrolls past. 
- **Implementation Clue:** Similar to the Sticky Feature Detail, but on a micro-scale repeated for every single timeline entry.

## 11. Reusable Patterns and Motifs
- **The "Glass Floating Widget":** 
  - *Recipe:* `border-radius: 12px`, `background: rgba(255,255,255,0.7)`, `backdrop-filter: blur(10px)`, slightly elevated soft drop shadow. Layout is a flex row with a small squircle icon on the left and dense, tiny text on the right.
- **The UI Bento Card:**
  - *Recipe:* White surface, 1px inner border, huge soft shadow. Internal layout splits content (bold heading, gray subtext, checklist) from an edge-to-edge, cropped UI graphic resting on a subtle background.
- **Section Introduction Lockup (Pill + H2 + Subtext):**
  - *Top:* Small, fully rounded pill (`border-radius: 99px`) with contrasting text/background.
  - *Middle:* Massive H2, tight tracking, explicitly line-broken.
  - *Bottom:* Gray subtext, max-width constrained.

## 12. Essential Traits to Preserve
1. **The Blurred Backlights:** White cards must sit on top of massive, heavily blurred (`blur(100px+)`) radial gradients to achieve the required depth. Solid color backgrounds will ruin the aesthetic.
2. **The 1px Inner Edge:** All white cards must use a 1px subtle inner shadow or border to define their edge against the white background.
3. **Typographic Density:** Headings must maintain tight negative letter-spacing and blocky silhouettes.
4. **Independent Floating Rhythms:** Floating elements must move asynchronously to create parallax, rather than moving as a single grouped layer.

## 13. Build Guardrails and Anti-Simplification Warnings
- **DO NOT** replace the blurred background orbs with flat background colors or standard linear gradients.
- **DO NOT** attempt to build the 3D Testimonial stack with standard relative CSS flow. It requires a defined scroll-track wrapper, `position: sticky` on the cards, and scroll-progress-linked transforms.
- **DO NOT** let the text in the sticky 40/60 split sections unpin before the corresponding imagery finishes scrolling.
- **DO NOT** allow the typographic tracking on headings to default to the browser standard. It must be explicitly tightened.
- **DO NOT** simplify the radial avatar orbit into a basic CSS grid. The circular math and positioning are visually mandatory.

## 14. Redaction and Abstraction Notes
- Literal brand names, app names, UI copy, and exact feature descriptions have been abstracted into generic design terms (e.g., "brand typography," "UI widgets," "Feature Detail").
- Contact information (emails, phone numbers, addresses) visible on the contact page have been ignored and treated as structural placeholders.
- Avatars and specific UI imagery contents have been abstracted to their functional roles.