# J.A.R.V.I.S. website — exported source

Next.js 16 (App Router) site with an embedded Payload CMS (Postgres).

## Requirements
- Node.js >= 22.17.1 (see `.nvmrc`)
- pnpm 10.14.x (`corepack enable && corepack prepare pnpm@10.14.0 --activate`)
- A Postgres database (for the Payload CMS content)

## Run it locally
1. `pnpm install`
2. Create a `.env.local` file in the project root (never commit it):
   ```
   APP_DATABASE_URL=postgres://user:password@localhost:5432/jarvis
   PAYLOAD_SECRET=<any long random string>
   NEXT_PUBLIC_SERVER_URL=http://localhost:4321
   ```
3. Load the starting content into the database: `pnpm seed` (uses `seed.json`)
4. `pnpm dev` — opens at http://localhost:4321 (CMS admin at `/admin`)

## Production build
- `pnpm build` then `pnpm start` (port 4321)

## Layout
- `src/app/**` routes and layouts; `src/components/**` shared components
- `src/data/**` site content data; `src/app/globals.css` global styles
- `src/payload.config.ts`, `src/payload/**` CMS config and collections
- `seed.json` starting CMS content; `public/` static assets
- `redirects.csv` redirect rules

## Notes
- Some packages are `@appsmithorg/*` and install from the public registry.
- Analytics variables (`NEXT_PUBLIC_KITE_*`) and platform login keys are optional and only apply on Kite hosting; no secrets are included in this archive.
- `pnpm typecheck` checks types.
