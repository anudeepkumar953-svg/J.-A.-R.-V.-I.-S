import { existsSync, readFileSync } from 'node:fs';

// Per-app redirects.csv is the platform's "bulk redirects" channel. The
// template ships a header-only file by default; only point Vercel at it once
// at least one redirect row has been added. Row validity is enforced by Vercel
// itself at build time.
// Vercel runs vercel.ts with cwd at the project root (where this file lives).
function hasRedirectRows(): boolean {
  if (!existsSync('redirects.csv')) return false;
  const dataRows = readFileSync('redirects.csv', 'utf8')
    .split('\n')
    .slice(1)
    .filter((line) => line.trim().length > 0);
  return dataRows.length > 0;
}

// Publish copies this file alone into existing sites, so this policy must
// remain self-contained. Keep it aligned with next.config production headers.
const contentSecurityPolicy = [
  "default-src 'self'",
  "script-src 'self' https: 'unsafe-inline' 'unsafe-eval'",
  "style-src 'self' https: 'unsafe-inline'",
  "img-src 'self' https: data: blob:",
  "font-src 'self' https: data:",
  "connect-src 'self' https: wss:",
  "media-src 'self' https: data: blob:",
  "frame-src 'self' https:",
  "worker-src 'self' blob:",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self' https:",
  "frame-ancestors 'self' https://kite.ai https://staging.kite.ai https://*.dp.appsmith.com https://v2.local.com https://v2.local.com:8443 http://localhost:3000 https://kite.appsmith.com https://ship.appsmith.com https://*.kite.localhost",
].join('; ');

// Common security and indexing headers for both framework layouts.
const RESPONSE_HEADERS = [
  {
    source: '/(.*)',
    headers: [
      { key: 'Strict-Transport-Security', value: 'max-age=31536000' },
      {
        key: 'Permissions-Policy',
        value: 'camera=(), microphone=(), geolocation=()',
      },
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
      {
        key: 'Content-Security-Policy',
        value: contentSecurityPolicy,
      },
    ],
  },
  ...['kite-v3.kite.space', 'kite-marketing-website.kite.space'].map(
    (host) => ({
      source: '/(.*)',
      has: [{ type: 'host', value: { eq: host } }],
      // CloudFront always adds this header. Its viewer-domain policy owns indexing,
      // so kite.ai stays indexable and staging adds noindex at CloudFront.
      missing: [{ type: 'header', key: 'x-amz-cf-id' }],
      headers: [{ key: 'X-Robots-Tag', value: 'noindex' }],
    }),
  ),
];

// Retain the older layout's policy; this adapter also supports legacy deploys.
const LEGACY_RESPONSE_HEADERS = [
  {
    source: '/(.*)',
    headers: [
      { key: 'X-Content-Type-Options', value: 'nosniff' },
      { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
      {
        key: 'Content-Security-Policy',
        value:
          "default-src * 'self' data: blob: 'unsafe-inline' 'unsafe-eval'; frame-ancestors *",
      },
    ],
  },
  ...RESPONSE_HEADERS.slice(1),
];

const REDIRECTS_CONFIG = hasRedirectRows()
  ? { bulkRedirectsPath: 'redirects.csv' }
  : {};

// Layout detection: new apps generated from the Next.js templates always ship
// `next.config.*` at the project root (this Payload template uses
// `next.config.mjs`). Legacy apps generated from the older Vite + Fastify
// template don't — they have a `frontend/` + `backend/` split and own a frozen
// `package.json` from when they were created. Each layout needs different
// Vercel project settings, so this single file branches on the marker file.
// Keep in sync with NEXT_CONFIG_NAMES in backend/app/utils/nextjs_detection.py.
const isNextjs = [
  'next.config.js',
  'next.config.mjs',
  'next.config.ts',
  'next.config.cjs',
].some((name) => existsSync(name));

// Plain object export — no `@vercel/config` import. Each deployed app has a
// frozen package.json from when it was generated; importing `@vercel/config`
// here would force every existing app to add the package as a dep before its
// next deploy. The Vercel docs explicitly support a bare typed export.
export const config = isNextjs
  ? {
      // Let Vercel use its built-in Next.js handling — it picks the right
      // build command, install command, and output directory based on the
      // detected lockfile and the `next` dep in package.json.
      framework: 'nextjs',
      ...REDIRECTS_CONFIG,
      headers: RESPONSE_HEADERS,
    }
  : {
      framework: null,
      cleanUrls: true,
      outputDirectory: 'frontend/dist/client',
      ...REDIRECTS_CONFIG,
      headers: LEGACY_RESPONSE_HEADERS,
      rewrites: [
        { source: '/api/(.*)', destination: '/api' },
        { source: '/(.*)', destination: '/api' },
      ],
      functions: {
        'api/index.ts': {
          includeFiles:
            '{shared/openapi_spec.yaml,node_modules/.pnpm/@seriousme+openapi-schema-validator@*/node_modules/@seriousme/openapi-schema-validator/schemas/**/*.json,frontend/dist/client/**}',
        },
      },
    };
