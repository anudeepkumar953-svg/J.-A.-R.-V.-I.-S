import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Which query strings send a CMS page to its per-request variant, and which
// URLs that must never touch. Imported by next.config.mjs and kept free of
// anything outside this template, because every generated site ships it.
//
// The CMS catch-all page is cached and cannot see the query string, so a URL
// carrying a parameter a block reads is rewritten to `/kite-facet/…`, which
// renders the same document per request with `searchParams`.

// The site's app directory: this module sits at the site root.
const SITE_APP_DIR = fileURLToPath(new URL('./src/app', import.meta.url));

// Query parameters a block reads. CollectionList's `?tag=` facet, and the AI
// tab's `?kite-preview` (src/payload/proposals.ts), which lets a signed-in
// editor see a page Kite wrote that nobody added yet. A block that reads
// another parameter must add it here, or on the published site it renders as
// if the parameter were absent.
export const FACET_QUERY_PARAMS = ['tag', 'kite-preview'];

export const FACET_PREFIX = '/kite-facet';

// Never a page: the catch-all would need a document with this slug, and the
// slug gate answers a missing one without a database read.
export const FACET_NOT_FOUND_PATH = '/_kite-facet-not-found';

const CATCH_ALL_DIR = '[[...slug]]';
const FACET_DIR = 'kite-facet';
// A site migrated onto the CMS keeps the catch-all in its required form
// `(frontend)/[...slug]` while a hand-coded page still serves `/`. Only that
// location: elsewhere `[...slug]` is a hand-coded route.
const MIGRATION_CATCH_ALL_DIR = '[...slug]';
const FRONTEND_GROUP = '(frontend)';

// A folder holding one of these serves its own URL.
const ROUTE_FILE = /^(?:page|route)\.(?:[jt]sx?|mdx?)$/;
// File-convention metadata routes (`opengraph-image.tsx`, `icon.png`,
// `sitemap.ts`, ...).
const METADATA_FILE =
  /^((favicon|icon|apple-icon|opengraph-image|twitter-image|sitemap|robots|manifest)\d*)\.([a-z]+)$/i;
const METADATA_CODE_EXTENSIONS = new Set(['js', 'jsx', 'ts', 'tsx']);
// Metadata files Next only recognises at the app root itself, outside any
// group, and the URL a code file of that kind serves.
const ROOT_ONLY_METADATA = {
  favicon: null,
  robots: 'txt',
  manifest: 'webmanifest',
};

// Next's 32-bit djb2 (next/dist/shared/lib/hash).
function djb2(value) {
  let hash = 5381;
  for (let i = 0; i < value.length; i++) {
    hash = ((hash << 5) + hash + value.charCodeAt(i)) & 0xffffffff;
  }
  return hash >>> 0;
}

// The URL segments a metadata file in folder `folder` (its path under the app
// directory, groups and slots included) serves, as owned-route tails, or none
// when Next does not treat the file as metadata:
//   static file   `<name>[-hash].<ext>`
//   sitemap code  `sitemap.xml` and `sitemap/<id>` (generateSitemaps)
//   image code    `<name>[-hash]` and `<name>[-hash]/<id>` (generateImageMetadata)
//   robots, manifest code  `robots.txt`, `manifest.webmanifest`
// Next appends a hash of the folder path when it holds a group or slot, so
// two groups cannot serve the same URL; never for a sitemap.
function metadataRoutes(folder, name, kind, extension) {
  const code = METADATA_CODE_EXTENSIONS.has(extension.toLowerCase());
  const lowerKind = kind.toLowerCase();
  if (lowerKind in ROOT_ONLY_METADATA) {
    if (folder.length > 0 || name !== kind) return [];
    const served = ROOT_ONLY_METADATA[lowerKind];
    if (code) return served ? [`${name}.${served}`] : [];
    return [`${name}.${extension}`];
  }
  if (lowerKind === 'sitemap') {
    return code ? [`${name}.xml`, `${name}/[id]`] : [`${name}.${extension}`];
  }
  const hashed = folder.some(
    (part) =>
      (part.startsWith('(') && part.endsWith(')')) ||
      (part.startsWith('@') && part !== '@children'),
  );
  const parent = `/${folder.join('/')}`;
  const base = hashed
    ? `${name}-${djb2(parent).toString(36).slice(0, 6)}`
    : name;
  return code ? [base, `${base}/[id]`] : [`${base}.${extension}`];
}

/**
 * The URL paths hand-coded routes under `appDir` serve, other than the CMS
 * catch-all and its per-request variant, as folder paths relative to the
 * app root with route groups `(name)` and parallel slots `@name` removed
 * (`blog/feed.xml`, `shop/[category]`, `` for `/`), plus the URLs each
 * metadata file serves (`robots.txt`, `blog/[slug]/opengraph-image-1g8epz`). Only a folder holding a page,
 * route or metadata file counts, so `blog/feed.xml/route.ts` owns that one URL and
 * leaves a CMS page at `/blog` alone. Private `_name` folders are not routes.
 * `dynamicRoot` names a top-level dynamic segment (e.g. `[lang]`), which
 * could own any URL.
 *
 * @param {string} appDir
 * @returns {{ ownedRoutes: string[], dynamicRoot: string | null }}
 */
export function scanRouteOwnership(appDir) {
  const owned = new Set();
  let dynamicRoot = null;
  const visit = (dir, segments, folder) => {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const entry of entries) {
      if (!entry.isFile()) continue;
      if (ROUTE_FILE.test(entry.name)) owned.add(segments.join('/'));
      const metadata = METADATA_FILE.exec(entry.name);
      if (metadata) {
        for (const tail of metadataRoutes(
          folder,
          metadata[1],
          metadata[2],
          metadata[3],
        )) {
          owned.add([...segments, tail].join('/'));
        }
      }
    }
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      const name = entry.name;
      const child = path.join(dir, name);
      if (name.startsWith('_')) continue;
      if (/^\(.*\)$/.test(name) || name.startsWith('@')) {
        visit(child, segments, [...folder, name]);
        continue;
      }
      if (segments.length === 0) {
        if (
          name === CATCH_ALL_DIR ||
          name === FACET_DIR ||
          (name === MIGRATION_CATCH_ALL_DIR &&
            path.basename(dir) === FRONTEND_GROUP)
        ) {
          continue;
        }
        if (name.startsWith('[')) {
          dynamicRoot ??= name;
          continue;
        }
      }
      visit(child, [...segments, name], [...folder, name]);
    }
  };
  visit(appDir, [], []);
  return { ownedRoutes: [...owned].sort(), dynamicRoot };
}

const escapeRegex = (value) => value.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

const SEGMENT = '[^/]+';

// The URLs one owned route serves, as a regex over the path after its leading
// slash. Only non-capturing groups: Next refuses a capturing group in a
// rewrite source.
function routePattern(route) {
  let pattern = '';
  for (const segment of route.split('/')) {
    if (/^\[\[\.\.\..+\]\]$/.test(segment)) {
      pattern += `(?:/${SEGMENT})*`;
      continue;
    }
    if (pattern) pattern += '/';
    if (/^\[\.\.\..+\]$/.test(segment)) {
      pattern += `${SEGMENT}(?:/${SEGMENT})*`;
    } else if (/^\[.+\]$/.test(segment)) {
      pattern += SEGMENT;
    } else {
      pattern += escapeRegex(segment);
    }
  }
  return pattern;
}

/**
 * The rewrites for next.config.mjs. `beforeFiles` makes `/kite-facet` itself
 * not found; `afterFiles` runs after static routes but before dynamic ones,
 * so the per-request rewrite skips every URL an owned route serves to leave
 * hand-coded dynamic routes alone. Empty when a top-level dynamic segment
 * makes that impossible.
 *
 * @param {{ ownedRoutes: string[], dynamicRoot: string | null }} ownership
 */
export function facetRewrites({ ownedRoutes, dynamicRoot }) {
  const beforeFiles = [
    { source: FACET_PREFIX, destination: FACET_NOT_FOUND_PATH },
    { source: `${FACET_PREFIX}/:path*`, destination: FACET_NOT_FOUND_PATH },
  ];
  if (dynamicRoot) return { beforeFiles, afterFiles: [] };

  const ownsRoot = ownedRoutes.includes('');
  const owned = ownedRoutes
    .filter((route) => route !== '')
    .map(routePattern)
    .join('|');
  // Anchored at the end of the whole path, so an owned route excludes only
  // the URLs it serves and not every URL that starts the same way.
  const first = owned ? `(?!(?:${owned})/?$)${SEGMENT}` : SEGMENT;
  const afterFiles = FACET_QUERY_PARAMS.flatMap((key) => {
    const has = [{ type: 'query', key }];
    return [
      ...(ownsRoot ? [] : [{ source: '/', has, destination: FACET_PREFIX }]),
      {
        source: `/:first(${first})/:rest*`,
        has,
        destination: `${FACET_PREFIX}/:first/:rest*`,
      },
    ];
  });
  return { beforeFiles, afterFiles };
}

/**
 * `nextConfig` with the facet rewrites added to whatever rewrites it already
 * has: its own `beforeFiles` after the facet ones, its own `afterFiles` (or a
 * plain rewrite list) before the per-request ones. Accepts a config object or
 * a config function. Wrapping an already wrapped config returns it as it is,
 * so the rewrites are added once however many times a config passes through.
 * `appDir` (the site's `src/app` by default) is scanned once here; a route
 * added while `next dev` runs is not seen until the dev server restarts.
 *
 * @template T
 * @param {T} nextConfig
 * @param {string} [appDir]
 * @returns {T}
 */
export function withCmsFacetRewrites(nextConfig, appDir = SITE_APP_DIR) {
  if (nextConfig?.[WRAPPED]) return nextConfig;
  const ownership = scanRouteOwnership(appDir);
  if (ownership.dynamicRoot) {
    console.warn(
      `[next.config] src/app has a top-level dynamic route ${ownership.dynamicRoot}; ` +
        'query-string facets (?tag=) on CMS pages are not rendered per request.',
    );
  }
  const facets = facetRewrites(ownership);
  const withFacets = (config) => {
    if (config?.[WRAPPED]) return config;
    return markWrapped({
      ...config,
      async rewrites() {
        const own = config?.rewrites ? await config.rewrites() : [];
        const phases = Array.isArray(own) ? { afterFiles: own } : (own ?? {});
        return {
          beforeFiles: [...facets.beforeFiles, ...(phases.beforeFiles ?? [])],
          afterFiles: [...(phases.afterFiles ?? []), ...facets.afterFiles],
          fallback: phases.fallback ?? [],
        };
      },
    });
  };
  return typeof nextConfig === 'function'
    ? markWrapped(async (...args) => withFacets(await nextConfig(...args)))
    : withFacets(nextConfig);
}

// Non-enumerable, so Next's config validation never sees an unknown key.
const WRAPPED = Symbol.for('kite.cmsFacetRewrites');
function markWrapped(value) {
  return Object.defineProperty(value, WRAPPED, { value: true });
}
