// Contract for preparing one collection item for Payload's REST create
// (scripts/prepare-collection-item.ts). A markdown body has to arrive as the
// Lexical document the seed would have made, images included, and a key the
// collection does not define has to be reported, because Payload drops it
// without a word and the item would be reported as written whole.
//
// Self-contained tsx script (the template ships no unit-test runner), run in CI
// by nextjs-template-code-quality.yml. Exits non-zero on any failure.
//
// Run locally: pnpm exec tsx scripts/prepare-collection-item.test.ts

import type { SanitizedConfig } from 'payload';
import config from '../src/payload.config';
import { makeCollection } from '../src/payload/collectionMeta';
import { prepareItem } from './prepare-collection-item';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
    return;
  }
  failures += 1;
  console.error(`  FAIL  ${name}${detail ? `: ${detail}` : ''}`);
}

type Node = { type: string; fields?: Record<string, unknown> };

const sanitized = await config;
// The template ships no content collections, so a blog's `posts` is added
// here the way generation writes one into `generated.ts`.
const posts = makeCollection('posts', {
  fields: [
    { name: 'excerpt', type: 'textarea' },
    {
      type: 'row',
      fields: [{ name: 'body', type: 'richText' }],
    },
    {
      name: 'sections',
      type: 'blocks',
      blocks: [
        {
          slug: 'quote',
          fields: [
            { name: 'text', type: 'text', required: true },
            { name: 'by', type: 'text' },
          ],
        },
      ],
    },
  ],
});
const site = {
  ...sanitized,
  collections: [
    ...sanitized.collections,
    posts as unknown as SanitizedConfig['collections'][number],
  ],
} as SanitizedConfig;

const written = await prepareItem(site, 'posts', {
  slug: 'blog/launch',
  title: 'Launch',
  excerpt: 'We launched.',
  featuredImage: 'https://static.kite.ai/hero.png',
  body: [
    'We launched today.',
    '',
    '![The team](https://static.kite.ai/team.png)',
    '',
    '## What is next',
  ].join('\n'),
});
const body = written.item.body as { root?: { children?: Node[] } } | string;
const children = typeof body === 'object' ? (body.root?.children ?? []) : [];

check(
  'an item of known fields reports nothing unknown',
  written.unknown.length === 0,
);
check(
  'a markdown body becomes a Lexical document',
  typeof body === 'object' && children.some((n) => n.type === 'heading'),
  JSON.stringify(body).slice(0, 200),
);
check(
  'an image line becomes the image block the site registers',
  children.some(
    (n) =>
      n.type === 'block' &&
      n.fields?.blockType === 'richTextImage' &&
      n.fields?.url === 'https://static.kite.ai/team.png',
  ),
);
check(
  'fields that are not rich text are left as given',
  written.item.featuredImage === 'https://static.kite.ai/hero.png' &&
    written.item.excerpt === 'We launched.',
);

const refused = await prepareItem(site, 'posts', {
  slug: 'blog/second',
  title: 'Second',
  summary: 'Not a field of posts.',
  tags: ['a'],
  body: 'Plain words.',
});
check(
  'every top-level key the collection does not define is reported',
  JSON.stringify(refused.unknown) === JSON.stringify(['summary', 'tags']),
  JSON.stringify(refused.unknown),
);
check(
  'the refusal can name every field the collection defines',
  refused.fields.includes('body') && refused.fields.includes('slug'),
  JSON.stringify(refused.fields),
);
check(
  'an item with an unknown key is not converted',
  refused.item.body === 'Plain words.',
);

const shapes = (await prepareItem(site, 'posts', {})).shapes;
const shapeOf = (name: string) => shapes.find((shape) => shape.name === name);
check(
  'the listing gives each field its type, rich text inside a row included',
  shapeOf('body')?.type === 'richText' &&
    shapeOf('excerpt')?.type === 'textarea',
  JSON.stringify(shapes).slice(0, 300),
);
check(
  'the listing says which fields are required and what a choice allows',
  shapeOf('title')?.required === true &&
    (shapeOf('status')?.options ?? []).includes('published'),
  JSON.stringify([shapeOf('title'), shapeOf('status')]),
);
const quote = shapeOf('sections')?.blocks?.find((b) => b.slug === 'quote');
check(
  'the listing gives each block its slug and its own fields, required ones marked',
  quote?.fields.find((f) => f.name === 'text')?.required === true &&
    quote?.fields.some((f) => f.name === 'by' && f.type === 'text'),
  JSON.stringify(shapeOf('sections')),
);

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`);
  process.exit(1);
}
console.log('\nall checks passed');
