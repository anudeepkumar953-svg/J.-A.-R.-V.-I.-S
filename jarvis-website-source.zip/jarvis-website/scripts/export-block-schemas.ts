/* eslint-disable no-console */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import type { Block, Field } from 'payload';
import { layoutBlocks } from '../src/payload/blocks';
import { generatedCollections } from '../src/payload/collections/generated';

// What this site can be built from, as JSON: every layout block it registers
// (the baked library plus its own `generated.ts`) with each block's fields
// serialized, and the content collections it holds.
//
// The platform plans a page against these. Inside the admin the panel reads
// them straight out of the running config (`src/admin/IdeaPanel.tsx`); a page
// generated server-side has no browser, so this script is shipped into the
// site's sandbox and run there — the site's OWN blocks, not the template's,
// which is the whole point: a bespoke `storyScroller` a design needed is
// plannable exactly like `hero`.
//
// Output: CLI arg path, else env OUT_FILE, else ./block-schemas.json.
// Needs no environment and no database: it reads the site's TypeScript config
// modules, never Payload's Local API.
//
// `serializeFields` below MIRRORS `src/admin/blockFill.tsx`, and
// `export-block-schemas.test.ts` fails if the two ever disagree. The copy is
// deliberate: this script is shipped into sites generated BEFORE the panel
// existed, where `src/admin/blockFill.tsx` is not on disk at all, so importing
// it would break the script on exactly the sites shipping it is for. (It does
// import cleanly under tsx where it exists — the reuse was verified and
// rejected on the older-site ground alone.)

export type SerializedField = {
  name: string;
  type: string;
  required?: boolean;
  options?: unknown[];
  isImage?: boolean;
  fields?: SerializedField[];
};

export type BlockSchema = {
  block_type: string;
  fields: SerializedField[];
};

export type BlockSchemaDocument = {
  blocks: BlockSchema[];
  collections: string[];
};

function isImageField(field: Field): boolean {
  if (!('name' in field) || field.type !== 'text') return false;
  // `imageUrlField()` tags image fields with `admin.custom.isImage` — the
  // authoritative signal. The `Url`-suffix check is a fallback for any image
  // text field authored without the helper.
  if (field.admin?.custom?.isImage === true) return true;
  return /url$/i.test(field.name);
}

export function serializeFields(fields: Field[]): SerializedField[] {
  const out: SerializedField[] = [];
  for (const field of fields) {
    if (field.type === 'ui' || !('name' in field)) continue;
    const s: SerializedField = { name: field.name, type: field.type };
    if ('required' in field && field.required) s.required = true;
    if ('options' in field && Array.isArray(field.options))
      s.options = field.options;
    if (isImageField(field)) s.isImage = true;
    if (
      (field.type === 'group' || field.type === 'array') &&
      'fields' in field
    ) {
      s.fields = serializeFields(field.fields);
    }
    out.push(s);
  }
  return out;
}

/**
 * The document the platform reads.
 *
 * Keys are snake_case because a Python service consumes this directly, unlike
 * the panel's camelCase bridge payloads.
 */
export function buildSchemaDocument(
  blocks: Block[],
  collectionSlugs: string[],
): BlockSchemaDocument {
  return {
    blocks: blocks.map((block) => ({
      block_type: block.slug,
      fields: serializeFields(block.fields),
    })),
    collections: [...collectionSlugs],
  };
}

function outFile(): string {
  const file = process.argv[2] ?? process.env.OUT_FILE ?? 'block-schemas.json';
  return path.isAbsolute(file) ? file : path.resolve(file);
}

function main(): void {
  // `generatedCollections` is the site's own answer to "which slugs are content
  // collections" (its module header says so): `pages` and `users` are the
  // admin's furniture and are deliberately not in it, which is the same set the
  // panel builds by filtering them out of the running config.
  const doc = buildSchemaDocument(
    layoutBlocks as Block[],
    generatedCollections.map((collection) => collection.slug),
  );
  fs.writeFileSync(outFile(), JSON.stringify(doc, null, 2));
  console.log(
    `exported ${doc.blocks.length} block schema(s) + ` +
      `${doc.collections.length} content collection(s)`,
  );
}

// Run only when executed, so the test can import the pure halves above without
// writing a file.
if (
  process.argv[1] &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  main();
}
