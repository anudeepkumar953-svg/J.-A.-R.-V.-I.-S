// Which statements of a Payload schema diff `ensure-schema.ts` may apply to a
// live database before a build. Kept beside it and free of imports so the
// rules can be tested without a database, and so the platform can copy the
// pair into any site.
//
// A statement is safe when the code already deployed keeps working after it
// and it cannot fail on the rows already there: it adds a table, column,
// index, sequence, enum type or value, or schema, or sets a column default.
// Two kinds of addition depend on existing data and are safe only on what the
// same diff creates: a unique index and a constraint (unique, primary key,
// foreign key, check). On an existing table they fail on duplicate or
// dangling rows, and would then fail every build until the data is fixed. A
// new NOT NULL column with no default is not safe either: the deployed code
// does not know the column and its inserts would fail.

const SAFE: RegExp[] = [
  /^CREATE SCHEMA\b/i,
  /^CREATE TABLE\b/i,
  /^CREATE (UNIQUE )?INDEX\b/i,
  /^CREATE SEQUENCE\b/i,
  /^CREATE TYPE \S+ AS ENUM\b/i,
  /^ALTER TYPE \S+ ADD VALUE\b/i,
  /^ALTER TABLE \S+ ADD COLUMN\b/i,
  /^ALTER TABLE \S+ ADD CONSTRAINT\b/i,
  /^ALTER TABLE \S+ ALTER COLUMN \S+ SET DEFAULT\b/i,
];

// Older drizzle-kit wraps a foreign key in a block that ignores a duplicate.
const GUARDED_CONSTRAINT =
  /^DO \$\$ BEGIN\s+(ALTER TABLE \S+ ADD CONSTRAINT\b[^;]*;)\s*EXCEPTION\s+WHEN duplicate_object THEN null;\s*END \$\$;?$/i;

const SET_DEFAULT = /^ALTER TABLE \S+ ALTER COLUMN \S+ SET DEFAULT\b/i;
const CREATE_TABLE = /^CREATE TABLE (?:IF NOT EXISTS )?(\S+)/i;
const ADD_COLUMN = /^ALTER TABLE (\S+) ADD COLUMN "([^"]+)"/i;
const UNIQUE_INDEX =
  /^CREATE UNIQUE INDEX (?:CONCURRENTLY )?(?:IF NOT EXISTS )?\S+ ON (?:ONLY )?(\S+)(?: USING \w+)? \((.*)\)/is;
const ADD_CONSTRAINT =
  /^ALTER TABLE (\S+) ADD CONSTRAINT \S+ (UNIQUE|PRIMARY KEY|FOREIGN KEY|CHECK)\b(.*)$/is;

/** What a diff creates, on which its data-dependent additions are safe. */
type Created = {
  tables: Set<string>;
  // `table.column` for columns added with no default: every existing row
  // holds NULL there, which no unique or foreign key rule rejects.
  emptyColumns: Set<string>;
};

function unwrap(statement: string): string {
  const trimmed = statement.trim();
  return GUARDED_CONSTRAINT.exec(trimmed)?.[1] ?? trimmed;
}

// Quoted identifiers and string literals blanked, so their contents never
// read as keywords or statement ends.
const withoutQuoted = (sql: string) =>
  sql.replace(/"[^"]*"/g, '""').replace(/'(?:[^']|'')*'/g, "''");

function createdBy(statements: string[]): Created {
  const created: Created = { tables: new Set(), emptyColumns: new Set() };
  for (const statement of statements.map(unwrap)) {
    const table = CREATE_TABLE.exec(statement);
    if (table) created.tables.add(table[1]);
    const column = ADD_COLUMN.exec(statement);
    if (column && !/\bDEFAULT\b/i.test(withoutQuoted(statement))) {
      created.emptyColumns.add(`${column[1]}.${column[2]}`);
    }
  }
  return created;
}

const columnsIn = (list: string) =>
  [...list.matchAll(/"([^"]+)"/g)].map((match) => match[1]);

function onCreated(table: string, columns: string[], created: Created) {
  if (created.tables.has(table)) return true;
  return (
    columns.length > 0 &&
    columns.every((column) => created.emptyColumns.has(`${table}.${column}`))
  );
}

// Unique indexes and constraints only on what this diff creates.
function dataSafe(statement: string, created: Created): boolean {
  const index = UNIQUE_INDEX.exec(statement);
  if (index) return onCreated(index[1], columnsIn(index[2]), created);
  const constraint = ADD_CONSTRAINT.exec(statement);
  if (!constraint) return true;
  const [, table, kind, rest] = constraint;
  if (/^CHECK$/i.test(kind)) return created.tables.has(table);
  // A foreign key's own columns come first; the referenced ones follow.
  const own = /^\s*(?:NULLS NOT DISTINCT\s*)?\(([^)]*)\)/i.exec(rest);
  return onCreated(table, own ? columnsIn(own[1]) : [], created);
}

// One statement per entry: a `;` before the end means a second statement
// rides behind a safe-looking first one.
function isSingle(statement: string): boolean {
  const unquoted = statement.replace(/'(?:[^']|'')*'/g, "''");
  return !/;\s*\S/.test(unquoted);
}

function isSafeSingle(statement: string, created: Created): boolean {
  if (!isSingle(statement)) return false;
  if (!SAFE.some((rule) => rule.test(statement))) return false;
  if (/^ALTER TABLE \S+ ADD COLUMN\b/i.test(statement)) {
    const unquoted = withoutQuoted(statement);
    if (/\bNOT NULL\b/i.test(unquoted) && !/\bDEFAULT\b/i.test(unquoted)) {
      return false;
    }
  }
  return dataSafe(statement, created);
}

/**
 * Whether the deployed code keeps working after this statement runs, and it
 * cannot fail on existing rows. `diff` is the whole diff it belongs to (what
 * it creates makes a unique index or constraint safe); alone by default.
 */
export function isAdditive(statement: string, diff = [statement]): boolean {
  const created = createdBy(diff);
  const trimmed = statement.trim();
  const guarded = GUARDED_CONSTRAINT.exec(trimmed);
  if (guarded) return isSafeSingle(guarded[1], created);
  return isSafeSingle(trimmed, created);
}

/** The statements of a diff that must not be applied before a deploy. */
export function notAdditive(statements: string[]): string[] {
  return statements.filter((statement) => !isAdditive(statement, statements));
}

/**
 * Drizzle proposes some column defaults on every diff even when they are
 * already set (`users.login_attempts`), so a diff of only these counts as up
 * to date.
 */
export function onlyDefaults(statements: string[]): boolean {
  return statements.every((statement) => SET_DEFAULT.test(statement.trim()));
}
