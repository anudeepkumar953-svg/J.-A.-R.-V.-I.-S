// End-to-end contract for scripts/create-schema.ts on real Postgres. The
// platform (backend `cms_publish_preview`) counts a Publish copy's tables as
// made only when the script's output holds `schema <name> is ready`, so:
//   1. a fresh schema gets its tables, and the output says so;
//   2. when Payload starts without pushing (PAYLOAD_MIGRATING=true stands in
//      for any boot that makes no tables), the script exits 1 and the output
//      never says the schema is ready.
//
// Needs `APP_DATABASE_URL` naming a Postgres SERVER where this user may create
// databases (the script makes its own and drops it) and `PAYLOAD_SECRET`
// (32+ characters). Children get only these variables, never `.env*` files.
//
// Run locally:
//   APP_DATABASE_URL=postgres://postgres@127.0.0.1:5432/postgres \
//   PAYLOAD_SECRET=<32+ chars> pnpm exec tsx scripts/create-schema.e2e.test.ts

import { spawnSync } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const TSX = path.join(ROOT, 'node_modules', '.bin', 'tsx');

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    console.error(`${name} is required (see the header of this script)`);
    process.exit(2);
  }
  return value;
}

const SERVER_URL = requireEnv('APP_DATABASE_URL');
const SECRET = requireEnv('PAYLOAD_SECRET');
const DATABASE = `create_schema_${crypto.randomBytes(4).toString('hex')}`;
const url = new URL(SERVER_URL);
url.pathname = `/${DATABASE}`;
const DATABASE_URL = url.toString();

async function query<T extends pg.QueryResultRow>(
  connectionString: string,
  text: string,
  values: unknown[] = [],
): Promise<T[]> {
  const client = new pg.Client({ connectionString });
  await client.connect();
  try {
    return (await client.query<T>(text, values)).rows;
  } finally {
    await client.end();
  }
}

// As the platform runs it in the main preview sandbox.
function scriptEnv(schema: string, extra: Record<string, string> = {}) {
  const env: Record<string, string> = {
    APP_DATABASE_URL: DATABASE_URL,
    PAYLOAD_SECRET: SECRET,
    PAYLOAD_SCHEMA: schema,
    NODE_ENV: 'development',
    // A dev boot regenerates the types file; keep the checkout as it is.
    PAYLOAD_TS_OUTPUT_PATH: path.join(os.tmpdir(), `${DATABASE}-types.ts`),
    ...extra,
  };
  for (const key of ['PATH', 'HOME', 'TMPDIR', 'LANG', 'CI']) {
    const value = process.env[key];
    if (value !== undefined) env[key] = value;
  }
  return env as NodeJS.ProcessEnv;
}

function createSchema(schema: string, extra: Record<string, string> = {}) {
  const run = spawnSync(TSX, ['scripts/create-schema.ts'], {
    cwd: ROOT,
    env: scriptEnv(schema, extra),
    stdio: ['ignore', 'pipe', 'pipe'],
    encoding: 'utf8',
  });
  return {
    code: run.status,
    stdout: run.stdout,
    output: run.stdout + run.stderr,
  };
}

async function tablesIn(schema: string): Promise<number> {
  const [row] = await query<{ tables: number }>(
    DATABASE_URL,
    "SELECT count(*)::int AS tables FROM information_schema.tables WHERE table_schema = $1 AND table_type = 'BASE TABLE'",
    [schema],
  );
  return row.tables;
}

let failures = 0;
function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok   ${name}`);
    return;
  }
  failures++;
  console.error(
    `  FAIL ${name}\n${detail.trim().split('\n').slice(-30).join('\n')}`,
  );
}

async function main(): Promise<void> {
  const made = 'payload_iter1_pub_20261013000000';
  const run = createSchema(made);
  const tables = await tablesIn(made);
  check('made: exits 0', run.code === 0, run.output);
  check(`made: the schema has tables (${tables})`, tables > 0, run.output);
  check(
    'made: the output says the schema is ready, with its table count',
    run.stdout.includes(`schema ${made} is ready (${tables} tables)`),
    run.output,
  );

  const skipped = 'payload_iter1_pub_20261013000001';
  const noPush = createSchema(skipped, { PAYLOAD_MIGRATING: 'true' });
  check('no push: exits 1', noPush.code === 1, noPush.output);
  check(
    'no push: the output never says the schema is ready',
    !noPush.output.includes(`schema ${skipped} is ready`),
    noPush.output,
  );

  const manifest = path.join(os.tmpdir(), `${DATABASE}-changed-docs.json`);
  const source = path.join(os.tmpdir(), `${DATABASE}-source.json`);
  try {
    fs.writeFileSync(
      source,
      JSON.stringify({
        pages: [{ slug: 'home', title: 'Draft merge round trip' }],
      }),
    );
    const seed = (schema: string, file: string) => {
      let run = spawnSync(TSX, ['scripts/seed-payload.ts', file], {
        cwd: ROOT,
        env: scriptEnv(schema),
        stdio: ['ignore', 'pipe', 'pipe'],
        encoding: 'utf8',
      });
      for (
        let attempt = 1;
        attempt < 3 &&
        run.status === 0 &&
        !run.stdout.includes(`seed complete: ${schema}`);
        attempt++
      ) {
        run = spawnSync(TSX, ['scripts/seed-payload.ts', file], {
          cwd: ROOT,
          env: scriptEnv(schema),
          stdio: ['ignore', 'pipe', 'pipe'],
          encoding: 'utf8',
        });
      }
      return run;
    };
    const sourceSeed = seed(made, source);
    check(
      'source seed: completes',
      sourceSeed.status === 0 &&
        sourceSeed.stdout.includes(`seed complete: ${made}`),
      sourceSeed.stdout + sourceSeed.stderr,
    );
    const exportDocs = () => {
      fs.rmSync(manifest, { force: true });
      return spawnSync(TSX, ['scripts/export-changed-docs.ts'], {
        cwd: ROOT,
        env: scriptEnv(made, {
          SINCE: '2000-01-01T00:00:00.000Z',
          OUT_FILE: manifest,
        }),
        stdio: ['ignore', 'pipe', 'pipe'],
        encoding: 'utf8',
      });
    };
    let exported = exportDocs();
    for (
      let attempt = 1;
      attempt < 3 &&
      exported.status === 0 &&
      !exported.stdout.includes(`wrote ${manifest}:`);
      attempt++
    ) {
      exported = exportDocs();
    }
    check('export: exits 0', exported.status === 0, exported.stderr);
    check(
      'export: writes its manifest',
      fs.existsSync(manifest),
      exported.stderr,
    );
    check(
      'export: reports the written manifest as its last line',
      exported.stdout
        .trimEnd()
        .split('\n')
        .at(-1)
        ?.startsWith(`wrote ${manifest}:`) ?? false,
      exported.stdout + exported.stderr,
    );
    if (fs.existsSync(manifest)) {
      check(
        'export: manifest is JSON',
        typeof JSON.parse(fs.readFileSync(manifest, 'utf8')) === 'object',
      );
      const target = 'payload_iter1_pub_20261013000002';
      const targetCreate = createSchema(target);
      check(
        'target: schema is ready',
        targetCreate.code === 0,
        targetCreate.output,
      );
      const targetSeed = seed(target, manifest);
      check(
        'target seed: completes',
        targetSeed.status === 0 &&
          targetSeed.stdout.includes(`seed complete: ${target}`),
        targetSeed.stdout + targetSeed.stderr,
      );
      const pages = await query<{ title: string }>(
        DATABASE_URL,
        `SELECT title FROM "${target}".pages WHERE slug = $1`,
        ['home'],
      );
      check(
        'draft export and seed carry the page into the target schema',
        pages[0]?.title === 'Draft merge round trip',
        JSON.stringify(pages),
      );
    }
  } finally {
    fs.rmSync(manifest, { force: true });
    fs.rmSync(source, { force: true });
  }
}

await query(SERVER_URL, `create database ${DATABASE}`);
try {
  await main();
} catch (error) {
  failures++;
  console.error(`\nFAIL ${error instanceof Error ? error.stack : error}`);
} finally {
  await query(SERVER_URL, `drop database if exists ${DATABASE} with (force)`);
}
if (failures > 0) {
  console.error(`${failures} check(s) failed`);
  process.exit(1);
}
console.log('all checks passed');
