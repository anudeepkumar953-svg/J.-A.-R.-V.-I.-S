/* eslint-disable no-console */
import fs from 'node:fs';
import path from 'node:path';
import {
  commitTransaction,
  createLocalReq,
  getPayload,
  initTransaction,
  killTransaction,
} from 'payload';
import type {
  Field,
  Payload,
  PayloadRequest,
  SanitizedConfig,
  Where,
} from 'payload';
import { sql } from '@payloadcms/db-postgres';
import config from '../src/payload.config';
import { keepLiveRowsAddedSince } from './live-rows';
import {
  convertRichTextStrings,
  markdownEditorConfig,
} from './markdown-lexical';
import { pageDeletionOrder, parentsFirst } from './page-merge';

// Idempotent seed: applies explicit deletions, upserts the SiteSettings global
// and one Pages doc per entry (keyed by `slug`), and ensures one admin user
// exists. Re-seeding never duplicates content.
//
// The platform writes this file and its siblings into sites made from every
// version of this template, so of the site's own code it imports only
// `src/payload.config.ts`. Its last line, `seed complete: <schema>`, is the
// platform's only proof the seed ran (`payload_scripts`): under tsx the process
// can end with code 0 while it is still loading the imports above.
//
// Source of the manifest, in order of precedence:
//   1. CLI arg:        `tsx scripts/seed-payload.ts path/to/seed.json`
//   2. env SEED_FILE:  absolute or cwd-relative path to a seed.json
//   3. built-in default (a single placeholder home page) so the template
//      renders out of the box during a standalone smoke test.
//
// Required env: APP_DATABASE_URL, PAYLOAD_SECRET, PAYLOAD_SCHEMA.

type SeedDoc = Record<string, unknown> & { slug: string };
type SeedManifest = {
  siteSettings?: Record<string, unknown>;
  pages?: SeedDoc[];
  // Repeating content collections keyed by collection slug (e.g. `posts`).
  collections?: Record<string, SeedDoc[]>;
  deletions?: {
    pages?: string[];
    collections?: Record<string, string[]>;
  };
};

const DEFAULT_MANIFEST: SeedManifest = {
  siteSettings: {
    brandName: 'Untitled Site',
  },
  pages: [
    {
      slug: 'home',
      title: 'Home',
      layout: [
        {
          blockType: 'hero',
          heading: 'Welcome',
          subheading: 'This site is powered by an embedded CMS.',
        },
      ],
    },
  ],
};

function loadManifest(): SeedManifest {
  const fromArg = process.argv[2];
  const fromEnv = process.env.SEED_FILE;
  const file = fromArg ?? fromEnv;
  if (file) {
    const resolved = path.isAbsolute(file) ? file : path.resolve(file);
    if (!fs.existsSync(resolved)) {
      throw new Error(`seed file not found: ${resolved}`);
    }
    return JSON.parse(fs.readFileSync(resolved, 'utf-8')) as SeedManifest;
  }
  return DEFAULT_MANIFEST;
}

function mergeNestedFields(
  patch: Record<string, unknown>,
  current: Record<string, unknown>,
): Record<string, unknown> {
  const merged: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(patch)) {
    const existing = current[key];
    if (
      value !== null &&
      typeof value === 'object' &&
      !Array.isArray(value) &&
      existing !== null &&
      typeof existing === 'object' &&
      !Array.isArray(existing)
    ) {
      merged[key] = {
        ...(existing as Record<string, unknown>),
        ...mergeNestedFields(
          value as Record<string, unknown>,
          existing as Record<string, unknown>,
        ),
      };
    } else {
      merged[key] = value;
    }
  }
  return merged;
}

// Row-locks the site-settings global inside req's transaction. A concurrent
// Payload save updates the same row, so it waits until this transaction ends.
async function lockSiteSettings(payload: Payload, req: PayloadRequest) {
  const schema = process.env.PAYLOAD_SCHEMA?.trim() || 'public';
  if (!/^[a-z0-9_]+$/i.test(schema)) {
    throw new Error(`unexpected PAYLOAD_SCHEMA ${schema}`);
  }
  const adapter = payload.db as unknown as {
    sessions?: Record<
      string,
      { db?: { execute: (query: unknown) => Promise<unknown> } }
    >;
  };
  const transactionID = await req.transactionID;
  const tx = transactionID
    ? adapter.sessions?.[String(transactionID)]?.db
    : undefined;
  if (!tx) throw new Error('site-settings merge has no transaction to lock in');
  await tx.execute(
    sql.raw(`SELECT id FROM "${schema}"."site_settings" FOR UPDATE`),
  );
}

async function main() {
  const manifest = loadManifest();
  const payload = await getPayload({ config });

  // Build the markdown→Lexical editor config once; seed docs may carry richText
  // bodies as markdown strings, which are converted in place before upsert.
  const sanitizedConfig = payload.config as unknown as SanitizedConfig;
  const editorConfig = await markdownEditorConfig(sanitizedConfig);
  const fieldsForCollection = (slug: string): Field[] | undefined =>
    sanitizedConfig.collections?.find((c) => c.slug === slug)?.fields;
  const fieldsForGlobal = (slug: string): Field[] | undefined =>
    sanitizedConfig.globals?.find((g) => g.slug === slug)?.fields;

  // Ensure an admin user exists for the platform-token strategy to resolve.
  // No password: the local email/password strategy is disabled on the Users
  // collection, so the signed platform cookie is the only way to authenticate.
  const existingUsers = await payload.count({ collection: 'users' });
  if (existingUsers.totalDocs === 0) {
    const email = process.env.PAYLOAD_ADMIN_EMAIL ?? 'admin@kite.local';
    await payload.create({ collection: 'users', data: { email } });
    console.log(`seeded admin user: ${email}`);
  }

  for (const [collection, slugs] of Object.entries(
    manifest.deletions?.collections ?? {},
  )) {
    for (const slug of slugs) {
      const existing = await payload.find({
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        collection: collection as any,
        where: { slug: { equals: slug } },
        limit: 1,
      });
      if (existing.docs[0]) {
        await payload.delete({
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          collection: collection as any,
          id: existing.docs[0].id,
        });
        console.log(`deleted ${collection}: ${slug}`);
      }
    }
  }

  if (manifest.siteSettings) {
    convertRichTextStrings(
      fieldsForGlobal('site-settings'),
      manifest.siteSettings,
      editorConfig,
    );
    // A draft merge passes its branch point: list rows the owner added on the
    // live site since then are kept rather than overwritten (live-rows.ts).
    // It reads, merges and writes under one row lock, so an admin save made
    // meanwhile waits for the merge and lands after it instead of being
    // replaced by a merge built from an older read.
    const since = process.env.SINCE ? new Date(process.env.SINCE) : null;
    const req = await createLocalReq({}, payload);
    const ownsTransaction = await initTransaction(req);
    try {
      if (since) await lockSiteSettings(payload, req);
      const current = await payload.findGlobal({ slug: 'site-settings', req });
      const settings = since
        ? keepLiveRowsAddedSince(
            manifest.siteSettings,
            current as unknown as Record<string, unknown>,
            since,
          )
        : manifest.siteSettings;
      const update = mergeNestedFields(
        settings,
        current as unknown as Record<string, unknown>,
      );
      await payload.updateGlobal({
        slug: 'site-settings',
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        data: update as any,
        req,
      });
      if (ownsTransaction) await commitTransaction(req);
    } catch (err) {
      if (ownsTransaction) await killTransaction(req);
      throw err;
    }
    console.log('upserted site-settings global');
  }

  const pagesFields = fieldsForCollection('pages');
  // A page may name its parent by address (`parentSlug`, as a draft merge
  // exports it): written parents-first, so the parent is already here and its
  // id in this schema is the one to store.
  for (const entry of parentsFirst(manifest.pages ?? [])) {
    const { parentSlug, ...rest } = entry as SeedDoc & { parentSlug?: string };
    const page = rest as SeedDoc;
    if (typeof parentSlug === 'string') {
      const parent = await payload.find({
        collection: 'pages',
        where: { slug: { equals: parentSlug } },
        limit: 1,
        depth: 0,
      });
      if (!parent.docs[0]) {
        throw new Error(
          `page "${page.slug}" sits under "${parentSlug}", which this site does not have`,
        );
      }
      page.parent = parent.docs[0].id;
    }
    convertRichTextStrings(pagesFields, page, editorConfig);
    const existing = await payload.find({
      collection: 'pages',
      where: { slug: { equals: page.slug } },
      limit: 1,
    });
    if (existing.docs[0]) {
      const update = mergeNestedFields(
        page,
        existing.docs[0] as unknown as Record<string, unknown>,
      );
      await payload.update({
        collection: 'pages',
        id: existing.docs[0].id,
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        data: update as any,
      });
      console.log(`updated page: ${page.slug}`);
    } else {
      await payload.create({
        collection: 'pages',
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        data: page as any,
      });
      console.log(`created page: ${page.slug}`);
    }
  }

  // Pages leave last and deepest first, so every kept child is already under
  // its new parent and no removed page still has one: a seed that stops
  // part-way leaves pages behind, never a child without its parent.
  for (const slug of pageDeletionOrder(
    manifest.deletions?.pages ?? [],
    (manifest.pages ?? []).map((page) => String(page.slug)),
  )) {
    const existing = await payload.find({
      collection: 'pages',
      where: { slug: { equals: slug } },
      limit: 1,
    });
    if (existing.docs[0]) {
      await payload.delete({
        collection: 'pages',
        id: existing.docs[0].id,
      });
      console.log(`deleted page: ${slug}`);
    }
  }

  // Repeating content collections (blog posts, etc.). Upsert by slug exactly
  // like pages, so re-seeding never duplicates items.
  for (const [collection, docs] of Object.entries(manifest.collections ?? {})) {
    const collectionFields = fieldsForCollection(collection);
    for (const doc of docs) {
      convertRichTextStrings(collectionFields, doc, editorConfig);
      const existing = await payload.find({
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        collection: collection as any,
        where: { slug: { equals: doc.slug } },
        limit: 1,
      });
      if (existing.docs[0]) {
        const update = mergeNestedFields(
          doc,
          existing.docs[0] as Record<string, unknown>,
        );
        await payload.update({
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          collection: collection as any,
          id: existing.docs[0].id,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          data: update as any,
        });
        console.log(`updated ${collection}: ${doc.slug}`);
      } else {
        await payload.create({
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          collection: collection as any,
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          data: doc as any,
        });
        console.log(`created ${collection}: ${doc.slug}`);
      }
    }
  }

  // Last, and never fatal: this is a cosmetic editor preference, while the
  // seed above is the site's entire content. A throw here would exit non-zero,
  // which the platform reads as a failed seed and fails the whole design
  // iteration — trading every page on the site for the preview pane's default
  // position.
  try {
    await defaultEditViewsToLivePreview(payload);
  } catch (err) {
    console.warn('could not default edit views to live preview:', err);
  }

  // `process.exit` drops the published-site refresh the save hooks queued.
  // Looked up by global name: the platform runs this script on sites whose
  // revalidate module may predate it.
  const flushPublishedSite = (globalThis as Record<symbol, unknown>)[
    Symbol.for('kite.flushPublishedSiteRevalidation')
  ];
  if (typeof flushPublishedSite === 'function') await flushPublishedSite();

  // Exit once the line is written: the open database pool would keep the
  // process alive.
  const schema = process.env.PAYLOAD_SCHEMA?.trim() || 'public';
  process.stdout.write(`seed complete: ${schema}\n`, () => process.exit(0));
}

/**
 * Open the preview-enabled edit views in Live Preview by default.
 *
 * Payload has no config option for the initial edit-view mode: the Document
 * RSC reads the entity's row of `payload-preferences` (`collection-{slug}` /
 * `global-{slug}`) and only renders the preview pane when its `editViewType`
 * is `live-preview`. Seeding that row is therefore the only way to make the
 * preview the first thing an editor sees — a client-side flip would paint the
 * form-only layout first and jump.
 *
 * Two constraints this respects:
 *  - **Write only when unset.** The same row records the editor's own toggle,
 *    so overwriting it would re-force the preview open every seed for someone
 *    who deliberately closed it.
 *  - **Preserve the rest of `value`.** The key is shared with the entity's
 *    other view state (e.g. the Pages list view's columns, sort, limit); a
 *    wholesale write would reset those.
 *
 * Seed only entities opted into `admin.livePreview` (payload.config.ts) —
 * for any other key the split layout would render with an empty pane.
 */
async function defaultEditViewsToLivePreview(
  payload: Awaited<ReturnType<typeof getPayload>>,
): Promise<void> {
  const admin = await payload.find({
    collection: 'users',
    limit: 1,
    sort: 'createdAt',
  });
  const adminUser = admin.docs[0];
  if (!adminUser) return;

  for (const key of ['collection-pages', 'global-site-settings']) {
    // The same where-clause shape Payload's own preferences update uses, so the
    // row this matches is exactly the one the Document view later reads.
    const where: Where = {
      and: [
        { key: { equals: key } },
        { 'user.value': { equals: adminUser.id } },
        { 'user.relationTo': { equals: 'users' } },
      ],
    };

    const existing = await payload.find({
      collection: 'payload-preferences',
      where,
      limit: 1,
    });
    const currentValue = (existing.docs[0]?.value ?? {}) as Record<
      string,
      unknown
    >;
    if (currentValue.editViewType) continue; // the editor's own choice wins

    // `db.upsert` rather than the Local API: the preferences collection's
    // `user` field is required and filled by a `beforeValidate` hook from
    // `req.user`, which a script has none of. With no matching row it inserts.
    await payload.db.upsert({
      collection: 'payload-preferences',
      data: {
        key,
        user: { relationTo: 'users', value: adminUser.id },
        value: { ...currentValue, editViewType: 'live-preview' },
      },
      where,
    });
    console.log(`defaulted ${key} to live preview`);
  }
}

main().catch((err) => {
  console.error('seed failed:', err);
  process.exit(1);
});
