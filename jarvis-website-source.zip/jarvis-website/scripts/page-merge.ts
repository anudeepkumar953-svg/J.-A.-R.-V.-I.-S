// What merging a draft carries for Pages, decided apart from the scripts that
// run it (`export-changed-docs.ts` reads the draft, `seed-payload.ts` writes
// main) so the rules can be tested without a database. Kept beside them and
// free of imports: the platform copies these three files into a site's
// sandbox at merge time, whatever template version the site was built from.
//
// Three rules:
// - A proposal (a page Kite wrote that the editor never added) stays in the
//   draft. Only pages the editor added reach main.
// - Users and the `page-proposals` collection (Main's proposals, copied into
//   a draft cloned from it) are never merged.
// - A page's parent travels as the parent's address, not its id. Ids are
//   handed out separately in the draft and in main, so a parent created in
//   the draft gets a different id in main; the address is the same in both.

type PageDoc = Record<string, unknown> & { slug: string };

const NEVER_MERGED = new Set(['users', 'page-proposals']);

/** The registered collections whose changed documents a merge carries. */
export function collectionsForMerge(slugs: string[]): string[] {
  return slugs.filter((slug) => !NEVER_MERGED.has(slug));
}
type RelationValue = string | number | { id?: unknown } | null | undefined;

function relationId(value: RelationValue): string | null {
  if (value === null || value === undefined) return null;
  if (typeof value === 'string' || typeof value === 'number') {
    return String(value);
  }
  return value.id === undefined || value.id === null ? null : String(value.id);
}

/**
 * The changed pages a merge carries, ready for main: proposals dropped, and
 * each parent id replaced by `parentSlug`, read from every page the draft
 * has (the parent itself may not have changed).
 */
export function pagesForMerge(
  changed: PageDoc[],
  allDraftPages: { id: unknown; slug: unknown }[],
): PageDoc[] {
  const slugById = new Map(
    allDraftPages
      .filter((page) => typeof page.slug === 'string')
      .map((page) => [String(page.id), page.slug as string]),
  );
  return changed
    .filter((page) => page.proposed !== true)
    .map((page) => {
      const { parent, ...rest } = page;
      const parentId = relationId(parent as RelationValue);
      if (parentId === null) return rest as PageDoc;
      const parentSlug = slugById.get(parentId);
      if (parentSlug === undefined) {
        throw new Error(
          `page "${page.slug}" sits under page ${parentId}, which the draft does not have`,
        );
      }
      return { ...rest, parentSlug } as PageDoc;
    });
}

/**
 * Pages in an order that writes every parent before its children, so a child
 * can look its parent up by address. Shallower addresses go first; ties keep
 * their order.
 */
export function parentsFirst<T extends { slug: string }>(pages: T[]): T[] {
  const depth = (slug: string) => slug.split('/').filter(Boolean).length;
  return pages
    .map((page, index) => ({ page, index }))
    .sort(
      (a, b) => depth(a.page.slug) - depth(b.page.slug) || a.index - b.index,
    )
    .map(({ page }) => page);
}

/**
 * The pages a seed removes, in the order it may remove them: never a page the
 * same seed writes, and children before their parents, so the CMS never sees
 * a parent removed while a page still sits under it.
 */
export function pageDeletionOrder(
  deletions: string[],
  written: string[],
): string[] {
  const kept = new Set(written);
  const depth = (slug: string) => slug.split('/').length;
  return [...new Set(deletions)]
    .filter((slug) => !kept.has(slug))
    .sort((a, b) => depth(b) - depth(a) || b.localeCompare(a));
}
