import {
  convertMarkdownToLexical,
  editorConfigFactory,
} from '@payloadcms/richtext-lexical';
import type {
  DefaultTypedEditorState,
  LexicalRichTextAdapter,
  SanitizedServerEditorConfig,
} from '@payloadcms/richtext-lexical';
import type { Field, SanitizedConfig } from 'payload';

// The seed's markdown → Lexical conversion. Kept beside `seed-payload.ts` and
// `prepare-collection-item.ts`, and importing only packages every Payload site
// has, because the platform copies it with them into a site's sandbox, whatever
// template version the site was built from. `src/payload/lexical.ts`
// re-exports it.

// Resolve the editor config the markdown→Lexical converter needs. Built once per
// seed run (it's the expensive part) and reused across every `markdownDoc` call.
// Uses the app's own editor, so markdown converts to the blocks it registers
// (images: src/payload/richText.ts).
export async function markdownEditorConfig(
  config: SanitizedConfig,
): Promise<SanitizedServerEditorConfig> {
  const editor = config.editor as Partial<LexicalRichTextAdapter> | undefined;
  return editor?.editorConfig ?? editorConfigFactory.default({ config });
}

// An inline markdown image and the spaces beside it. A linked image
// (`[![alt](src)](href)`) is skipped: splitting it would break the link.
const MARKDOWN_IMAGE =
  /[ \t]*((?<!\[)!\[[^\]]*\]\(\s*<?[^\s)>]+>?(?:\s+"[^"]*")?\s*\))[ \t]*/g;
const CODE_FENCE = /^\s{0,3}(?:```|~~~)/;
// List items, quotes, tables and headings keep their images inline.
const STRUCTURED_LINE = /^\s*(?:[-*+]\s|\d+[.)]\s|>|\||#)/;

// The converter joins soft-wrapped lines into one paragraph before matching,
// so an image only becomes an image block when blank lines surround it.
export function isolateMarkdownImages(markdown: string): string {
  let inFence = false;
  return markdown
    .split('\n')
    .map((line) => {
      if (CODE_FENCE.test(line)) {
        inFence = !inFence;
        return line;
      }
      if (inFence || STRUCTURED_LINE.test(line)) return line;
      return line.replace(MARKDOWN_IMAGE, (_, image) => `\n\n${image}\n\n`);
    })
    .join('\n');
}

// Convert a long-form markdown string into a Lexical richText document, so seed
// content can be authored as markdown (headings, lists, quotes, links, bold, images)
// rather than hand-built node trees — `lexicalDoc` only carries plain-text
// paragraphs and silently drops every other markdown construct. Runs at seed
// time; the admin still stores/edits real Lexical, so it round-trips on re-seed.
export function markdownDoc(
  editorConfig: SanitizedServerEditorConfig,
  markdown: string,
): DefaultTypedEditorState {
  return convertMarkdownToLexical({
    editorConfig,
    markdown: isolateMarkdownImages(markdown),
  }) as unknown as DefaultTypedEditorState;
}

// Walk a list of Payload field configs alongside a data object and convert any
// `richText` field whose seed value is a plain string into a Lexical document
// (treating the string as markdown). Seed content may author long-form bodies as
// markdown strings; Payload's Local API rejects a string for richText, so this
// converts in place before upsert. Mirrors the validator's `dataFields`
// flattening so presentational wrappers (row/collapsible/unnamed group/tabs)
// share the parent's data namespace.
export function convertRichTextStrings(
  fields: Field[] | undefined,
  data: unknown,
  editorConfig: SanitizedServerEditorConfig,
): void {
  if (!fields || data === null || typeof data !== 'object') return;
  const obj = data as Record<string, unknown>;
  for (const f of fields) {
    if (!f || typeof f !== 'object') continue;
    const type = (f as { type?: string }).type;
    const name = (f as { name?: string }).name;
    const sub = (f as { fields?: Field[] }).fields;
    if (type === 'ui') continue;
    // Presentational wrappers: children live in the parent's namespace.
    if (
      type === 'row' ||
      type === 'collapsible' ||
      (type === 'group' && !name)
    ) {
      convertRichTextStrings(sub, obj, editorConfig);
      continue;
    }
    if (type === 'tabs') {
      for (const tab of (f as { tabs?: { name?: string; fields?: Field[] }[] })
        .tabs ?? []) {
        if (tab.name) {
          convertRichTextStrings(tab.fields, obj[tab.name], editorConfig);
        } else {
          convertRichTextStrings(tab.fields, obj, editorConfig);
        }
      }
      continue;
    }
    if (!name) continue;
    const value = obj[name];
    if (type === 'richText') {
      if (typeof value === 'string') {
        obj[name] = markdownDoc(editorConfig, value);
      }
    } else if (type === 'group') {
      convertRichTextStrings(sub, value, editorConfig);
    } else if (type === 'array') {
      if (Array.isArray(value)) {
        for (const item of value)
          convertRichTextStrings(sub, item, editorConfig);
      }
    } else if (type === 'blocks') {
      if (Array.isArray(value)) {
        const bySlug = new Map(
          (
            (f as { blocks?: { slug: string; fields?: Field[] }[] }).blocks ??
            []
          ).map((b) => [b.slug, b]),
        );
        for (const item of value) {
          const block = bySlug.get(
            (item as { blockType?: string })?.blockType ?? '',
          );
          if (block) convertRichTextStrings(block.fields, item, editorConfig);
        }
      }
    }
  }
}
