// Brings the live database up to the schema this code needs, before the build
// that will serve it (`pnpm run build` runs it ahead of `next build`). Payload's
// own production migrations cannot run here: the preview sandboxes push the
// schema in dev mode against the same database, and the migrator then stops
// on a "you've run Payload in dev mode" question.
//
// The diff is the one Payload's dev push makes. It is applied only when every
// statement passes `schema-diff-policy.ts`, which code already deployed
// tolerates. Anything else applies nothing and fails the build, so the
// published site stays on its current deployment.
//
// Needs APP_DATABASE_URL and PAYLOAD_SECRET in the environment (PAYLOAD_SCHEMA
// picks the schema); without a database URL there is nothing to check.
// ENSURE_SCHEMA_KEEP_DRIFT=1 is the operator's way past a site whose schema
// already differed before the deploy (old relational block tables, a hand
// repair): the additive statements apply, the refused ones are only logged.
import { existsSync } from 'node:fs';
import { sql } from '@payloadcms/db-postgres';
import { getPayload } from 'payload';
// Static: a dynamic import() of the config under tsx hung about one run in
// fifteen with an idle event loop.
import config from '../src/payload.config';
import { notAdditive, onlyDefaults } from './schema-diff-policy';

const TIMEOUT_MS = 120_000;
const ENUM_VALUE = /^ALTER TYPE \S+ ADD VALUE\b/i;

type PushResult = {
  hasDataLoss: boolean;
  warnings: string[];
  statementsToExecute: string[];
};

type Executor = {
  execute: (query: unknown) => Promise<{ rows: Record<string, unknown>[] }>;
};

type DrizzleAdapter = {
  schema: unknown;
  drizzle: Executor & {
    transaction: <T>(run: (tx: Executor) => Promise<T>) => Promise<T>;
  };
  schemaName?: string;
  tablesFilter?: string[];
  extensions?: { postgis?: boolean };
  requireDrizzleKit: () => {
    pushSchema: (
      schema: unknown,
      drizzle: unknown,
      schemaFilters?: string[],
      tablesFilter?: string[],
      extensionsFilter?: string[],
    ) => Promise<PushResult>;
  };
};

function log(message: string): void {
  console.log(`[ensure-schema] ${message}`);
}

function fail(message: string): never {
  for (const line of message.split('\n')) {
    console.error(`[ensure-schema] ${line}`);
  }
  process.exit(1);
}

async function main(): Promise<void> {
  // A historical file may include authored guidance. Do not discard it to
  // resolve Next's public-file/route collision.
  const siteRoot = new URL('../', import.meta.url);
  if (
    existsSync(new URL('src/app/(payload)/llms.txt/route.ts', siteRoot)) &&
    existsSync(new URL('public/llms.txt', siteRoot))
  ) {
    fail(
      'public/llms.txt conflicts with the CMS route; the file was preserved. ' +
        'Review its guidance, transfer applicable content into CMS site/page descriptions, ' +
        'then explicitly remove the static file before rebuilding.',
    );
  }
  if (!process.env.APP_DATABASE_URL) {
    log('no APP_DATABASE_URL; nothing to check');
    return;
  }
  // Keeps Payload from running its own dev push while it starts up here.
  process.env.PAYLOAD_MIGRATING = 'true';
  const payload = await getPayload({ config });
  const adapter = payload.db as unknown as DrizzleAdapter;
  // A schema Payload never pushed is not this site's content (a lost
  // PAYLOAD_SCHEMA points at `public`); building a CMS there would serve an
  // empty site, so leave it to the build as it was.
  const migrations = `"${adapter.schemaName ?? 'public'}"."payload_migrations"`;
  const { rows } = await adapter.drizzle.execute(
    sql.raw(`select to_regclass('${migrations}') is not null as pushed`),
  );
  if (!rows[0]?.pushed) {
    log(`${migrations} does not exist; not a Payload schema, nothing applied`);
    return;
  }
  // The same call Payload's dev push makes (`pushDevSchema`).
  const { pushSchema } = adapter.requireDrizzleKit();
  const { hasDataLoss, warnings, statementsToExecute } = await pushSchema(
    adapter.schema,
    adapter.drizzle,
    adapter.schemaName ? [adapter.schemaName] : undefined,
    adapter.tablesFilter,
    adapter.extensions?.postgis ? ['postgis'] : undefined,
  );
  if (statementsToExecute.length === 0) {
    log('schema is up to date');
    return;
  }
  const refused = notAdditive(statementsToExecute);
  const unsafe = hasDataLoss || warnings.length > 0 || refused.length > 0;
  if (unsafe && process.env.ENSURE_SCHEMA_KEEP_DRIFT !== '1') {
    fail(
      [
        'the schema change is not additive; nothing was applied.',
        ...warnings,
        ...refused.map((statement) => `not additive: ${statement.trim()}`),
        'If these statements are drift this site had before the deploy, set',
        'ENSURE_SCHEMA_KEEP_DRIFT=1 on the deployment to apply only the',
        'additive statements and leave the rest of the schema as it is.',
      ].join('\n'),
    );
  }
  const additive = statementsToExecute.filter(
    (statement) => !refused.includes(statement),
  );
  for (const statement of refused) log(`kept as it is: ${statement.trim()}`);
  for (const statement of additive) log(statement.trim());
  // All or nothing, so a build that stops part way leaves the schema as it
  // was and the next build sees the same diff (a lone foreign key or unique
  // index on a table an earlier run created would be refused). New enum
  // values go first and outside: Postgres cannot use a value added in the
  // same transaction, and a value already added drops out of the next diff.
  const enumValues = additive.filter((statement) =>
    ENUM_VALUE.test(statement.trim()),
  );
  for (const statement of enumValues) {
    await adapter.drizzle.execute(sql.raw(statement));
  }
  await adapter.drizzle.transaction(async (tx) => {
    for (const statement of additive) {
      if (!enumValues.includes(statement)) await tx.execute(sql.raw(statement));
    }
  });
  if (additive.length === 0 || onlyDefaults(additive)) {
    log(
      `schema is up to date (re-set ${additive.length} column default(s)${
        refused.length > 0 ? `, kept ${refused.length} drift statement(s)` : ''
      })`,
    );
    return;
  }
  log(
    `applied ${additive.length} additive statement(s)${
      refused.length > 0 ? `; kept ${refused.length} drift statement(s)` : ''
    }`,
  );
}

// A diff drizzle cannot settle alone (a possible rename) waits for an answer
// that never comes in a build; fail rather than hang.
const timer = setTimeout(
  () =>
    fail(
      'timed out after 120 s: the diff needs a decision (a possible rename), or the database is too slow',
    ),
  TIMEOUT_MS,
);
main()
  .then(() => {
    clearTimeout(timer);
    process.exit(0);
  })
  .catch((error: unknown) =>
    fail(
      error instanceof Error ? (error.stack ?? error.message) : String(error),
    ),
  );
