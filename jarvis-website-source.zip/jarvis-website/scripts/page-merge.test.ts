// Contract for what a draft merge carries for Pages: only pages the editor
// added, each parent by its address so it resolves in main whatever id main
// gave it, and never Main's page proposals or its users.
//
// Run locally: pnpm exec tsx scripts/page-merge.test.ts

import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  collectionsForMerge,
  pageDeletionOrder,
  pagesForMerge,
  parentsFirst,
} from './page-merge';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

const draftPages = [
  { id: 2, slug: 'menu-visit' },
  { id: 3, slug: 'catering' },
  { id: 4, slug: 'catering/office-lunches' },
  { id: 5, slug: 'gift-cards' },
];

{
  console.log('a merge carries only the pages the editor added');
  const merged = pagesForMerge(
    [
      { slug: 'catering', proposed: false },
      { slug: 'gift-cards', proposed: true },
      { slug: 'older-page' },
    ],
    draftPages,
  );
  check(
    'a proposal stays in the draft; added and older pages go',
    merged.map((page) => page.slug).join(',') === 'catering,older-page',
  );
}

{
  console.log('a parent travels by its address');
  const [child, underExisting, topLevel] = pagesForMerge(
    [
      { slug: 'catering/office-lunches', parent: 3 },
      { slug: 'menu-visit/hours', parent: { id: 2 } },
      { slug: 'catering', parent: null },
    ],
    draftPages,
  );
  check(
    'a parent made in the draft is named by its address, not its draft id',
    child.parentSlug === 'catering' && !('parent' in child),
  );
  check(
    'a populated parent is read the same way',
    underExisting.parentSlug === 'menu-visit',
  );
  check(
    'a top-level page carries no parent',
    !('parentSlug' in topLevel) && !('parent' in topLevel),
  );
  let refused = '';
  try {
    pagesForMerge([{ slug: 'x/y', parent: 99 }], draftPages);
  } catch (error) {
    refused = String(error);
  }
  check(
    'a parent the draft does not have stops the merge',
    refused.includes('99'),
  );
}

{
  console.log('proposals and users never leave the draft');
  // Every collection a site registers, as `export-changed-docs.ts` reads
  // them from the running config.
  const merged = collectionsForMerge([
    'users',
    'pages',
    'page-proposals',
    'posts',
    'payload-preferences',
  ]);
  check(
    'page proposals copied from Main are not exported',
    !merged.includes('page-proposals'),
    merged.join(','),
  );
  check('users are not exported', !merged.includes('users'));
  check(
    'pages and content collections still are',
    merged.includes('pages') && merged.includes('posts'),
  );

  const exporter = readFileSync(
    join(dirname(fileURLToPath(import.meta.url)), 'export-changed-docs.ts'),
    'utf8',
  );
  check(
    'the export reads its collection list through this rule',
    /collectionsForMerge\(\s*\(sanitized\.collections/.test(exporter),
  );
}

{
  console.log('parents are written before their children');
  const order = parentsFirst([
    { slug: 'catering/office-lunches/menus' },
    { slug: 'catering/office-lunches' },
    { slug: 'gift-cards' },
    { slug: 'catering' },
  ]).map((page) => page.slug);
  check(
    'shallower addresses first, ties in their original order',
    order.join(',') ===
      'gift-cards,catering,catering/office-lunches,catering/office-lunches/menus',
    order.join(','),
  );
}

{
  console.log(
    '\na seed removes children before their parents, and never what it writes',
  );
  const order = pageDeletionOrder(
    [
      'menu-visit',
      'menu-visit/catering',
      'menu-visit/catering/office',
      'about',
      'jobs',
    ],
    ['jobs'],
  );
  check(
    'deepest first; a page the seed also writes stays',
    order.join(',') ===
      'menu-visit/catering/office,menu-visit/catering,menu-visit,about',
  );
  check(
    'a page named twice is removed once',
    pageDeletionOrder(['a', 'a'], []).join(',') === 'a',
  );
  const seed = readFileSync(
    join(dirname(fileURLToPath(import.meta.url)), 'seed-payload.ts'),
    'utf8',
  );
  check(
    'the seeder removes pages after it has written the kept ones',
    seed.indexOf('pageDeletionOrder(') >
      seed.indexOf('parentsFirst(manifest.pages'),
  );
}

if (failures > 0) {
  console.error(`\n${failures} check(s) failed`);
  process.exit(1);
}
console.log('\nall checks passed');
