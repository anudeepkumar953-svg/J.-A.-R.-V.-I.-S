/* eslint-disable no-console */
import { getPayload } from 'payload';
import config from '../src/payload.config';

// Create the Payload tables of the schema PAYLOAD_SCHEMA names, then exit.
//
// Publish copies a site's content into a fresh schema before the deployed site
// reads it, and only Payload's `push` knows the tables this code needs. Push
// runs when Payload boots outside production, so the platform runs this once
// in the site's editing sandbox (same code Publish deploys) with
// `NODE_ENV=development`. The deployed site never pushes. Not
// `ensure-schema.ts`, which the build runs to bring an existing schema up to
// this code and which leaves a schema with no tables alone.
//
// The platform writes this file into every Payload site, whatever version of
// this template made it, so it imports only what all of them have: `payload`
// and the site's `src/payload.config.ts`.
//
// The last line, `schema <name> is ready (<n> tables)`, is the platform's only
// proof that the tables exist (`cms_publish_preview`), so it is printed after
// counting them. Exit code 0 is not proof: under tsx the process can end with
// code 0 while it is still loading the imports above, before any line here
// runs.
//
// Required env: APP_DATABASE_URL, PAYLOAD_SECRET, PAYLOAD_SCHEMA.

async function main() {
  // Unset or `public` would push into the connection's default schema.
  const schema = process.env.PAYLOAD_SCHEMA;
  if (!schema || schema === 'public') {
    throw new Error('PAYLOAD_SCHEMA is required');
  }
  const payload = await getPayload({ config });
  const { rows } = await payload.db.pool.query<{ tables: number }>(
    "SELECT count(*)::int AS tables FROM information_schema.tables WHERE table_schema = $1 AND table_type = 'BASE TABLE'",
    [schema],
  );
  const tables = rows[0]?.tables ?? 0;
  if (tables === 0) {
    throw new Error(`Payload started but made no tables in ${schema}`);
  }
  // Exit once the line is written: the open database pool would keep the
  // process alive.
  process.stdout.write(`schema ${schema} is ready (${tables} tables)\n`, () =>
    process.exit(0),
  );
}

main().catch((err) => {
  console.error('create-schema failed:', err);
  process.exit(1);
});
