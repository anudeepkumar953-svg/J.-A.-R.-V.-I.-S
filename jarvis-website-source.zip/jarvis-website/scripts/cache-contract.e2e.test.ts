// End-to-end contract for how a published site serves CMS pages from cache
// (production build, real Postgres). Pins what the unit contracts cannot:
//   - a CMS page is rendered once, then served from cache with `s-maxage=30`;
//   - a write followed by the signed `/cms-revalidate` shows on the next
//     request, and a write with no signal shows after the 30-second window;
//   - `?tag=` reaches the per-request variant (`no-store`), a tracking-only
//     query string gets the cached page, `/kite-facet` itself is not found, and
//     a hand-coded route keeps its own page, per request, even with `?tag=`;
//   - a new unknown URL is a 404 with no database transaction, and a page
//     created later becomes reachable once the signal fires;
//   - `/sitemap.xml` lists every page of a site with more than 1,000, and a
//     repeat request runs no database transaction;
//   - under `next dev` nothing is cached.
// Not covered: that a block receives `searchParams` on the per-request
// variant. No stock block shows `?tag=` without a content collection, which
// the template does not register; only the routing (headers) is checked here.
//
// The script builds its own copy of the app: the build adds a temporary
// hand-coded probe route and runs with the database unreachable, which also
// proves such a route builds without one. It moves an existing `.next` aside
// for the run and puts it back afterwards, and it removes the probe route and
// everything `next dev` writes into the project, also on failure.
//
// Needs `APP_DATABASE_URL` naming a Postgres SERVER where this user may
// create databases: the script creates its own scratch database there and
// drops it at the end, so it never touches the data in the named database.
// Also `PAYLOAD_SECRET` (32+ characters) and `NEXT_PUBLIC_SITE_URL`. Every
// child process gets only these, never the project's `.env*` files, so a
// local run behaves like CI. Exits non-zero on any failure.
//
// Run locally (about two minutes plus the build):
//   APP_DATABASE_URL=postgres://postgres@127.0.0.1:5432/postgres \
//   PAYLOAD_SECRET=<32+ chars> NEXT_PUBLIC_SITE_URL=http://localhost:3000 \
//   pnpm exec tsx scripts/cache-contract.e2e.test.ts

import { spawn, type ChildProcess } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import net from 'node:net';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';
import {
  CMS_REVALIDATE_PATH,
  signRevalidateRequest,
} from '../src/payload/revalidate-signal';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const BIN = (name: string) => path.join(ROOT, 'node_modules', '.bin', name);

// A hand-coded route as an agent writes one: reads the database, no route
// config. The dynamic sibling is the case the `?tag=` rewrite could take over.
const PROBE_SEGMENT = 'zz-cache-contract-probe';
const PROBE_DIR = path.join(ROOT, 'src', 'app', '(frontend)', PROBE_SEGMENT);
const PROBE_FILES: Record<string, string> = {
  'save.ts': `import { getPayload } from 'payload';
import config from '../../../payload.config';
import { flushPublishedSiteRevalidation } from '../../../payload/revalidate';
const payload = await getPayload({ config });
await payload.updateGlobal({ slug: 'site-settings', data: { brandName: 'CMS hook update' } });
await flushPublishedSiteRevalidation();
process.exit(0);
`,
  'page.tsx': `import { getPayload } from 'payload';
import config from '@payload-config';

export default async function Probe() {
  const payload = await getPayload({ config });
  const { totalDocs } = await payload.count({ collection: 'pages' });
  return <main data-cache-contract-probe="static">{totalDocs} {Date.now()}</main>;
}
`,
  '[id]/page.tsx': `import { getPayload } from 'payload';
import config from '@payload-config';

export default async function ProbeItem({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const payload = await getPayload({ config });
  const { totalDocs } = await payload.count({ collection: 'pages' });
  return <main data-cache-contract-probe={\`dynamic:\${id}\`}>{totalDocs} {Date.now()}</main>;
}
`,
};

const NEXT_DIR = path.join(ROOT, '.next');
const NEXT_BACKUP = path.join(
  ROOT,
  'node_modules',
  '.cache',
  `cache-contract-next-${process.pid}`,
);
// Files `next build` / `next dev` write into the project; restored byte for
// byte, or removed when the run created them.
const TOUCHED_FILES = [
  'next-env.d.ts',
  'tsconfig.tsbuildinfo',
  'AGENTS.md',
  'CLAUDE.md',
  'src/payload/collections/generated.ts',
  'src/payload-types.ts',
  'public/llms.txt',
].map((name) => path.join(ROOT, name));

// The catch-all route's `revalidate` and the CMS data cache TTL.
const WINDOW_MS = 30_000;
// Postgres reports a backend's transaction counts late: PG 15+ flushes an idle
// backend's pending counts after up to 10 s, and on PG 14 they wait for the
// backend's next statement or its exit, which the template's production pool
// forces after 10 s idle. Measured: stragglers from a request landed 10 s
// later. 13 s of quiet before and after a batch leaves room for both.
const QUIET_MS = 13_000;
// Transactions a batch may add beyond the counting reads' own. The server
// itself runs none in a passing batch (checked with statement logging), but
// autovacuum visits each database about once a minute and a visit adds 2 to 4
// (measured on an idle database), so one visit can land in a window. A
// regression adds at least one per request: making `slugMayExist` always true
// adds 83 for the 40 unknown URLs (measured on PG 16).
const TOLERANCE = 6;
const UNKNOWN_URLS = 40;
const SITEMAP_REPEATS = 5;
const BULK_PAGES = 1_200;

let failures = 0;
function check(name: string, condition: boolean, detail = ''): void {
  if (condition) {
    console.log(`  ok  ${name}`);
  } else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n        ${detail}` : ''}`);
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const startedAt = Date.now();
const elapsed = () => `${((Date.now() - startedAt) / 1000).toFixed(1)}s`;
const step = (name: string) => console.log(`\n[${elapsed()}] ${name}`);

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    console.error(`${name} is required (see the header of this script)`);
    process.exit(2);
  }
  return value;
}

const SERVER_URL = requireEnv('APP_DATABASE_URL');
const SECRET = requireEnv('PAYLOAD_SECRET');
const SITE_URL = requireEnv('NEXT_PUBLIC_SITE_URL').replace(/\/+$/, '');
if (SECRET.length < 32) {
  console.error('PAYLOAD_SECRET must be at least 32 characters');
  process.exit(2);
}

// Refuse to run over the leftovers of an interrupted run rather than mistake
// them for the developer's own files.
for (const leftover of [PROBE_DIR, NEXT_BACKUP]) {
  if (fs.existsSync(leftover)) {
    console.error(
      `${path.relative(ROOT, leftover)} exists: a previous run was interrupted.\n` +
        `Remove the probe route, or put the saved build back with\n` +
        `  rm -rf .next && mv ${path.relative(ROOT, NEXT_BACKUP)} .next`,
    );
    process.exit(2);
  }
}

const nonce = crypto.randomBytes(4).toString('hex');
const scratchDb = `cache_contract_${nonce}`;
const scratchUrl = (() => {
  const url = new URL(SERVER_URL);
  url.pathname = `/${scratchDb}`;
  return url.toString();
})();

// Only what the app reads, so nothing comes from the caller's shell or the
// project's `.env*` files. `__NEXT_PROCESSED_ENV` is the flag @next/env sets
// once it has merged those files; set up front, `next build`, `next start`
// and `next dev` skip them (checked: with it, a server whose only database
// address was in `.env.local` could not reach the database).
type Env = Record<string, string>;
function childEnv(databaseUrl: string): Env {
  const env: Env = {};
  for (const key of ['PATH', 'HOME', 'TMPDIR', 'LANG', 'CI']) {
    const value = process.env[key];
    if (value !== undefined) env[key] = value;
  }
  return {
    ...env,
    __NEXT_PROCESSED_ENV: 'true',
    NEXT_TELEMETRY_DISABLED: '1',
    APP_DATABASE_URL: databaseUrl,
    PAYLOAD_SECRET: SECRET,
    NEXT_PUBLIC_SITE_URL: SITE_URL,
  };
}

// ---------------------------------------------------------------- processes

type Proc = { child: ChildProcess; output: string[]; exited: Promise<number> };
const running = new Set<Proc>();

function launch(bin: string, args: string[], env: Env): Proc {
  // Own process group, so stopping it also stops the workers it forks.
  const child = spawn(BIN(bin), args, {
    cwd: ROOT,
    // Next's types make NODE_ENV required; leaving it unset is the point.
    env: env as NodeJS.ProcessEnv,
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: true,
  });
  const output: string[] = [];
  const keep = (chunk: Buffer) => {
    output.push(chunk.toString());
    if (output.length > 400) output.shift();
  };
  child.stdout?.on('data', keep);
  child.stderr?.on('data', keep);
  const exited = new Promise<number>((resolve) => {
    child.on('exit', (code, signal) => resolve(code ?? (signal ? 1 : 0)));
    child.on('error', () => resolve(1));
  });
  const proc = { child, output, exited };
  running.add(proc);
  void exited.then(() => running.delete(proc));
  return proc;
}

async function stop(proc: Proc): Promise<void> {
  if (!running.has(proc) || proc.child.pid === undefined) return;
  const signalGroup = (signal: NodeJS.Signals) => {
    try {
      process.kill(-proc.child.pid!, signal);
    } catch {
      // Already gone.
    }
  };
  signalGroup('SIGTERM');
  const done = await Promise.race([
    proc.exited.then(() => true),
    sleep(10_000),
  ]);
  if (!done) signalGroup('SIGKILL');
  await Promise.race([proc.exited, sleep(5_000)]);
}

async function runToEnd(
  bin: string,
  args: string[],
  env: Env,
): Promise<{ code: number; output: string }> {
  const proc = launch(bin, args, env);
  const code = await proc.exited;
  return { code, output: proc.output.join('') };
}

const tail = (text: string, lines = 40) =>
  text.trim().split('\n').slice(-lines).join('\n');

async function freePort(): Promise<number> {
  return new Promise((resolve, reject) => {
    const server = net.createServer();
    server.once('error', reject);
    server.listen(0, '127.0.0.1', () => {
      const { port } = server.address() as net.AddressInfo;
      server.close(() => resolve(port));
    });
  });
}

async function startServer(
  mode: 'start' | 'dev',
  env: Env,
): Promise<{ proc: Proc; base: string }> {
  const port = await freePort();
  const proc = launch(
    'next',
    [mode, '-p', String(port), '-H', '127.0.0.1'],
    env,
  );
  const base = `http://127.0.0.1:${port}`;
  const deadline = Date.now() + 60_000;
  while (Date.now() < deadline) {
    if (!running.has(proc)) break;
    try {
      const res = await fetch(`${base}/robots.txt`, {
        signal: AbortSignal.timeout(30_000),
      });
      if (res.ok) return { proc, base };
    } catch {
      // Not listening yet.
    }
    await sleep(250);
  }
  throw new Error(
    `next ${mode} did not come up\n${tail(proc.output.join(''))}`,
  );
}

// ---------------------------------------------------------------- database

async function withClient<T>(
  url: string,
  fn: (client: pg.Client) => Promise<T>,
): Promise<T> {
  const client = new pg.Client({ connectionString: url });
  await client.connect();
  try {
    return await fn(client);
  } finally {
    await client.end();
  }
}

// A fresh connection per statement: a backend's counts reach
// pg_stat_database at its exit at the latest, so none of the script's own
// work arrives late inside a measured window.
const sql = (text: string, params: unknown[] = []) =>
  withClient(scratchUrl, (client) => client.query(text, params));

async function transactions(): Promise<number> {
  const { rows } = await sql(
    `select xact_commit + xact_rollback as n from pg_stat_database
     where datname = current_database()`,
  );
  return Number(rows[0].n);
}

// What one `transactions()` read adds to the counter (2 on PG 14 and 16: the
// connection's start-up and the query). The median of four gaps between reads
// of the idle database, so one autovacuum visit, or a brand-new database's
// first report, cannot skew it.
async function measureReadCost(): Promise<number> {
  const reads: number[] = [];
  for (let i = 0; i < 5; i++) {
    if (i > 0) await sleep(1_000);
    reads.push(await transactions());
  }
  const gaps = reads
    .slice(1)
    .map((n, i) => n - reads[i])
    .sort((a, b) => a - b);
  return gaps[2];
}
let readCost = 0;

/**
 * Transactions `batch` caused beyond the counting reads, after a quiet period
 * on both sides. Counted up to a third read two seconds after the second, so
 * anything that still arrives late is included rather than missed.
 */
async function transactionsCausedBy(
  batch: () => Promise<void>,
): Promise<number> {
  await sleep(QUIET_MS);
  const before = await transactions();
  await batch();
  await sleep(QUIET_MS);
  await transactions();
  await sleep(2_000);
  const last = await transactions();
  return last - before - 2 * readCost;
}

async function setHomeHeading(heading: string): Promise<void> {
  await sql(
    `update pages set layout = jsonb_set(layout, '{0,heading}', to_jsonb($1::text))
     where slug = 'home'`,
    [heading],
  );
}

// ---------------------------------------------------------------- HTTP

type Got = { status: number; headers: Headers; body: string };

async function get(base: string, pathAndQuery: string): Promise<Got> {
  const res = await fetch(base + pathAndQuery, {
    redirect: 'manual',
    signal: AbortSignal.timeout(120_000),
  });
  return { status: res.status, headers: res.headers, body: await res.text() };
}

const cacheControl = (got: Got) => got.headers.get('cache-control') ?? '';
const isCachedForWindow = (got: Got) =>
  /\bs-maxage=30\b/.test(cacheControl(got));
const isNoStore = (got: Got) => /\bno-store\b/.test(cacheControl(got));
const nextCache = (got: Got) => got.headers.get('x-nextjs-cache') ?? '(none)';
const describe = (got: Got) =>
  `status ${got.status}, cache-control "${cacheControl(got)}", x-nextjs-cache ${nextCache(got)}`;

async function signalRevalidation(base: string, tags: string[]): Promise<void> {
  // The server runs without PAYLOAD_SCHEMA, so its schema is ''.
  const signed = signRevalidateRequest({ tags, schema: '' }, SECRET);
  if (!signed) throw new Error('could not sign the revalidation request');
  const res = await fetch(base + CMS_REVALIDATE_PATH, {
    method: 'POST',
    body: signed.body,
    headers: signed.headers,
  });
  const text = await res.text();
  check(
    `signed ${CMS_REVALIDATE_PATH} accepted (${tags.join(', ')})`,
    res.status === 200 && tags.every((tag) => text.includes(tag)),
    `status ${res.status}: ${text}`,
  );
}

// ---------------------------------------------------------------- the run

async function llmsTxt(base: string): Promise<void> {
  step('llms.txt serves current public CMS content');
  await sql(
    `update site_settings set brand_name = 'Crawler fixture', default_seo_description = 'A current CMS description'`,
  );
  await sql(`insert into pages (title, slug, layout, proposed, seo_noindex, seo_robots)
    select 'Hidden bulk page', 'hidden-bulk-' || n, '[]', false, n <= 1005,
      case when n > 1005 then 'none' else null end
    from generate_series(1, 2010) n`);
  await sql(`insert into llmsarticles (title, slug, status, noindex)
    select 'Hidden bulk item', 'hidden-item-' || n, 'published', true
    from generate_series(1, 1005) n`);
  await sql(`insert into pages (title, slug, layout, proposed, seo_noindex, seo_robots, seo_canonical_url, seo_description) values
    ('About fixture', 'about-fixture', '[]', false, false, null, '/about-fixture', 'About the current business'),
    ('Proposed secret', 'proposed-secret', '[]', true, false, null, null, null),
    ('Hidden secret', 'hidden-secret', '[]', false, true, null, null, null),
    ('Robots secret', 'robots-secret', '[]', false, false, 'none', null, null),
    ('Canonical duplicate', 'canonical-duplicate', '[]', false, false, null, 'https://elsewhere.example/page', null)`);
  await sql(`insert into llmsarticles (title, slug, status, meta_description, noindex) values
    ('Public article', 'public-article', 'published', 'Published current summary', false),
    ('Draft secret', 'draft-secret', 'draft', 'Never disclose this draft', false),
    ('Hidden article secret', 'hidden-article', 'published', 'Never disclose this hidden article', true),
    ('Shadowed article secret', 'hidden-secret', 'published', 'Never disclose a shadowed article', false)`);
  await sql(
    `insert into privatecontent (title, slug, status) values ('Private secret', 'private-secret', 'published')`,
  );
  await signalRevalidation(base, ['cms-content', 'site-settings']);
  const first = await get(base, '/llms.txt');
  check(
    'llms.txt returns text with current branding, pages and published articles',
    first.status === 200 &&
      first.headers.get('content-type')?.startsWith('text/plain') === true &&
      first.body.includes('# Crawler fixture') &&
      first.body.includes('A current CMS description') &&
      first.body.includes(
        `[About fixture](${SITE_URL}/about-fixture): About the current business`,
      ) &&
      first.body.includes(
        `[Public article](${SITE_URL}/public-article): Published current summary`,
      ),
    first.body,
  );
  check(
    'llms.txt excludes proposals, drafts, noindex, duplicates, shadowed and private content',
    !/secret|Hidden bulk|canonical-duplicate|elsewhere\.example|Never disclose/i.test(
      first.body,
    ),
    first.body,
  );
  check(
    'llms.txt is not cached by the browser or CDN',
    isNoStore(first),
    describe(first),
  );
  const query = await get(base, '/llms.txt?tag=x&kite-preview=1');
  check(
    'preview and facet parameters cannot expose private content in llms.txt',
    query.status === 200 && query.body === first.body,
    query.body,
  );
  for (const slug of ['about-fixture', 'public-article']) {
    const target = await get(base, `/${slug}`);
    check(
      `llms.txt link /${slug} resolves to a public page`,
      target.status === 200,
      describe(target),
    );
  }
  await sql('alter table llmsarticles rename to llmsarticles_unavailable');
  try {
    await signalRevalidation(base, ['cms-content']);
    const partial = await get(base, '/llms.txt');
    check(
      'an unavailable collection preserves the current Pages index',
      partial.status === 200 &&
        partial.body.includes('About fixture') &&
        !partial.body.includes('Public article'),
      partial.body,
    );
  } finally {
    await sql('alter table llmsarticles_unavailable rename to llmsarticles');
    await signalRevalidation(base, ['cms-content']);
  }
  const cmsEdit = await runToEnd('tsx', [path.join(PROBE_DIR, 'save.ts')], {
    ...childEnv(scratchUrl),
    KITE_PUBLISHED_SITE_URL: base,
  });
  check(
    'a real CMS save delivers its revalidation hook',
    cmsEdit.code === 0,
    tail(cmsEdit.output),
  );
  const hookEdit = await get(base, '/llms.txt');
  check(
    'the first request after a CMS save sees the changed brand',
    hookEdit.status === 200 && hookEdit.body.includes('# CMS hook update'),
    hookEdit.body,
  );
  await sql(`update site_settings set brand_name = 'Edited brand'`);
  await sql(
    `update pages set title = 'Edited about', seo_description = 'Edited description' where slug = 'about-fixture'`,
  );
  await sql(
    `update llmsarticles set status = 'draft' where slug = 'public-article'`,
  );
  await sql(
    `update llmsarticles set status = 'published', title = 'Now public article' where slug = 'draft-secret'`,
  );
  await signalRevalidation(base, ['cms-content', 'site-settings']);
  const edited = await get(base, '/llms.txt');
  check(
    'the next llms.txt request reflects edits, publication and withdrawal',
    edited.status === 200 &&
      edited.body.includes('# Edited brand') &&
      edited.body.includes(
        `[Edited about](${SITE_URL}/about-fixture): Edited description`,
      ) &&
      edited.body.includes('Now public article') &&
      !edited.body.includes('Public article'),
    edited.body,
  );
  await sql(`delete from llmsarticles`);
  await sql(`delete from privatecontent`);
  await sql(`delete from pages where slug != 'home'`);
  await signalRevalidation(base, ['cms-content', 'site-settings']);
  const removed = await get(base, '/llms.txt');
  check(
    'deleted pages and items leave llms.txt immediately',
    removed.status === 200 &&
      !/about-fixture|Now public article/.test(removed.body),
    removed.body,
  );
}

async function production(base: string): Promise<void> {
  await llmsTxt(base);

  step('cached CMS page');
  const first = await get(base, '/');
  check(
    'a CMS page renders on first request',
    first.status === 200 && first.body.includes('Welcome'),
    describe(first),
  );
  check(
    'a CMS page is cacheable for the window (s-maxage=30)',
    isCachedForWindow(first),
    describe(first),
  );
  const second = await get(base, '/');
  check(
    'the second request is served from cache',
    nextCache(second) === 'HIT' && isCachedForWindow(second),
    describe(second),
  );

  step('query strings and the per-request variant');
  const tracking = await get(base, '/?utm_source=x');
  check(
    'a tracking-only query string gets the cached page',
    tracking.status === 200 &&
      nextCache(tracking) === 'HIT' &&
      isCachedForWindow(tracking),
    describe(tracking),
  );
  const facet = await get(base, '/?tag=x');
  check(
    '?tag= renders the page per request (no-store)',
    facet.status === 200 &&
      facet.body.includes('Welcome') &&
      isNoStore(facet) &&
      !facet.headers.has('x-nextjs-cache'),
    describe(facet),
  );
  for (const direct of ['/kite-facet', '/kite-facet/home']) {
    const got = await get(base, direct);
    check(`${direct} is not found`, got.status === 404, describe(got));
  }

  step('hand-coded route');
  const probeA = await get(base, `/${PROBE_SEGMENT}`);
  await sleep(5);
  const probeB = await get(base, `/${PROBE_SEGMENT}`);
  check(
    'a hand-coded route renders per request (no-store, fresh each time)',
    probeA.status === 200 &&
      isNoStore(probeA) &&
      probeA.body.includes('data-cache-contract-probe="static"') &&
      probeA.body !== probeB.body,
    describe(probeA),
  );
  const probeTag = await get(base, `/${PROBE_SEGMENT}?tag=x`);
  check(
    'a hand-coded route keeps its own page with ?tag=',
    probeTag.status === 200 &&
      isNoStore(probeTag) &&
      probeTag.body.includes('data-cache-contract-probe="static"'),
    describe(probeTag),
  );
  const probeDynamic = await get(base, `/${PROBE_SEGMENT}/abc?tag=x`);
  check(
    'a hand-coded dynamic route keeps its own page with ?tag=',
    probeDynamic.status === 200 &&
      isNoStore(probeDynamic) &&
      probeDynamic.body.includes('data-cache-contract-probe="dynamic:abc"'),
    describe(probeDynamic),
  );

  step('a page created after the slug list was cached');
  // The requests above loaded the list of known slugs.
  const lateSlug = `cc-late-${nonce}`;
  const lateHeading = `Late page ${nonce}`;
  await sql(
    `insert into pages (title, slug, layout) values ($1, $2, $3::jsonb)`,
    [
      lateHeading,
      lateSlug,
      JSON.stringify([
        { id: `late${nonce}`, blockType: 'hero', heading: lateHeading },
      ]),
    ],
  );
  // More than the 1,000 the old sitemap stopped at; read only after the
  // signal below, so the sitemap's first read already sees them.
  await sql(
    `insert into pages (title, slug, layout)
     select 'Bulk ' || g, 'cc-bulk-' || g, '[]'::jsonb
     from generate_series(1, $1::int) g`,
    [BULK_PAGES],
  );
  // Leave autovacuum nothing to do inside a measured window. The second pass
  // clears the dead rows the first one's ANALYZE leaves in pg_statistic.
  await sql('vacuum analyze');
  await sql('vacuum');
  const lateBefore = await get(base, `/${lateSlug}`);
  check(
    'before the signal the new page is not found (the cached list decides)',
    lateBefore.status === 404,
    describe(lateBefore),
  );

  step('signed revalidation');
  const signalled = `Signalled ${nonce}`;
  await setHomeHeading(signalled);
  // Both tags, so every cached read an unknown URL's 404 touches (the
  // site-settings read in the layout included) is fresh for the measured
  // window below.
  await signalRevalidation(base, ['cms-content', 'site-settings']);
  const afterSignal = await get(base, '/');
  check(
    'a write followed by the signal shows on the very next request',
    afterSignal.status === 200 && afterSignal.body.includes(signalled),
    describe(afterSignal),
  );
  const pageRegeneratedAt = Date.now();
  const lateAfter = await get(base, `/${lateSlug}`);
  check(
    'after the signal the new page is reachable',
    lateAfter.status === 200 && lateAfter.body.includes(lateHeading),
    describe(lateAfter),
  );
  const lateFacet = await get(base, `/${lateSlug}?tag=x`);
  check(
    '?tag= on a nested CMS page renders it per request (no-store)',
    lateFacet.status === 200 &&
      lateFacet.body.includes(lateHeading) &&
      isNoStore(lateFacet),
    describe(lateFacet),
  );

  step(
    'a write with no signal (the 30 s window runs while unknown URLs are counted)',
  );
  const windowed = `Windowed ${nonce}`;
  await setHomeHeading(windowed);
  const stillCached = await get(base, '/');
  check(
    'a write with no signal is not shown inside the window',
    stillCached.body.includes(signalled) && nextCache(stillCached) === 'HIT',
    describe(stillCached),
  );

  const unknownExtra = await transactionsCausedBy(async () => {
    const statuses = new Set<number>();
    for (let i = 0; i < UNKNOWN_URLS; i++) {
      statuses.add((await get(base, `/cc-missing-${nonce}-${i}`)).status);
    }
    check(
      `${UNKNOWN_URLS} new unknown URLs are not found`,
      statuses.size === 1 && statuses.has(404),
      `statuses ${[...statuses].join(', ')}`,
    );
  });
  check(
    `${UNKNOWN_URLS} new unknown URLs run no database transaction (${unknownExtra} beyond the counting reads, allowed ${TOLERANCE})`,
    unknownExtra <= TOLERANCE,
  );

  const windowEnds = pageRegeneratedAt + WINDOW_MS + 1_000;
  if (Date.now() < windowEnds) await sleep(windowEnds - Date.now());
  // The first request after the window may still get the old copy while the
  // new one renders; a following one must be fresh.
  let shown = false;
  const tries: string[] = [];
  for (let i = 0; i < 8 && !shown; i++) {
    const got = await get(base, '/');
    tries.push(nextCache(got));
    shown = got.body.includes(windowed);
    if (!shown) await sleep(1_000);
  }
  check(
    'a write with no signal shows after the window',
    shown && tries.length <= 3,
    `x-nextjs-cache per request: ${tries.join(', ')}; shown: ${shown}`,
  );

  step('sitemap');
  const sitemap = await get(base, '/sitemap.xml');
  const locs = new Set(
    [...sitemap.body.matchAll(/<loc>([^<]*)<\/loc>/g)].map((m) => m[1]),
  );
  const missing: string[] = [];
  for (let i = 1; i <= BULK_PAGES; i++) {
    if (!locs.has(`${SITE_URL}/cc-bulk-${i}`)) missing.push(`cc-bulk-${i}`);
  }
  if (!locs.has(`${SITE_URL}/${lateSlug}`)) missing.push(lateSlug);
  if (!locs.has(SITE_URL) && !locs.has(`${SITE_URL}/`)) missing.push('home');
  check(
    `/sitemap.xml lists all ${BULK_PAGES + 2} pages`,
    sitemap.status === 200 && missing.length === 0,
    `status ${sitemap.status}, ${locs.size} URLs, missing ${missing.length} (e.g. ${missing.slice(0, 3).join(', ')})`,
  );
  const sitemapExtra = await transactionsCausedBy(async () => {
    for (let i = 0; i < SITEMAP_REPEATS; i++) {
      const again = await get(base, '/sitemap.xml');
      if (again.body !== sitemap.body) {
        check('a repeat sitemap request returns the same file', false);
        return;
      }
    }
  });
  check(
    `${SITEMAP_REPEATS} repeat sitemap requests run no database transaction (${sitemapExtra} beyond the counting reads, allowed ${TOLERANCE})`,
    sitemapExtra <= TOLERANCE,
  );
}

async function development(base: string): Promise<void> {
  const beforeLlms = await get(base, '/llms.txt');
  await sql(`update site_settings set brand_name = 'Live crawler brand'`);
  const liveLlms = await get(base, '/llms.txt');
  check(
    'development llms.txt reflects a save without cached data',
    beforeLlms.status === 200 &&
      liveLlms.status === 200 &&
      liveLlms.body.includes('# Live crawler brand'),
  );
  await sql('alter table pages rename to llms_unavailable');
  try {
    const unavailable = await get(base, '/llms.txt');
    check(
      'a failed CMS read returns 503 without publishing an empty index',
      unavailable.status === 503 &&
        isNoStore(unavailable) &&
        !unavailable.body.includes('# Live crawler brand'),
      describe(unavailable),
    );
  } finally {
    await sql('alter table llms_unavailable rename to pages');
  }
  const recovered = await get(base, '/llms.txt');
  check(
    'llms.txt recovers on the next request after the CMS is available',
    recovered.status === 200 && recovered.body.includes('# Live crawler brand'),
    describe(recovered),
  );

  step('next dev reads live');
  const before = await get(base, '/');
  check(
    'next dev renders the CMS page',
    before.status === 200 && before.body.includes('Windowed'),
    `status ${before.status}`,
  );
  const live = `Live ${nonce}`;
  await setHomeHeading(live);
  const after = await get(base, '/');
  check(
    'under next dev a raw database change shows on the next request',
    after.body.includes(live),
    `status ${after.status}`,
  );
}

// ---------------------------------------------------------------- set-up

const snapshots = new Map<string, Buffer | null>();
let movedNext = false;
let createdDb = false;

function prepareTree(): void {
  for (const file of TOUCHED_FILES) {
    snapshots.set(file, fs.existsSync(file) ? fs.readFileSync(file) : null);
  }
  fs.writeFileSync(
    path.join(ROOT, 'src/payload/collections/generated.ts'),
    `import { makeCollection } from '../collectionMeta';
export const generatedCollections = [
  makeCollection('llmsarticles'),
  { ...makeCollection('privatecontent'), access: { read: () => false } },
];
`,
  );
  fs.writeFileSync(
    path.join(ROOT, 'public/llms.txt'),
    '# Obsolete static snapshot\n',
  );
  if (fs.existsSync(NEXT_DIR)) {
    fs.mkdirSync(path.dirname(NEXT_BACKUP), { recursive: true });
    fs.renameSync(NEXT_DIR, NEXT_BACKUP);
    movedNext = true;
  }
  for (const [name, source] of Object.entries(PROBE_FILES)) {
    const file = path.join(PROBE_DIR, name);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    fs.writeFileSync(file, source);
  }
}

let cleaned: Promise<void> | null = null;
function cleanup(): Promise<void> {
  cleaned ??= (async () => {
    await Promise.all([...running].map(stop));
    const attempt = async (what: string, fn: () => unknown) => {
      try {
        await fn();
      } catch (error) {
        failures++;
        console.error(`  FAIL cleanup: ${what}: ${String(error)}`);
      }
    };
    await attempt('remove the probe route', () =>
      fs.rmSync(PROBE_DIR, { recursive: true, force: true }),
    );
    await attempt('restore generated files', () => {
      for (const [file, content] of snapshots) {
        if (content === null) fs.rmSync(file, { force: true });
        else if (
          !fs.existsSync(file) ||
          !fs.readFileSync(file).equals(content)
        ) {
          fs.writeFileSync(file, content);
        }
      }
    });
    await attempt('restore .next', () => {
      fs.rmSync(NEXT_DIR, { recursive: true, force: true });
      if (movedNext) fs.renameSync(NEXT_BACKUP, NEXT_DIR);
    });
    if (createdDb) {
      await attempt('drop the scratch database', () =>
        withClient(SERVER_URL, (client) =>
          client.query(`drop database if exists ${scratchDb} with (force)`),
        ),
      );
    }
  })();
  return cleaned;
}

for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.on(signal, () => {
    console.error(`\n${signal}: cleaning up`);
    void cleanup().then(() => process.exit(1));
  });
}

async function main(): Promise<void> {
  prepareTree();

  step('preserve authored llms.txt on a conflicting build');
  const staticPath = path.join(ROOT, 'public/llms.txt');
  const authored = fs.readFileSync(staticPath);
  const prepared = await runToEnd(
    'tsx',
    ['scripts/ensure-schema.ts'],
    childEnv(''),
  );
  const preserved =
    fs.existsSync(staticPath) && fs.readFileSync(staticPath).equals(authored);
  check(
    'the Payload build refuses the URL conflict and preserves authored bytes',
    prepared.code !== 0 &&
      prepared.output.includes('public/llms.txt conflicts') &&
      preserved,
    tail(prepared.output),
  );
  if (prepared.code === 0 || !preserved) return;
  fs.unlinkSync(staticPath);
  const resolved = await runToEnd(
    'tsx',
    ['scripts/ensure-schema.ts'],
    childEnv(''),
  );
  check(
    'an explicitly resolved static conflict permits the build',
    resolved.code === 0,
    tail(resolved.output),
  );
  if (resolved.code !== 0) return;

  step('build (database unreachable, probe route included)');
  const build = await runToEnd(
    'next',
    ['build'],
    childEnv('postgres://cache-contract@127.0.0.1:1/unreachable'),
  );
  check(
    'the build passes with the database unreachable',
    build.code === 0,
    tail(build.output),
  );
  if (build.code !== 0) return;
  check(
    'the hand-coded probe route builds as per-request (ƒ)',
    new RegExp(`ƒ /${PROBE_SEGMENT}\\s`).test(build.output),
    tail(build.output, 25),
  );

  step(`scratch database ${scratchDb}`);
  await withClient(SERVER_URL, (client) =>
    client.query(`create database ${scratchDb}`),
  );
  createdDb = true;

  // The default manifest: one `home` page with a hero block. Run without
  // NODE_ENV, so Payload pushes the schema into the empty database.
  const seed = await runToEnd(
    'tsx',
    ['scripts/seed-payload.ts'],
    childEnv(scratchUrl),
  );
  // The draft merge counts a seed as run only on this line
  // (backend `preview_sandbox_service`).
  check(
    'the default seed completes on an empty database and says so',
    seed.code === 0 && seed.output.includes('seed complete: public'),
    tail(seed.output),
  );
  if (seed.code !== 0) return;
  readCost = await measureReadCost();
  if (readCost <= 0) throw new Error('the transaction counter does not move');

  step('next start');
  const prod = await startServer('start', childEnv(scratchUrl));
  try {
    await production(prod.base);
  } finally {
    await stop(prod.proc);
  }

  const dev = await startServer('dev', childEnv(scratchUrl));
  try {
    await development(dev.base);
  } finally {
    await stop(dev.proc);
  }
}

try {
  await main();
} catch (error) {
  failures++;
  console.error(`\nFAIL ${error instanceof Error ? error.message : error}`);
} finally {
  await cleanup();
}

console.log(`\nfinished in ${elapsed()}`);
if (failures > 0) {
  console.error(`${failures} check(s) failed`);
  process.exit(1);
}
console.log('all checks passed');
