// Contract for scripts/live-rows.ts: approving a draft keeps the list rows
// added on the live site after the draft opened, and keeps the draft's own
// removals. Self-contained tsx script (the template ships no unit-test runner);
// exits non-zero on the first failed check.
import assert from 'node:assert/strict';
import { keepLiveRowsAddedSince, rowCreatedAt } from './live-rows';

const since = new Date('2026-10-05T10:00:00Z');
const secondsHex = (iso: string) =>
  Math.floor(new Date(iso).getTime() / 1000).toString(16);
const idAt = (iso: string, tail: string) => `${secondsHex(iso)}${tail}`;

const before = idAt('2026-10-05T09:00:00Z', '0000000000000001');
const removedInDraft = idAt('2026-10-05T09:30:00Z', '0000000000000002');
const addedInDraft = idAt('2026-10-05T10:05:00Z', '0000000000000003');
const addedOnLive = idAt('2026-10-05T10:10:00Z', '0000000000000004');

assert.equal(rowCreatedAt(before)?.toISOString(), '2026-10-05T09:00:00.000Z');
assert.equal(rowCreatedAt('row-1'), null);

const draft = {
  brandName: 'Acme',
  socialLinks: [
    { id: before, platform: 'Facebook', href: 'https://facebook.com/acme' },
    { id: addedInDraft, platform: 'Instagram', href: 'https://ig.com/acme' },
  ],
  footer: { tagline: 'Hi', links: [] as Record<string, unknown>[] },
};
const live = {
  brandName: 'Acme',
  socialLinks: [
    { id: before, platform: 'Facebook', href: 'https://facebook.com/acme' },
    { id: removedInDraft, platform: 'X', href: 'https://x.com/acme' },
    { id: addedOnLive, platform: 'TikTok', href: 'https://tiktok.com/@acme' },
  ],
  footer: {
    tagline: 'Hi',
    links: [{ id: addedOnLive, label: 'Jobs', href: '/jobs' }],
  },
};

const merged = keepLiveRowsAddedSince(draft, live, since) as typeof draft;

// The owner's TikTok link, added on live after the draft opened, survives.
assert.deepEqual(
  merged.socialLinks.map((row) => row.platform),
  ['Facebook', 'Instagram', 'TikTok'],
);
// Lists inside groups are covered too.
assert.deepEqual(
  merged.footer.links.map((row) => row.label),
  ['Jobs'],
);
// The draft's own edits stand: X, removed in the draft, stays removed.
assert.ok(!merged.socialLinks.some((row) => row.platform === 'X'));
assert.equal(merged.brandName, 'Acme');
// Nothing added on live: the draft's list goes through unchanged.
assert.deepEqual(
  keepLiveRowsAddedSince(draft, { socialLinks: draft.socialLinks }, since),
  draft,
);

console.log('live-rows: all checks passed');
