// End-to-end contract for scripts/ensure-schema.ts on real Postgres: a site
// built from an older template, with content in it, is brought up to this
// template's schema before its build, and a change the deployed code would
// not survive is refused. Each check runs against a copy of a template with a
// `posts` collection (the cms-management skill's example) in its
// `generated.ts`, seeded with that skill's golden collections fixture:
//   1. upgrade: the base template's dev push and seed make the old schema; this
//      template's ensure-schema exits 0, a second run reports it up to date,
//      the result equals Payload's own dev push of this template, and no row
//      is lost;
//   2. additive: a new field, a new select (an enum) and a new collection are
//      applied the same way;
//   3. refused: a field removed from `posts` exits 1, names the DROP, and
//      leaves the schema as it was;
//   4. empty: a schema Payload never pushed (a lost PAYLOAD_SCHEMA) is left
//      alone;
//   5. drift: with ENSURE_SCHEMA_KEEP_DRIFT=1 the same drop is kept and a new
//      field on another table still applies;
//   6. interrupted: an apply that fails part way leaves nothing behind, and
//      the next build applies the whole diff.
// Because the base is the target branch, a template change whose schema
// change is not additive fails check 1.
//
// Needs `APP_DATABASE_URL` naming a Postgres SERVER where this user may create
// databases (the script makes its own and drops them), `PAYLOAD_SECRET`
// (32+ characters) and `BASE_TEMPLATE_DIR`, an export of the target branch's
// nextjs-template-payload. Without its own node_modules the base uses this
// template's. Children get only these variables, never `.env*` files.
//
// Run locally:
//   git archive origin/main nextjs-template-payload | tar -x -C /tmp/base
//   APP_DATABASE_URL=postgres://postgres@127.0.0.1:5432/postgres \
//   PAYLOAD_SECRET=<32+ chars> BASE_TEMPLATE_DIR=/tmp/base/nextjs-template-payload \
//   pnpm exec tsx scripts/ensure-schema.e2e.test.ts

import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const TSX = path.join(ROOT, 'node_modules', '.bin', 'tsx');
const SEED_FIXTURE = path.resolve(
  ROOT,
  '../backend/app/llm/skills/cms-management/fixtures/seed.collections.golden.json',
);
const SCHEMA = 'payload_iter1';

function requireEnv(name: string): string {
  const value = process.env[name];
  if (!value) {
    console.error(`${name} is required (see the header of this script)`);
    process.exit(2);
  }
  return value;
}

const SERVER_URL = requireEnv('APP_DATABASE_URL');
const SECRET = requireEnv('PAYLOAD_SECRET');
const BASE_DIR = path.resolve(requireEnv('BASE_TEMPLATE_DIR'));
if (!fs.existsSync(path.join(BASE_DIR, 'src', 'payload.config.ts'))) {
  console.error(`${BASE_DIR} is not a Payload template export`);
  process.exit(2);
}

// ---------------------------------------------------------------- fixtures

const POSTS_FIELDS = `
      { name: 'excerpt', type: 'textarea' },
      { name: 'body', type: 'richText' },`;
const ADDED_FIELDS = `
      { name: 'subtitle', type: 'text' },
      {
        name: 'format',
        type: 'select',
        options: [
          { label: 'Article', value: 'article' },
          { label: 'Video', value: 'video' },
        ],
      },`;

function generatedCollections(postsFields: string, eventsFields?: string) {
  const events = eventsFields
    ? `
  makeCollection('events', {
    labelSingular: 'Event',
    labelPlural: 'Events',
    fields: [${eventsFields}],
  }),`
    : '';
  return `import type { CollectionConfig } from 'payload';
import { makeCollection } from '../collectionMeta';

export const generatedCollections: CollectionConfig[] = [
  makeCollection('posts', {
    labelSingular: 'Post',
    labelPlural: 'Posts',
    fields: [${postsFields}
    ],
  }),${events}
];
`;
}

const EVENTS_FIELDS = `{ name: 'venue', type: 'text' }`;
const WITHOUT_EXCERPT = POSTS_FIELDS.replace(/\n.*'excerpt'.*/, '');
const OLD = generatedCollections(POSTS_FIELDS);
const ADDED = generatedCollections(POSTS_FIELDS + ADDED_FIELDS, EVENTS_FIELDS);
const DROPPED = generatedCollections(
  WITHOUT_EXCERPT + ADDED_FIELDS,
  EVENTS_FIELDS,
);
// The drop as drift this site already had, next to a new field on another
// table (on the same table drizzle would ask whether it is a rename).
const DRIFTED = generatedCollections(
  WITHOUT_EXCERPT + ADDED_FIELDS,
  `${EVENTS_FIELDS}, { name: 'capacity', type: 'number' }`,
);
// A unique field on a new column: its index comes after the column in the
// diff, so a failure between them is an interrupted apply.
const RESUMED = generatedCollections(
  WITHOUT_EXCERPT + ADDED_FIELDS,
  `${EVENTS_FIELDS}, { name: 'capacity', type: 'number' }, { name: 'ticketCode', type: 'text', unique: true }`,
);

// ---------------------------------------------------------------- harness

let failures = 0;
const started = Date.now();
const elapsed = () => `${((Date.now() - started) / 1000).toFixed(1)}s`;

function step(name: string): void {
  console.log(`\n== ${name} (${elapsed()})`);
}

function check(name: string, ok: boolean, detail = ''): boolean {
  if (ok) console.log(`  ok   ${name}`);
  else {
    failures++;
    console.error(`  FAIL ${name}${detail ? `\n${indent(detail)}` : ''}`);
  }
  return ok;
}

const indent = (text: string) =>
  text
    .trim()
    .split('\n')
    .map((line) => `       ${line}`)
    .join('\n');
const tail = (text: string, lines = 30) =>
  text.trim().split('\n').slice(-lines).join('\n');

const nonce = crypto.randomBytes(4).toString('hex');
const WORK = fs.mkdtempSync(path.join(os.tmpdir(), 'ensure-schema-e2e-'));
const databases: string[] = [];

function dbUrl(name: string): string {
  const url = new URL(SERVER_URL);
  url.pathname = `/${name}`;
  return url.toString();
}

async function withClient<T>(
  url: string,
  fn: (client: pg.Client) => Promise<T>,
): Promise<T> {
  const client = new pg.Client({ connectionString: url });
  await client.connect();
  try {
    return await fn(client);
  } finally {
    await client.end();
  }
}

async function createDatabase(label: string): Promise<string> {
  const name = `ensure_schema_${nonce}_${label}`;
  await withClient(SERVER_URL, (client) =>
    client.query(`create database ${name}`),
  );
  databases.push(name);
  return dbUrl(name);
}

const SKIP = new Set([
  'node_modules',
  '.next',
  '.ci-packs',
  'iter1',
  'iter2',
  'iter3',
]);

// A copy of a template with `collections` as its generated.ts, so the
// checkout itself is never edited.
function templateCopy(name: string, from: string, collections: string): string {
  const dir = path.join(WORK, name);
  fs.cpSync(from, dir, {
    recursive: true,
    filter: (source) => !SKIP.has(path.basename(source)),
  });
  const modules = fs.existsSync(path.join(from, 'node_modules'))
    ? path.join(from, 'node_modules')
    : path.join(ROOT, 'node_modules');
  fs.symlinkSync(modules, path.join(dir, 'node_modules'), 'dir');
  fs.writeFileSync(
    path.join(dir, 'src', 'payload', 'collections', 'generated.ts'),
    collections,
  );
  return dir;
}

function run(
  cwd: string,
  script: string,
  args: string[],
  env: Record<string, string>,
): Promise<{ code: number; output: string }> {
  const childEnv: Record<string, string> = {
    PAYLOAD_SECRET: SECRET,
    PAYLOAD_SCHEMA: SCHEMA,
  };
  for (const key of ['PATH', 'HOME', 'TMPDIR', 'LANG', 'CI']) {
    const value = process.env[key];
    if (value !== undefined) childEnv[key] = value;
  }
  Object.assign(childEnv, env);
  return new Promise((resolve) => {
    const child = spawn(TSX, [script, ...args], {
      cwd,
      // Next's types make NODE_ENV required; the dev push runs without it.
      env: childEnv as NodeJS.ProcessEnv,
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    const output: string[] = [];
    child.stdout.on('data', (chunk: Buffer) => output.push(chunk.toString()));
    child.stderr.on('data', (chunk: Buffer) => output.push(chunk.toString()));
    child.on('error', (error) => resolve({ code: 1, output: String(error) }));
    child.on('exit', (code, signal) =>
      resolve({ code: code ?? (signal ? 1 : 0), output: output.join('') }),
    );
  });
}

// Payload's own dev push (no NODE_ENV) plus a seed, as a preview sandbox
// leaves a site's database.
async function devPushAndSeed(dir: string, url: string, what: string) {
  const seed = await run(dir, 'scripts/seed-payload.ts', [SEED_FIXTURE], {
    APP_DATABASE_URL: url,
  });
  return check(
    `${what}: dev push and seed complete`,
    seed.code === 0 && seed.output.includes('seed complete'),
    tail(seed.output),
  );
}

// As a Vercel build runs it.
function ensureSchema(
  dir: string,
  url: string,
  extra: Record<string, string> = {},
) {
  return run(dir, 'scripts/ensure-schema.ts', [], {
    APP_DATABASE_URL: url,
    NODE_ENV: 'production',
    ...extra,
  });
}

const ensureLines = (output: string) =>
  output
    .split('\n')
    .filter((line) => line.startsWith('[ensure-schema]'))
    .join('\n');

// Everything the schema holds that code can depend on, one line per item.
async function snapshot(url: string): Promise<string[]> {
  const { rows } = await withClient(url, (client) =>
    client.query<{ item: string }>(
      `select 'column ' || table_name || '.' || column_name || ' ' || udt_name
              || ' null=' || is_nullable || ' default=' || coalesce(column_default, '') as item
         from information_schema.columns where table_schema = $1
       union all
       select 'index ' || indexdef from pg_indexes where schemaname = $1
       union all
       select 'constraint ' || cl.relname || '.' || con.conname || ' ' || pg_get_constraintdef(con.oid)
         from pg_constraint con
         join pg_class cl on cl.oid = con.conrelid
         join pg_namespace ns on ns.oid = cl.relnamespace
        where ns.nspname = $1
       union all
       select 'enum ' || t.typname || ' ' || string_agg(e.enumlabel, ',' order by e.enumsortorder)
         from pg_type t
         join pg_enum e on e.enumtypid = t.oid
         join pg_namespace ns on ns.oid = t.typnamespace
        where ns.nspname = $1
        group by t.typname`,
      [SCHEMA],
    ),
  );
  return rows.map((row) => row.item).sort();
}

function sameSchema(name: string, actual: string[], expected: string[]) {
  const missing = expected.filter((item) => !actual.includes(item));
  const extra = actual.filter((item) => !expected.includes(item));
  return check(
    name,
    missing.length === 0 && extra.length === 0,
    [...missing.map((m) => `missing: ${m}`), ...extra.map((e) => `extra: ${e}`)]
      .slice(0, 40)
      .join('\n'),
  );
}

async function contentRows(url: string): Promise<string> {
  const { rows } = await withClient(url, (client) =>
    client.query<{ n: string }>(
      `select (select count(*) from ${SCHEMA}.pages) || ' pages, ' ||
              (select count(*) from ${SCHEMA}.posts) || ' posts' as n`,
    ),
  );
  return rows[0].n;
}

// Exit 0, then a second run with nothing structural left to do, and the
// result equal to a dev push of the same template.
async function upgrades(
  what: string,
  dir: string,
  url: string,
  rows: string,
): Promise<boolean> {
  const first = await ensureSchema(dir, url);
  if (
    !check(
      `${what}: ensure-schema exits 0`,
      first.code === 0,
      tail(first.output),
    )
  ) {
    return false;
  }
  console.log(indent(tail(ensureLines(first.output), 12)));
  const second = await ensureSchema(dir, url);
  check(
    `${what}: a second run reports the schema up to date`,
    second.code === 0 &&
      ensureLines(second.output).includes('schema is up to date'),
    tail(second.output),
  );
  const reference = await createDatabase(`${what}_ref`);
  if (!(await devPushAndSeed(dir, reference, `${what} reference`))) {
    return false;
  }
  sameSchema(
    `${what}: the schema equals Payload's own dev push of the same template`,
    await snapshot(url),
    await snapshot(reference),
  );
  check(
    `${what}: no content row is lost (${rows})`,
    (await contentRows(url)) === rows,
  );
  return true;
}

// ---------------------------------------------------------------- checks

async function main(): Promise<void> {
  const oldDir = templateCopy('old', BASE_DIR, OLD);
  const newDir = templateCopy('new', ROOT, OLD);
  const addedDir = templateCopy('added', ROOT, ADDED);
  const droppedDir = templateCopy('dropped', ROOT, DROPPED);
  const driftedDir = templateCopy('drifted', ROOT, DRIFTED);
  const resumedDir = templateCopy('resumed', ROOT, RESUMED);
  const site = await createDatabase('site');

  step('a database Payload never pushed');
  const untouched = await ensureSchema(newDir, site);
  check(
    'empty: ensure-schema exits 0, applies nothing and creates no table',
    untouched.code === 0 &&
      ensureLines(untouched.output).includes('not a Payload schema') &&
      (await snapshot(site)).length === 0,
    tail(untouched.output),
  );

  step('a site on the base template');
  if (!(await devPushAndSeed(oldDir, site, 'base template'))) return;
  const rows = await contentRows(site);
  check('the site holds content', !rows.startsWith('0 pages'), rows);

  step('upgrade to this template');
  if (!(await upgrades('upgrade', newDir, site, rows))) return;

  step('an additive change: new field, new select, new collection');
  const before = await snapshot(site);
  if (!(await upgrades('additive', addedDir, site, rows))) return;
  check(
    'additive: the schema changed',
    (await snapshot(site)).join('\n') !== before.join('\n'),
  );

  step('a field removed from posts');
  const kept = await snapshot(site);
  const refused = await ensureSchema(droppedDir, site);
  const lines = ensureLines(refused.output);
  check(
    'refused: ensure-schema exits 1 and names the dropped column',
    refused.code === 1 &&
      lines.includes('nothing was applied') &&
      /not additive: ALTER TABLE \S+"posts" DROP COLUMN "excerpt"/.test(lines),
    tail(refused.output),
  );
  sameSchema('refused: the schema is unchanged', await snapshot(site), kept);

  step('the same drop as drift, kept by the operator, with a new field');
  const drifted = await ensureSchema(driftedDir, site, {
    ENSURE_SCHEMA_KEEP_DRIFT: '1',
  });
  const driftLines = ensureLines(drifted.output);
  const after = await snapshot(site);
  check(
    'drift: exits 0, adds the new field, keeps the dropped column',
    drifted.code === 0 &&
      /kept as it is: ALTER TABLE \S+"posts" DROP COLUMN "excerpt"/.test(
        driftLines,
      ) &&
      after.some((item) => item.startsWith('column events.capacity ')) &&
      after.some((item) => item.startsWith('column posts.excerpt ')),
    tail(drifted.output),
  );
  check(
    `drift: no content row is lost (${rows})`,
    (await contentRows(site)) === rows,
  );

  step('an apply that fails part way, then the next build');
  // An index already holding the new unique index's name makes it fail after
  // the column it indexes was added.
  const blocker = `create index events_ticket_code_idx on ${SCHEMA}.posts (id)`;
  await withClient(site, (client) => client.query(blocker));
  const beforeFailure = await snapshot(site);
  const keep = { ENSURE_SCHEMA_KEEP_DRIFT: '1' };
  const interrupted = await ensureSchema(resumedDir, site, keep);
  check('interrupted: ensure-schema exits 1', interrupted.code === 1);
  sameSchema(
    'interrupted: nothing of that diff is left behind',
    await snapshot(site),
    beforeFailure,
  );
  await withClient(site, (client) =>
    client.query(`drop index ${SCHEMA}.events_ticket_code_idx`),
  );
  const resumed = await ensureSchema(resumedDir, site, keep);
  const resumedSchema = await snapshot(site);
  check(
    'resumed: the next build applies the column and its unique index',
    resumed.code === 0 &&
      resumedSchema.some((item) =>
        item.startsWith('column events.ticket_code '),
      ) &&
      resumedSchema.some((item) =>
        /^index CREATE UNIQUE INDEX events_ticket_code_idx ON \S+\.events /.test(
          item,
        ),
      ),
    tail(resumed.output),
  );
}

async function cleanup(): Promise<void> {
  for (const name of databases) {
    try {
      await withClient(SERVER_URL, (client) =>
        client.query(`drop database if exists ${name} with (force)`),
      );
    } catch (error) {
      failures++;
      console.error(`  FAIL cleanup: drop ${name}: ${String(error)}`);
    }
  }
  fs.rmSync(WORK, { recursive: true, force: true });
}

try {
  await main();
} catch (error) {
  failures++;
  console.error(`\nFAIL ${error instanceof Error ? error.stack : error}`);
} finally {
  await cleanup();
}

console.log(`\nfinished in ${elapsed()}`);
if (failures > 0) {
  console.error(`${failures} check(s) failed`);
  process.exit(1);
}
console.log('all checks passed');
