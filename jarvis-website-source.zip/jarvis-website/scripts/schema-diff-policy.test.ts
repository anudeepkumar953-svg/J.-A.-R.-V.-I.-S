// Contract for scripts/schema-diff-policy.ts: what `ensure-schema.ts` may
// apply to a live database before a build. The samples are the statements
// drizzle-kit writes for a Payload schema. Self-contained tsx script (the
// template ships no unit-test runner); exits non-zero on the first failed
// check.
import assert from 'node:assert/strict';
import { isAdditive, notAdditive, onlyDefaults } from './schema-diff-policy';

const T = '"payload_iter1"."pages"';

const additive = [
  'CREATE SCHEMA "payload_iter1";\n',
  `CREATE TABLE "payload_iter1"."page_proposals" (\n\t"id" serial PRIMARY KEY NOT NULL,\n\t"title" varchar NOT NULL,\n\t"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL\n);\n`,
  'CREATE UNIQUE INDEX "page_proposals_slug_idx" ON "payload_iter1"."page_proposals" USING btree ("slug");',
  'CREATE INDEX "pages_parent_idx" ON "payload_iter1"."pages" USING btree ("parent_id");',
  'CREATE SEQUENCE "payload_iter1"."pages_seq" INCREMENT BY 1;',
  `CREATE TYPE "payload_iter1"."enum_posts_status" AS ENUM('draft', 'published');`,
  `ALTER TYPE "payload_iter1"."enum_posts_status" ADD VALUE 'archived';`,
  `ALTER TABLE ${T} ADD COLUMN "parent_id" integer;`,
  `ALTER TABLE ${T} ADD COLUMN "proposed" boolean DEFAULT false;`,
  `ALTER TABLE ${T} ADD COLUMN "rank" numeric DEFAULT 0 NOT NULL;`,
  `ALTER TABLE ${T} ADD CONSTRAINT "pages_parent_id_pages_id_fk" FOREIGN KEY ("parent_id") REFERENCES ${T}("id") ON DELETE set null ON UPDATE no action;`,
  `DO $$ BEGIN\n ALTER TABLE ${T} ADD CONSTRAINT "pages_parent_id_pages_id_fk" FOREIGN KEY ("parent_id") REFERENCES ${T}("id") ON DELETE set null ON UPDATE no action;\nEXCEPTION\n WHEN duplicate_object THEN null;\nEND $$;\n`,
  'ALTER TABLE "payload_iter1"."users" ALTER COLUMN "login_attempts" SET DEFAULT 0;',
  // A `;` inside a quoted default is not a second statement.
  `ALTER TABLE ${T} ADD COLUMN "note" varchar DEFAULT 'a; b';`,
];
// One diff, as drizzle returns it: the unique index and the foreign keys sit
// on the table and the column it creates.
for (const statement of additive) {
  assert.equal(
    isAdditive(statement, additive),
    true,
    `should be additive: ${statement}`,
  );
}
assert.deepEqual(notAdditive(additive), []);

// A unique index or a constraint can fail on rows already there, so it is
// safe only on a table or an empty column the same diff creates.
const P = '"payload_iter1"."posts"';
const onExisting = [
  `CREATE UNIQUE INDEX "pages_title_idx" ON ${T} USING btree ("title");`,
  `ALTER TABLE ${T} ADD CONSTRAINT "pages_title_unique" UNIQUE("title");`,
  `ALTER TABLE ${T} ADD CONSTRAINT "pages_pkey" PRIMARY KEY("id");`,
  `ALTER TABLE ${T} ADD CONSTRAINT "pages_parent_id_pages_id_fk" FOREIGN KEY ("parent_id") REFERENCES ${T}("id");`,
  `ALTER TABLE ${T} ADD CONSTRAINT "pages_title_check" CHECK (length("title") > 0);`,
];
for (const statement of onExisting) {
  assert.equal(
    isAdditive(statement),
    false,
    `existing rows may break it: ${statement}`,
  );
}
// A column added with a default is not empty: every row holds that value.
assert.deepEqual(
  notAdditive([
    `ALTER TABLE ${P} ADD COLUMN "code" varchar DEFAULT 'x';`,
    `CREATE UNIQUE INDEX "posts_code_idx" ON ${P} USING btree ("code");`,
  ]),
  [`CREATE UNIQUE INDEX "posts_code_idx" ON ${P} USING btree ("code");`],
);
// An empty new column takes a unique index or a foreign key; a check needs a
// new table.
assert.deepEqual(
  notAdditive([
    `ALTER TABLE ${P} ADD COLUMN "code" varchar;`,
    `CREATE UNIQUE INDEX "posts_code_idx" ON ${P} USING btree ("code");`,
    `ALTER TABLE ${P} ADD CONSTRAINT "posts_code_fk" FOREIGN KEY ("code") REFERENCES ${T}("slug");`,
    `ALTER TABLE ${P} ADD CONSTRAINT "posts_code_check" CHECK ("code" <> '');`,
  ]),
  [`ALTER TABLE ${P} ADD CONSTRAINT "posts_code_check" CHECK ("code" <> '');`],
);
// A plain index never fails on data.
assert.equal(
  isAdditive(`CREATE INDEX "pages_title_idx" ON ${T} USING btree ("title");`),
  true,
);

const destructive = [
  `ALTER TABLE ${T} DROP COLUMN "excerpt";`,
  `DROP TABLE ${T} CASCADE;`,
  'DROP INDEX "pages_parent_idx";',
  `ALTER TABLE ${T} DROP CONSTRAINT "pages_parent_id_pages_id_fk";`,
  `ALTER TABLE ${T} RENAME COLUMN "excerpt" TO "summary";`,
  `ALTER TABLE ${T} RENAME TO "documents";`,
  `ALTER TABLE ${T} ALTER COLUMN "title" SET DATA TYPE text;`,
  `ALTER TABLE ${T} ALTER COLUMN "title" SET NOT NULL;`,
  `ALTER TABLE ${T} ALTER COLUMN "title" DROP NOT NULL;`,
  `ALTER TABLE ${T} ALTER COLUMN "title" DROP DEFAULT;`,
  `DROP TYPE "payload_iter1"."enum_posts_status";`,
  `truncate table ${T} cascade;`,
  // The deployed code would insert rows without it.
  `ALTER TABLE ${T} ADD COLUMN "subtitle" varchar NOT NULL;`,
  // A column named `default` is not a default.
  `ALTER TABLE ${T} ADD COLUMN "default" varchar NOT NULL;`,
  // A safe-looking first statement does not carry a second one.
  `ALTER TABLE ${T} ADD COLUMN "x" integer;\nALTER TABLE ${T} DROP COLUMN "excerpt";`,
  `ALTER TABLE ${T} DROP CONSTRAINT "pages_pkey";\n--> statement-breakpoint\nALTER TABLE ${T} ADD CONSTRAINT "pages_pkey" PRIMARY KEY("id");`,
  `ALTER TABLE ${T} ADD COLUMN "x" varchar DEFAULT 'a;';\nDROP TABLE ${T};`,
  `DO $$ BEGIN\n ALTER TABLE ${T} DROP COLUMN "excerpt";\nEXCEPTION\n WHEN duplicate_object THEN null;\nEND $$;`,
  `DO $$ BEGIN\n ALTER TABLE ${T} ADD CONSTRAINT "x" UNIQUE("slug");\n DROP TABLE ${T};\nEXCEPTION\n WHEN duplicate_object THEN null;\nEND $$;`,
];
for (const statement of destructive) {
  assert.equal(
    isAdditive(statement),
    false,
    `should not be additive: ${statement}`,
  );
}

assert.deepEqual(
  notAdditive([additive[7], destructive[0], additive[8], destructive[1]]),
  [destructive[0], destructive[1]],
);
assert.deepEqual(notAdditive([]), []);

assert.equal(
  onlyDefaults([
    'ALTER TABLE "payload_iter1"."users" ALTER COLUMN "login_attempts" SET DEFAULT 0;',
  ]),
  true,
);
assert.equal(onlyDefaults([additive[12], additive[7]]), false);

console.log('schema-diff-policy contract OK');
