/* eslint-disable no-console */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import type { Field, SanitizedConfig } from 'payload';
import config from '../src/payload.config';
import {
  convertRichTextStrings,
  markdownEditorConfig,
} from './markdown-lexical';

// One content-collection item, written as a seed.json `collections.<slug>[]`
// entry holds it, made ready for Payload's REST create: richText strings are
// converted to Lexical with the site's own editor, exactly as the seed
// converts them, so an image line becomes the image block the site registers.
//
// It also names the item's top-level keys the collection does not define.
// Payload's REST create drops an unknown field without a word, so the platform
// refuses such an item rather than report a field as written.
//
// The platform ships this into a site's sandbox and runs it there, outside the
// site's checkout, so of the site's code it imports only `src/payload.config.ts`.
// It awaits the sanitized config and never opens Payload, so it needs no
// environment and no database.
//
// Input: env ITEM_FILE, `{"collection": "<slug>", "item": {...}}`.
// Output: env OUT_FILE, `{"item": {...}, "unknown": ["<key>", ...], "fields":
// ["<name>", ...], "shapes": [...]}`; the item is converted only when nothing
// is unknown, `fields` names what the collection does define, for the refusal
// to offer, and `shapes` describes each field's value for the read-only listing;
// `missing` says the site's code defines no such collection at all. Its last line, `wrote <OUT_FILE>`,
// is the platform's only proof it ran (`payload_scripts`).

export type PreparedItem = {
  item: Record<string, unknown>;
  unknown: string[];
  fields: string[];
  shapes: FieldShape[];
  missing?: true;
};

// What an item's value for one field looks like, for an agent writing a
// complete item before it sends one.
export type FieldShape = {
  name: string;
  type: string;
  required?: true;
  hasMany?: true;
  options?: string[];
  relationTo?: string | string[];
  blocks?: { slug: string; fields: FieldShape[] }[];
  fields?: FieldShape[];
};

export function fieldShapes(fields: Field[]): FieldShape[] {
  const shapes: FieldShape[] = [];
  for (const field of fields) {
    if (field.type === 'ui') continue;
    if (field.type === 'tabs') {
      for (const tab of field.tabs) {
        if ('name' in tab && tab.name) {
          shapes.push({
            name: tab.name,
            type: 'group',
            fields: fieldShapes(tab.fields),
          });
        } else shapes.push(...fieldShapes(tab.fields));
      }
      continue;
    }
    if (!('name' in field) || !field.name) {
      if ('fields' in field) shapes.push(...fieldShapes(field.fields));
      continue;
    }
    const shape: FieldShape = { name: field.name, type: field.type };
    if ('required' in field && field.required) shape.required = true;
    if ('hasMany' in field && field.hasMany) shape.hasMany = true;
    if ('options' in field && Array.isArray(field.options)) {
      shape.options = field.options.map((option) =>
        typeof option === 'string' ? option : option.value,
      );
    }
    if ('relationTo' in field) shape.relationTo = field.relationTo;
    if (field.type === 'blocks') {
      shape.blocks = field.blocks.map((block) => ({
        slug: block.slug,
        fields: fieldShapes(block.fields),
      }));
    } else if ('fields' in field) {
      shape.fields = fieldShapes(field.fields);
    }
    shapes.push(shape);
  }
  return shapes;
}

// The names a document of these fields holds at its top level. Presentational
// wrappers share the parent's namespace, as in `convertRichTextStrings`.
export function dataFieldNames(fields: Field[]): Set<string> {
  const names = new Set<string>();
  for (const field of fields) {
    if (field.type === 'ui') continue;
    if (field.type === 'tabs') {
      for (const tab of field.tabs) {
        if ('name' in tab && tab.name) names.add(tab.name);
        else for (const name of dataFieldNames(tab.fields)) names.add(name);
      }
      continue;
    }
    if ('name' in field && field.name) {
      names.add(field.name);
    } else if ('fields' in field) {
      for (const name of dataFieldNames(field.fields)) names.add(name);
    }
  }
  return names;
}

export async function prepareItem(
  sanitized: SanitizedConfig,
  collection: string,
  item: Record<string, unknown>,
): Promise<PreparedItem> {
  const fields = sanitized.collections.find(
    (c) => c.slug === collection,
  )?.fields;
  if (!fields)
    return { item, unknown: [], fields: [], shapes: [], missing: true };
  const known = dataFieldNames(fields);
  const unknown = Object.keys(item)
    .filter((key) => !known.has(key))
    .sort();
  if (unknown.length === 0) {
    convertRichTextStrings(fields, item, await markdownEditorConfig(sanitized));
  }
  return {
    item,
    unknown,
    fields: [...known].sort(),
    shapes: fieldShapes(fields),
  };
}

function envPath(name: string): string {
  const file = process.env[name];
  if (!file) throw new Error(`${name} is required`);
  return path.isAbsolute(file) ? file : path.resolve(file);
}

async function main(): Promise<void> {
  const { collection, item } = JSON.parse(
    fs.readFileSync(envPath('ITEM_FILE'), 'utf-8'),
  ) as { collection: string; item: Record<string, unknown> };
  const prepared = await prepareItem(await config, collection, item);
  const out = envPath('OUT_FILE');
  fs.writeFileSync(out, JSON.stringify(prepared));
  console.log(`wrote ${out}`);
}

// Run only when executed, so the test can import `prepareItem`.
if (
  process.argv[1] &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)
) {
  await main();
}
