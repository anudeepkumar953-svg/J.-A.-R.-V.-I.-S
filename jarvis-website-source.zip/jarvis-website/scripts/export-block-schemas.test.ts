// Contract for the block schemas the platform plans a page against
// (scripts/export-block-schemas.ts).
//
// Three things here fail silently and each one produces a plausible-looking
// page nobody can build:
//   - the serializer drifting from the admin panel's
//     (`src/admin/blockFill.tsx`), so a page generated server-side is planned
//     against different field definitions than the same page generated in the
//     browser — the script carries a copy precisely because it is shipped into
//     sites that have no `blockFill.tsx`, so nothing but this check holds the
//     two together;
//   - a site's OWN generated block missing from the export, which silently
//     restricts every generated page to the baked library — the bespoke
//     section the design exists for can never be planned;
//   - the collection list disagreeing with the site's config, which either
//     offers collection-backed blocks a site cannot render or withholds ones
//     it can.
//
// The template ships no unit-test runner, so this is a self-contained tsx
// script (run in CI by nextjs-template-code-quality.yml). Exits non-zero on
// any failure.
//
// Run locally: pnpm exec tsx scripts/export-block-schemas.test.ts

import type { Block, Field } from 'payload';
import { serializeFields as panelSerializeFields } from '../src/admin/blockFill';
import config from '../src/payload.config';
import { layoutBlocks } from '../src/payload/blocks';
import { buildSchemaDocument, serializeFields } from './export-block-schemas';

let failures = 0;

function check(name: string, ok: boolean, detail = ''): void {
  if (ok) {
    console.log(`  ok  ${name}`);
    return;
  }
  failures += 1;
  console.error(`  FAIL  ${name}${detail ? `: ${detail}` : ''}`);
}

// --- The shipped serializer and the panel's are one definition --------------
{
  console.log('the script serializes fields exactly as the admin panel does');
  for (const block of layoutBlocks as Block[]) {
    const mine = JSON.stringify(serializeFields(block.fields));
    const panel = JSON.stringify(panelSerializeFields(block.fields));
    check(`${block.slug} serializes identically`, mine === panel, panel);
  }

  // The library happens to use a subset of Payload's field kinds, so the
  // shapes that separate the two implementations are exercised explicitly:
  // an untagged image field, a tagged one, a required field, options, nested
  // groups and arrays, and the two kinds the panel drops.
  const awkward: Field[] = [
    { name: 'heading', type: 'text', required: true },
    { name: 'backdropUrl', type: 'text' },
    {
      name: 'portrait',
      type: 'text',
      admin: { custom: { isImage: true } },
    },
    {
      name: 'background',
      type: 'select',
      options: ['light', 'muted', 'dark'],
    },
    {
      name: 'panel',
      type: 'group',
      fields: [
        { name: 'caption', type: 'text' },
        {
          name: 'steps',
          type: 'array',
          fields: [{ name: 'iconUrl', type: 'text', required: true }],
        },
      ],
    },
    { name: 'notice', type: 'ui' },
    { type: 'row', fields: [{ name: 'inRow', type: 'text' }] },
  ] as Field[];
  check(
    'the shapes the library does not use agree too',
    JSON.stringify(serializeFields(awkward)) ===
      JSON.stringify(panelSerializeFields(awkward)),
    JSON.stringify(serializeFields(awkward)),
  );

  const serialized = serializeFields(awkward);
  check(
    'an image field is tagged by its custom flag',
    serialized.find((f) => f.name === 'portrait')?.isImage === true,
  );
  check(
    'and by a Url-suffixed name',
    serialized.find((f) => f.name === 'backdropUrl')?.isImage === true,
  );
  check(
    'a nested array keeps its own fields',
    serialized.find((f) => f.name === 'panel')?.fields?.[1]?.fields?.[0]
      ?.name === 'iconUrl',
  );
}

// --- A site's own block is plannable ----------------------------------------
{
  console.log("\nthe export carries the site's own generated blocks");
  const storyScroller: Block = {
    slug: 'storyScroller',
    fields: [
      { name: 'heading', type: 'text', required: true },
      {
        name: 'steps',
        type: 'array',
        fields: [
          { name: 'caption', type: 'text' },
          { name: 'imageUrl', type: 'text' },
        ],
      },
    ],
  };
  const doc = buildSchemaDocument(
    [...(layoutBlocks as Block[]), storyScroller],
    ['posts'],
  );
  const exported = doc.blocks.find((b) => b.block_type === 'storyScroller');
  check('a site-specific block reaches the export', exported !== undefined);
  check(
    'with its fields, nested rows included',
    exported?.fields[1]?.fields?.[1]?.name === 'imageUrl',
    JSON.stringify(exported?.fields),
  );
  check(
    'the library blocks travel with it',
    doc.blocks.length === (layoutBlocks as Block[]).length + 1,
  );
  check(
    'the field keys are the ones the platform reads',
    Object.keys(doc).join(',') === 'blocks,collections' &&
      Object.keys(doc.blocks[0]).join(',') === 'block_type,fields',
    Object.keys(doc.blocks[0]).join(','),
  );
  check('the collections travel verbatim', doc.collections[0] === 'posts');
}

// --- The collections are the site's own -------------------------------------
{
  console.log('\nthe exported collections are the site’s content types');
  // The site's real content types, read from the running config: everything
  // the admin shows (`admin.hidden` covers `users` and Payload's own
  // bookkeeping collections, which grow with each Payload release — 3.85 added
  // `payload-kv`) except `pages`, which is where a generated page GOES rather
  // than a collection a block can list. The script reads `generatedCollections`
  // instead, because it runs without booting Payload; the two must name the
  // same set, or a page gets planned against collection-backed blocks this
  // site cannot render.
  const sanitized = await config;
  const fromConfig = (sanitized.collections ?? [])
    .filter(
      (collection) =>
        collection.admin?.hidden !== true && collection.slug !== 'pages',
    )
    .map((collection) => collection.slug)
    .sort();
  const { generatedCollections } = await import(
    '../src/payload/collections/generated'
  );
  const fromScript = generatedCollections
    .map((collection: { slug: string }) => collection.slug)
    .sort();
  check(
    'the script names the same content collections as the running config',
    JSON.stringify(fromScript) === JSON.stringify(fromConfig),
    `${JSON.stringify(fromScript)} vs ${JSON.stringify(fromConfig)}`,
  );
}

if (failures > 0) {
  console.error(`\n${failures} failure(s)`);
  process.exit(1);
}
console.log('\nall checks passed');
