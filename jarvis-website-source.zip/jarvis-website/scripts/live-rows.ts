// Keeps list rows added on the live site while a draft was open.
//
// A draft merge writes the draft's copy of the `site-settings` global over the
// live one, and Payload takes a list whole. A row the owner added in /admin
// after the draft opened (a new social link, a footer link) is not in the
// draft's copy, so the merge would drop it. Such a row is kept: its id is an
// ObjectId whose leading seconds say when Payload created it, and a row created
// after the draft's branch point cannot be one the draft removed. A row that
// existed when the draft opened and is missing from it was removed in the
// draft, and stays removed.

type Doc = Record<string, unknown>;

const OBJECT_ID = /^[0-9a-f]{24}$/i;

function isPlainObject(value: unknown): value is Doc {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

/** When Payload created the row, from its ObjectId; null for any other id. */
export function rowCreatedAt(id: unknown): Date | null {
  if (typeof id !== 'string' || !OBJECT_ID.test(id)) return null;
  return new Date(parseInt(id.slice(0, 8), 16) * 1000);
}

/** The draft's fields with live rows created after `since` appended to each list. */
export function keepLiveRowsAddedSince(
  patch: Doc,
  current: Doc,
  since: Date,
): Doc {
  const merged: Doc = { ...patch };
  for (const [key, value] of Object.entries(patch)) {
    const live = current[key];
    if (Array.isArray(value) && Array.isArray(live)) {
      const ids = new Set(
        value.map((row) => (isPlainObject(row) ? row.id : undefined)),
      );
      const added = live.filter((row) => {
        if (!isPlainObject(row) || ids.has(row.id)) return false;
        const created = rowCreatedAt(row.id);
        return created !== null && created > since;
      });
      if (added.length) merged[key] = [...value, ...added];
    } else if (isPlainObject(value) && isPlainObject(live)) {
      merged[key] = keepLiveRowsAddedSince(value, live, since);
    }
  }
  return merged;
}
